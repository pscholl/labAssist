

android.app.AlarmManager
android.app.IntentService
android.app.PendingIntent
android.content.Context
android.content.Intent
android.os.PowerManager
android.os.PowerManager.WakeLock
android.os.SystemClock
android.util.Log
java.util.Random
java.util.concurrent.TimeUnit

GCMBaseIntentService
  

  EXTRA_TOKEN = "token"
  LOCK = 
  MAX_BACKOFF_MS = SECONDStoMillis3600L
  TAG = "GCMBaseIntentService"
  TOKEN = toBinaryStringsRandomnextLong()
  WAKELOCK_KEY = "GCM_LIB"
  sCounter = 0
  sRandom = ()
  sWakeLock
  []mSenderIds
  
  GCMBaseIntentService
  
    getName"DynamicSenderIds", 
  
  
  GCMBaseIntentService, []
  
    
    mSenderIds = paramArrayOfString;
  }
  
  protected GCMBaseIntentService(String... paramVarArgs)
  {
    this(getName(paramVarArgs), paramVarArgs);
  }
  
  private static String getName(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("GCMIntentService-").append(paramString).append("-");
    int i = 1 + sCounter;
    sCounter = i;
    String str = i;
    Log.v("GCMBaseIntentService", "Intent service name: " + str);
    return str;
  }
  
  private static String getName(String[] paramArrayOfString)
  {
    return getName(GCMRegistrar.getFlatSenderIds(paramArrayOfString));
  }
  
  private void handleRegistration(Context paramContext, Intent paramIntent)
  {
    String str1 = paramIntent.getStringExtra("registration_id");
    String str2 = paramIntent.getStringExtra("error");
    String str3 = paramIntent.getStringExtra("unregistered");
    Log.d("GCMBaseIntentService", "handleRegistration: registrationId = " + str1 + ", error = " + str2 + ", unregistered = " + str3);
    if (str1 != null)
    {
      GCMRegistrar.resetBackoff(paramContext);
      GCMRegistrar.setRegistrationId(paramContext, str1);
      onRegistered(paramContext, str1);
    }
    int i;
    do
    {
      return;
      if (str3 != null)
      {
        GCMRegistrar.resetBackoff(paramContext);
        onUnregistered(paramContext, GCMRegistrar.clearRegistrationId(paramContext));
        return;
      }
      Log.d("GCMBaseIntentService", "Registration error: " + str2);
      if (!"SERVICE_NOT_AVAILABLE".equals(str2)) {
        break label296;
      }
      if (!onRecoverableError(paramContext, str2)) {
        break;
      }
      i = GCMRegistrar.getBackoff(paramContext);
      int j = i / 2 + sRandom.nextInt(i);
      Log.d("GCMBaseIntentService", "Scheduling registration retry, backoff = " + j + " (" + i + ")");
      Intent localIntent = new Intent("com.google.android.gcm.intent.RETRY");
      localIntent.putExtra("token", TOKEN);
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent, 0);
      ((AlarmManager)paramContext.getSystemService("alarm")).set(3, SystemClock.elapsedRealtime() + j, localPendingIntent);
    } while (i >= MAX_BACKOFF_MS);
    GCMRegistrar.setBackoff(paramContext, i * 2);
    return;
    Log.d("GCMBaseIntentService", "Not retrying failed operation");
    return;
    label296:
    onError(paramContext, str2);
  }
  
  static void runIntentInService(Context paramContext, Intent paramIntent, String paramString)
  {
    synchronized (LOCK)
    {
      if (sWakeLock == null) {
        sWakeLock = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, "GCM_LIB");
      }
      Log.v("GCMBaseIntentService", "Acquiring wakelock");
      sWakeLock.acquire();
      paramIntent.setClassName(paramContext, paramString);
      paramContext.startService(paramIntent);
      return;
    }
  }
  
  protected String[] getSenderIds(Context paramContext)
  {
    if (this.mSenderIds == null) {
      throw new IllegalStateException("sender id not set on constructor");
    }
    return this.mSenderIds;
  }
  
  protected void onDeletedMessages(Context paramContext, int paramInt) {}
  
  protected abstract void onError(Context paramContext, String paramString);
  
  public final void onHandleIntent(Intent paramIntent)
  {
    try
    {
      localContext = getApplicationContext();
      str1 = paramIntent.getAction();
      if (str1.equals("com.google.android.c2dm.intent.REGISTRATION"))
      {
        GCMRegistrar.setRetryBroadcastReceiver(localContext);
        handleRegistration(localContext, paramIntent);
      }
    }
    finally
    {
      for (;;)
      {
        Context localContext;
        String str1;
        String str3;
        synchronized (LOCK)
        {
          if (sWakeLock != null)
          {
            Log.v("GCMBaseIntentService", "Releasing wakelock");
            sWakeLock.release();
            return;
            if (str1.equals("com.google.android.c2dm.intent.RECEIVE"))
            {
              str3 = paramIntent.getStringExtra("message_type");
              if (str3 != null) {
                if (str3.equals("deleted_messages"))
                {
                  String str4 = paramIntent.getStringExtra("total_deleted");
                  if (str4 == null) {
                    continue;
                  }
                  try
                  {
                    int i = Integer.parseInt(str4);
                    Log.v("GCMBaseIntentService", "Received deleted messages notification: " + i);
                    onDeletedMessages(localContext, i);
                  }
                  catch (NumberFormatException localNumberFormatException)
                  {
                    Log.e("GCMBaseIntentService", "GCM returned invalid number of deleted messages: " + str4);
                  }
                  continue;
                  localObject1 = finally;
                }
              }
            }
          }
        }
        synchronized (LOCK)
        {
          if (sWakeLock != null)
          {
            Log.v("GCMBaseIntentService", "Releasing wakelock");
            sWakeLock.release();
            throw localObject1;
            Log.e("GCMBaseIntentService", "Received unknown special message: " + str3);
            continue;
            onMessage(localContext, paramIntent);
            continue;
            if (!str1.equals("com.google.android.gcm.intent.RETRY")) {
              continue;
            }
            String str2 = paramIntent.getStringExtra("token");
            if (!TOKEN.equals(str2))
            {
              Log.e("GCMBaseIntentService", "Received invalid token: " + str2);
              for (;;)
              {
                synchronized (LOCK)
                {
                  if (sWakeLock != null)
                  {
                    Log.v("GCMBaseIntentService", "Releasing wakelock");
                    sWakeLock.release();
                    return;
                  }
                }
                Log.e("GCMBaseIntentService", "Wakelock reference is null");
              }
            }
            if (GCMRegistrar.isRegistered(localContext))
            {
              GCMRegistrar.internalUnregister(localContext);
              continue;
            }
            GCMRegistrar.internalRegister(localContext, getSenderIds(localContext));
            continue;
            Log.e("GCMBaseIntentService", "Wakelock reference is null");
            continue;
            localObject5 = finally;
            throw localObject5;
          }
          Log.e("GCMBaseIntentService", "Wakelock reference is null");
        }
      }
    }
  }
  
  protected abstract void onMessage(Context paramContext, Intent paramIntent);
  
  protected boolean onRecoverableError(Context paramContext, String paramString)
  {
    return true;
  }
  
  protected abstract void onRegistered(Context paramContext, String paramString);
  
  protected abstract void onUnregistered(Context paramContext, String paramString);
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gcm.GCMBaseIntentService
 * JD-Core Version:    0.7.0.1
 */