

BuildData

  BOARD = 10
  BRAND = 11
  BUILD_ID = 2
  BUILD_TYPE = 3
  CODENAME = 9
  DEVICE = 1
  INCREMENTAL = 8
  MODEL = 4
  PRODUCT = 5
  RELEASE = 7
  SDK_INT = 6



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.BuildData
 * JD-Core Version:    0.7.0.1
 */