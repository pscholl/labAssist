

CommonData

  DESCRIPTION = 2
  DESCRIPTION_TRANSLATED = 4
  GAIA_ID = 1
  GAIA_USER_TYPE = 14
  OBFUSCATED_GAIA_ID = 12
  OBFUSCATED_GAIA_ID_STRING = 16
  OBFUSCATED_GAIA_TYPE = 13
  PRODUCT_SPECIFIC_BINARY_DATA = 9
  PRODUCT_SPECIFIC_BINARY_DATA_NAME = 8
  PRODUCT_SPECIFIC_CONTEXT = 15
  PRODUCT_SPECIFIC_DATA = 11
  PRODUCT_VERSION = 10
  RATING = 18
  SOURCE_DESCRIPTION_LANGUAGE = 5
  SPELLING_ERROR_COUNT = 17
  UI_LANGUAGE = 6
  UNIQUE_REPORT_IDENTIFIER = 7
  USER_EMAIL = 3



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.CommonData
 * JD-Core Version:    0.7.0.1
 */