

MobileBugReport

  COMMON_DATA = 1
  MOBILE_DATA = 2
  OS_TYPE = 4
  OS_TYPE_ANDROID = 0
  OS_TYPE_IOS = 1
  REPORT_TYPE = 3



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.MobileBugReport
 * JD-Core Version:    0.7.0.1
 */