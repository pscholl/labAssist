

TelephonyData

  NETWORK_NAME = 2
  NETWORK_TYPE = 3
  PHONE_TYPE = 1



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.TelephonyData
 * JD-Core Version:    0.7.0.1
 */