

AnrData

  ACTIVITY = 1
  CAUSE = 2
  EXTRA = 3
  STACK_TRACES = 4



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.AnrData
 * JD-Core Version:    0.7.0.1
 */