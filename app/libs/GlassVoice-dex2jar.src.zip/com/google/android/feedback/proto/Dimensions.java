

Dimensions

  HEIGHT = 2
  WIDTH = 1



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.Dimensions
 * JD-Core Version:    0.7.0.1
 */