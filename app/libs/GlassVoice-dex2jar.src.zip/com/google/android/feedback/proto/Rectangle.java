

Rectangle

  HEIGHT = 4
  LEFT = 1
  TOP = 2
  WIDTH = 3



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.Rectangle
 * JD-Core Version:    0.7.0.1
 */