

MobileData

  ANR_DATA = 5
  BATTERY_DATA = 6
  BUILD_DATA = 3
  CRASH_DATA = 4
  PACKAGE_DATA = 2
  REPORT_TYPE = 10
  RUNNING_SERVICE_DATA = 7
  SYSTEM_DATA = 1
  USER_INITIATED_FEEDBACK_DATA = 9



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.MobileData
 * JD-Core Version:    0.7.0.1
 */