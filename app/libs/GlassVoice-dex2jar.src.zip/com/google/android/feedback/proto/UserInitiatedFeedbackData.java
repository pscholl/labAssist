

UserInitiatedFeedbackData

  ACCOUNTS = 1
  BUCKET = 7
  CATEGORY_TAG = 6
  DEVICE_ID = 3
  PRODUCT_ID = 5
  PRODUCT_SPECIFIC_BINARY_DATA = 2
  SCREENSHOT = 4



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.UserInitiatedFeedbackData
 * JD-Core Version:    0.7.0.1
 */