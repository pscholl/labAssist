

RunningServiceData

  DURATION_MILLIS = 1
  SERVICE_DETAILS = 2



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.RunningServiceData
 * JD-Core Version:    0.7.0.1
 */