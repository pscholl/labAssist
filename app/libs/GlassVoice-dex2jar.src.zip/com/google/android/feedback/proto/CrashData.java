

CrashData

  EXCEPTION_CLASS_NAME = 1
  EXCEPTION_MESSAGE = 2
  SIGNAL = 8
  STACK_TRACE = 7
  THROW_CLASS_NAME = 5
  THROW_FILE_NAME = 3
  THROW_LINE_NUMBER = 4
  THROW_METHOD_NAME = 6



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.CrashData
 * JD-Core Version:    0.7.0.1
 */