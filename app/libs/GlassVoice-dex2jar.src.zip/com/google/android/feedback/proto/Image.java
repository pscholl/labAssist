

Image

  CONTENT = 2
  IMAGE_DIMENSION = 3
  MIME_TYPE = 1



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.Image
 * JD-Core Version:    0.7.0.1
 */