

BatteryData

  BATTERY_LEVEL = 5
  BATTERY_STATE = 6
  BATTERY_STATE_CHARGING = 2
  BATTERY_STATE_FULL = 3
  BATTERY_STATE_UNKNOWN = 0
  BATTERY_STATE_UNPLUGGED = 1
  CHECKIN_DETAILS = 4
  DURATION_MICROS = 2
  USAGE_DETAILS = 3
  USAGE_PERCENT = 1



/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.BatteryData
 * JD-Core Version:    0.7.0.1
 */