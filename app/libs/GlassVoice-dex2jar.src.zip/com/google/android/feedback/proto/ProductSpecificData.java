

ProductSpecificData

  KEY = 1
  VALUE = 2



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.ProductSpecificData
 * JD-Core Version:    0.7.0.1
 */