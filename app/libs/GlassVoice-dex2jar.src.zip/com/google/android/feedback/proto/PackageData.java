

PackageData

  INSTALLER_PACKAGE_NAME = 2
  PACKAGE_NAME = 1
  PACKAGE_VERSION = 4
  PACKAGE_VERSION_NAME = 5
  PROCESS_NAME = 3
  SYSTEM_APP = 6



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.PackageData
 * JD-Core Version:    0.7.0.1
 */