

SystemData

  EVENT_LOG = 3
  INSTALLED_PACKAGES = 4
  RUNNING_APPLICATIONS = 5
  SYSTEM_LOG = 2
  TELEPHONY_DATA = 6
  TIMESTAMP = 1



/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.SystemData
 * JD-Core Version:    0.7.0.1
 */