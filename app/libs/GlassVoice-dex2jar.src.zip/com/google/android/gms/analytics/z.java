package com.google.android.gms.analytics;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class z
{
  private final Map<String, Integer> nl = new HashMap();
  private final Map<String, String> nm = new HashMap();
  private final boolean nn;
  private final String no;
  
  z(String paramString, boolean paramBoolean)
  {
    this.nn = paramBoolean;
    this.no = paramString;
  }
  
  String aK()
  {
    if (!this.nn) {
      return "";
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.no);
    Iterator localIterator1 = this.nl.keySet().iterator();
    while (localIterator1.hasNext())
    {
      String str2 = (String)localIterator1.next();
      localStringBuilder.append("&").append(str2).append("=").append(this.nl.get(str2));
    }
    Iterator localIterator2 = this.nm.keySet().iterator();
    while (localIterator2.hasNext())
    {
      String str1 = (String)localIterator2.next();
      localStringBuilder.append("&").append(str1).append("=").append((String)this.nm.get(str1));
    }
    return localStringBuilder.toString();
  }
  
  void c(String paramString, int paramInt)
  {
    if (!this.nn) {
      return;
    }
    Integer localInteger = (Integer)this.nl.get(paramString);
    if (localInteger == null) {
      localInteger = Integer.valueOf(0);
    }
    this.nl.put(paramString, Integer.valueOf(paramInt + localInteger.intValue()));
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.z
 * JD-Core Version:    0.7.0.1
 */