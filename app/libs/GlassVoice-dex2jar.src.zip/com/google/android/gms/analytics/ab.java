package com.google.android.gms.analytics;

abstract interface ab
{
  public abstract boolean aI();
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ab
 * JD-Core Version:    0.7.0.1
 */