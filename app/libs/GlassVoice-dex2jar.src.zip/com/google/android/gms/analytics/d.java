package com.google.android.gms.analytics;

import com.google.android.gms.internal.z;
import java.util.Collection;
import java.util.Map;

abstract interface d
{
  public abstract n P();
  
  public abstract void a(long paramLong);
  
  public abstract void a(Map<String, String> paramMap, long paramLong, String paramString, Collection<z> paramCollection);
  
  public abstract void dispatch();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.d
 * JD-Core Version:    0.7.0.1
 */