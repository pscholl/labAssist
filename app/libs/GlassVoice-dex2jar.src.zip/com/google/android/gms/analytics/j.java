package com.google.android.gms.analytics;

abstract interface j {}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.j
 * JD-Core Version:    0.7.0.1
 */