package com.google.android.gms.analytics;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

abstract interface f
{
  public abstract void clearHits();
  
  public abstract void dispatch();
  
  public abstract LinkedBlockingQueue<Runnable> getQueue();
  
  public abstract Thread getThread();
  
  public abstract void sendHit(Map<String, String> paramMap);
  
  public abstract void setForceLocalDispatch();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.f
 * JD-Core Version:    0.7.0.1
 */