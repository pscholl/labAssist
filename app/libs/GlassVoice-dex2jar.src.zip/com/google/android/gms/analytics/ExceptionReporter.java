package com.google.android.gms.analytics;

import android.content.Context;
import java.util.ArrayList;

public class ExceptionReporter
  implements Thread.UncaughtExceptionHandler
{
  private final Thread.UncaughtExceptionHandler kt;
  private final Tracker ku;
  private ExceptionParser kv;
  private final Context mContext;
  
  public ExceptionReporter(Tracker paramTracker, Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler, Context paramContext)
  {
    if (paramTracker == null) {
      throw new NullPointerException("tracker cannot be null");
    }
    if (paramContext == null) {
      throw new NullPointerException("context cannot be null");
    }
    this.kt = paramUncaughtExceptionHandler;
    this.ku = paramTracker;
    this.kv = new StandardExceptionParser(paramContext, new ArrayList());
    this.mContext = paramContext.getApplicationContext();
    StringBuilder localStringBuilder = new StringBuilder().append("ExceptionReporter created, original handler is ");
    if (paramUncaughtExceptionHandler == null) {}
    for (String str = "null";; str = paramUncaughtExceptionHandler.getClass().getName())
    {
      y.v(str);
      return;
    }
  }
  
  public ExceptionParser getExceptionParser()
  {
    return this.kv;
  }
  
  public void setExceptionParser(ExceptionParser paramExceptionParser)
  {
    this.kv = paramExceptionParser;
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    String str1 = "UncaughtException";
    if (this.kv != null) {
      if (paramThread == null) {
        break label114;
      }
    }
    label114:
    for (String str2 = paramThread.getName();; str2 = null)
    {
      str1 = this.kv.getDescription(str2, paramThrowable);
      y.v("Tracking Exception: " + str1);
      this.ku.send(new HitBuilders.ExceptionBuilder().setDescription(str1).setFatal(true).build());
      GoogleAnalytics.getInstance(this.mContext).dispatchLocalHits();
      if (this.kt != null)
      {
        y.v("Passing exception to original handler.");
        this.kt.uncaughtException(paramThread, paramThrowable);
      }
      return;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ExceptionReporter
 * JD-Core Version:    0.7.0.1
 */