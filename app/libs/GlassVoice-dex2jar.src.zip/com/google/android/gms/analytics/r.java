package com.google.android.gms.analytics;

import android.content.Context;
import com.google.android.gms.internal.z;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;

class r
  implements ae, c.b, c.c
{
  private final f kA;
  private boolean kC;
  private volatile long kM;
  private volatile a kN;
  private volatile b kO;
  private d kP;
  private final GoogleAnalytics kQ;
  private final Queue<d> kR = new ConcurrentLinkedQueue();
  private volatile int kS;
  private volatile Timer kT;
  private volatile Timer kU;
  private volatile Timer kV;
  private boolean kW;
  private boolean kX;
  private boolean kY;
  private i kZ;
  private d kz;
  private long la = 300000L;
  private final Context mContext;
  
  r(Context paramContext, f paramf)
  {
    this(paramContext, paramf, null, GoogleAnalytics.getInstance(paramContext));
  }
  
  r(Context paramContext, f paramf, d paramd, GoogleAnalytics paramGoogleAnalytics)
  {
    this.kP = paramd;
    this.mContext = paramContext;
    this.kA = paramf;
    this.kQ = paramGoogleAnalytics;
    this.kZ = new i()
    {
      public long currentTimeMillis()
      {
        return System.currentTimeMillis();
      }
    };
    this.kS = 0;
    this.kN = a.lj;
  }
  
  private Timer a(Timer paramTimer)
  {
    if (paramTimer != null) {
      paramTimer.cancel();
    }
    return null;
  }
  
  private void ad()
  {
    this.kT = a(this.kT);
    this.kU = a(this.kU);
    this.kV = a(this.kV);
  }
  
  private void af()
  {
    for (;;)
    {
      try
      {
        if (!Thread.currentThread().equals(this.kA.getThread()))
        {
          this.kA.getQueue().add(new Runnable()
          {
            public void run()
            {
              r.a(r.this);
            }
          });
          return;
        }
        if (this.kW) {
          clearHits();
        }
        switch (3.lc[this.kN.ordinal()])
        {
        case 1: 
          if (!this.kR.isEmpty())
          {
            d locald2 = (d)this.kR.poll();
            y.v("Sending hit to store  " + locald2);
            this.kz.a(locald2.al(), locald2.am(), locald2.getPath(), locald2.an());
            continue;
          }
          if (!this.kC) {
            continue;
          }
        }
      }
      finally {}
      ag();
      continue;
      if (!this.kR.isEmpty())
      {
        d locald1 = (d)this.kR.peek();
        y.v("Sending hit to service   " + locald1);
        if (!this.kQ.isDryRunEnabled()) {
          this.kO.a(locald1.al(), locald1.am(), locald1.getPath(), locald1.an());
        }
        for (;;)
        {
          this.kR.poll();
          break;
          y.v("Dry run enabled. Hit not actually sent to service.");
        }
      }
      this.kM = this.kZ.currentTimeMillis();
      continue;
      y.v("Need to reconnect");
      if (!this.kR.isEmpty()) {
        ai();
      }
    }
  }
  
  private void ag()
  {
    this.kz.dispatch();
    this.kC = false;
  }
  
  private void ah()
  {
    for (;;)
    {
      try
      {
        a locala1 = this.kN;
        a locala2 = a.lf;
        if (locala1 == locala2) {
          return;
        }
        ad();
        y.v("falling back to local store");
        if (this.kP != null)
        {
          this.kz = this.kP;
          this.kN = a.lf;
          af();
          continue;
        }
        localGAServiceManager = GAServiceManager.getInstance();
      }
      finally {}
      GAServiceManager localGAServiceManager;
      localGAServiceManager.a(this.mContext, this.kA);
      this.kz = localGAServiceManager.aa();
    }
  }
  
  private void ai()
  {
    for (;;)
    {
      try
      {
        if ((!this.kY) && (this.kO != null))
        {
          a locala1 = this.kN;
          a locala2 = a.lf;
          if (locala1 != locala2) {
            try
            {
              this.kS = (1 + this.kS);
              a(this.kU);
              this.kN = a.ld;
              this.kU = new Timer("Failed Connect");
              this.kU.schedule(new c(null), 3000L);
              y.v("connecting to Analytics service");
              this.kO.connect();
              return;
            }
            catch (SecurityException localSecurityException)
            {
              y.w("security exception on connectToService");
              ah();
              continue;
            }
          }
        }
        y.w("client not initialized.");
      }
      finally {}
      ah();
    }
  }
  
  private void aj()
  {
    try
    {
      if ((this.kO != null) && (this.kN == a.le))
      {
        this.kN = a.li;
        this.kO.disconnect();
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  private void ak()
  {
    this.kT = a(this.kT);
    this.kT = new Timer("Service Reconnect");
    this.kT.schedule(new e(null), 5000L);
  }
  
  /* Error */
  public void a(int paramInt, android.content.Intent paramIntent)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getstatic 336	com/google/android/gms/analytics/r$a:lh	Lcom/google/android/gms/analytics/r$a;
    //   6: putfield 89	com/google/android/gms/analytics/r:kN	Lcom/google/android/gms/analytics/r$a;
    //   9: aload_0
    //   10: getfield 82	com/google/android/gms/analytics/r:kS	I
    //   13: iconst_2
    //   14: if_icmpge +39 -> 53
    //   17: new 164	java/lang/StringBuilder
    //   20: dup
    //   21: invokespecial 165	java/lang/StringBuilder:<init>	()V
    //   24: ldc_w 338
    //   27: invokevirtual 171	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: iload_1
    //   31: invokevirtual 341	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   34: ldc_w 343
    //   37: invokevirtual 171	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: invokevirtual 178	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   43: invokestatic 294	com/google/android/gms/analytics/y:w	(Ljava/lang/String;)V
    //   46: aload_0
    //   47: invokespecial 345	com/google/android/gms/analytics/r:ak	()V
    //   50: aload_0
    //   51: monitorexit
    //   52: return
    //   53: new 164	java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial 165	java/lang/StringBuilder:<init>	()V
    //   60: ldc_w 338
    //   63: invokevirtual 171	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: iload_1
    //   67: invokevirtual 341	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   70: ldc_w 347
    //   73: invokevirtual 171	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: invokevirtual 178	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   79: invokestatic 294	com/google/android/gms/analytics/y:w	(Ljava/lang/String;)V
    //   82: aload_0
    //   83: invokespecial 296	com/google/android/gms/analytics/r:ah	()V
    //   86: goto -36 -> 50
    //   89: astore_3
    //   90: aload_0
    //   91: monitorexit
    //   92: aload_3
    //   93: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	94	0	this	r
    //   0	94	1	paramInt	int
    //   0	94	2	paramIntent	android.content.Intent
    //   89	4	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	50	89	finally
    //   53	86	89	finally
  }
  
  public void ae()
  {
    if (this.kO != null) {
      return;
    }
    this.kO = new c(this.mContext, this, this);
    ai();
  }
  
  public void b(Map<String, String> paramMap, long paramLong, String paramString, List<z> paramList)
  {
    y.v("putHit called");
    this.kR.add(new d(paramMap, paramLong, paramString, paramList));
    af();
  }
  
  public void clearHits()
  {
    y.v("clearHits called");
    this.kR.clear();
    switch (3.lc[this.kN.ordinal()])
    {
    default: 
      this.kW = true;
      return;
    case 1: 
      this.kz.a(0L);
      this.kW = false;
      return;
    }
    this.kO.clearHits();
    this.kW = false;
  }
  
  public void dispatch()
  {
    switch (3.lc[this.kN.ordinal()])
    {
    default: 
      this.kC = true;
    case 2: 
      return;
    }
    ag();
  }
  
  /* Error */
  public void onConnected()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: aload_0
    //   5: getfield 106	com/google/android/gms/analytics/r:kU	Ljava/util/Timer;
    //   8: invokespecial 104	com/google/android/gms/analytics/r:a	(Ljava/util/Timer;)Ljava/util/Timer;
    //   11: putfield 106	com/google/android/gms/analytics/r:kU	Ljava/util/Timer;
    //   14: aload_0
    //   15: iconst_0
    //   16: putfield 82	com/google/android/gms/analytics/r:kS	I
    //   19: ldc_w 370
    //   22: invokestatic 184	com/google/android/gms/analytics/y:v	(Ljava/lang/String;)V
    //   25: aload_0
    //   26: getstatic 302	com/google/android/gms/analytics/r$a:le	Lcom/google/android/gms/analytics/r$a;
    //   29: putfield 89	com/google/android/gms/analytics/r:kN	Lcom/google/android/gms/analytics/r$a;
    //   32: aload_0
    //   33: getfield 372	com/google/android/gms/analytics/r:kX	Z
    //   36: ifeq +15 -> 51
    //   39: aload_0
    //   40: invokespecial 330	com/google/android/gms/analytics/r:aj	()V
    //   43: aload_0
    //   44: iconst_0
    //   45: putfield 372	com/google/android/gms/analytics/r:kX	Z
    //   48: aload_0
    //   49: monitorexit
    //   50: return
    //   51: aload_0
    //   52: invokespecial 99	com/google/android/gms/analytics/r:af	()V
    //   55: aload_0
    //   56: aload_0
    //   57: aload_0
    //   58: getfield 108	com/google/android/gms/analytics/r:kV	Ljava/util/Timer;
    //   61: invokespecial 104	com/google/android/gms/analytics/r:a	(Ljava/util/Timer;)Ljava/util/Timer;
    //   64: putfield 108	com/google/android/gms/analytics/r:kV	Ljava/util/Timer;
    //   67: aload_0
    //   68: new 93	java/util/Timer
    //   71: dup
    //   72: ldc_w 374
    //   75: invokespecial 273	java/util/Timer:<init>	(Ljava/lang/String;)V
    //   78: putfield 108	com/google/android/gms/analytics/r:kV	Ljava/util/Timer;
    //   81: aload_0
    //   82: getfield 108	com/google/android/gms/analytics/r:kV	Ljava/util/Timer;
    //   85: new 376	com/google/android/gms/analytics/r$b
    //   88: dup
    //   89: aload_0
    //   90: aconst_null
    //   91: invokespecial 377	com/google/android/gms/analytics/r$b:<init>	(Lcom/google/android/gms/analytics/r;Lcom/google/android/gms/analytics/r$1;)V
    //   94: aload_0
    //   95: getfield 65	com/google/android/gms/analytics/r:la	J
    //   98: invokevirtual 284	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
    //   101: goto -53 -> 48
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	109	0	this	r
    //   104	4	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	48	104	finally
    //   51	101	104	finally
  }
  
  public void onDisconnected()
  {
    for (;;)
    {
      try
      {
        if (this.kN == a.li)
        {
          y.v("Disconnected from service");
          ad();
          this.kN = a.lj;
          return;
        }
        y.v("Unexpected disconnect.");
        this.kN = a.lh;
        if (this.kS < 2) {
          ak();
        } else {
          ah();
        }
      }
      finally {}
    }
  }
  
  public void setForceLocalDispatch()
  {
    for (;;)
    {
      try
      {
        boolean bool = this.kY;
        if (bool) {
          return;
        }
        y.v("setForceLocalDispatch called.");
        this.kY = true;
        switch (3.lc[this.kN.ordinal()])
        {
        case 1: 
        case 4: 
        case 5: 
        case 6: 
        case 2: 
          aj();
          break;
        case 3: 
          this.kX = true;
        }
      }
      finally {}
    }
  }
  
  private static enum a
  {
    static
    {
      a[] arrayOfa = new a[7];
      arrayOfa[0] = ld;
      arrayOfa[1] = le;
      arrayOfa[2] = lf;
      arrayOfa[3] = lg;
      arrayOfa[4] = lh;
      arrayOfa[5] = li;
      arrayOfa[6] = lj;
      lk = arrayOfa;
    }
    
    private a() {}
  }
  
  private class b
    extends TimerTask
  {
    private b() {}
    
    public void run()
    {
      if ((r.b(r.this) == r.a.le) && (r.e(r.this).isEmpty()) && (r.f(r.this) + r.g(r.this) < r.h(r.this).currentTimeMillis()))
      {
        y.v("Disconnecting due to inactivity");
        r.i(r.this);
        return;
      }
      r.j(r.this).schedule(new b(r.this), r.g(r.this));
    }
  }
  
  private class c
    extends TimerTask
  {
    private c() {}
    
    public void run()
    {
      if (r.b(r.this) == r.a.ld) {
        r.c(r.this);
      }
    }
  }
  
  private static class d
  {
    private final Map<String, String> ll;
    private final long lm;
    private final String ln;
    private final List<z> lo;
    
    public d(Map<String, String> paramMap, long paramLong, String paramString, List<z> paramList)
    {
      this.ll = paramMap;
      this.lm = paramLong;
      this.ln = paramString;
      this.lo = paramList;
    }
    
    public Map<String, String> al()
    {
      return this.ll;
    }
    
    public long am()
    {
      return this.lm;
    }
    
    public List<z> an()
    {
      return this.lo;
    }
    
    public String getPath()
    {
      return this.ln;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("PATH: ");
      localStringBuilder.append(this.ln);
      if (this.ll != null)
      {
        localStringBuilder.append("  PARAMS: ");
        Iterator localIterator = this.ll.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          localStringBuilder.append((String)localEntry.getKey());
          localStringBuilder.append("=");
          localStringBuilder.append((String)localEntry.getValue());
          localStringBuilder.append(",  ");
        }
      }
      return localStringBuilder.toString();
    }
  }
  
  private class e
    extends TimerTask
  {
    private e() {}
    
    public void run()
    {
      r.d(r.this);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.r
 * JD-Core Version:    0.7.0.1
 */