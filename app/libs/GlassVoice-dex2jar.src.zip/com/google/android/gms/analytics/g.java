package com.google.android.gms.analytics;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

class g
  implements m
{
  private static Object jY = new Object();
  private static g kl;
  protected String kh;
  protected String ki;
  protected String kj;
  protected String kk;
  
  protected g() {}
  
  private g(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    this.kj = paramContext.getPackageName();
    this.kk = localPackageManager.getInstallerPackageName(this.kj);
    str1 = this.kj;
    try
    {
      PackageInfo localPackageInfo = localPackageManager.getPackageInfo(paramContext.getPackageName(), 0);
      str2 = null;
      if (localPackageInfo != null)
      {
        str1 = localPackageManager.getApplicationLabel(localPackageInfo.applicationInfo).toString();
        str2 = localPackageInfo.versionName;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;)
      {
        y.e("Error retrieving package info: appName set to " + str1);
        String str2 = null;
      }
    }
    this.kh = str1;
    this.ki = str2;
  }
  
  public static g Q()
  {
    return kl;
  }
  
  public static void i(Context paramContext)
  {
    synchronized (jY)
    {
      if (kl == null) {
        kl = new g(paramContext);
      }
      return;
    }
  }
  
  public boolean c(String paramString)
  {
    return ("&an".equals(paramString)) || ("&av".equals(paramString)) || ("&aid".equals(paramString)) || ("&aiid".equals(paramString));
  }
  
  public String getValue(String paramString)
  {
    if (paramString == null) {}
    do
    {
      return null;
      if (paramString.equals("&an")) {
        return this.kh;
      }
      if (paramString.equals("&av")) {
        return this.ki;
      }
      if (paramString.equals("&aid")) {
        return this.kj;
      }
    } while (!paramString.equals("&aiid"));
    return this.kk;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.g
 * JD-Core Version:    0.7.0.1
 */