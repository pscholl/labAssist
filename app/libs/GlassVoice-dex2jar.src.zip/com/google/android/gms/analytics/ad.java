package com.google.android.gms.analytics;

abstract class ad
{
  abstract void ab();
  
  abstract void c(boolean paramBoolean);
  
  abstract void dispatchLocalHits();
  
  abstract void overrideHostUrl(String paramString);
  
  abstract void setLocalDispatchPeriod(int paramInt);
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ad
 * JD-Core Version:    0.7.0.1
 */