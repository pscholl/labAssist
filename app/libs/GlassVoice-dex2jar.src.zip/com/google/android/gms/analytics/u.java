package com.google.android.gms.analytics;

class u
  implements j
{
  String kh;
  String ki;
  String mO;
  int mP = -1;
  int mQ = -1;
  
  public boolean aA()
  {
    return this.mQ != -1;
  }
  
  public boolean aB()
  {
    return this.mQ == 1;
  }
  
  public boolean as()
  {
    return this.kh != null;
  }
  
  public String at()
  {
    return this.kh;
  }
  
  public boolean au()
  {
    return this.ki != null;
  }
  
  public String av()
  {
    return this.ki;
  }
  
  public boolean aw()
  {
    return this.mO != null;
  }
  
  public String ax()
  {
    return this.mO;
  }
  
  public boolean ay()
  {
    return this.mP >= 0;
  }
  
  public int az()
  {
    return this.mP;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.u
 * JD-Core Version:    0.7.0.1
 */