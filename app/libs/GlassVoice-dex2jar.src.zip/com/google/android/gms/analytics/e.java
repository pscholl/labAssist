package com.google.android.gms.analytics;

abstract interface e
{
  public abstract void b(boolean paramBoolean);
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.e
 * JD-Core Version:    0.7.0.1
 */