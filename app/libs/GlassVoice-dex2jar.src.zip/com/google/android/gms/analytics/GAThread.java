package com.google.android.gms.analytics;

import android.content.Context;
import android.os.Process;
import android.text.TextUtils;
import com.google.android.gms.internal.z;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

class GAThread
  extends Thread
  implements f
{
  private static GAThread lt;
  private volatile String kn;
  private final LinkedBlockingQueue<Runnable> lp = new LinkedBlockingQueue();
  private volatile boolean lq = false;
  private volatile List<z> lr;
  private volatile String ls;
  private volatile ae lu;
  private volatile boolean mClosed = false;
  private final Context mContext;
  
  private GAThread(Context paramContext)
  {
    super("GAThread");
    if (paramContext != null) {}
    for (this.mContext = paramContext.getApplicationContext();; this.mContext = paramContext)
    {
      start();
      return;
    }
  }
  
  private String a(Throwable paramThrowable)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream localPrintStream = new PrintStream(localByteArrayOutputStream);
    paramThrowable.printStackTrace(localPrintStream);
    localPrintStream.flush();
    return new String(localByteArrayOutputStream.toByteArray());
  }
  
  private String a(Map<String, String> paramMap)
  {
    if (paramMap.containsKey("useSecure"))
    {
      if (ai.d((String)paramMap.get("useSecure"), true)) {
        return "https:";
      }
      return "http:";
    }
    return "https:";
  }
  
  private boolean b(Map<String, String> paramMap)
  {
    if (paramMap.get("&sf") == null) {
      return false;
    }
    double d = ai.a((String)paramMap.get("&sf"), 100.0D);
    if (d >= 100.0D) {
      return false;
    }
    if (j((String)paramMap.get("&cid")) % 10000 >= d * 100.0D)
    {
      if (paramMap.get("&t") == null) {}
      for (String str = "unknown";; str = (String)paramMap.get("&t"))
      {
        y.v(String.format("%s hit sampled out", new Object[] { str }));
        return true;
      }
    }
    return false;
  }
  
  private void c(Map<String, String> paramMap)
  {
    m localm = a.h(this.mContext);
    ai.a(paramMap, "&adid", localm.getValue("&adid"));
    ai.a(paramMap, "&ate", localm.getValue("&ate"));
  }
  
  private void d(Map<String, String> paramMap)
  {
    g localg = g.Q();
    ai.a(paramMap, "&an", localg.getValue("&an"));
    ai.a(paramMap, "&av", localg.getValue("&av"));
    ai.a(paramMap, "&aid", localg.getValue("&aid"));
    ai.a(paramMap, "&aiid", localg.getValue("&aiid"));
    paramMap.put("&v", "1");
  }
  
  static GAThread getInstance(Context paramContext)
  {
    if (lt == null) {
      lt = new GAThread(paramContext);
    }
    return lt;
  }
  
  static int j(String paramString)
  {
    int i = 1;
    if (!TextUtils.isEmpty(paramString))
    {
      int j = -1 + paramString.length();
      i = 0;
      for (int k = j; k >= 0; k--)
      {
        int m = paramString.charAt(k);
        i = m + (0xFFFFFFF & i << 6) + (m << 14);
        int n = 0xFE00000 & i;
        if (n != 0) {
          i ^= n >> 21;
        }
      }
    }
    return i;
  }
  
  static String l(Context paramContext)
  {
    try
    {
      FileInputStream localFileInputStream = paramContext.openFileInput("gaInstallData");
      arrayOfByte = new byte[8192];
      i = localFileInputStream.read(arrayOfByte, 0, 8192);
      if (localFileInputStream.available() > 0)
      {
        y.e("Too much campaign data, ignoring it.");
        localFileInputStream.close();
        paramContext.deleteFile("gaInstallData");
        return null;
      }
      localFileInputStream.close();
      paramContext.deleteFile("gaInstallData");
      if (i <= 0)
      {
        y.w("Campaign file is empty.");
        return null;
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      byte[] arrayOfByte;
      int i;
      y.i("No campaign data found.");
      return null;
      String str = new String(arrayOfByte, 0, i);
      y.i("Campaign found: " + str);
      return str;
    }
    catch (IOException localIOException)
    {
      y.e("Error reading campaign data.");
      paramContext.deleteFile("gaInstallData");
    }
    return null;
  }
  
  void a(Runnable paramRunnable)
  {
    this.lp.add(paramRunnable);
  }
  
  public void clearHits()
  {
    a(new Runnable()
    {
      public void run()
      {
        GAThread.e(GAThread.this).clearHits();
      }
    });
  }
  
  public void dispatch()
  {
    a(new Runnable()
    {
      public void run()
      {
        GAThread.e(GAThread.this).dispatch();
      }
    });
  }
  
  public LinkedBlockingQueue<Runnable> getQueue()
  {
    return this.lp;
  }
  
  public Thread getThread()
  {
    return this;
  }
  
  protected void init()
  {
    this.lu.ae();
    this.lr = new ArrayList();
    this.lr.add(new z("appendVersion", "&_v".substring(1), "ma4.0.0"));
    this.lr.add(new z("appendQueueTime", "&qt".substring(1), null));
    this.lr.add(new z("appendCacheBuster", "&z".substring(1), null));
  }
  
  void loadCampaign()
  {
    this.ls = l(this.mContext);
  }
  
  public void run()
  {
    Process.setThreadPriority(10);
    try
    {
      Thread.sleep(5000L);
      for (;;)
      {
        try
        {
          if (this.lu == null) {
            this.lu = new r(this.mContext, this);
          }
          init();
          this.kn = h.R().getValue("&cid");
          if (this.kn == null) {
            this.lq = true;
          }
          this.ls = l(this.mContext);
          y.v("Initialized GA Thread");
        }
        catch (Throwable localThrowable1)
        {
          y.e("Error initializing the GAThread: " + a(localThrowable1));
          y.e("Google Analytics will not start up.");
          this.lq = true;
          continue;
        }
        if (this.mClosed) {
          return;
        }
        try
        {
          Runnable localRunnable = (Runnable)this.lp.take();
          if (!this.lq) {
            localRunnable.run();
          }
        }
        catch (InterruptedException localInterruptedException2)
        {
          y.i(localInterruptedException2.toString());
        }
        catch (Throwable localThrowable2)
        {
          y.e("Error on GAThread: " + a(localThrowable2));
          y.e("Google Analytics is shutting down.");
          this.lq = true;
        }
      }
    }
    catch (InterruptedException localInterruptedException1)
    {
      for (;;)
      {
        y.w("sleep interrupted in GAThread initialize");
      }
    }
  }
  
  public void sendHit(Map<String, String> paramMap)
  {
    final HashMap localHashMap = new HashMap(paramMap);
    String str = (String)paramMap.get("&ht");
    if (str != null) {}
    try
    {
      Long.valueOf(str);
      if (str == null) {
        localHashMap.put("&ht", Long.toString(System.currentTimeMillis()));
      }
      a(new Runnable()
      {
        public void run()
        {
          if (TextUtils.isEmpty((CharSequence)localHashMap.get("&cid"))) {
            localHashMap.put("&cid", GAThread.a(GAThread.this));
          }
          if ((GoogleAnalytics.getInstance(GAThread.b(GAThread.this)).getAppOptOut()) || (GAThread.a(GAThread.this, localHashMap))) {
            return;
          }
          if (!TextUtils.isEmpty(GAThread.c(GAThread.this)))
          {
            s.ao().d(true);
            localHashMap.putAll(new HitBuilders.HitBuilder().setCampaignParamsFromUrl(GAThread.c(GAThread.this)).build());
            s.ao().d(false);
            GAThread.a(GAThread.this, null);
          }
          GAThread.b(GAThread.this, localHashMap);
          GAThread.c(GAThread.this, localHashMap);
          Map localMap = w.e(localHashMap);
          GAThread.e(GAThread.this).b(localMap, Long.valueOf((String)localHashMap.get("&ht")).longValue(), GAThread.d(GAThread.this, localHashMap), GAThread.d(GAThread.this));
        }
      });
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      for (;;)
      {
        str = null;
      }
    }
  }
  
  public void setForceLocalDispatch()
  {
    a(new Runnable()
    {
      public void run()
      {
        GAThread.e(GAThread.this).setForceLocalDispatch();
      }
    });
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.GAThread
 * JD-Core Version:    0.7.0.1
 */