package com.google.android.gms.analytics;

abstract interface i
{
  public abstract long currentTimeMillis();
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.i
 * JD-Core Version:    0.7.0.1
 */