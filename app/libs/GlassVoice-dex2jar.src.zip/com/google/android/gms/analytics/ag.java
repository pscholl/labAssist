package com.google.android.gms.analytics;

import android.content.Context;
import java.util.Map;

class ag
  extends k<ah>
{
  public ag(Context paramContext)
  {
    super(paramContext, new a());
  }
  
  private static class a
    implements k.a<ah>
  {
    private final ah nY = new ah();
    
    public void a(String paramString, int paramInt)
    {
      if ("ga_sessionTimeout".equals(paramString))
      {
        this.nY.ob = paramInt;
        return;
      }
      y.w("int configuration name not recognized:  " + paramString);
    }
    
    public ah aX()
    {
      return this.nY;
    }
    
    public void b(String paramString1, String paramString2)
    {
      this.nY.of.put(paramString1, paramString2);
    }
    
    public void c(String paramString1, String paramString2)
    {
      if ("ga_trackingId".equals(paramString1))
      {
        this.nY.nZ = paramString2;
        return;
      }
      if ("ga_sampleFrequency".equals(paramString1)) {
        try
        {
          this.nY.oa = Double.parseDouble(paramString2);
          return;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          y.e("Error parsing ga_sampleFrequency value: " + paramString2);
          return;
        }
      }
      y.w("string configuration name not recognized:  " + paramString1);
    }
    
    public void c(String paramString, boolean paramBoolean)
    {
      int i = 1;
      if ("ga_autoActivityTracking".equals(paramString))
      {
        ah localah3 = this.nY;
        if (paramBoolean) {}
        for (;;)
        {
          localah3.oc = i;
          return;
          i = 0;
        }
      }
      if ("ga_anonymizeIp".equals(paramString))
      {
        ah localah2 = this.nY;
        if (paramBoolean) {}
        for (;;)
        {
          localah2.od = i;
          return;
          i = 0;
        }
      }
      if ("ga_reportUncaughtExceptions".equals(paramString))
      {
        ah localah1 = this.nY;
        if (paramBoolean) {}
        for (;;)
        {
          localah1.oe = i;
          return;
          i = 0;
        }
      }
      y.w("bool configuration name not recognized:  " + paramString);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ag
 * JD-Core Version:    0.7.0.1
 */