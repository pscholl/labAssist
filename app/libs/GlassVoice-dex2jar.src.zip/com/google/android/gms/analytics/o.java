package com.google.android.gms.analytics;

final class o
{
  static String b(int paramInt)
  {
    return b("&cd", paramInt);
  }
  
  private static String b(String paramString, int paramInt)
  {
    if (paramInt < 1)
    {
      y.e("index out of range for " + paramString + " (" + paramInt + ")");
      return "";
    }
    return paramString + paramInt;
  }
  
  static String c(int paramInt)
  {
    return b("&cm", paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.o
 * JD-Core Version:    0.7.0.1
 */