package com.google.android.gms.analytics;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;

class a
  implements m
{
  private static Object jY = new Object();
  private static a jZ;
  private AdvertisingIdClient.Info ka;
  private long kb;
  private Context mContext;
  
  private a(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  private AdvertisingIdClient.Info K()
  {
    try
    {
      AdvertisingIdClient.Info localInfo = AdvertisingIdClient.getAdvertisingIdInfo(this.mContext);
      return localInfo;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      y.w("IllegalStateException getting Ad Id Info");
      return null;
    }
    catch (GooglePlayServicesRepairableException localGooglePlayServicesRepairableException)
    {
      y.w("GooglePlayServicesRepairableException getting Ad Id Info");
      return null;
    }
    catch (IOException localIOException)
    {
      y.w("IOException getting Ad Id Info");
      return null;
    }
    catch (GooglePlayServicesNotAvailableException localGooglePlayServicesNotAvailableException)
    {
      y.w("GooglePlayServicesNotAvailableException getting Ad Id Info");
      return null;
    }
    catch (Exception localException)
    {
      y.w("Unknown exception. Could not get the ad Id.");
    }
    return null;
  }
  
  public static m h(Context paramContext)
  {
    if (jZ == null) {}
    synchronized (jY)
    {
      if (jZ == null) {
        jZ = new a(paramContext);
      }
      return jZ;
    }
  }
  
  public String getValue(String paramString)
  {
    long l = System.currentTimeMillis();
    if (l - this.kb > 1000L)
    {
      this.ka = K();
      this.kb = l;
    }
    if (this.ka != null)
    {
      if ("&adid".equals(paramString)) {
        return this.ka.getId();
      }
      if ("&ate".equals(paramString))
      {
        if (this.ka.isLimitAdTrackingEnabled()) {
          return "1";
        }
        return "0";
      }
    }
    return null;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.a
 * JD-Core Version:    0.7.0.1
 */