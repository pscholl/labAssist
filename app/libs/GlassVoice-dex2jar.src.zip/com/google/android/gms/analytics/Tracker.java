package com.google.android.gms.analytics;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.internal.at;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Tracker
{
  private final TrackerHandler nE;
  private final Map<String, String> nF = new HashMap();
  private ab nG;
  private final h nH;
  private final ac nI;
  private final g nJ;
  private boolean nK;
  private a nL;
  private ah nM;
  
  Tracker(String paramString, TrackerHandler paramTrackerHandler)
  {
    this(paramString, paramTrackerHandler, h.R(), ac.aP(), g.Q(), new x("tracking"));
  }
  
  Tracker(String paramString, TrackerHandler paramTrackerHandler, h paramh, ac paramac, g paramg, ab paramab)
  {
    this.nE = paramTrackerHandler;
    if (paramString != null) {
      this.nF.put("&tid", paramString);
    }
    this.nF.put("useSecure", "1");
    this.nH = paramh;
    this.nI = paramac;
    this.nJ = paramg;
    this.nG = paramab;
    this.nL = new a();
  }
  
  void a(Context paramContext, ah paramah)
  {
    y.v("Loading Tracker config values.");
    this.nM = paramah;
    if (this.nM.aY())
    {
      String str2 = this.nM.aZ();
      set("&tid", str2);
      y.v("[Tracker] trackingId loaded: " + str2);
    }
    if (this.nM.ba())
    {
      String str1 = Double.toString(this.nM.bb());
      set("&sf", str1);
      y.v("[Tracker] sample frequency loaded: " + str1);
    }
    if (this.nM.bc())
    {
      setSessionTimeout(this.nM.getSessionTimeout());
      y.v("[Tracker] session timeout loaded: " + aR());
    }
    if (this.nM.bd())
    {
      enableAutoActivityTracking(this.nM.be());
      y.v("[Tracker] auto activity tracking loaded: " + aS());
    }
    if (this.nM.bf())
    {
      if (this.nM.bg())
      {
        set("&aip", "1");
        y.v("[Tracker] anonymize ip loaded: true");
      }
      y.v("[Tracker] anonymize ip loaded: false");
    }
    this.nK = this.nM.bh();
    if (this.nM.bh())
    {
      Thread.setDefaultUncaughtExceptionHandler(new ExceptionReporter(this, Thread.getDefaultUncaughtExceptionHandler(), paramContext));
      y.v("[Tracker] report uncaught exceptions loaded: " + this.nK);
    }
  }
  
  long aR()
  {
    return this.nL.aR();
  }
  
  boolean aS()
  {
    return this.nL.aS();
  }
  
  public void enableAdvertisingIdCollection(boolean paramBoolean)
  {
    if (!paramBoolean)
    {
      this.nF.put("&ate", null);
      this.nF.put("&adid", null);
    }
    do
    {
      return;
      if (this.nF.containsKey("&ate")) {
        this.nF.remove("&ate");
      }
    } while (!this.nF.containsKey("&adid"));
    this.nF.remove("&adid");
  }
  
  public void enableAutoActivityTracking(boolean paramBoolean)
  {
    this.nL.enableAutoActivityTracking(paramBoolean);
  }
  
  public String get(String paramString)
  {
    s.ao().a(s.a.lK);
    if (TextUtils.isEmpty(paramString)) {}
    do
    {
      return null;
      if (this.nF.containsKey(paramString)) {
        return (String)this.nF.get(paramString);
      }
      if (paramString.equals("&ul")) {
        return ai.a(Locale.getDefault());
      }
      if ((this.nH != null) && (this.nH.c(paramString))) {
        return this.nH.getValue(paramString);
      }
      if ((this.nI != null) && (this.nI.c(paramString))) {
        return this.nI.getValue(paramString);
      }
    } while ((this.nJ == null) || (!this.nJ.c(paramString)));
    return this.nJ.getValue(paramString);
  }
  
  public void send(Map<String, String> paramMap)
  {
    s.ao().a(s.a.lM);
    HashMap localHashMap = new HashMap();
    localHashMap.putAll(this.nF);
    if (paramMap != null) {
      localHashMap.putAll(paramMap);
    }
    if (TextUtils.isEmpty((CharSequence)localHashMap.get("&tid"))) {
      y.w(String.format("Missing tracking id (%s) parameter.", new Object[] { "&tid" }));
    }
    String str = (String)localHashMap.get("&t");
    if (TextUtils.isEmpty(str))
    {
      y.w(String.format("Missing hit type (%s) parameter.", new Object[] { "&t" }));
      str = "";
    }
    if (this.nL.aT()) {
      localHashMap.put("&sc", "start");
    }
    if ((!str.equals("transaction")) && (!str.equals("item")) && (!this.nG.aI()))
    {
      y.w("Too many hits sent too quickly, rate limiting invoked.");
      return;
    }
    this.nE.sendHit(localHashMap);
  }
  
  public void set(String paramString1, String paramString2)
  {
    at.a(paramString1, "Key should be non-null");
    s.ao().a(s.a.lL);
    this.nF.put(paramString1, paramString2);
  }
  
  public void setAnonymizeIp(boolean paramBoolean)
  {
    set("&aip", ai.e(paramBoolean));
  }
  
  public void setAppId(String paramString)
  {
    set("&aid", paramString);
  }
  
  public void setAppInstallerId(String paramString)
  {
    set("&aiid", paramString);
  }
  
  public void setAppName(String paramString)
  {
    set("&an", paramString);
  }
  
  public void setAppVersion(String paramString)
  {
    set("&av", paramString);
  }
  
  public void setClientId(String paramString)
  {
    set("&cid", paramString);
  }
  
  public void setEncoding(String paramString)
  {
    set("&de", paramString);
  }
  
  public void setHostname(String paramString)
  {
    set("&dh", paramString);
  }
  
  public void setLanguage(String paramString)
  {
    set("&ul", paramString);
  }
  
  public void setLocation(String paramString)
  {
    set("&dl", paramString);
  }
  
  public void setPage(String paramString)
  {
    set("&dp", paramString);
  }
  
  public void setReferrer(String paramString)
  {
    set("&dr", paramString);
  }
  
  public void setSampleRate(double paramDouble)
  {
    set("&sf", Double.toHexString(paramDouble));
  }
  
  public void setScreenColors(String paramString)
  {
    set("&sd", paramString);
  }
  
  public void setScreenName(String paramString)
  {
    set("&cd", paramString);
  }
  
  public void setScreenResolution(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) && (paramInt2 < 0))
    {
      y.w("Invalid width or height. The values should be non-negative.");
      return;
    }
    set("&sr", paramInt1 + "x" + paramInt2);
  }
  
  public void setSessionTimeout(long paramLong)
  {
    this.nL.setSessionTimeout(1000L * paramLong);
  }
  
  public void setTitle(String paramString)
  {
    set("&dt", paramString);
  }
  
  public void setUseSecure(boolean paramBoolean)
  {
    set("useSecure", ai.e(paramBoolean));
  }
  
  public void setViewportSize(String paramString)
  {
    set("&vp", paramString);
  }
  
  private class a
    implements GoogleAnalytics.a
  {
    private i kZ = new i()
    {
      public long currentTimeMillis()
      {
        return System.currentTimeMillis();
      }
    };
    private Timer nN;
    private TimerTask nO;
    private boolean nP = false;
    private boolean nQ = false;
    private int nR = 0;
    private long nS = -1L;
    private boolean nT = false;
    private long nU;
    
    public a() {}
    
    private void aU()
    {
      GoogleAnalytics localGoogleAnalytics = GoogleAnalytics.aC();
      if (localGoogleAnalytics == null)
      {
        y.e("GoogleAnalytics isn't initialized for the Tracker!");
        return;
      }
      if ((this.nS >= 0L) || (this.nQ))
      {
        localGoogleAnalytics.a(Tracker.b(Tracker.this));
        return;
      }
      localGoogleAnalytics.b(Tracker.b(Tracker.this));
    }
    
    private void aV()
    {
      try
      {
        if (this.nN != null)
        {
          this.nN.cancel();
          this.nN = null;
        }
        return;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }
    
    public long aR()
    {
      return this.nS;
    }
    
    public boolean aS()
    {
      return this.nQ;
    }
    
    public boolean aT()
    {
      boolean bool = this.nT;
      this.nT = false;
      return bool;
    }
    
    boolean aW()
    {
      return (this.nS == 0L) || ((this.nS > 0L) && (this.kZ.currentTimeMillis() > this.nU + this.nS));
    }
    
    public void c(Activity paramActivity)
    {
      s.ao().a(s.a.mJ);
      aV();
      if ((!this.nP) && (this.nR == 0) && (aW())) {
        this.nT = true;
      }
      this.nP = true;
      this.nR = (1 + this.nR);
      HashMap localHashMap;
      Tracker localTracker;
      if (this.nQ)
      {
        localHashMap = new HashMap();
        localHashMap.put("&t", "appview");
        s.ao().d(true);
        localTracker = Tracker.this;
        if (Tracker.c(Tracker.this) == null) {
          break label141;
        }
      }
      label141:
      for (String str = Tracker.c(Tracker.this).e(paramActivity);; str = paramActivity.getClass().getCanonicalName())
      {
        localTracker.set("&cd", str);
        Tracker.this.send(localHashMap);
        s.ao().d(false);
        return;
      }
    }
    
    public void d(Activity paramActivity)
    {
      s.ao().a(s.a.mK);
      this.nR = (-1 + this.nR);
      this.nR = Math.max(0, this.nR);
      this.nU = this.kZ.currentTimeMillis();
      if (this.nR == 0)
      {
        aV();
        this.nO = new a(null);
        this.nN = new Timer("waitForActivityStart");
        this.nN.schedule(this.nO, 1000L);
      }
    }
    
    public void enableAutoActivityTracking(boolean paramBoolean)
    {
      this.nQ = paramBoolean;
      aU();
    }
    
    public void setSessionTimeout(long paramLong)
    {
      this.nS = paramLong;
      aU();
    }
    
    private class a
      extends TimerTask
    {
      private a() {}
      
      public void run()
      {
        Tracker.a.a(Tracker.a.this, false);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.Tracker
 * JD-Core Version:    0.7.0.1
 */