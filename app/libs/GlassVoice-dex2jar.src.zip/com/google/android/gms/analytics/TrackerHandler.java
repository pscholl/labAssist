package com.google.android.gms.analytics;

import java.util.Map;

abstract class TrackerHandler
{
  abstract void sendHit(Map<String, String> paramMap);
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.TrackerHandler
 * JD-Core Version:    0.7.0.1
 */