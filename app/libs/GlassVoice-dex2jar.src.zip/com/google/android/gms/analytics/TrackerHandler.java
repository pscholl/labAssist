package com.google.android.gms.analytics;

import java.util.Map;

abstract class TrackerHandler
{
  abstract void sendHit(Map<String, String> paramMap);
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.TrackerHandler
 * JD-Core Version:    0.7.0.1
 */