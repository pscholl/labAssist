package com.google.android.gms.analytics;

import java.util.SortedSet;
import java.util.TreeSet;

class s
{
  private static final s lA = new s();
  private SortedSet<a> lx = new TreeSet();
  private StringBuilder ly = new StringBuilder();
  private boolean lz = false;
  
  public static s ao()
  {
    return lA;
  }
  
  public void a(a parama)
  {
    try
    {
      if (!this.lz)
      {
        this.lx.add(parama);
        this.ly.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(parama.ordinal()));
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public String ap()
  {
    try
    {
      StringBuilder localStringBuilder = new StringBuilder();
      int i = 6;
      int j = 0;
      while (this.lx.size() > 0)
      {
        a locala = (a)this.lx.first();
        this.lx.remove(locala);
        int k = locala.ordinal();
        while (k >= i)
        {
          localStringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(j));
          i += 6;
          j = 0;
        }
        j += (1 << locala.ordinal() % 6);
      }
      if ((j > 0) || (localStringBuilder.length() == 0)) {
        localStringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(j));
      }
      this.lx.clear();
      String str = localStringBuilder.toString();
      return str;
    }
    finally {}
  }
  
  public String aq()
  {
    try
    {
      if (this.ly.length() > 0) {
        this.ly.insert(0, ".");
      }
      String str = this.ly.toString();
      this.ly = new StringBuilder();
      return str;
    }
    finally {}
  }
  
  public void d(boolean paramBoolean)
  {
    try
    {
      this.lz = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public static enum a
  {
    static
    {
      mA = new a("CONSTRUCT_ITEM", 51);
      mB = new a("BLANK_52", 52);
      mC = new a("BLANK_53", 53);
      mD = new a("SET_DRY_RUN", 54);
      mE = new a("GET_DRY_RUN", 55);
      mF = new a("SET_LOGGER", 56);
      mG = new a("SET_FORCE_LOCAL_DISPATCH", 57);
      mH = new a("GET_TRACKER_NAME", 58);
      mI = new a("CLOSE_TRACKER", 59);
      mJ = new a("EASY_TRACKER_ACTIVITY_START", 60);
      mK = new a("EASY_TRACKER_ACTIVITY_STOP", 61);
      mL = new a("CONSTRUCT_APP_VIEW", 62);
      a[] arrayOfa = new a[63];
      arrayOfa[0] = lB;
      arrayOfa[1] = lC;
      arrayOfa[2] = lD;
      arrayOfa[3] = lE;
      arrayOfa[4] = lF;
      arrayOfa[5] = lG;
      arrayOfa[6] = lH;
      arrayOfa[7] = lI;
      arrayOfa[8] = lJ;
      arrayOfa[9] = lK;
      arrayOfa[10] = lL;
      arrayOfa[11] = lM;
      arrayOfa[12] = lN;
      arrayOfa[13] = lO;
      arrayOfa[14] = lP;
      arrayOfa[15] = lQ;
      arrayOfa[16] = lR;
      arrayOfa[17] = lS;
      arrayOfa[18] = lT;
      arrayOfa[19] = lU;
      arrayOfa[20] = lV;
      arrayOfa[21] = lW;
      arrayOfa[22] = lX;
      arrayOfa[23] = lY;
      arrayOfa[24] = lZ;
      arrayOfa[25] = ma;
      arrayOfa[26] = mb;
      arrayOfa[27] = mc;
      arrayOfa[28] = md;
      arrayOfa[29] = me;
      arrayOfa[30] = mf;
      arrayOfa[31] = mg;
      arrayOfa[32] = mh;
      arrayOfa[33] = mi;
      arrayOfa[34] = mj;
      arrayOfa[35] = mk;
      arrayOfa[36] = ml;
      arrayOfa[37] = mm;
      arrayOfa[38] = mn;
      arrayOfa[39] = mo;
      arrayOfa[40] = mp;
      arrayOfa[41] = mq;
      arrayOfa[42] = mr;
      arrayOfa[43] = ms;
      arrayOfa[44] = mt;
      arrayOfa[45] = mu;
      arrayOfa[46] = mv;
      arrayOfa[47] = mw;
      arrayOfa[48] = mx;
      arrayOfa[49] = my;
      arrayOfa[50] = mz;
      arrayOfa[51] = mA;
      arrayOfa[52] = mB;
      arrayOfa[53] = mC;
      arrayOfa[54] = mD;
      arrayOfa[55] = mE;
      arrayOfa[56] = mF;
      arrayOfa[57] = mG;
      arrayOfa[58] = mH;
      arrayOfa[59] = mI;
      arrayOfa[60] = mJ;
      arrayOfa[61] = mK;
      arrayOfa[62] = mL;
      mM = arrayOfa;
    }
    
    private a() {}
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.s
 * JD-Core Version:    0.7.0.1
 */