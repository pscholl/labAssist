package com.google.android.gms.analytics;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

class ac
  implements m
{
  private static Object jY = new Object();
  private static ac nz;
  private final Context mContext;
  
  protected ac(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  public static ac aP()
  {
    synchronized (jY)
    {
      ac localac = nz;
      return localac;
    }
  }
  
  public static void i(Context paramContext)
  {
    synchronized (jY)
    {
      if (nz == null) {
        nz = new ac(paramContext);
      }
      return;
    }
  }
  
  protected String aQ()
  {
    DisplayMetrics localDisplayMetrics = this.mContext.getResources().getDisplayMetrics();
    return localDisplayMetrics.widthPixels + "x" + localDisplayMetrics.heightPixels;
  }
  
  public boolean c(String paramString)
  {
    return "&sr".equals(paramString);
  }
  
  public String getValue(String paramString)
  {
    if (paramString == null) {}
    while (!paramString.equals("&sr")) {
      return null;
    }
    return aQ();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ac
 * JD-Core Version:    0.7.0.1
 */