package com.google.android.gms.analytics;

import android.text.TextUtils;

class v
{
  private String na;
  private final long nb;
  private final long nc;
  private String nd = "https:";
  
  v(String paramString, long paramLong1, long paramLong2)
  {
    this.na = paramString;
    this.nb = paramLong1;
    this.nc = paramLong2;
  }
  
  String aE()
  {
    return this.na;
  }
  
  long aF()
  {
    return this.nb;
  }
  
  long aG()
  {
    return this.nc;
  }
  
  String aH()
  {
    return this.nd;
  }
  
  void l(String paramString)
  {
    this.na = paramString;
  }
  
  void m(String paramString)
  {
    if ((paramString == null) || (TextUtils.isEmpty(paramString.trim()))) {}
    while (!paramString.toLowerCase().startsWith("http:")) {
      return;
    }
    this.nd = "http:";
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.v
 * JD-Core Version:    0.7.0.1
 */