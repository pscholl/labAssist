package com.google.android.gms.analytics;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.aa;
import com.google.android.gms.internal.aa.a;
import com.google.android.gms.internal.z;
import java.util.List;
import java.util.Map;

class c
  implements b
{
  private ServiceConnection kc;
  private b kd;
  private c ke;
  private aa kf;
  private Context mContext;
  
  public c(Context paramContext, b paramb, c paramc)
  {
    this.mContext = paramContext;
    if (paramb == null) {
      throw new IllegalArgumentException("onConnectedListener cannot be null");
    }
    this.kd = paramb;
    if (paramc == null) {
      throw new IllegalArgumentException("onConnectionFailedListener cannot be null");
    }
    this.ke = paramc;
  }
  
  private aa L()
  {
    M();
    return this.kf;
  }
  
  private void N()
  {
    O();
  }
  
  private void O()
  {
    this.kd.onConnected();
  }
  
  protected void M()
  {
    if (!isConnected()) {
      throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
    }
  }
  
  public void a(Map<String, String> paramMap, long paramLong, String paramString, List<z> paramList)
  {
    try
    {
      L().a(paramMap, paramLong, paramString, paramList);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      y.e("sendHit failed: " + localRemoteException);
    }
  }
  
  public void clearHits()
  {
    try
    {
      L().clearHits();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      y.e("clear hits failed: " + localRemoteException);
    }
  }
  
  public void connect()
  {
    Intent localIntent = new Intent("com.google.android.gms.analytics.service.START");
    localIntent.setComponent(new ComponentName("com.google.android.gms", "com.google.android.gms.analytics.service.AnalyticsService"));
    localIntent.putExtra("app_package_name", this.mContext.getPackageName());
    if (this.kc != null) {
      y.e("Calling connect() while still connected, missing disconnect().");
    }
    boolean bool;
    do
    {
      return;
      this.kc = new a();
      bool = this.mContext.bindService(localIntent, this.kc, 129);
      y.v("connect: bindService returned " + bool + " for " + localIntent);
    } while (bool);
    this.kc = null;
    this.ke.a(1, null);
  }
  
  public void disconnect()
  {
    this.kf = null;
    if (this.kc != null) {}
    try
    {
      this.mContext.unbindService(this.kc);
      label23:
      this.kc = null;
      this.kd.onDisconnected();
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      break label23;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      break label23;
    }
  }
  
  public boolean isConnected()
  {
    return this.kf != null;
  }
  
  final class a
    implements ServiceConnection
  {
    a() {}
    
    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      y.v("service connected, binder: " + paramIBinder);
      try
      {
        if ("com.google.android.gms.analytics.internal.IAnalyticsService".equals(paramIBinder.getInterfaceDescriptor()))
        {
          y.v("bound to service");
          c.a(c.this, aa.a.h(paramIBinder));
          c.a(c.this);
          return;
        }
      }
      catch (RemoteException localRemoteException)
      {
        c.b(c.this).unbindService(this);
        c.a(c.this, null);
        c.c(c.this).a(2, null);
      }
    }
    
    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      y.v("service disconnected: " + paramComponentName);
      c.a(c.this, null);
      c.d(c.this).onDisconnected();
    }
  }
  
  public static abstract interface b
  {
    public abstract void onConnected();
    
    public abstract void onDisconnected();
  }
  
  public static abstract interface c
  {
    public abstract void a(int paramInt, Intent paramIntent);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.c
 * JD-Core Version:    0.7.0.1
 */