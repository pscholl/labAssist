package com.google.android.gms.analytics;

class x
  implements ab
{
  private final String mAction;
  private final long nf;
  private final int ng;
  private double nh;
  private long ni;
  private final Object nj = new Object();
  
  public x(int paramInt, long paramLong, String paramString)
  {
    this.ng = paramInt;
    this.nh = this.ng;
    this.nf = paramLong;
    this.mAction = paramString;
  }
  
  public x(String paramString)
  {
    this(60, 2000L, paramString);
  }
  
  public boolean aI()
  {
    synchronized (this.nj)
    {
      long l = System.currentTimeMillis();
      if (this.nh < this.ng)
      {
        double d = (l - this.ni) / this.nf;
        if (d > 0.0D) {
          this.nh = Math.min(this.ng, d + this.nh);
        }
      }
      this.ni = l;
      if (this.nh >= 1.0D)
      {
        this.nh -= 1.0D;
        return true;
      }
      y.w("Excessive " + this.mAction + " detected; call ignored.");
      return false;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.x
 * JD-Core Version:    0.7.0.1
 */