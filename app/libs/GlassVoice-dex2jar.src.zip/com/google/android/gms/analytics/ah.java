package com.google.android.gms.analytics;

import android.app.Activity;
import java.util.HashMap;
import java.util.Map;

class ah
  implements j
{
  String nZ;
  double oa = -1.0D;
  int ob = -1;
  int oc = -1;
  int od = -1;
  int oe = -1;
  Map<String, String> of = new HashMap();
  
  public boolean aY()
  {
    return this.nZ != null;
  }
  
  public String aZ()
  {
    return this.nZ;
  }
  
  public boolean ba()
  {
    return this.oa >= 0.0D;
  }
  
  public double bb()
  {
    return this.oa;
  }
  
  public boolean bc()
  {
    return this.ob >= 0;
  }
  
  public boolean bd()
  {
    return this.oc != -1;
  }
  
  public boolean be()
  {
    return this.oc == 1;
  }
  
  public boolean bf()
  {
    return this.od != -1;
  }
  
  public boolean bg()
  {
    return this.od == 1;
  }
  
  public boolean bh()
  {
    return this.oe == 1;
  }
  
  public String e(Activity paramActivity)
  {
    return o(paramActivity.getClass().getCanonicalName());
  }
  
  public int getSessionTimeout()
  {
    return this.ob;
  }
  
  public String o(String paramString)
  {
    String str = (String)this.of.get(paramString);
    if (str != null) {
      return str;
    }
    return paramString;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ah
 * JD-Core Version:    0.7.0.1
 */