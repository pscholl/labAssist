package com.google.android.gms.analytics;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class GoogleAnalytics
  extends TrackerHandler
{
  private static boolean mR;
  private static GoogleAnalytics mY;
  private f kA;
  private String kh;
  private String ki;
  private Context mContext;
  private boolean mS;
  private ad mT;
  private volatile Boolean mU = Boolean.valueOf(false);
  private Logger mV;
  private Set<a> mW;
  private boolean mX = false;
  
  protected GoogleAnalytics(Context paramContext)
  {
    this(paramContext, GAThread.getInstance(paramContext), GAServiceManager.getInstance());
  }
  
  private GoogleAnalytics(Context paramContext, f paramf, ad paramad)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException("context cannot be null");
    }
    this.mContext = paramContext.getApplicationContext();
    this.kA = paramf;
    this.mT = paramad;
    g.i(this.mContext);
    ac.i(this.mContext);
    h.i(this.mContext);
    this.mV = new l();
    this.mW = new HashSet();
    aD();
  }
  
  private Tracker a(Tracker paramTracker)
  {
    if (this.kh != null) {
      paramTracker.set("&an", this.kh);
    }
    if (this.ki != null) {
      paramTracker.set("&av", this.ki);
    }
    return paramTracker;
  }
  
  private void a(Activity paramActivity)
  {
    Iterator localIterator = this.mW.iterator();
    while (localIterator.hasNext()) {
      ((a)localIterator.next()).c(paramActivity);
    }
  }
  
  static GoogleAnalytics aC()
  {
    try
    {
      GoogleAnalytics localGoogleAnalytics = mY;
      return localGoogleAnalytics;
    }
    finally {}
  }
  
  private void aD()
  {
    if (mR) {}
    u localu;
    do
    {
      int i;
      do
      {
        Bundle localBundle;
        do
        {
          return;
          try
          {
            ApplicationInfo localApplicationInfo2 = this.mContext.getPackageManager().getApplicationInfo(this.mContext.getPackageName(), 129);
            localApplicationInfo1 = localApplicationInfo2;
          }
          catch (PackageManager.NameNotFoundException localNameNotFoundException)
          {
            ApplicationInfo localApplicationInfo1;
            for (;;)
            {
              y.v("PackageManager doesn't know about package: " + localNameNotFoundException);
              localApplicationInfo1 = null;
            }
            localBundle = localApplicationInfo1.metaData;
          }
          if (localApplicationInfo1 == null)
          {
            y.w("Couldn't get ApplicationInfo to load gloabl config.");
            return;
          }
        } while (localBundle == null);
        i = localBundle.getInt("com.google.android.gms.analytics.globalConfigResource");
      } while (i <= 0);
      localu = (u)new t(this.mContext).a(i);
    } while (localu == null);
    a(localu);
  }
  
  private void b(Activity paramActivity)
  {
    Iterator localIterator = this.mW.iterator();
    while (localIterator.hasNext()) {
      ((a)localIterator.next()).d(paramActivity);
    }
  }
  
  public static GoogleAnalytics getInstance(Context paramContext)
  {
    try
    {
      if (mY == null) {
        mY = new GoogleAnalytics(paramContext);
      }
      GoogleAnalytics localGoogleAnalytics = mY;
      return localGoogleAnalytics;
    }
    finally {}
  }
  
  private int k(String paramString)
  {
    String str = paramString.toLowerCase();
    if ("verbose".equals(str)) {
      return 0;
    }
    if ("info".equals(str)) {
      return 1;
    }
    if ("warning".equals(str)) {
      return 2;
    }
    if ("error".equals(str)) {
      return 3;
    }
    return -1;
  }
  
  void a(a parama)
  {
    this.mW.add(parama);
  }
  
  void a(u paramu)
  {
    y.v("Loading global config values.");
    if (paramu.as())
    {
      this.kh = paramu.at();
      y.v("app name loaded: " + this.kh);
    }
    if (paramu.au())
    {
      this.ki = paramu.av();
      y.v("app version loaded: " + this.ki);
    }
    if (paramu.aw())
    {
      int i = k(paramu.ax());
      if (i >= 0)
      {
        y.v("log level loaded: " + i);
        getLogger().setLogLevel(i);
      }
    }
    if (paramu.ay()) {
      this.mT.setLocalDispatchPeriod(paramu.az());
    }
    if (paramu.aA()) {
      setDryRun(paramu.aB());
    }
  }
  
  void b(a parama)
  {
    this.mW.remove(parama);
  }
  
  @Deprecated
  public void dispatchLocalHits()
  {
    this.mT.dispatchLocalHits();
  }
  
  public void enableAutoActivityReports(Application paramApplication)
  {
    if ((Build.VERSION.SDK_INT >= 14) && (!this.mX))
    {
      paramApplication.registerActivityLifecycleCallbacks(new b());
      this.mX = true;
    }
  }
  
  public boolean getAppOptOut()
  {
    s.ao().a(s.a.ms);
    return this.mU.booleanValue();
  }
  
  public Logger getLogger()
  {
    return this.mV;
  }
  
  public boolean isDryRunEnabled()
  {
    s.ao().a(s.a.mE);
    return this.mS;
  }
  
  public Tracker newTracker(int paramInt)
  {
    try
    {
      s.ao().a(s.a.mo);
      Tracker localTracker1 = new Tracker(null, this);
      if (paramInt > 0)
      {
        ah localah = (ah)new ag(this.mContext).a(paramInt);
        if (localah != null) {
          localTracker1.a(this.mContext, localah);
        }
      }
      Tracker localTracker2 = a(localTracker1);
      return localTracker2;
    }
    finally {}
  }
  
  public Tracker newTracker(String paramString)
  {
    try
    {
      s.ao().a(s.a.mo);
      Tracker localTracker = a(new Tracker(paramString, this));
      return localTracker;
    }
    finally {}
  }
  
  void overrideHostUrl(String paramString)
  {
    try
    {
      this.mT.overrideHostUrl(paramString);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void reportActivityStart(Activity paramActivity)
  {
    if (!this.mX) {
      a(paramActivity);
    }
  }
  
  public void reportActivityStop(Activity paramActivity)
  {
    if (!this.mX) {
      b(paramActivity);
    }
  }
  
  void sendHit(Map<String, String> paramMap)
  {
    if (paramMap == null) {
      try
      {
        throw new IllegalArgumentException("hit cannot be null");
      }
      finally {}
    }
    ai.a(paramMap, "&ul", ai.a(Locale.getDefault()));
    ai.a(paramMap, "&sr", ac.aP().getValue("&sr"));
    paramMap.put("&_u", s.ao().aq());
    s.ao().ap();
    this.kA.sendHit(paramMap);
  }
  
  public void setAppOptOut(boolean paramBoolean)
  {
    s.ao().a(s.a.mr);
    this.mU = Boolean.valueOf(paramBoolean);
    if (this.mU.booleanValue()) {
      this.kA.clearHits();
    }
  }
  
  public void setDryRun(boolean paramBoolean)
  {
    s.ao().a(s.a.mD);
    this.mS = paramBoolean;
  }
  
  @Deprecated
  public void setLocalDispatchPeriod(int paramInt)
  {
    this.mT.setLocalDispatchPeriod(paramInt);
  }
  
  public void setLogger(Logger paramLogger)
  {
    s.ao().a(s.a.mF);
    this.mV = paramLogger;
  }
  
  static abstract interface a
  {
    public abstract void c(Activity paramActivity);
    
    public abstract void d(Activity paramActivity);
  }
  
  class b
    implements Application.ActivityLifecycleCallbacks
  {
    b() {}
    
    public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {}
    
    public void onActivityDestroyed(Activity paramActivity) {}
    
    public void onActivityPaused(Activity paramActivity) {}
    
    public void onActivityResumed(Activity paramActivity) {}
    
    public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {}
    
    public void onActivityStarted(Activity paramActivity)
    {
      GoogleAnalytics.a(GoogleAnalytics.this, paramActivity);
    }
    
    public void onActivityStopped(Activity paramActivity)
    {
      GoogleAnalytics.b(GoogleAnalytics.this, paramActivity);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.GoogleAnalytics
 * JD-Core Version:    0.7.0.1
 */