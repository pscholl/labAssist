package com.google.android.gms.analytics;

import java.util.List;

abstract interface n
{
  public abstract boolean X();
  
  public abstract int a(List<v> paramList, z paramz, boolean paramBoolean);
  
  public abstract void overrideHostUrl(String paramString);
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.n
 * JD-Core Version:    0.7.0.1
 */