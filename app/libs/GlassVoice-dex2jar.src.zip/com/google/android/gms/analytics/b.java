package com.google.android.gms.analytics;

import com.google.android.gms.internal.z;
import java.util.List;
import java.util.Map;

abstract interface b
{
  public abstract void a(Map<String, String> paramMap, long paramLong, String paramString, List<z> paramList);
  
  public abstract void clearHits();
  
  public abstract void connect();
  
  public abstract void disconnect();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.b
 * JD-Core Version:    0.7.0.1
 */