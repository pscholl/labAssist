package com.google.android.gms.analytics;

import android.content.Context;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

class h
  implements m
{
  private static final Object jY = new Object();
  private static h km;
  private String kn;
  private boolean ko = false;
  private final Object kp = new Object();
  private final Context mContext;
  
  protected h(Context paramContext)
  {
    this.mContext = paramContext;
    U();
  }
  
  public static h R()
  {
    synchronized (jY)
    {
      h localh = km;
      return localh;
    }
  }
  
  private String S()
  {
    if (!this.ko) {}
    synchronized (this.kp)
    {
      if (!this.ko) {
        y.v("Waiting for clientId to load");
      }
      try
      {
        do
        {
          this.kp.wait();
        } while (!this.ko);
        y.v("Loaded clientId");
        return this.kn;
      }
      catch (InterruptedException localInterruptedException)
      {
        for (;;)
        {
          y.e("Exception while waiting for clientId: " + localInterruptedException);
        }
      }
    }
  }
  
  private void U()
  {
    new Thread("client_id_fetcher")
    {
      public void run()
      {
        synchronized (h.a(h.this))
        {
          h.a(h.this, h.this.V());
          h.a(h.this, true);
          h.a(h.this).notifyAll();
          return;
        }
      }
    }.start();
  }
  
  private boolean f(String paramString)
  {
    try
    {
      y.v("Storing clientId.");
      FileOutputStream localFileOutputStream = this.mContext.openFileOutput("gaClientId", 0);
      localFileOutputStream.write(paramString.getBytes());
      localFileOutputStream.close();
      return true;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      y.e("Error creating clientId file.");
      return false;
    }
    catch (IOException localIOException)
    {
      y.e("Error writing to clientId file.");
    }
    return false;
  }
  
  public static void i(Context paramContext)
  {
    synchronized (jY)
    {
      if (km == null) {
        km = new h(paramContext);
      }
      return;
    }
  }
  
  protected String T()
  {
    String str = UUID.randomUUID().toString().toLowerCase();
    try
    {
      if (!f(str)) {
        str = "0";
      }
      return str;
    }
    catch (Exception localException) {}
    return null;
  }
  
  String V()
  {
    Object localObject = null;
    try
    {
      localFileInputStream = this.mContext.openFileInput("gaClientId");
      byte[] arrayOfByte = new byte[''];
      int i = localFileInputStream.read(arrayOfByte, 0, 128);
      if (localFileInputStream.available() > 0)
      {
        y.e("clientId file seems corrupted, deleting it.");
        localFileInputStream.close();
        this.mContext.deleteFile("gaClientId");
      }
      for (;;)
      {
        if (localObject == null) {
          localObject = T();
        }
        return localObject;
        if (i > 0) {
          break;
        }
        y.e("clientId file seems empty, deleting it.");
        localFileInputStream.close();
        this.mContext.deleteFile("gaClientId");
        localObject = null;
      }
      str = new String(arrayOfByte, 0, i);
    }
    catch (IOException localIOException1)
    {
      for (;;)
      {
        try
        {
          FileInputStream localFileInputStream;
          localFileInputStream.close();
          localObject = str;
        }
        catch (IOException localIOException2)
        {
          localObject = str;
          continue;
        }
        catch (FileNotFoundException localFileNotFoundException2)
        {
          String str;
          localObject = str;
        }
        localIOException1 = localIOException1;
        y.e("Error reading clientId file, deleting it.");
        this.mContext.deleteFile("gaClientId");
      }
    }
    catch (FileNotFoundException localFileNotFoundException1)
    {
      for (;;)
      {
        localObject = null;
      }
    }
  }
  
  public boolean c(String paramString)
  {
    return "&cid".equals(paramString);
  }
  
  public String getValue(String paramString)
  {
    if ("&cid".equals(paramString)) {
      return S();
    }
    return null;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.h
 * JD-Core Version:    0.7.0.1
 */