package com.google.android.gms.analytics;

import android.content.Context;

class t
  extends k<u>
{
  public t(Context paramContext)
  {
    super(paramContext, new a());
  }
  
  private static class a
    implements k.a<u>
  {
    private final u mN = new u();
    
    public void a(String paramString, int paramInt)
    {
      if ("ga_dispatchPeriod".equals(paramString))
      {
        this.mN.mP = paramInt;
        return;
      }
      y.w("int configuration name not recognized:  " + paramString);
    }
    
    public u ar()
    {
      return this.mN;
    }
    
    public void b(String paramString1, String paramString2) {}
    
    public void c(String paramString1, String paramString2)
    {
      if ("ga_appName".equals(paramString1))
      {
        this.mN.kh = paramString2;
        return;
      }
      if ("ga_appVersion".equals(paramString1))
      {
        this.mN.ki = paramString2;
        return;
      }
      if ("ga_logLevel".equals(paramString1))
      {
        this.mN.mO = paramString2;
        return;
      }
      y.w("string configuration name not recognized:  " + paramString1);
    }
    
    public void c(String paramString, boolean paramBoolean)
    {
      if ("ga_dryRun".equals(paramString))
      {
        u localu = this.mN;
        if (paramBoolean) {}
        for (int i = 1;; i = 0)
        {
          localu.mQ = i;
          return;
        }
      }
      y.w("bool configuration name not recognized:  " + paramString);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.t
 * JD-Core Version:    0.7.0.1
 */