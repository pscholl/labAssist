package com.google.android.gms.glass.auth;

import android.content.Context;
import com.google.android.gms.auth.firstparty.dataservice.GoogleAccountDataServiceClient;
import com.google.common.base.Preconditions;
import com.google.common.base.Supplier;
import com.google.glass.inject.Provider;

public final class GoogleAccountDataServiceClientProvider
  extends Provider<GoogleAccountDataServiceClient>
{
  private static final GoogleAccountDataServiceClientProvider INSTANCE = new GoogleAccountDataServiceClientProvider();
  
  public static GoogleAccountDataServiceClientProvider getInstance()
  {
    return INSTANCE;
  }
  
  public GoogleAccountDataServiceClient get(final Context paramContext)
  {
    Preconditions.checkNotNull(paramContext, "null context");
    (GoogleAccountDataServiceClient)get(new Supplier()
    {
      public GoogleAccountDataServiceClient get()
      {
        return new GoogleAccountDataServiceClient(paramContext);
      }
    });
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.glass.auth.GoogleAccountDataServiceClientProvider
 * JD-Core Version:    0.7.0.1
 */