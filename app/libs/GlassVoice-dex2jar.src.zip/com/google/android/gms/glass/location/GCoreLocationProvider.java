package com.google.android.gms.glass.location;

import android.app.PendingIntent;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationRequest;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.MapMaker;
import com.google.glass.logging.FormattingLogger;
import com.google.glass.logging.FormattingLoggers;
import com.google.glass.predicates.Assert;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.PriorityBlockingQueue;

public class GCoreLocationProvider
{
  @VisibleForTesting
  static final String REMOTE_GPS_PROVIDER = "remote_gps";
  private static final FormattingLogger logger = ;
  private volatile boolean initialized;
  @VisibleForTesting
  ConcurrentMap<PendingIntent, Long> intentToRemoteGpsRequestIntervalsMap = new MapMaker().weakKeys().makeMap();
  @VisibleForTesting
  ConcurrentMap<com.google.android.gms.location.LocationListener, Long> listenerToRemoteGpsRequestIntervalsMap = new MapMaker().weakKeys().makeMap();
  private LocationClient locationClient;
  private LocationManager locationManager;
  @VisibleForTesting
  final GooglePlayServicesClient.ConnectionCallbacks locationServicesConnectionCallbacks = new GooglePlayServicesClient.ConnectionCallbacks()
  {
    public void onConnected(Bundle paramAnonymousBundle)
    {
      GCoreLocationProvider.logger.v("Connected to Google Play Services location services", new Object[0]);
      Iterator localIterator = GCoreLocationProvider.this.pendingLocationUpdateRequests.values().iterator();
      if (localIterator.hasNext())
      {
        GCoreLocationProvider.LocationUpdateParameters localLocationUpdateParameters = (GCoreLocationProvider.LocationUpdateParameters)localIterator.next();
        if (GCoreLocationProvider.LocationUpdateParameters.access$300(localLocationUpdateParameters) != null) {
          GCoreLocationProvider.this.locationClient.requestLocationUpdates(GCoreLocationProvider.LocationUpdateParameters.access$400(localLocationUpdateParameters), GCoreLocationProvider.LocationUpdateParameters.access$300(localLocationUpdateParameters));
        }
        for (;;)
        {
          GCoreLocationProvider.this.requestRemoteGpsIfNeeded(GCoreLocationProvider.LocationUpdateParameters.access$400(localLocationUpdateParameters), GCoreLocationProvider.LocationUpdateParameters.access$700(localLocationUpdateParameters), GCoreLocationProvider.LocationUpdateParameters.access$300(localLocationUpdateParameters));
          break;
          if (GCoreLocationProvider.LocationUpdateParameters.access$600(localLocationUpdateParameters) != null) {
            GCoreLocationProvider.this.locationClient.requestLocationUpdates(GCoreLocationProvider.LocationUpdateParameters.access$400(localLocationUpdateParameters), GCoreLocationProvider.LocationUpdateParameters.access$700(localLocationUpdateParameters), GCoreLocationProvider.LocationUpdateParameters.access$600(localLocationUpdateParameters));
          } else {
            GCoreLocationProvider.this.locationClient.requestLocationUpdates(GCoreLocationProvider.LocationUpdateParameters.access$400(localLocationUpdateParameters), GCoreLocationProvider.LocationUpdateParameters.access$700(localLocationUpdateParameters));
          }
        }
      }
      GCoreLocationProvider.this.pendingLocationUpdateRequests.clear();
    }
    
    public void onDisconnected()
    {
      GCoreLocationProvider.logger.v("Disconnected from Google Play Services location services", new Object[0]);
    }
  };
  private final GooglePlayServicesClient.OnConnectionFailedListener locationServicesConnectionFailedListener = new GooglePlayServicesClient.OnConnectionFailedListener()
  {
    public void onConnectionFailed(ConnectionResult paramAnonymousConnectionResult)
    {
      GCoreLocationProvider.logger.w("Could not connect to Google Play Services location services: %s", new Object[] { paramAnonymousConnectionResult });
    }
  };
  @VisibleForTesting
  ConcurrentMap<Object, LocationUpdateParameters> pendingLocationUpdateRequests = new MapMaker().weakValues().makeMap();
  @VisibleForTesting
  final android.location.LocationListener remoteGpsLocationListener = new android.location.LocationListener()
  {
    public void onLocationChanged(Location paramAnonymousLocation)
    {
      GCoreLocationProvider.logger.v("received remote gps: %s", new Object[] { paramAnonymousLocation });
      if (GCoreLocationProvider.this.isConnected())
      {
        GCoreLocationProvider.logger.v("inject remote gps location into FusionEngine", new Object[0]);
        GCoreLocationProvider.this.locationClient.injectLocation(paramAnonymousLocation, 1);
      }
    }
    
    public void onProviderDisabled(String paramAnonymousString) {}
    
    public void onProviderEnabled(String paramAnonymousString) {}
    
    public void onStatusChanged(String paramAnonymousString, int paramAnonymousInt, Bundle paramAnonymousBundle) {}
  };
  @VisibleForTesting
  PriorityBlockingQueue<Long> remoteGpsRequestIntervals = new PriorityBlockingQueue();
  
  public static GCoreLocationProvider getInstance()
  {
    return GCoreLocationProviderHolder.instance;
  }
  
  private void requestRemoteGpsIfNeeded(LocationRequest paramLocationRequest, com.google.android.gms.location.LocationListener paramLocationListener, PendingIntent paramPendingIntent)
  {
    if (paramLocationRequest.getPriority() != 100) {}
    long l;
    do
    {
      return;
      l = paramLocationRequest.getInterval();
      Long localLong = (Long)this.remoteGpsRequestIntervals.peek();
      if ((localLong == null) || (l < localLong.longValue()))
      {
        logger.v("requesting remote gps", new Object[0]);
        if (localLong != null) {
          this.locationManager.removeUpdates(this.remoteGpsLocationListener);
        }
        this.locationManager.requestLocationUpdates("remote_gps", l, 0.0F, this.remoteGpsLocationListener);
      }
      this.remoteGpsRequestIntervals.add(Long.valueOf(l));
      if (paramLocationListener != null)
      {
        this.listenerToRemoteGpsRequestIntervalsMap.put(paramLocationListener, Long.valueOf(l));
        return;
      }
    } while (paramPendingIntent == null);
    this.intentToRemoteGpsRequestIntervalsMap.put(paramPendingIntent, Long.valueOf(l));
  }
  
  private void restorePreviousRemoteGpsRequestIfNeeded(long paramLong)
  {
    if (this.remoteGpsRequestIntervals.isEmpty()) {
      logger.w("No active remote gps requests, but have an active gps request.", new Object[0]);
    }
    Long localLong;
    do
    {
      return;
      if (paramLong != ((Long)this.remoteGpsRequestIntervals.peek()).longValue()) {
        break;
      }
      this.locationManager.removeUpdates(this.remoteGpsLocationListener);
      this.remoteGpsRequestIntervals.poll();
      localLong = (Long)this.remoteGpsRequestIntervals.peek();
    } while (localLong == null);
    this.locationManager.requestLocationUpdates("remote_gps", localLong.longValue(), 0.0F, this.remoteGpsLocationListener);
    return;
    this.remoteGpsRequestIntervals.remove(Long.valueOf(paramLong));
  }
  
  private void warnNotConnected()
  {
    if (this.locationClient == null)
    {
      logger.w("Received location update request before init.", new Object[0]);
      return;
    }
    logger.w("Received location update request while disconnected from locationClient.", new Object[0]);
  }
  
  public Location getLastLocation()
  {
    if (isConnected()) {
      return this.locationClient.getLastLocation();
    }
    return null;
  }
  
  @VisibleForTesting
  LocationClient getLocationClient()
  {
    Assert.assertIsTest();
    return this.locationClient;
  }
  
  @VisibleForTesting
  LocationManager getLocationManager()
  {
    Assert.assertIsTest();
    return this.locationManager;
  }
  
  @VisibleForTesting
  PriorityBlockingQueue<Long> getRemoteGpsRequestIntervals()
  {
    Assert.assertIsTest();
    return this.remoteGpsRequestIntervals;
  }
  
  public void init(Context paramContext)
  {
    if (!this.initialized)
    {
      this.initialized = true;
      Context localContext = paramContext.getApplicationContext();
      this.locationClient = new LocationClient(localContext, this.locationServicesConnectionCallbacks, this.locationServicesConnectionFailedListener);
      this.locationClient.connect();
      this.locationManager = ((LocationManager)localContext.getSystemService("location"));
      return;
    }
    logger.w("Already initialized, skip init", new Object[0]);
  }
  
  public boolean isConnected()
  {
    return (this.locationClient != null) && (this.locationClient.isConnected());
  }
  
  @VisibleForTesting
  void reInitForTest(LocationManager paramLocationManager, LocationClient paramLocationClient)
  {
    Assert.assertIsTest();
    this.initialized = false;
    this.locationManager = paramLocationManager;
    this.locationClient = paramLocationClient;
    this.remoteGpsRequestIntervals.clear();
    this.listenerToRemoteGpsRequestIntervalsMap.clear();
    this.intentToRemoteGpsRequestIntervalsMap.clear();
    this.pendingLocationUpdateRequests.clear();
  }
  
  public void removeLocationUpdate(PendingIntent paramPendingIntent)
  {
    this.locationClient.removeLocationUpdates(paramPendingIntent);
    Long localLong = (Long)this.intentToRemoteGpsRequestIntervalsMap.remove(paramPendingIntent);
    if (localLong != null) {
      restorePreviousRemoteGpsRequestIfNeeded(localLong.longValue());
    }
  }
  
  public void removeLocationUpdate(com.google.android.gms.location.LocationListener paramLocationListener)
  {
    this.locationClient.removeLocationUpdates(paramLocationListener);
    Long localLong = (Long)this.listenerToRemoteGpsRequestIntervalsMap.remove(paramLocationListener);
    if (localLong != null) {
      restorePreviousRemoteGpsRequestIfNeeded(localLong.longValue());
    }
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, PendingIntent paramPendingIntent)
  {
    if (isConnected())
    {
      this.locationClient.requestLocationUpdates(paramLocationRequest, paramPendingIntent);
      requestRemoteGpsIfNeeded(paramLocationRequest, null, paramPendingIntent);
      return;
    }
    warnNotConnected();
    this.pendingLocationUpdateRequests.put(new Object(), new LocationUpdateParameters(paramLocationRequest, paramPendingIntent));
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, com.google.android.gms.location.LocationListener paramLocationListener)
  {
    if (isConnected())
    {
      this.locationClient.requestLocationUpdates(paramLocationRequest, paramLocationListener);
      requestRemoteGpsIfNeeded(paramLocationRequest, paramLocationListener, null);
      return;
    }
    warnNotConnected();
    this.pendingLocationUpdateRequests.put(new Object(), new LocationUpdateParameters(paramLocationRequest, paramLocationListener));
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, com.google.android.gms.location.LocationListener paramLocationListener, Looper paramLooper)
  {
    if (isConnected())
    {
      this.locationClient.requestLocationUpdates(paramLocationRequest, paramLocationListener, paramLooper);
      requestRemoteGpsIfNeeded(paramLocationRequest, paramLocationListener, null);
      return;
    }
    warnNotConnected();
    this.pendingLocationUpdateRequests.put(new Object(), new LocationUpdateParameters(paramLocationRequest, paramLocationListener, paramLooper));
  }
  
  private static class GCoreLocationProviderHolder
  {
    private static GCoreLocationProvider instance = new GCoreLocationProvider(null);
  }
  
  private class LocationUpdateParameters
  {
    private final com.google.android.gms.location.LocationListener listener;
    private final Looper looper;
    private final PendingIntent pendingIntent;
    private final LocationRequest request;
    
    LocationUpdateParameters(LocationRequest paramLocationRequest, PendingIntent paramPendingIntent)
    {
      this.request = paramLocationRequest;
      this.pendingIntent = paramPendingIntent;
      this.listener = null;
      this.looper = null;
    }
    
    LocationUpdateParameters(LocationRequest paramLocationRequest, com.google.android.gms.location.LocationListener paramLocationListener)
    {
      this(paramLocationRequest, paramLocationListener, null);
    }
    
    LocationUpdateParameters(LocationRequest paramLocationRequest, com.google.android.gms.location.LocationListener paramLocationListener, Looper paramLooper)
    {
      this.request = paramLocationRequest;
      this.listener = paramLocationListener;
      this.looper = paramLooper;
      this.pendingIntent = null;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.glass.location.GCoreLocationProvider
 * JD-Core Version:    0.7.0.1
 */