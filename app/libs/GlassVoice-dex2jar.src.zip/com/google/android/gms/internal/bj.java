package com.google.android.gms.internal;

public final class bj
  implements bi
{
  private static bj vr;
  
  public static bi cl()
  {
    try
    {
      if (vr == null) {
        vr = new bj();
      }
      bj localbj = vr;
      return localbj;
    }
    finally {}
  }
  
  public long currentTimeMillis()
  {
    return System.currentTimeMillis();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bj
 * JD-Core Version:    0.7.0.1
 */