package com.google.android.gms.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.location.places.PlaceType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.util.ArrayList;

public class ci
  implements Parcelable.Creator<ch>
{
  static void a(ch paramch, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.a(paramParcel, 1, paramch.getId(), false);
    b.a(paramParcel, 2, paramch.cH(), false);
    b.a(paramParcel, 3, paramch.cI(), paramInt, false);
    b.a(paramParcel, 4, paramch.getLatLng(), paramInt, false);
    b.a(paramParcel, 5, paramch.getLevelNumber());
    b.a(paramParcel, 6, paramch.getViewport(), paramInt, false);
    b.a(paramParcel, 7, paramch.cJ(), false);
    b.a(paramParcel, 8, paramch.getWebsiteUri(), paramInt, false);
    b.a(paramParcel, 9, paramch.isPermanentlyClosed());
    b.a(paramParcel, 10, paramch.getRating());
    b.c(paramParcel, 11, paramch.getPriceLevel());
    b.a(paramParcel, 12, paramch.cG());
    b.b(paramParcel, 13, paramch.getTypes(), false);
    b.c(paramParcel, 1000, paramch.oj);
    b.C(paramParcel, i);
  }
  
  public ch[] aT(int paramInt)
  {
    return new ch[paramInt];
  }
  
  public ch au(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    String str1 = null;
    ArrayList localArrayList = null;
    Bundle localBundle = null;
    cj localcj = null;
    LatLng localLatLng = null;
    float f1 = 0.0F;
    LatLngBounds localLatLngBounds = null;
    String str2 = null;
    Uri localUri = null;
    boolean bool = false;
    float f2 = 0.0F;
    int k = 0;
    long l = 0L;
    while (paramParcel.dataPosition() < i)
    {
      int m = a.X(paramParcel);
      switch (a.al(m))
      {
      default: 
        a.b(paramParcel, m);
        break;
      case 1: 
        str1 = a.l(paramParcel, m);
        break;
      case 2: 
        localBundle = a.n(paramParcel, m);
        break;
      case 3: 
        localcj = (cj)a.a(paramParcel, m, cj.CREATOR);
        break;
      case 4: 
        localLatLng = (LatLng)a.a(paramParcel, m, LatLng.CREATOR);
        break;
      case 5: 
        f1 = a.i(paramParcel, m);
        break;
      case 6: 
        localLatLngBounds = (LatLngBounds)a.a(paramParcel, m, LatLngBounds.CREATOR);
        break;
      case 7: 
        str2 = a.l(paramParcel, m);
        break;
      case 8: 
        localUri = (Uri)a.a(paramParcel, m, Uri.CREATOR);
        break;
      case 9: 
        bool = a.c(paramParcel, m);
        break;
      case 10: 
        f2 = a.i(paramParcel, m);
        break;
      case 11: 
        k = a.f(paramParcel, m);
        break;
      case 12: 
        l = a.g(paramParcel, m);
        break;
      case 13: 
        localArrayList = a.c(paramParcel, m, PlaceType.CREATOR);
        break;
      case 1000: 
        j = a.f(paramParcel, m);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new ch(j, str1, localArrayList, localBundle, localcj, localLatLng, f1, localLatLngBounds, str2, localUri, bool, f2, k, l);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ci
 * JD-Core Version:    0.7.0.1
 */