package com.google.android.gms.internal;

import android.accounts.Account;
import android.util.Log;

public class cq
{
  public static String a(Account paramAccount)
  {
    if (paramAccount == null) {
      return "null";
    }
    if (Log.isLoggable("GCoreUlr", 2)) {
      return paramAccount.name;
    }
    return "account#" + paramAccount.name.hashCode() % 20 + "#";
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cq
 * JD-Core Version:    0.7.0.1
 */