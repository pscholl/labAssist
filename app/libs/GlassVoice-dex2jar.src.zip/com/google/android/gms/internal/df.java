package com.google.android.gms.internal;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.common.data.b;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.model.Person;
import java.util.regex.Pattern;

public final class df
  extends b
  implements Person
{
  public static final String[] Ct = { "qualified_id", "gaia_id", "name", "sort_key", "sort_key_irank", "avatar", "profile_type", "v_circle_ids", "blocked", "in_viewer_domain", "last_modified", "name_verified", "given_name", "family_name" };
  private final Bundle sk;
  
  public df(d paramd, int paramInt, Bundle paramBundle)
  {
    super(paramd, paramInt);
    this.sk = paramBundle;
  }
  
  @Deprecated
  public String getAccountName()
  {
    return getOwnerAccountName();
  }
  
  public String getAvatarUrl()
  {
    return db.Bk.V(getString("avatar"));
  }
  
  public String[] getBelongingCircleIds()
  {
    String str = getString("v_circle_ids");
    if (TextUtils.isEmpty(str)) {
      return de.Cj;
    }
    return de.Ck.split(str, -1);
  }
  
  public String getFamilyName()
  {
    return getString("family_name");
  }
  
  public String getGaiaId()
  {
    return getString("gaia_id");
  }
  
  public String getGivenName()
  {
    return getString("given_name");
  }
  
  public int getInViewerDomain()
  {
    return getInteger("in_viewer_domain");
  }
  
  public String getInteractionRankSortKey()
  {
    return getString("sort_key_irank");
  }
  
  public long getLastModifiedTime()
  {
    return getLong("last_modified");
  }
  
  public String getName()
  {
    return getString("name");
  }
  
  public String getNameSortKey()
  {
    return getString("sort_key");
  }
  
  public String getOwnerAccountName()
  {
    return this.sk.getString("account");
  }
  
  public String getOwnerPlusPageId()
  {
    return this.sk.getString("pagegaiaid");
  }
  
  @Deprecated
  public String getPlusPageGaiaId()
  {
    return getOwnerPlusPageId();
  }
  
  public int getProfileType()
  {
    return getInteger("profile_type");
  }
  
  public String getQualifiedId()
  {
    return getString("qualified_id");
  }
  
  public boolean isBlocked()
  {
    return getInteger("blocked") != 0;
  }
  
  public boolean isNameVerified()
  {
    return getInteger("name_verified") != 0;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.df
 * JD-Core Version:    0.7.0.1
 */