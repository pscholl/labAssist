package com.google.android.gms.internal;

import java.io.IOException;
import java.util.List;

public abstract interface c
{
  public static final class a
    extends eb<a>
  {
    public int ek;
    public int el;
    public int level;
    
    public a()
    {
      a();
    }
    
    public a a()
    {
      this.level = 1;
      this.ek = 0;
      this.el = 0;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public a a(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          int j = paramdz.gd();
          switch (j)
          {
          default: 
            break;
          }
          this.level = j;
          break;
        case 16: 
          this.ek = paramdz.gd();
          break;
        }
        this.el = paramdz.gd();
      }
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      a locala;
      boolean bool3;
      do
      {
        int n;
        int i1;
        do
        {
          int k;
          int m;
          do
          {
            int i;
            int j;
            do
            {
              boolean bool1;
              do
              {
                return bool2;
                bool1 = paramObject instanceof a;
                bool2 = false;
              } while (!bool1);
              locala = (a)paramObject;
              i = this.level;
              j = locala.level;
              bool2 = false;
            } while (i != j);
            k = this.ek;
            m = locala.ek;
            bool2 = false;
          } while (k != m);
          n = this.el;
          i1 = locala.el;
          bool2 = false;
        } while (n != i1);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label140;
        }
        if (locala.Jd == null) {
          break;
        }
        bool3 = locala.Jd.isEmpty();
        bool2 = false;
      } while (!bool3);
      return true;
      label140:
      return this.Jd.equals(locala.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize();
      if (this.level != 1) {
        i += ea.e(1, this.level);
      }
      if (this.ek != 0) {
        i += ea.e(2, this.ek);
      }
      if (this.el != 0) {
        i += ea.e(3, this.el);
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i = 31 * (31 * (31 * (527 + this.level) + this.ek) + this.el);
      if ((this.Jd == null) || (this.Jd.isEmpty())) {}
      for (int j = 0;; j = this.Jd.hashCode()) {
        return j + i;
      }
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if (this.level != 1) {
        paramea.d(1, this.level);
      }
      if (this.ek != 0) {
        paramea.d(2, this.ek);
      }
      if (this.el != 0) {
        paramea.d(3, this.el);
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class b
    extends eb<b>
  {
    private static volatile b[] em;
    public int[] en;
    public int eo;
    public boolean ep;
    public boolean eq;
    public int name;
    
    public b()
    {
      c();
    }
    
    public static b[] b()
    {
      if (em == null) {}
      synchronized (ed.Jg)
      {
        if (em == null) {
          em = new b[0];
        }
        return em;
      }
    }
    
    public b b(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          this.eq = paramdz.ge();
          break;
        case 16: 
          this.eo = paramdz.gd();
          break;
        case 24: 
          int i1 = ei.b(paramdz, 24);
          if (this.en == null) {}
          int[] arrayOfInt2;
          for (int i2 = 0;; i2 = this.en.length)
          {
            arrayOfInt2 = new int[i1 + i2];
            if (i2 != 0) {
              System.arraycopy(this.en, 0, arrayOfInt2, 0, i2);
            }
            while (i2 < -1 + arrayOfInt2.length)
            {
              arrayOfInt2[i2] = paramdz.gd();
              paramdz.ga();
              i2++;
            }
          }
          arrayOfInt2[i2] = paramdz.gd();
          this.en = arrayOfInt2;
          break;
        case 26: 
          int j = paramdz.by(paramdz.gf());
          int k = paramdz.getPosition();
          for (int m = 0; paramdz.gk() > 0; m++) {
            paramdz.gd();
          }
          paramdz.bA(k);
          if (this.en == null) {}
          int[] arrayOfInt1;
          for (int n = 0;; n = this.en.length)
          {
            arrayOfInt1 = new int[m + n];
            if (n != 0) {
              System.arraycopy(this.en, 0, arrayOfInt1, 0, n);
            }
            while (n < arrayOfInt1.length)
            {
              arrayOfInt1[n] = paramdz.gd();
              n++;
            }
          }
          this.en = arrayOfInt1;
          paramdz.bz(j);
          break;
        case 32: 
          this.name = paramdz.gd();
          break;
        }
        this.ep = paramdz.ge();
      }
    }
    
    public b c()
    {
      this.en = ei.Jj;
      this.eo = 0;
      this.name = 0;
      this.ep = false;
      this.eq = false;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      b localb;
      boolean bool8;
      do
      {
        boolean bool6;
        boolean bool7;
        do
        {
          boolean bool4;
          boolean bool5;
          do
          {
            int k;
            int m;
            do
            {
              int i;
              int j;
              do
              {
                boolean bool3;
                do
                {
                  boolean bool1;
                  do
                  {
                    return bool2;
                    bool1 = paramObject instanceof b;
                    bool2 = false;
                  } while (!bool1);
                  localb = (b)paramObject;
                  bool3 = ed.equals(this.en, localb.en);
                  bool2 = false;
                } while (!bool3);
                i = this.eo;
                j = localb.eo;
                bool2 = false;
              } while (i != j);
              k = this.name;
              m = localb.name;
              bool2 = false;
            } while (k != m);
            bool4 = this.ep;
            bool5 = localb.ep;
            bool2 = false;
          } while (bool4 != bool5);
          bool6 = this.eq;
          bool7 = localb.eq;
          bool2 = false;
        } while (bool6 != bool7);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label183;
        }
        if (localb.Jd == null) {
          break;
        }
        bool8 = localb.Jd.isEmpty();
        bool2 = false;
      } while (!bool8);
      return true;
      label183:
      return this.Jd.equals(localb.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = super.getSerializedSize();
      if (this.eq) {
        j += ea.b(1, this.eq);
      }
      int k = j + ea.e(2, this.eo);
      if ((this.en != null) && (this.en.length > 0)) {
        for (int n = 0; n < this.en.length; n++) {
          i += ea.bE(this.en[n]);
        }
      }
      for (int m = k + i + 1 * this.en.length;; m = k)
      {
        if (this.name != 0) {
          m += ea.e(4, this.name);
        }
        if (this.ep) {
          m += ea.b(6, this.ep);
        }
        this.Jh = m;
        return m;
      }
    }
    
    public int hashCode()
    {
      int i = 1231;
      int j = 31 * (31 * (31 * (527 + ed.hashCode(this.en)) + this.eo) + this.name);
      int k;
      label59:
      int n;
      if (this.ep)
      {
        k = i;
        int m = 31 * (k + j);
        if (!this.eq) {
          break label103;
        }
        n = 31 * (m + i);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label110;
        }
      }
      label103:
      label110:
      for (int i1 = 0;; i1 = this.Jd.hashCode())
      {
        return i1 + n;
        k = 1237;
        break;
        i = 1237;
        break label59;
      }
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if (this.eq) {
        paramea.a(1, this.eq);
      }
      paramea.d(2, this.eo);
      if ((this.en != null) && (this.en.length > 0)) {
        for (int i = 0; i < this.en.length; i++) {
          paramea.d(3, this.en[i]);
        }
      }
      if (this.name != 0) {
        paramea.d(4, this.name);
      }
      if (this.ep) {
        paramea.a(6, this.ep);
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class c
    extends eb<c>
  {
    private static volatile c[] er;
    public long es;
    public long et;
    public boolean eu;
    public long ev;
    public String key;
    
    public c()
    {
      e();
    }
    
    public static c[] d()
    {
      if (er == null) {}
      synchronized (ed.Jg)
      {
        if (er == null) {
          er = new c[0];
        }
        return er;
      }
    }
    
    public c c(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 10: 
          this.key = paramdz.readString();
          break;
        case 16: 
          this.es = paramdz.gc();
          break;
        case 24: 
          this.et = paramdz.gc();
          break;
        case 32: 
          this.eu = paramdz.ge();
          break;
        }
        this.ev = paramdz.gc();
      }
    }
    
    public c e()
    {
      this.key = "";
      this.es = 0L;
      this.et = 2147483647L;
      this.eu = false;
      this.ev = 0L;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      c localc;
      do
      {
        boolean bool1;
        do
        {
          return bool2;
          bool1 = paramObject instanceof c;
          bool2 = false;
        } while (!bool1);
        localc = (c)paramObject;
        if (this.key != null) {
          break;
        }
        str = localc.key;
        bool2 = false;
      } while (str != null);
      while (this.key.equals(localc.key))
      {
        String str;
        boolean bool3 = this.es < localc.es;
        bool2 = false;
        if (bool3) {
          break;
        }
        boolean bool4 = this.et < localc.et;
        bool2 = false;
        if (bool4) {
          break;
        }
        boolean bool5 = this.eu;
        boolean bool6 = localc.eu;
        bool2 = false;
        if (bool5 != bool6) {
          break;
        }
        boolean bool7 = this.ev < localc.ev;
        bool2 = false;
        if (bool7) {
          break;
        }
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label191;
        }
        if (localc.Jd != null)
        {
          boolean bool8 = localc.Jd.isEmpty();
          bool2 = false;
          if (!bool8) {
            break;
          }
        }
        return true;
      }
      return false;
      label191:
      return this.Jd.equals(localc.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize();
      if (!this.key.equals("")) {
        i += ea.c(1, this.key);
      }
      if (this.es != 0L) {
        i += ea.c(2, this.es);
      }
      if (this.et != 2147483647L) {
        i += ea.c(3, this.et);
      }
      if (this.eu) {
        i += ea.b(4, this.eu);
      }
      if (this.ev != 0L) {
        i += ea.c(5, this.ev);
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i;
      int k;
      label63:
      int m;
      int n;
      if (this.key == null)
      {
        i = 0;
        int j = 31 * (31 * (31 * (i + 527) + (int)(this.es ^ this.es >>> 32)) + (int)(this.et ^ this.et >>> 32));
        if (!this.eu) {
          break label138;
        }
        k = 1231;
        m = 31 * (31 * (k + j) + (int)(this.ev ^ this.ev >>> 32));
        List localList = this.Jd;
        n = 0;
        if (localList != null)
        {
          boolean bool = this.Jd.isEmpty();
          n = 0;
          if (!bool) {
            break label145;
          }
        }
      }
      for (;;)
      {
        return m + n;
        i = this.key.hashCode();
        break;
        label138:
        k = 1237;
        break label63;
        label145:
        n = this.Jd.hashCode();
      }
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if (!this.key.equals("")) {
        paramea.b(1, this.key);
      }
      if (this.es != 0L) {
        paramea.b(2, this.es);
      }
      if (this.et != 2147483647L) {
        paramea.b(3, this.et);
      }
      if (this.eu) {
        paramea.a(4, this.eu);
      }
      if (this.ev != 0L) {
        paramea.b(5, this.ev);
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class d
    extends eb<d>
  {
    public d.a[] ew;
    public d.a[] ex;
    public c.c[] ey;
    
    public d()
    {
      f();
    }
    
    public d d(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 10: 
          int i1 = ei.b(paramdz, 10);
          if (this.ew == null) {}
          d.a[] arrayOfa2;
          for (int i2 = 0;; i2 = this.ew.length)
          {
            arrayOfa2 = new d.a[i1 + i2];
            if (i2 != 0) {
              System.arraycopy(this.ew, 0, arrayOfa2, 0, i2);
            }
            while (i2 < -1 + arrayOfa2.length)
            {
              arrayOfa2[i2] = new d.a();
              paramdz.a(arrayOfa2[i2]);
              paramdz.ga();
              i2++;
            }
          }
          arrayOfa2[i2] = new d.a();
          paramdz.a(arrayOfa2[i2]);
          this.ew = arrayOfa2;
          break;
        case 18: 
          int m = ei.b(paramdz, 18);
          if (this.ex == null) {}
          d.a[] arrayOfa1;
          for (int n = 0;; n = this.ex.length)
          {
            arrayOfa1 = new d.a[m + n];
            if (n != 0) {
              System.arraycopy(this.ex, 0, arrayOfa1, 0, n);
            }
            while (n < -1 + arrayOfa1.length)
            {
              arrayOfa1[n] = new d.a();
              paramdz.a(arrayOfa1[n]);
              paramdz.ga();
              n++;
            }
          }
          arrayOfa1[n] = new d.a();
          paramdz.a(arrayOfa1[n]);
          this.ex = arrayOfa1;
          break;
        }
        int j = ei.b(paramdz, 26);
        if (this.ey == null) {}
        c.c[] arrayOfc;
        for (int k = 0;; k = this.ey.length)
        {
          arrayOfc = new c.c[j + k];
          if (k != 0) {
            System.arraycopy(this.ey, 0, arrayOfc, 0, k);
          }
          while (k < -1 + arrayOfc.length)
          {
            arrayOfc[k] = new c.c();
            paramdz.a(arrayOfc[k]);
            paramdz.ga();
            k++;
          }
        }
        arrayOfc[k] = new c.c();
        paramdz.a(arrayOfc[k]);
        this.ey = arrayOfc;
      }
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      d locald;
      boolean bool6;
      do
      {
        boolean bool5;
        do
        {
          boolean bool4;
          do
          {
            boolean bool3;
            do
            {
              boolean bool1;
              do
              {
                return bool2;
                bool1 = paramObject instanceof d;
                bool2 = false;
              } while (!bool1);
              locald = (d)paramObject;
              bool3 = ed.equals(this.ew, locald.ew);
              bool2 = false;
            } while (!bool3);
            bool4 = ed.equals(this.ex, locald.ex);
            bool2 = false;
          } while (!bool4);
          bool5 = ed.equals(this.ey, locald.ey);
          bool2 = false;
        } while (!bool5);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label137;
        }
        if (locald.Jd == null) {
          break;
        }
        bool6 = locald.Jd.isEmpty();
        bool2 = false;
      } while (!bool6);
      return true;
      label137:
      return this.Jd.equals(locald.Jd);
    }
    
    public d f()
    {
      this.ew = d.a.p();
      this.ex = d.a.p();
      this.ey = c.c.d();
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize();
      if ((this.ew != null) && (this.ew.length > 0))
      {
        int i1 = i;
        for (int i2 = 0; i2 < this.ew.length; i2++)
        {
          d.a locala2 = this.ew[i2];
          if (locala2 != null) {
            i1 += ea.b(1, locala2);
          }
        }
        i = i1;
      }
      if ((this.ex != null) && (this.ex.length > 0))
      {
        int m = i;
        for (int n = 0; n < this.ex.length; n++)
        {
          d.a locala1 = this.ex[n];
          if (locala1 != null) {
            m += ea.b(2, locala1);
          }
        }
        i = m;
      }
      if (this.ey != null)
      {
        int j = this.ey.length;
        int k = 0;
        if (j > 0) {
          while (k < this.ey.length)
          {
            c.c localc = this.ey[k];
            if (localc != null) {
              i += ea.b(3, localc);
            }
            k++;
          }
        }
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i = 31 * (31 * (31 * (527 + ed.hashCode(this.ew)) + ed.hashCode(this.ex)) + ed.hashCode(this.ey));
      if ((this.Jd == null) || (this.Jd.isEmpty())) {}
      for (int j = 0;; j = this.Jd.hashCode()) {
        return j + i;
      }
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if ((this.ew != null) && (this.ew.length > 0)) {
        for (int m = 0; m < this.ew.length; m++)
        {
          d.a locala2 = this.ew[m];
          if (locala2 != null) {
            paramea.a(1, locala2);
          }
        }
      }
      if ((this.ex != null) && (this.ex.length > 0)) {
        for (int k = 0; k < this.ex.length; k++)
        {
          d.a locala1 = this.ex[k];
          if (locala1 != null) {
            paramea.a(2, locala1);
          }
        }
      }
      if (this.ey != null)
      {
        int i = this.ey.length;
        int j = 0;
        if (i > 0) {
          while (j < this.ey.length)
          {
            c.c localc = this.ey[j];
            if (localc != null) {
              paramea.a(3, localc);
            }
            j++;
          }
        }
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class e
    extends eb<e>
  {
    private static volatile e[] ez;
    public int key;
    public int value;
    
    public e()
    {
      h();
    }
    
    public static e[] g()
    {
      if (ez == null) {}
      synchronized (ed.Jg)
      {
        if (ez == null) {
          ez = new e[0];
        }
        return ez;
      }
    }
    
    public e e(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          this.key = paramdz.gd();
          break;
        }
        this.value = paramdz.gd();
      }
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      e locale;
      boolean bool3;
      do
      {
        int k;
        int m;
        do
        {
          int i;
          int j;
          do
          {
            boolean bool1;
            do
            {
              return bool2;
              bool1 = paramObject instanceof e;
              bool2 = false;
            } while (!bool1);
            locale = (e)paramObject;
            i = this.key;
            j = locale.key;
            bool2 = false;
          } while (i != j);
          k = this.value;
          m = locale.value;
          bool2 = false;
        } while (k != m);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label118;
        }
        if (locale.Jd == null) {
          break;
        }
        bool3 = locale.Jd.isEmpty();
        bool2 = false;
      } while (!bool3);
      return true;
      label118:
      return this.Jd.equals(locale.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize() + ea.e(1, this.key) + ea.e(2, this.value);
      this.Jh = i;
      return i;
    }
    
    public e h()
    {
      this.key = 0;
      this.value = 0;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public int hashCode()
    {
      int i = 31 * (31 * (527 + this.key) + this.value);
      if ((this.Jd == null) || (this.Jd.isEmpty())) {}
      for (int j = 0;; j = this.Jd.hashCode()) {
        return j + i;
      }
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      paramea.d(1, this.key);
      paramea.d(2, this.value);
      super.writeTo(paramea);
    }
  }
  
  public static final class f
    extends eb<f>
  {
    public String[] eA;
    public String[] eB;
    public d.a[] eC;
    public c.e[] eD;
    public c.b[] eE;
    public c.b[] eF;
    public c.b[] eG;
    public c.g[] eH;
    public String eI;
    public String eJ;
    public String eK;
    public c.a eL;
    public float eM;
    public boolean eN;
    public String[] eO;
    public int eP;
    public String version;
    
    public f()
    {
      i();
    }
    
    public static f a(byte[] paramArrayOfByte)
      throws ee
    {
      return (f)ef.mergeFrom(new f(), paramArrayOfByte);
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      f localf;
      label215:
      label236:
      do
      {
        String str1;
        do
        {
          String str2;
          do
          {
            String str3;
            do
            {
              String str4;
              do
              {
                boolean bool10;
                do
                {
                  boolean bool9;
                  do
                  {
                    boolean bool8;
                    do
                    {
                      boolean bool7;
                      do
                      {
                        boolean bool6;
                        do
                        {
                          boolean bool5;
                          do
                          {
                            boolean bool4;
                            do
                            {
                              boolean bool3;
                              do
                              {
                                boolean bool1;
                                do
                                {
                                  return bool2;
                                  bool1 = paramObject instanceof f;
                                  bool2 = false;
                                } while (!bool1);
                                localf = (f)paramObject;
                                bool3 = ed.equals(this.eA, localf.eA);
                                bool2 = false;
                              } while (!bool3);
                              bool4 = ed.equals(this.eB, localf.eB);
                              bool2 = false;
                            } while (!bool4);
                            bool5 = ed.equals(this.eC, localf.eC);
                            bool2 = false;
                          } while (!bool5);
                          bool6 = ed.equals(this.eD, localf.eD);
                          bool2 = false;
                        } while (!bool6);
                        bool7 = ed.equals(this.eE, localf.eE);
                        bool2 = false;
                      } while (!bool7);
                      bool8 = ed.equals(this.eF, localf.eF);
                      bool2 = false;
                    } while (!bool8);
                    bool9 = ed.equals(this.eG, localf.eG);
                    bool2 = false;
                  } while (!bool9);
                  bool10 = ed.equals(this.eH, localf.eH);
                  bool2 = false;
                } while (!bool10);
                if (this.eI != null) {
                  break;
                }
                str4 = localf.eI;
                bool2 = false;
              } while (str4 != null);
              if (this.eJ != null) {
                break label457;
              }
              str3 = localf.eJ;
              bool2 = false;
            } while (str3 != null);
            if (this.eK != null) {
              break label474;
            }
            str2 = localf.eK;
            bool2 = false;
          } while (str2 != null);
          if (this.version != null) {
            break label491;
          }
          str1 = localf.version;
          bool2 = false;
        } while (str1 != null);
        if (this.eL != null) {
          break label508;
        }
        locala = localf.eL;
        bool2 = false;
      } while (locala != null);
      label257:
      label278:
      label457:
      label474:
      label491:
      label508:
      while (this.eL.equals(localf.eL))
      {
        c.a locala;
        int i = Float.floatToIntBits(this.eM);
        int j = Float.floatToIntBits(localf.eM);
        bool2 = false;
        if (i != j) {
          break;
        }
        boolean bool11 = this.eN;
        boolean bool12 = localf.eN;
        bool2 = false;
        if (bool11 != bool12) {
          break;
        }
        boolean bool13 = ed.equals(this.eO, localf.eO);
        bool2 = false;
        if (!bool13) {
          break;
        }
        int k = this.eP;
        int m = localf.eP;
        bool2 = false;
        if (k != m) {
          break;
        }
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label525;
        }
        if (localf.Jd != null)
        {
          boolean bool14 = localf.Jd.isEmpty();
          bool2 = false;
          if (!bool14) {
            break;
          }
        }
        return true;
        if (this.eI.equals(localf.eI)) {
          break label215;
        }
        return false;
        if (this.eJ.equals(localf.eJ)) {
          break label236;
        }
        return false;
        if (this.eK.equals(localf.eK)) {
          break label257;
        }
        return false;
        if (this.version.equals(localf.version)) {
          break label278;
        }
        return false;
      }
      return false;
      label525:
      return this.Jd.equals(localf.Jd);
    }
    
    public f f(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 10: 
          int i13 = ei.b(paramdz, 10);
          if (this.eB == null) {}
          String[] arrayOfString3;
          for (int i14 = 0;; i14 = this.eB.length)
          {
            arrayOfString3 = new String[i13 + i14];
            if (i14 != 0) {
              System.arraycopy(this.eB, 0, arrayOfString3, 0, i14);
            }
            while (i14 < -1 + arrayOfString3.length)
            {
              arrayOfString3[i14] = paramdz.readString();
              paramdz.ga();
              i14++;
            }
          }
          arrayOfString3[i14] = paramdz.readString();
          this.eB = arrayOfString3;
          break;
        case 18: 
          int i11 = ei.b(paramdz, 18);
          if (this.eC == null) {}
          d.a[] arrayOfa;
          for (int i12 = 0;; i12 = this.eC.length)
          {
            arrayOfa = new d.a[i11 + i12];
            if (i12 != 0) {
              System.arraycopy(this.eC, 0, arrayOfa, 0, i12);
            }
            while (i12 < -1 + arrayOfa.length)
            {
              arrayOfa[i12] = new d.a();
              paramdz.a(arrayOfa[i12]);
              paramdz.ga();
              i12++;
            }
          }
          arrayOfa[i12] = new d.a();
          paramdz.a(arrayOfa[i12]);
          this.eC = arrayOfa;
          break;
        case 26: 
          int i9 = ei.b(paramdz, 26);
          if (this.eD == null) {}
          c.e[] arrayOfe;
          for (int i10 = 0;; i10 = this.eD.length)
          {
            arrayOfe = new c.e[i9 + i10];
            if (i10 != 0) {
              System.arraycopy(this.eD, 0, arrayOfe, 0, i10);
            }
            while (i10 < -1 + arrayOfe.length)
            {
              arrayOfe[i10] = new c.e();
              paramdz.a(arrayOfe[i10]);
              paramdz.ga();
              i10++;
            }
          }
          arrayOfe[i10] = new c.e();
          paramdz.a(arrayOfe[i10]);
          this.eD = arrayOfe;
          break;
        case 34: 
          int i7 = ei.b(paramdz, 34);
          if (this.eE == null) {}
          c.b[] arrayOfb3;
          for (int i8 = 0;; i8 = this.eE.length)
          {
            arrayOfb3 = new c.b[i7 + i8];
            if (i8 != 0) {
              System.arraycopy(this.eE, 0, arrayOfb3, 0, i8);
            }
            while (i8 < -1 + arrayOfb3.length)
            {
              arrayOfb3[i8] = new c.b();
              paramdz.a(arrayOfb3[i8]);
              paramdz.ga();
              i8++;
            }
          }
          arrayOfb3[i8] = new c.b();
          paramdz.a(arrayOfb3[i8]);
          this.eE = arrayOfb3;
          break;
        case 42: 
          int i5 = ei.b(paramdz, 42);
          if (this.eF == null) {}
          c.b[] arrayOfb2;
          for (int i6 = 0;; i6 = this.eF.length)
          {
            arrayOfb2 = new c.b[i5 + i6];
            if (i6 != 0) {
              System.arraycopy(this.eF, 0, arrayOfb2, 0, i6);
            }
            while (i6 < -1 + arrayOfb2.length)
            {
              arrayOfb2[i6] = new c.b();
              paramdz.a(arrayOfb2[i6]);
              paramdz.ga();
              i6++;
            }
          }
          arrayOfb2[i6] = new c.b();
          paramdz.a(arrayOfb2[i6]);
          this.eF = arrayOfb2;
          break;
        case 50: 
          int i3 = ei.b(paramdz, 50);
          if (this.eG == null) {}
          c.b[] arrayOfb1;
          for (int i4 = 0;; i4 = this.eG.length)
          {
            arrayOfb1 = new c.b[i3 + i4];
            if (i4 != 0) {
              System.arraycopy(this.eG, 0, arrayOfb1, 0, i4);
            }
            while (i4 < -1 + arrayOfb1.length)
            {
              arrayOfb1[i4] = new c.b();
              paramdz.a(arrayOfb1[i4]);
              paramdz.ga();
              i4++;
            }
          }
          arrayOfb1[i4] = new c.b();
          paramdz.a(arrayOfb1[i4]);
          this.eG = arrayOfb1;
          break;
        case 58: 
          int i1 = ei.b(paramdz, 58);
          if (this.eH == null) {}
          c.g[] arrayOfg;
          for (int i2 = 0;; i2 = this.eH.length)
          {
            arrayOfg = new c.g[i1 + i2];
            if (i2 != 0) {
              System.arraycopy(this.eH, 0, arrayOfg, 0, i2);
            }
            while (i2 < -1 + arrayOfg.length)
            {
              arrayOfg[i2] = new c.g();
              paramdz.a(arrayOfg[i2]);
              paramdz.ga();
              i2++;
            }
          }
          arrayOfg[i2] = new c.g();
          paramdz.a(arrayOfg[i2]);
          this.eH = arrayOfg;
          break;
        case 74: 
          this.eI = paramdz.readString();
          break;
        case 82: 
          this.eJ = paramdz.readString();
          break;
        case 98: 
          this.eK = paramdz.readString();
          break;
        case 106: 
          this.version = paramdz.readString();
          break;
        case 114: 
          if (this.eL == null) {
            this.eL = new c.a();
          }
          paramdz.a(this.eL);
          break;
        case 125: 
          this.eM = paramdz.readFloat();
          break;
        case 130: 
          int m = ei.b(paramdz, 130);
          if (this.eO == null) {}
          String[] arrayOfString2;
          for (int n = 0;; n = this.eO.length)
          {
            arrayOfString2 = new String[m + n];
            if (n != 0) {
              System.arraycopy(this.eO, 0, arrayOfString2, 0, n);
            }
            while (n < -1 + arrayOfString2.length)
            {
              arrayOfString2[n] = paramdz.readString();
              paramdz.ga();
              n++;
            }
          }
          arrayOfString2[n] = paramdz.readString();
          this.eO = arrayOfString2;
          break;
        case 136: 
          this.eP = paramdz.gd();
          break;
        case 144: 
          this.eN = paramdz.ge();
          break;
        }
        int j = ei.b(paramdz, 154);
        if (this.eA == null) {}
        String[] arrayOfString1;
        for (int k = 0;; k = this.eA.length)
        {
          arrayOfString1 = new String[j + k];
          if (k != 0) {
            System.arraycopy(this.eA, 0, arrayOfString1, 0, k);
          }
          while (k < -1 + arrayOfString1.length)
          {
            arrayOfString1[k] = paramdz.readString();
            paramdz.ga();
            k++;
          }
        }
        arrayOfString1[k] = paramdz.readString();
        this.eA = arrayOfString1;
      }
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = super.getSerializedSize();
      int i17;
      int i18;
      if ((this.eB != null) && (this.eB.length > 0))
      {
        int i16 = 0;
        i17 = 0;
        i18 = 0;
        while (i16 < this.eB.length)
        {
          String str3 = this.eB[i16];
          if (str3 != null)
          {
            i18++;
            i17 += ea.be(str3);
          }
          i16++;
        }
      }
      for (int k = j + i17 + i18 * 1;; k = j)
      {
        if ((this.eC != null) && (this.eC.length > 0))
        {
          int i14 = k;
          for (int i15 = 0; i15 < this.eC.length; i15++)
          {
            d.a locala = this.eC[i15];
            if (locala != null) {
              i14 += ea.b(2, locala);
            }
          }
          k = i14;
        }
        if ((this.eD != null) && (this.eD.length > 0))
        {
          int i12 = k;
          for (int i13 = 0; i13 < this.eD.length; i13++)
          {
            c.e locale = this.eD[i13];
            if (locale != null) {
              i12 += ea.b(3, locale);
            }
          }
          k = i12;
        }
        if ((this.eE != null) && (this.eE.length > 0))
        {
          int i10 = k;
          for (int i11 = 0; i11 < this.eE.length; i11++)
          {
            c.b localb3 = this.eE[i11];
            if (localb3 != null) {
              i10 += ea.b(4, localb3);
            }
          }
          k = i10;
        }
        if ((this.eF != null) && (this.eF.length > 0))
        {
          int i8 = k;
          for (int i9 = 0; i9 < this.eF.length; i9++)
          {
            c.b localb2 = this.eF[i9];
            if (localb2 != null) {
              i8 += ea.b(5, localb2);
            }
          }
          k = i8;
        }
        if ((this.eG != null) && (this.eG.length > 0))
        {
          int i6 = k;
          for (int i7 = 0; i7 < this.eG.length; i7++)
          {
            c.b localb1 = this.eG[i7];
            if (localb1 != null) {
              i6 += ea.b(6, localb1);
            }
          }
          k = i6;
        }
        if ((this.eH != null) && (this.eH.length > 0))
        {
          int i4 = k;
          for (int i5 = 0; i5 < this.eH.length; i5++)
          {
            c.g localg = this.eH[i5];
            if (localg != null) {
              i4 += ea.b(7, localg);
            }
          }
          k = i4;
        }
        if (!this.eI.equals("")) {
          k += ea.c(9, this.eI);
        }
        if (!this.eJ.equals("")) {
          k += ea.c(10, this.eJ);
        }
        if (!this.eK.equals("0")) {
          k += ea.c(12, this.eK);
        }
        if (!this.version.equals("")) {
          k += ea.c(13, this.version);
        }
        if (this.eL != null) {
          k += ea.b(14, this.eL);
        }
        if (Float.floatToIntBits(this.eM) != Float.floatToIntBits(0.0F)) {
          k += ea.b(15, this.eM);
        }
        if ((this.eO != null) && (this.eO.length > 0))
        {
          int i1 = 0;
          int i2 = 0;
          int i3 = 0;
          while (i1 < this.eO.length)
          {
            String str2 = this.eO[i1];
            if (str2 != null)
            {
              i3++;
              i2 += ea.be(str2);
            }
            i1++;
          }
          k = k + i2 + i3 * 2;
        }
        if (this.eP != 0) {
          k += ea.e(17, this.eP);
        }
        if (this.eN) {
          k += ea.b(18, this.eN);
        }
        if ((this.eA != null) && (this.eA.length > 0))
        {
          int m = 0;
          int n = 0;
          while (i < this.eA.length)
          {
            String str1 = this.eA[i];
            if (str1 != null)
            {
              n++;
              m += ea.be(str1);
            }
            i++;
          }
          k = k + m + n * 2;
        }
        this.Jh = k;
        return k;
      }
    }
    
    public int hashCode()
    {
      int i = 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (527 + ed.hashCode(this.eA)) + ed.hashCode(this.eB)) + ed.hashCode(this.eC)) + ed.hashCode(this.eD)) + ed.hashCode(this.eE)) + ed.hashCode(this.eF)) + ed.hashCode(this.eG)) + ed.hashCode(this.eH));
      int j;
      int m;
      label118:
      int i1;
      label137:
      int i3;
      label157:
      int i5;
      label177:
      int i7;
      label210:
      int i8;
      int i9;
      if (this.eI == null)
      {
        j = 0;
        int k = 31 * (j + i);
        if (this.eJ != null) {
          break label289;
        }
        m = 0;
        int n = 31 * (m + k);
        if (this.eK != null) {
          break label301;
        }
        i1 = 0;
        int i2 = 31 * (i1 + n);
        if (this.version != null) {
          break label313;
        }
        i3 = 0;
        int i4 = 31 * (i3 + i2);
        if (this.eL != null) {
          break label325;
        }
        i5 = 0;
        int i6 = 31 * (31 * (i5 + i4) + Float.floatToIntBits(this.eM));
        if (!this.eN) {
          break label337;
        }
        i7 = 1231;
        i8 = 31 * (31 * (31 * (i7 + i6) + ed.hashCode(this.eO)) + this.eP);
        List localList = this.Jd;
        i9 = 0;
        if (localList != null)
        {
          boolean bool = this.Jd.isEmpty();
          i9 = 0;
          if (!bool) {
            break label345;
          }
        }
      }
      for (;;)
      {
        return i8 + i9;
        j = this.eI.hashCode();
        break;
        label289:
        m = this.eJ.hashCode();
        break label118;
        label301:
        i1 = this.eK.hashCode();
        break label137;
        label313:
        i3 = this.version.hashCode();
        break label157;
        label325:
        i5 = this.eL.hashCode();
        break label177;
        label337:
        i7 = 1237;
        break label210;
        label345:
        i9 = this.Jd.hashCode();
      }
    }
    
    public f i()
    {
      this.eA = ei.Jo;
      this.eB = ei.Jo;
      this.eC = d.a.p();
      this.eD = c.e.g();
      this.eE = c.b.b();
      this.eF = c.b.b();
      this.eG = c.b.b();
      this.eH = c.g.j();
      this.eI = "";
      this.eJ = "";
      this.eK = "0";
      this.version = "";
      this.eL = null;
      this.eM = 0.0F;
      this.eN = false;
      this.eO = ei.Jo;
      this.eP = 0;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if ((this.eB != null) && (this.eB.length > 0)) {
        for (int i5 = 0; i5 < this.eB.length; i5++)
        {
          String str3 = this.eB[i5];
          if (str3 != null) {
            paramea.b(1, str3);
          }
        }
      }
      if ((this.eC != null) && (this.eC.length > 0)) {
        for (int i4 = 0; i4 < this.eC.length; i4++)
        {
          d.a locala = this.eC[i4];
          if (locala != null) {
            paramea.a(2, locala);
          }
        }
      }
      if ((this.eD != null) && (this.eD.length > 0)) {
        for (int i3 = 0; i3 < this.eD.length; i3++)
        {
          c.e locale = this.eD[i3];
          if (locale != null) {
            paramea.a(3, locale);
          }
        }
      }
      if ((this.eE != null) && (this.eE.length > 0)) {
        for (int i2 = 0; i2 < this.eE.length; i2++)
        {
          c.b localb3 = this.eE[i2];
          if (localb3 != null) {
            paramea.a(4, localb3);
          }
        }
      }
      if ((this.eF != null) && (this.eF.length > 0)) {
        for (int i1 = 0; i1 < this.eF.length; i1++)
        {
          c.b localb2 = this.eF[i1];
          if (localb2 != null) {
            paramea.a(5, localb2);
          }
        }
      }
      if ((this.eG != null) && (this.eG.length > 0)) {
        for (int n = 0; n < this.eG.length; n++)
        {
          c.b localb1 = this.eG[n];
          if (localb1 != null) {
            paramea.a(6, localb1);
          }
        }
      }
      if ((this.eH != null) && (this.eH.length > 0)) {
        for (int m = 0; m < this.eH.length; m++)
        {
          c.g localg = this.eH[m];
          if (localg != null) {
            paramea.a(7, localg);
          }
        }
      }
      if (!this.eI.equals("")) {
        paramea.b(9, this.eI);
      }
      if (!this.eJ.equals("")) {
        paramea.b(10, this.eJ);
      }
      if (!this.eK.equals("0")) {
        paramea.b(12, this.eK);
      }
      if (!this.version.equals("")) {
        paramea.b(13, this.version);
      }
      if (this.eL != null) {
        paramea.a(14, this.eL);
      }
      if (Float.floatToIntBits(this.eM) != Float.floatToIntBits(0.0F)) {
        paramea.a(15, this.eM);
      }
      if ((this.eO != null) && (this.eO.length > 0)) {
        for (int k = 0; k < this.eO.length; k++)
        {
          String str2 = this.eO[k];
          if (str2 != null) {
            paramea.b(16, str2);
          }
        }
      }
      if (this.eP != 0) {
        paramea.d(17, this.eP);
      }
      if (this.eN) {
        paramea.a(18, this.eN);
      }
      if (this.eA != null)
      {
        int i = this.eA.length;
        int j = 0;
        if (i > 0) {
          while (j < this.eA.length)
          {
            String str1 = this.eA[j];
            if (str1 != null) {
              paramea.b(19, str1);
            }
            j++;
          }
        }
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class g
    extends eb<g>
  {
    private static volatile g[] eQ;
    public int[] eR;
    public int[] eS;
    public int[] eT;
    public int[] eU;
    public int[] eV;
    public int[] eW;
    public int[] eX;
    public int[] eY;
    public int[] eZ;
    public int[] fa;
    
    public g()
    {
      k();
    }
    
    public static g[] j()
    {
      if (eQ == null) {}
      synchronized (ed.Jg)
      {
        if (eQ == null) {
          eQ = new g[0];
        }
        return eQ;
      }
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      g localg;
      boolean bool13;
      do
      {
        boolean bool12;
        do
        {
          boolean bool11;
          do
          {
            boolean bool10;
            do
            {
              boolean bool9;
              do
              {
                boolean bool8;
                do
                {
                  boolean bool7;
                  do
                  {
                    boolean bool6;
                    do
                    {
                      boolean bool5;
                      do
                      {
                        boolean bool4;
                        do
                        {
                          boolean bool3;
                          do
                          {
                            boolean bool1;
                            do
                            {
                              return bool2;
                              bool1 = paramObject instanceof g;
                              bool2 = false;
                            } while (!bool1);
                            localg = (g)paramObject;
                            bool3 = ed.equals(this.eR, localg.eR);
                            bool2 = false;
                          } while (!bool3);
                          bool4 = ed.equals(this.eS, localg.eS);
                          bool2 = false;
                        } while (!bool4);
                        bool5 = ed.equals(this.eT, localg.eT);
                        bool2 = false;
                      } while (!bool5);
                      bool6 = ed.equals(this.eU, localg.eU);
                      bool2 = false;
                    } while (!bool6);
                    bool7 = ed.equals(this.eV, localg.eV);
                    bool2 = false;
                  } while (!bool7);
                  bool8 = ed.equals(this.eW, localg.eW);
                  bool2 = false;
                } while (!bool8);
                bool9 = ed.equals(this.eX, localg.eX);
                bool2 = false;
              } while (!bool9);
              bool10 = ed.equals(this.eY, localg.eY);
              bool2 = false;
            } while (!bool10);
            bool11 = ed.equals(this.eZ, localg.eZ);
            bool2 = false;
          } while (!bool11);
          bool12 = ed.equals(this.fa, localg.fa);
          bool2 = false;
        } while (!bool12);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label284;
        }
        if (localg.Jd == null) {
          break;
        }
        bool13 = localg.Jd.isEmpty();
        bool2 = false;
      } while (!bool13);
      return true;
      label284:
      return this.Jd.equals(localg.Jd);
    }
    
    public g g(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          int i55 = ei.b(paramdz, 8);
          if (this.eR == null) {}
          int[] arrayOfInt20;
          for (int i56 = 0;; i56 = this.eR.length)
          {
            arrayOfInt20 = new int[i55 + i56];
            if (i56 != 0) {
              System.arraycopy(this.eR, 0, arrayOfInt20, 0, i56);
            }
            while (i56 < -1 + arrayOfInt20.length)
            {
              arrayOfInt20[i56] = paramdz.gd();
              paramdz.ga();
              i56++;
            }
          }
          arrayOfInt20[i56] = paramdz.gd();
          this.eR = arrayOfInt20;
          break;
        case 10: 
          int i51 = paramdz.by(paramdz.gf());
          int i52 = paramdz.getPosition();
          for (int i53 = 0; paramdz.gk() > 0; i53++) {
            paramdz.gd();
          }
          paramdz.bA(i52);
          if (this.eR == null) {}
          int[] arrayOfInt19;
          for (int i54 = 0;; i54 = this.eR.length)
          {
            arrayOfInt19 = new int[i53 + i54];
            if (i54 != 0) {
              System.arraycopy(this.eR, 0, arrayOfInt19, 0, i54);
            }
            while (i54 < arrayOfInt19.length)
            {
              arrayOfInt19[i54] = paramdz.gd();
              i54++;
            }
          }
          this.eR = arrayOfInt19;
          paramdz.bz(i51);
          break;
        case 16: 
          int i49 = ei.b(paramdz, 16);
          if (this.eS == null) {}
          int[] arrayOfInt18;
          for (int i50 = 0;; i50 = this.eS.length)
          {
            arrayOfInt18 = new int[i49 + i50];
            if (i50 != 0) {
              System.arraycopy(this.eS, 0, arrayOfInt18, 0, i50);
            }
            while (i50 < -1 + arrayOfInt18.length)
            {
              arrayOfInt18[i50] = paramdz.gd();
              paramdz.ga();
              i50++;
            }
          }
          arrayOfInt18[i50] = paramdz.gd();
          this.eS = arrayOfInt18;
          break;
        case 18: 
          int i45 = paramdz.by(paramdz.gf());
          int i46 = paramdz.getPosition();
          for (int i47 = 0; paramdz.gk() > 0; i47++) {
            paramdz.gd();
          }
          paramdz.bA(i46);
          if (this.eS == null) {}
          int[] arrayOfInt17;
          for (int i48 = 0;; i48 = this.eS.length)
          {
            arrayOfInt17 = new int[i47 + i48];
            if (i48 != 0) {
              System.arraycopy(this.eS, 0, arrayOfInt17, 0, i48);
            }
            while (i48 < arrayOfInt17.length)
            {
              arrayOfInt17[i48] = paramdz.gd();
              i48++;
            }
          }
          this.eS = arrayOfInt17;
          paramdz.bz(i45);
          break;
        case 24: 
          int i43 = ei.b(paramdz, 24);
          if (this.eT == null) {}
          int[] arrayOfInt16;
          for (int i44 = 0;; i44 = this.eT.length)
          {
            arrayOfInt16 = new int[i43 + i44];
            if (i44 != 0) {
              System.arraycopy(this.eT, 0, arrayOfInt16, 0, i44);
            }
            while (i44 < -1 + arrayOfInt16.length)
            {
              arrayOfInt16[i44] = paramdz.gd();
              paramdz.ga();
              i44++;
            }
          }
          arrayOfInt16[i44] = paramdz.gd();
          this.eT = arrayOfInt16;
          break;
        case 26: 
          int i39 = paramdz.by(paramdz.gf());
          int i40 = paramdz.getPosition();
          for (int i41 = 0; paramdz.gk() > 0; i41++) {
            paramdz.gd();
          }
          paramdz.bA(i40);
          if (this.eT == null) {}
          int[] arrayOfInt15;
          for (int i42 = 0;; i42 = this.eT.length)
          {
            arrayOfInt15 = new int[i41 + i42];
            if (i42 != 0) {
              System.arraycopy(this.eT, 0, arrayOfInt15, 0, i42);
            }
            while (i42 < arrayOfInt15.length)
            {
              arrayOfInt15[i42] = paramdz.gd();
              i42++;
            }
          }
          this.eT = arrayOfInt15;
          paramdz.bz(i39);
          break;
        case 32: 
          int i37 = ei.b(paramdz, 32);
          if (this.eU == null) {}
          int[] arrayOfInt14;
          for (int i38 = 0;; i38 = this.eU.length)
          {
            arrayOfInt14 = new int[i37 + i38];
            if (i38 != 0) {
              System.arraycopy(this.eU, 0, arrayOfInt14, 0, i38);
            }
            while (i38 < -1 + arrayOfInt14.length)
            {
              arrayOfInt14[i38] = paramdz.gd();
              paramdz.ga();
              i38++;
            }
          }
          arrayOfInt14[i38] = paramdz.gd();
          this.eU = arrayOfInt14;
          break;
        case 34: 
          int i33 = paramdz.by(paramdz.gf());
          int i34 = paramdz.getPosition();
          for (int i35 = 0; paramdz.gk() > 0; i35++) {
            paramdz.gd();
          }
          paramdz.bA(i34);
          if (this.eU == null) {}
          int[] arrayOfInt13;
          for (int i36 = 0;; i36 = this.eU.length)
          {
            arrayOfInt13 = new int[i35 + i36];
            if (i36 != 0) {
              System.arraycopy(this.eU, 0, arrayOfInt13, 0, i36);
            }
            while (i36 < arrayOfInt13.length)
            {
              arrayOfInt13[i36] = paramdz.gd();
              i36++;
            }
          }
          this.eU = arrayOfInt13;
          paramdz.bz(i33);
          break;
        case 40: 
          int i31 = ei.b(paramdz, 40);
          if (this.eV == null) {}
          int[] arrayOfInt12;
          for (int i32 = 0;; i32 = this.eV.length)
          {
            arrayOfInt12 = new int[i31 + i32];
            if (i32 != 0) {
              System.arraycopy(this.eV, 0, arrayOfInt12, 0, i32);
            }
            while (i32 < -1 + arrayOfInt12.length)
            {
              arrayOfInt12[i32] = paramdz.gd();
              paramdz.ga();
              i32++;
            }
          }
          arrayOfInt12[i32] = paramdz.gd();
          this.eV = arrayOfInt12;
          break;
        case 42: 
          int i27 = paramdz.by(paramdz.gf());
          int i28 = paramdz.getPosition();
          for (int i29 = 0; paramdz.gk() > 0; i29++) {
            paramdz.gd();
          }
          paramdz.bA(i28);
          if (this.eV == null) {}
          int[] arrayOfInt11;
          for (int i30 = 0;; i30 = this.eV.length)
          {
            arrayOfInt11 = new int[i29 + i30];
            if (i30 != 0) {
              System.arraycopy(this.eV, 0, arrayOfInt11, 0, i30);
            }
            while (i30 < arrayOfInt11.length)
            {
              arrayOfInt11[i30] = paramdz.gd();
              i30++;
            }
          }
          this.eV = arrayOfInt11;
          paramdz.bz(i27);
          break;
        case 48: 
          int i25 = ei.b(paramdz, 48);
          if (this.eW == null) {}
          int[] arrayOfInt10;
          for (int i26 = 0;; i26 = this.eW.length)
          {
            arrayOfInt10 = new int[i25 + i26];
            if (i26 != 0) {
              System.arraycopy(this.eW, 0, arrayOfInt10, 0, i26);
            }
            while (i26 < -1 + arrayOfInt10.length)
            {
              arrayOfInt10[i26] = paramdz.gd();
              paramdz.ga();
              i26++;
            }
          }
          arrayOfInt10[i26] = paramdz.gd();
          this.eW = arrayOfInt10;
          break;
        case 50: 
          int i21 = paramdz.by(paramdz.gf());
          int i22 = paramdz.getPosition();
          for (int i23 = 0; paramdz.gk() > 0; i23++) {
            paramdz.gd();
          }
          paramdz.bA(i22);
          if (this.eW == null) {}
          int[] arrayOfInt9;
          for (int i24 = 0;; i24 = this.eW.length)
          {
            arrayOfInt9 = new int[i23 + i24];
            if (i24 != 0) {
              System.arraycopy(this.eW, 0, arrayOfInt9, 0, i24);
            }
            while (i24 < arrayOfInt9.length)
            {
              arrayOfInt9[i24] = paramdz.gd();
              i24++;
            }
          }
          this.eW = arrayOfInt9;
          paramdz.bz(i21);
          break;
        case 56: 
          int i19 = ei.b(paramdz, 56);
          if (this.eX == null) {}
          int[] arrayOfInt8;
          for (int i20 = 0;; i20 = this.eX.length)
          {
            arrayOfInt8 = new int[i19 + i20];
            if (i20 != 0) {
              System.arraycopy(this.eX, 0, arrayOfInt8, 0, i20);
            }
            while (i20 < -1 + arrayOfInt8.length)
            {
              arrayOfInt8[i20] = paramdz.gd();
              paramdz.ga();
              i20++;
            }
          }
          arrayOfInt8[i20] = paramdz.gd();
          this.eX = arrayOfInt8;
          break;
        case 58: 
          int i15 = paramdz.by(paramdz.gf());
          int i16 = paramdz.getPosition();
          for (int i17 = 0; paramdz.gk() > 0; i17++) {
            paramdz.gd();
          }
          paramdz.bA(i16);
          if (this.eX == null) {}
          int[] arrayOfInt7;
          for (int i18 = 0;; i18 = this.eX.length)
          {
            arrayOfInt7 = new int[i17 + i18];
            if (i18 != 0) {
              System.arraycopy(this.eX, 0, arrayOfInt7, 0, i18);
            }
            while (i18 < arrayOfInt7.length)
            {
              arrayOfInt7[i18] = paramdz.gd();
              i18++;
            }
          }
          this.eX = arrayOfInt7;
          paramdz.bz(i15);
          break;
        case 64: 
          int i13 = ei.b(paramdz, 64);
          if (this.eY == null) {}
          int[] arrayOfInt6;
          for (int i14 = 0;; i14 = this.eY.length)
          {
            arrayOfInt6 = new int[i13 + i14];
            if (i14 != 0) {
              System.arraycopy(this.eY, 0, arrayOfInt6, 0, i14);
            }
            while (i14 < -1 + arrayOfInt6.length)
            {
              arrayOfInt6[i14] = paramdz.gd();
              paramdz.ga();
              i14++;
            }
          }
          arrayOfInt6[i14] = paramdz.gd();
          this.eY = arrayOfInt6;
          break;
        case 66: 
          int i9 = paramdz.by(paramdz.gf());
          int i10 = paramdz.getPosition();
          for (int i11 = 0; paramdz.gk() > 0; i11++) {
            paramdz.gd();
          }
          paramdz.bA(i10);
          if (this.eY == null) {}
          int[] arrayOfInt5;
          for (int i12 = 0;; i12 = this.eY.length)
          {
            arrayOfInt5 = new int[i11 + i12];
            if (i12 != 0) {
              System.arraycopy(this.eY, 0, arrayOfInt5, 0, i12);
            }
            while (i12 < arrayOfInt5.length)
            {
              arrayOfInt5[i12] = paramdz.gd();
              i12++;
            }
          }
          this.eY = arrayOfInt5;
          paramdz.bz(i9);
          break;
        case 72: 
          int i7 = ei.b(paramdz, 72);
          if (this.eZ == null) {}
          int[] arrayOfInt4;
          for (int i8 = 0;; i8 = this.eZ.length)
          {
            arrayOfInt4 = new int[i7 + i8];
            if (i8 != 0) {
              System.arraycopy(this.eZ, 0, arrayOfInt4, 0, i8);
            }
            while (i8 < -1 + arrayOfInt4.length)
            {
              arrayOfInt4[i8] = paramdz.gd();
              paramdz.ga();
              i8++;
            }
          }
          arrayOfInt4[i8] = paramdz.gd();
          this.eZ = arrayOfInt4;
          break;
        case 74: 
          int i3 = paramdz.by(paramdz.gf());
          int i4 = paramdz.getPosition();
          for (int i5 = 0; paramdz.gk() > 0; i5++) {
            paramdz.gd();
          }
          paramdz.bA(i4);
          if (this.eZ == null) {}
          int[] arrayOfInt3;
          for (int i6 = 0;; i6 = this.eZ.length)
          {
            arrayOfInt3 = new int[i5 + i6];
            if (i6 != 0) {
              System.arraycopy(this.eZ, 0, arrayOfInt3, 0, i6);
            }
            while (i6 < arrayOfInt3.length)
            {
              arrayOfInt3[i6] = paramdz.gd();
              i6++;
            }
          }
          this.eZ = arrayOfInt3;
          paramdz.bz(i3);
          break;
        case 80: 
          int i1 = ei.b(paramdz, 80);
          if (this.fa == null) {}
          int[] arrayOfInt2;
          for (int i2 = 0;; i2 = this.fa.length)
          {
            arrayOfInt2 = new int[i1 + i2];
            if (i2 != 0) {
              System.arraycopy(this.fa, 0, arrayOfInt2, 0, i2);
            }
            while (i2 < -1 + arrayOfInt2.length)
            {
              arrayOfInt2[i2] = paramdz.gd();
              paramdz.ga();
              i2++;
            }
          }
          arrayOfInt2[i2] = paramdz.gd();
          this.fa = arrayOfInt2;
          break;
        }
        int j = paramdz.by(paramdz.gf());
        int k = paramdz.getPosition();
        for (int m = 0; paramdz.gk() > 0; m++) {
          paramdz.gd();
        }
        paramdz.bA(k);
        if (this.fa == null) {}
        int[] arrayOfInt1;
        for (int n = 0;; n = this.fa.length)
        {
          arrayOfInt1 = new int[m + n];
          if (n != 0) {
            System.arraycopy(this.fa, 0, arrayOfInt1, 0, n);
          }
          while (n < arrayOfInt1.length)
          {
            arrayOfInt1[n] = paramdz.gd();
            n++;
          }
        }
        this.fa = arrayOfInt1;
        paramdz.bz(j);
      }
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = super.getSerializedSize();
      int i17;
      if ((this.eR != null) && (this.eR.length > 0))
      {
        int i16 = 0;
        i17 = 0;
        while (i16 < this.eR.length)
        {
          i17 += ea.bE(this.eR[i16]);
          i16++;
        }
      }
      for (int k = j + i17 + 1 * this.eR.length;; k = j)
      {
        if ((this.eS != null) && (this.eS.length > 0))
        {
          int i14 = 0;
          int i15 = 0;
          while (i14 < this.eS.length)
          {
            i15 += ea.bE(this.eS[i14]);
            i14++;
          }
          k = k + i15 + 1 * this.eS.length;
        }
        if ((this.eT != null) && (this.eT.length > 0))
        {
          int i12 = 0;
          int i13 = 0;
          while (i12 < this.eT.length)
          {
            i13 += ea.bE(this.eT[i12]);
            i12++;
          }
          k = k + i13 + 1 * this.eT.length;
        }
        if ((this.eU != null) && (this.eU.length > 0))
        {
          int i10 = 0;
          int i11 = 0;
          while (i10 < this.eU.length)
          {
            i11 += ea.bE(this.eU[i10]);
            i10++;
          }
          k = k + i11 + 1 * this.eU.length;
        }
        if ((this.eV != null) && (this.eV.length > 0))
        {
          int i8 = 0;
          int i9 = 0;
          while (i8 < this.eV.length)
          {
            i9 += ea.bE(this.eV[i8]);
            i8++;
          }
          k = k + i9 + 1 * this.eV.length;
        }
        if ((this.eW != null) && (this.eW.length > 0))
        {
          int i6 = 0;
          int i7 = 0;
          while (i6 < this.eW.length)
          {
            i7 += ea.bE(this.eW[i6]);
            i6++;
          }
          k = k + i7 + 1 * this.eW.length;
        }
        if ((this.eX != null) && (this.eX.length > 0))
        {
          int i4 = 0;
          int i5 = 0;
          while (i4 < this.eX.length)
          {
            i5 += ea.bE(this.eX[i4]);
            i4++;
          }
          k = k + i5 + 1 * this.eX.length;
        }
        if ((this.eY != null) && (this.eY.length > 0))
        {
          int i2 = 0;
          int i3 = 0;
          while (i2 < this.eY.length)
          {
            i3 += ea.bE(this.eY[i2]);
            i2++;
          }
          k = k + i3 + 1 * this.eY.length;
        }
        if ((this.eZ != null) && (this.eZ.length > 0))
        {
          int n = 0;
          int i1 = 0;
          while (n < this.eZ.length)
          {
            i1 += ea.bE(this.eZ[n]);
            n++;
          }
          k = k + i1 + 1 * this.eZ.length;
        }
        if ((this.fa != null) && (this.fa.length > 0))
        {
          int m = 0;
          while (i < this.fa.length)
          {
            m += ea.bE(this.fa[i]);
            i++;
          }
          k = k + m + 1 * this.fa.length;
        }
        this.Jh = k;
        return k;
      }
    }
    
    public int hashCode()
    {
      int i = 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (527 + ed.hashCode(this.eR)) + ed.hashCode(this.eS)) + ed.hashCode(this.eT)) + ed.hashCode(this.eU)) + ed.hashCode(this.eV)) + ed.hashCode(this.eW)) + ed.hashCode(this.eX)) + ed.hashCode(this.eY)) + ed.hashCode(this.eZ)) + ed.hashCode(this.fa));
      if ((this.Jd == null) || (this.Jd.isEmpty())) {}
      for (int j = 0;; j = this.Jd.hashCode()) {
        return j + i;
      }
    }
    
    public g k()
    {
      this.eR = ei.Jj;
      this.eS = ei.Jj;
      this.eT = ei.Jj;
      this.eU = ei.Jj;
      this.eV = ei.Jj;
      this.eW = ei.Jj;
      this.eX = ei.Jj;
      this.eY = ei.Jj;
      this.eZ = ei.Jj;
      this.fa = ei.Jj;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if ((this.eR != null) && (this.eR.length > 0)) {
        for (int i6 = 0; i6 < this.eR.length; i6++) {
          paramea.d(1, this.eR[i6]);
        }
      }
      if ((this.eS != null) && (this.eS.length > 0)) {
        for (int i5 = 0; i5 < this.eS.length; i5++) {
          paramea.d(2, this.eS[i5]);
        }
      }
      if ((this.eT != null) && (this.eT.length > 0)) {
        for (int i4 = 0; i4 < this.eT.length; i4++) {
          paramea.d(3, this.eT[i4]);
        }
      }
      if ((this.eU != null) && (this.eU.length > 0)) {
        for (int i3 = 0; i3 < this.eU.length; i3++) {
          paramea.d(4, this.eU[i3]);
        }
      }
      if ((this.eV != null) && (this.eV.length > 0)) {
        for (int i2 = 0; i2 < this.eV.length; i2++) {
          paramea.d(5, this.eV[i2]);
        }
      }
      if ((this.eW != null) && (this.eW.length > 0)) {
        for (int i1 = 0; i1 < this.eW.length; i1++) {
          paramea.d(6, this.eW[i1]);
        }
      }
      if ((this.eX != null) && (this.eX.length > 0)) {
        for (int n = 0; n < this.eX.length; n++) {
          paramea.d(7, this.eX[n]);
        }
      }
      if ((this.eY != null) && (this.eY.length > 0)) {
        for (int m = 0; m < this.eY.length; m++) {
          paramea.d(8, this.eY[m]);
        }
      }
      if ((this.eZ != null) && (this.eZ.length > 0)) {
        for (int k = 0; k < this.eZ.length; k++) {
          paramea.d(9, this.eZ[k]);
        }
      }
      if (this.fa != null)
      {
        int i = this.fa.length;
        int j = 0;
        if (i > 0) {
          while (j < this.fa.length)
          {
            paramea.d(10, this.fa[j]);
            j++;
          }
        }
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class h
    extends eb<h>
  {
    public static final ec<d.a, h> fb = ec.a(11, h.class, 810);
    private static final h[] fc = new h[0];
    public int[] fd;
    public int[] fe;
    public int[] ff;
    public int fg;
    public int[] fh;
    public int fi;
    public int fj;
    
    public h()
    {
      l();
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      h localh;
      boolean bool7;
      do
      {
        int n;
        int i1;
        do
        {
          int k;
          int m;
          do
          {
            boolean bool6;
            do
            {
              int i;
              int j;
              do
              {
                boolean bool5;
                do
                {
                  boolean bool4;
                  do
                  {
                    boolean bool3;
                    do
                    {
                      boolean bool1;
                      do
                      {
                        return bool2;
                        bool1 = paramObject instanceof h;
                        bool2 = false;
                      } while (!bool1);
                      localh = (h)paramObject;
                      bool3 = ed.equals(this.fd, localh.fd);
                      bool2 = false;
                    } while (!bool3);
                    bool4 = ed.equals(this.fe, localh.fe);
                    bool2 = false;
                  } while (!bool4);
                  bool5 = ed.equals(this.ff, localh.ff);
                  bool2 = false;
                } while (!bool5);
                i = this.fg;
                j = localh.fg;
                bool2 = false;
              } while (i != j);
              bool6 = ed.equals(this.fh, localh.fh);
              bool2 = false;
            } while (!bool6);
            k = this.fi;
            m = localh.fi;
            bool2 = false;
          } while (k != m);
          n = this.fj;
          i1 = localh.fj;
          bool2 = false;
        } while (n != i1);
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label224;
        }
        if (localh.Jd == null) {
          break;
        }
        bool7 = localh.Jd.isEmpty();
        bool2 = false;
      } while (!bool7);
      return true;
      label224:
      return this.Jd.equals(localh.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = super.getSerializedSize();
      int i5;
      if ((this.fd != null) && (this.fd.length > 0))
      {
        int i4 = 0;
        i5 = 0;
        while (i4 < this.fd.length)
        {
          i5 += ea.bE(this.fd[i4]);
          i4++;
        }
      }
      for (int k = j + i5 + 1 * this.fd.length;; k = j)
      {
        if ((this.fe != null) && (this.fe.length > 0))
        {
          int i2 = 0;
          int i3 = 0;
          while (i2 < this.fe.length)
          {
            i3 += ea.bE(this.fe[i2]);
            i2++;
          }
          k = k + i3 + 1 * this.fe.length;
        }
        if ((this.ff != null) && (this.ff.length > 0))
        {
          int n = 0;
          int i1 = 0;
          while (n < this.ff.length)
          {
            i1 += ea.bE(this.ff[n]);
            n++;
          }
          k = k + i1 + 1 * this.ff.length;
        }
        if (this.fg != 0) {
          k += ea.e(4, this.fg);
        }
        if ((this.fh != null) && (this.fh.length > 0))
        {
          int m = 0;
          while (i < this.fh.length)
          {
            m += ea.bE(this.fh[i]);
            i++;
          }
          k = k + m + 1 * this.fh.length;
        }
        if (this.fi != 0) {
          k += ea.e(6, this.fi);
        }
        if (this.fj != 0) {
          k += ea.e(7, this.fj);
        }
        this.Jh = k;
        return k;
      }
    }
    
    public h h(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          int i19 = ei.b(paramdz, 8);
          if (this.fd == null) {}
          int[] arrayOfInt8;
          for (int i20 = 0;; i20 = this.fd.length)
          {
            arrayOfInt8 = new int[i19 + i20];
            if (i20 != 0) {
              System.arraycopy(this.fd, 0, arrayOfInt8, 0, i20);
            }
            while (i20 < -1 + arrayOfInt8.length)
            {
              arrayOfInt8[i20] = paramdz.gd();
              paramdz.ga();
              i20++;
            }
          }
          arrayOfInt8[i20] = paramdz.gd();
          this.fd = arrayOfInt8;
          break;
        case 10: 
          int i15 = paramdz.by(paramdz.gf());
          int i16 = paramdz.getPosition();
          for (int i17 = 0; paramdz.gk() > 0; i17++) {
            paramdz.gd();
          }
          paramdz.bA(i16);
          if (this.fd == null) {}
          int[] arrayOfInt7;
          for (int i18 = 0;; i18 = this.fd.length)
          {
            arrayOfInt7 = new int[i17 + i18];
            if (i18 != 0) {
              System.arraycopy(this.fd, 0, arrayOfInt7, 0, i18);
            }
            while (i18 < arrayOfInt7.length)
            {
              arrayOfInt7[i18] = paramdz.gd();
              i18++;
            }
          }
          this.fd = arrayOfInt7;
          paramdz.bz(i15);
          break;
        case 16: 
          int i13 = ei.b(paramdz, 16);
          if (this.fe == null) {}
          int[] arrayOfInt6;
          for (int i14 = 0;; i14 = this.fe.length)
          {
            arrayOfInt6 = new int[i13 + i14];
            if (i14 != 0) {
              System.arraycopy(this.fe, 0, arrayOfInt6, 0, i14);
            }
            while (i14 < -1 + arrayOfInt6.length)
            {
              arrayOfInt6[i14] = paramdz.gd();
              paramdz.ga();
              i14++;
            }
          }
          arrayOfInt6[i14] = paramdz.gd();
          this.fe = arrayOfInt6;
          break;
        case 18: 
          int i9 = paramdz.by(paramdz.gf());
          int i10 = paramdz.getPosition();
          for (int i11 = 0; paramdz.gk() > 0; i11++) {
            paramdz.gd();
          }
          paramdz.bA(i10);
          if (this.fe == null) {}
          int[] arrayOfInt5;
          for (int i12 = 0;; i12 = this.fe.length)
          {
            arrayOfInt5 = new int[i11 + i12];
            if (i12 != 0) {
              System.arraycopy(this.fe, 0, arrayOfInt5, 0, i12);
            }
            while (i12 < arrayOfInt5.length)
            {
              arrayOfInt5[i12] = paramdz.gd();
              i12++;
            }
          }
          this.fe = arrayOfInt5;
          paramdz.bz(i9);
          break;
        case 24: 
          int i7 = ei.b(paramdz, 24);
          if (this.ff == null) {}
          int[] arrayOfInt4;
          for (int i8 = 0;; i8 = this.ff.length)
          {
            arrayOfInt4 = new int[i7 + i8];
            if (i8 != 0) {
              System.arraycopy(this.ff, 0, arrayOfInt4, 0, i8);
            }
            while (i8 < -1 + arrayOfInt4.length)
            {
              arrayOfInt4[i8] = paramdz.gd();
              paramdz.ga();
              i8++;
            }
          }
          arrayOfInt4[i8] = paramdz.gd();
          this.ff = arrayOfInt4;
          break;
        case 26: 
          int i3 = paramdz.by(paramdz.gf());
          int i4 = paramdz.getPosition();
          for (int i5 = 0; paramdz.gk() > 0; i5++) {
            paramdz.gd();
          }
          paramdz.bA(i4);
          if (this.ff == null) {}
          int[] arrayOfInt3;
          for (int i6 = 0;; i6 = this.ff.length)
          {
            arrayOfInt3 = new int[i5 + i6];
            if (i6 != 0) {
              System.arraycopy(this.ff, 0, arrayOfInt3, 0, i6);
            }
            while (i6 < arrayOfInt3.length)
            {
              arrayOfInt3[i6] = paramdz.gd();
              i6++;
            }
          }
          this.ff = arrayOfInt3;
          paramdz.bz(i3);
          break;
        case 32: 
          this.fg = paramdz.gd();
          break;
        case 40: 
          int i1 = ei.b(paramdz, 40);
          if (this.fh == null) {}
          int[] arrayOfInt2;
          for (int i2 = 0;; i2 = this.fh.length)
          {
            arrayOfInt2 = new int[i1 + i2];
            if (i2 != 0) {
              System.arraycopy(this.fh, 0, arrayOfInt2, 0, i2);
            }
            while (i2 < -1 + arrayOfInt2.length)
            {
              arrayOfInt2[i2] = paramdz.gd();
              paramdz.ga();
              i2++;
            }
          }
          arrayOfInt2[i2] = paramdz.gd();
          this.fh = arrayOfInt2;
          break;
        case 42: 
          int j = paramdz.by(paramdz.gf());
          int k = paramdz.getPosition();
          for (int m = 0; paramdz.gk() > 0; m++) {
            paramdz.gd();
          }
          paramdz.bA(k);
          if (this.fh == null) {}
          int[] arrayOfInt1;
          for (int n = 0;; n = this.fh.length)
          {
            arrayOfInt1 = new int[m + n];
            if (n != 0) {
              System.arraycopy(this.fh, 0, arrayOfInt1, 0, n);
            }
            while (n < arrayOfInt1.length)
            {
              arrayOfInt1[n] = paramdz.gd();
              n++;
            }
          }
          this.fh = arrayOfInt1;
          paramdz.bz(j);
          break;
        case 48: 
          this.fi = paramdz.gd();
          break;
        }
        this.fj = paramdz.gd();
      }
    }
    
    public int hashCode()
    {
      int i = 31 * (31 * (31 * (31 * (31 * (31 * (31 * (527 + ed.hashCode(this.fd)) + ed.hashCode(this.fe)) + ed.hashCode(this.ff)) + this.fg) + ed.hashCode(this.fh)) + this.fi) + this.fj);
      if ((this.Jd == null) || (this.Jd.isEmpty())) {}
      for (int j = 0;; j = this.Jd.hashCode()) {
        return j + i;
      }
    }
    
    public h l()
    {
      this.fd = ei.Jj;
      this.fe = ei.Jj;
      this.ff = ei.Jj;
      this.fg = 0;
      this.fh = ei.Jj;
      this.fi = 0;
      this.fj = 0;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if ((this.fd != null) && (this.fd.length > 0)) {
        for (int n = 0; n < this.fd.length; n++) {
          paramea.d(1, this.fd[n]);
        }
      }
      if ((this.fe != null) && (this.fe.length > 0)) {
        for (int m = 0; m < this.fe.length; m++) {
          paramea.d(2, this.fe[m]);
        }
      }
      if ((this.ff != null) && (this.ff.length > 0)) {
        for (int k = 0; k < this.ff.length; k++) {
          paramea.d(3, this.ff[k]);
        }
      }
      if (this.fg != 0) {
        paramea.d(4, this.fg);
      }
      if (this.fh != null)
      {
        int i = this.fh.length;
        int j = 0;
        if (i > 0) {
          while (j < this.fh.length)
          {
            paramea.d(5, this.fh[j]);
            j++;
          }
        }
      }
      if (this.fi != 0) {
        paramea.d(6, this.fi);
      }
      if (this.fj != 0) {
        paramea.d(7, this.fj);
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class i
    extends eb<i>
  {
    private static volatile i[] fk;
    public d.a fl;
    public c.d fm;
    public String name;
    
    public i()
    {
      n();
    }
    
    public static i[] m()
    {
      if (fk == null) {}
      synchronized (ed.Jg)
      {
        if (fk == null) {
          fk = new i[0];
        }
        return fk;
      }
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      i locali;
      label47:
      label68:
      c.d locald;
      do
      {
        d.a locala;
        do
        {
          String str;
          do
          {
            boolean bool1;
            do
            {
              return bool2;
              bool1 = paramObject instanceof i;
              bool2 = false;
            } while (!bool1);
            locali = (i)paramObject;
            if (this.name != null) {
              break;
            }
            str = locali.name;
            bool2 = false;
          } while (str != null);
          if (this.fl != null) {
            break label154;
          }
          locala = locali.fl;
          bool2 = false;
        } while (locala != null);
        if (this.fm != null) {
          break label171;
        }
        locald = locali.fm;
        bool2 = false;
      } while (locald != null);
      for (;;)
      {
        if ((this.Jd == null) || (this.Jd.isEmpty()))
        {
          if (locali.Jd != null)
          {
            boolean bool3 = locali.Jd.isEmpty();
            bool2 = false;
            if (!bool3) {
              break;
            }
          }
          return true;
          if (this.name.equals(locali.name)) {
            break label47;
          }
          return false;
          label154:
          if (this.fl.equals(locali.fl)) {
            break label68;
          }
          return false;
          label171:
          if (!this.fm.equals(locali.fm)) {
            return false;
          }
        }
      }
      return this.Jd.equals(locali.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize();
      if (!this.name.equals("")) {
        i += ea.c(1, this.name);
      }
      if (this.fl != null) {
        i += ea.b(2, this.fl);
      }
      if (this.fm != null) {
        i += ea.b(3, this.fm);
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i;
      int k;
      label27:
      int n;
      label45:
      int i1;
      int i2;
      if (this.name == null)
      {
        i = 0;
        int j = 31 * (i + 527);
        if (this.fl != null) {
          break label105;
        }
        k = 0;
        int m = 31 * (k + j);
        if (this.fm != null) {
          break label116;
        }
        n = 0;
        i1 = 31 * (n + m);
        List localList = this.Jd;
        i2 = 0;
        if (localList != null)
        {
          boolean bool = this.Jd.isEmpty();
          i2 = 0;
          if (!bool) {
            break label128;
          }
        }
      }
      for (;;)
      {
        return i1 + i2;
        i = this.name.hashCode();
        break;
        label105:
        k = this.fl.hashCode();
        break label27;
        label116:
        n = this.fm.hashCode();
        break label45;
        label128:
        i2 = this.Jd.hashCode();
      }
    }
    
    public i i(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 10: 
          this.name = paramdz.readString();
          break;
        case 18: 
          if (this.fl == null) {
            this.fl = new d.a();
          }
          paramdz.a(this.fl);
          break;
        }
        if (this.fm == null) {
          this.fm = new c.d();
        }
        paramdz.a(this.fm);
      }
    }
    
    public i n()
    {
      this.name = "";
      this.fl = null;
      this.fm = null;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if (!this.name.equals("")) {
        paramea.b(1, this.name);
      }
      if (this.fl != null) {
        paramea.a(2, this.fl);
      }
      if (this.fm != null) {
        paramea.a(3, this.fm);
      }
      super.writeTo(paramea);
    }
  }
  
  public static final class j
    extends eb<j>
  {
    public c.i[] fn;
    public c.f fo;
    public String fp;
    
    public j()
    {
      o();
    }
    
    public static j b(byte[] paramArrayOfByte)
      throws ee
    {
      return (j)ef.mergeFrom(new j(), paramArrayOfByte);
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      j localj;
      label68:
      String str;
      do
      {
        c.f localf;
        do
        {
          boolean bool3;
          do
          {
            boolean bool1;
            do
            {
              return bool2;
              bool1 = paramObject instanceof j;
              bool2 = false;
            } while (!bool1);
            localj = (j)paramObject;
            bool3 = ed.equals(this.fn, localj.fn);
            bool2 = false;
          } while (!bool3);
          if (this.fo != null) {
            break;
          }
          localf = localj.fo;
          bool2 = false;
        } while (localf != null);
        if (this.fp != null) {
          break label154;
        }
        str = localj.fp;
        bool2 = false;
      } while (str != null);
      for (;;)
      {
        if ((this.Jd == null) || (this.Jd.isEmpty()))
        {
          if (localj.Jd != null)
          {
            boolean bool4 = localj.Jd.isEmpty();
            bool2 = false;
            if (!bool4) {
              break;
            }
          }
          return true;
          if (this.fo.equals(localj.fo)) {
            break label68;
          }
          return false;
          label154:
          if (!this.fp.equals(localj.fp)) {
            return false;
          }
        }
      }
      return this.Jd.equals(localj.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize();
      if ((this.fn != null) && (this.fn.length > 0)) {
        for (int j = 0; j < this.fn.length; j++)
        {
          c.i locali = this.fn[j];
          if (locali != null) {
            i += ea.b(1, locali);
          }
        }
      }
      if (this.fo != null) {
        i += ea.b(2, this.fo);
      }
      if (!this.fp.equals("")) {
        i += ea.c(3, this.fp);
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i = 31 * (527 + ed.hashCode(this.fn));
      int j;
      int m;
      label41:
      int n;
      int i1;
      if (this.fo == null)
      {
        j = 0;
        int k = 31 * (j + i);
        if (this.fp != null) {
          break label100;
        }
        m = 0;
        n = 31 * (m + k);
        List localList = this.Jd;
        i1 = 0;
        if (localList != null)
        {
          boolean bool = this.Jd.isEmpty();
          i1 = 0;
          if (!bool) {
            break label112;
          }
        }
      }
      for (;;)
      {
        return n + i1;
        j = this.fo.hashCode();
        break;
        label100:
        m = this.fp.hashCode();
        break label41;
        label112:
        i1 = this.Jd.hashCode();
      }
    }
    
    public j j(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 10: 
          int j = ei.b(paramdz, 10);
          if (this.fn == null) {}
          c.i[] arrayOfi;
          for (int k = 0;; k = this.fn.length)
          {
            arrayOfi = new c.i[j + k];
            if (k != 0) {
              System.arraycopy(this.fn, 0, arrayOfi, 0, k);
            }
            while (k < -1 + arrayOfi.length)
            {
              arrayOfi[k] = new c.i();
              paramdz.a(arrayOfi[k]);
              paramdz.ga();
              k++;
            }
          }
          arrayOfi[k] = new c.i();
          paramdz.a(arrayOfi[k]);
          this.fn = arrayOfi;
          break;
        case 18: 
          if (this.fo == null) {
            this.fo = new c.f();
          }
          paramdz.a(this.fo);
          break;
        }
        this.fp = paramdz.readString();
      }
    }
    
    public j o()
    {
      this.fn = c.i.m();
      this.fo = null;
      this.fp = "";
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      if ((this.fn != null) && (this.fn.length > 0)) {
        for (int i = 0; i < this.fn.length; i++)
        {
          c.i locali = this.fn[i];
          if (locali != null) {
            paramea.a(1, locali);
          }
        }
      }
      if (this.fo != null) {
        paramea.a(2, this.fo);
      }
      if (!this.fp.equals("")) {
        paramea.b(3, this.fp);
      }
      super.writeTo(paramea);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.c
 * JD-Core Version:    0.7.0.1
 */