package com.google.android.gms.internal;

import android.os.Build.VERSION;

public final class bn
{
  private static boolean az(int paramInt)
  {
    return Build.VERSION.SDK_INT >= paramInt;
  }
  
  public static boolean cm()
  {
    return az(11);
  }
  
  public static boolean cn()
  {
    return az(13);
  }
  
  public static boolean co()
  {
    return az(14);
  }
  
  public static boolean cp()
  {
    return az(17);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bn
 * JD-Core Version:    0.7.0.1
 */