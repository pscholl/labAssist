package com.google.android.gms.internal;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.google.android.gms.common.people.data.Audience;
import com.google.android.gms.common.people.data.a;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.b.a;

public abstract interface ab
  extends IInterface
{
  public abstract void a(b paramb1, b paramb2, ac paramac)
    throws RemoteException;
  
  public abstract void ac(int paramInt)
    throws RemoteException;
  
  public abstract b getView()
    throws RemoteException;
  
  public abstract void onRestoreInstanceState(Bundle paramBundle)
    throws RemoteException;
  
  public abstract Bundle onSaveInstanceState()
    throws RemoteException;
  
  public abstract void setAudience(Audience paramAudience)
    throws RemoteException;
  
  public abstract void setShowEmptyText(boolean paramBoolean)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements ab
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.common.audience.dynamite.IAudienceView");
    }
    
    public static ab l(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
      if ((localIInterface != null) && ((localIInterface instanceof ab))) {
        return (ab)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.common.audience.dynamite.IAudienceView");
        return true;
      case 2: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
        a(b.a.x(paramParcel1.readStrongBinder()), b.a.x(paramParcel1.readStrongBinder()), ac.a.m(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 8: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
        b localb = getView();
        paramParcel2.writeNoException();
        IBinder localIBinder = null;
        if (localb != null) {
          localIBinder = localb.asBinder();
        }
        paramParcel2.writeStrongBinder(localIBinder);
        return true;
      case 3: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
        ac(paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 4: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool = true;; bool = false)
        {
          setShowEmptyText(bool);
          paramParcel2.writeNoException();
          return true;
        }
      case 5: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
        int j = paramParcel1.readInt();
        Audience localAudience = null;
        if (j != 0) {
          localAudience = Audience.CREATOR.aa(paramParcel1);
        }
        setAudience(localAudience);
        paramParcel2.writeNoException();
        return true;
      case 6: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
        Bundle localBundle2 = onSaveInstanceState();
        paramParcel2.writeNoException();
        if (localBundle2 != null)
        {
          paramParcel2.writeInt(1);
          localBundle2.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceView");
      int i = paramParcel1.readInt();
      Bundle localBundle1 = null;
      if (i != 0) {
        localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
      }
      onRestoreInstanceState(localBundle1);
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class a
      implements ab
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      /* Error */
      public void a(b paramb1, b paramb2, ac paramac)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +91 -> 109
        //   21: aload_1
        //   22: invokeinterface 37 1 0
        //   27: astore 7
        //   29: aload 4
        //   31: aload 7
        //   33: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   36: aload_2
        //   37: ifnull +78 -> 115
        //   40: aload_2
        //   41: invokeinterface 37 1 0
        //   46: astore 8
        //   48: aload 4
        //   50: aload 8
        //   52: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   55: aconst_null
        //   56: astore 9
        //   58: aload_3
        //   59: ifnull +11 -> 70
        //   62: aload_3
        //   63: invokeinterface 43 1 0
        //   68: astore 9
        //   70: aload 4
        //   72: aload 9
        //   74: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   77: aload_0
        //   78: getfield 15	com/google/android/gms/internal/ab$a$a:jR	Landroid/os/IBinder;
        //   81: iconst_2
        //   82: aload 4
        //   84: aload 5
        //   86: iconst_0
        //   87: invokeinterface 49 5 0
        //   92: pop
        //   93: aload 5
        //   95: invokevirtual 52	android/os/Parcel:readException	()V
        //   98: aload 5
        //   100: invokevirtual 55	android/os/Parcel:recycle	()V
        //   103: aload 4
        //   105: invokevirtual 55	android/os/Parcel:recycle	()V
        //   108: return
        //   109: aconst_null
        //   110: astore 7
        //   112: goto -83 -> 29
        //   115: aconst_null
        //   116: astore 8
        //   118: goto -70 -> 48
        //   121: astore 6
        //   123: aload 5
        //   125: invokevirtual 55	android/os/Parcel:recycle	()V
        //   128: aload 4
        //   130: invokevirtual 55	android/os/Parcel:recycle	()V
        //   133: aload 6
        //   135: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	136	0	this	a
        //   0	136	1	paramb1	b
        //   0	136	2	paramb2	b
        //   0	136	3	paramac	ac
        //   3	126	4	localParcel1	Parcel
        //   8	116	5	localParcel2	Parcel
        //   121	13	6	localObject	Object
        //   27	84	7	localIBinder1	IBinder
        //   46	71	8	localIBinder2	IBinder
        //   56	17	9	localIBinder3	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	17	121	finally
        //   21	29	121	finally
        //   29	36	121	finally
        //   40	48	121	finally
        //   48	55	121	finally
        //   62	70	121	finally
        //   70	98	121	finally
      }
      
      public void ac(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.common.audience.dynamite.IAudienceView");
          localParcel1.writeInt(paramInt);
          this.jR.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public b getView()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.common.audience.dynamite.IAudienceView");
          this.jR.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          b localb = b.a.x(localParcel2.readStrongBinder());
          return localb;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void onRestoreInstanceState(Bundle paramBundle)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +42 -> 57
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 60	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 79	android/os/Bundle:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	com/google/android/gms/internal/ab$a$a:jR	Landroid/os/IBinder;
        //   33: bipush 7
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 55	android/os/Parcel:recycle	()V
        //   52: aload_2
        //   53: invokevirtual 55	android/os/Parcel:recycle	()V
        //   56: return
        //   57: aload_2
        //   58: iconst_0
        //   59: invokevirtual 60	android/os/Parcel:writeInt	(I)V
        //   62: goto -33 -> 29
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 55	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 55	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	a
        //   0	78	1	paramBundle	Bundle
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	29	65	finally
        //   29	48	65	finally
        //   57	62	65	finally
      }
      
      /* Error */
      public Bundle onSaveInstanceState()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	com/google/android/gms/internal/ab$a$a:jR	Landroid/os/IBinder;
        //   18: bipush 6
        //   20: aload_1
        //   21: aload_2
        //   22: iconst_0
        //   23: invokeinterface 49 5 0
        //   28: pop
        //   29: aload_2
        //   30: invokevirtual 52	android/os/Parcel:readException	()V
        //   33: aload_2
        //   34: invokevirtual 85	android/os/Parcel:readInt	()I
        //   37: ifeq +28 -> 65
        //   40: getstatic 89	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
        //   43: aload_2
        //   44: invokeinterface 95 2 0
        //   49: checkcast 75	android/os/Bundle
        //   52: astore 5
        //   54: aload_2
        //   55: invokevirtual 55	android/os/Parcel:recycle	()V
        //   58: aload_1
        //   59: invokevirtual 55	android/os/Parcel:recycle	()V
        //   62: aload 5
        //   64: areturn
        //   65: aconst_null
        //   66: astore 5
        //   68: goto -14 -> 54
        //   71: astore_3
        //   72: aload_2
        //   73: invokevirtual 55	android/os/Parcel:recycle	()V
        //   76: aload_1
        //   77: invokevirtual 55	android/os/Parcel:recycle	()V
        //   80: aload_3
        //   81: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	82	0	this	a
        //   3	74	1	localParcel1	Parcel
        //   7	66	2	localParcel2	Parcel
        //   71	10	3	localObject	Object
        //   52	15	5	localBundle	Bundle
        // Exception table:
        //   from	to	target	type
        //   8	54	71	finally
      }
      
      /* Error */
      public void setAudience(Audience paramAudience)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +41 -> 56
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 60	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 100	com/google/android/gms/common/people/data/Audience:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	com/google/android/gms/internal/ab$a$a:jR	Landroid/os/IBinder;
        //   33: iconst_5
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 49 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 52	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 55	android/os/Parcel:recycle	()V
        //   51: aload_2
        //   52: invokevirtual 55	android/os/Parcel:recycle	()V
        //   55: return
        //   56: aload_2
        //   57: iconst_0
        //   58: invokevirtual 60	android/os/Parcel:writeInt	(I)V
        //   61: goto -32 -> 29
        //   64: astore 4
        //   66: aload_3
        //   67: invokevirtual 55	android/os/Parcel:recycle	()V
        //   70: aload_2
        //   71: invokevirtual 55	android/os/Parcel:recycle	()V
        //   74: aload 4
        //   76: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	77	0	this	a
        //   0	77	1	paramAudience	Audience
        //   3	68	2	localParcel1	Parcel
        //   7	60	3	localParcel2	Parcel
        //   64	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	64	finally
        //   18	29	64	finally
        //   29	47	64	finally
        //   56	61	64	finally
      }
      
      public void setShowEmptyText(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.common.audience.dynamite.IAudienceView");
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.jR.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ab
 * JD-Core Version:    0.7.0.1
 */