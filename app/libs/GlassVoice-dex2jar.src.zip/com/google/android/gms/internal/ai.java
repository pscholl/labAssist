package com.google.android.gms.internal;

import android.os.Parcel;
import android.view.View;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class ai
{
  private final View re;
  private final a tu;
  
  public ai(String paramString1, Collection<String> paramCollection, int paramInt, View paramView, String paramString2)
  {
    this.tu = new a(paramString1, paramCollection, paramInt, paramString2);
    this.re = paramView;
  }
  
  public String getAccountName()
  {
    return this.tu.getAccountName();
  }
  
  public static final class a
    implements SafeParcelable
  {
    public static final as CREATOR = new as();
    private final int oj;
    private final String pU;
    private final int rd;
    private final String rf;
    private final List<String> tv = new ArrayList();
    
    a(int paramInt1, String paramString1, List<String> paramList, int paramInt2, String paramString2)
    {
      this.oj = paramInt1;
      this.pU = paramString1;
      this.tv.addAll(paramList);
      this.rd = paramInt2;
      this.rf = paramString2;
    }
    
    public a(String paramString1, Collection<String> paramCollection, int paramInt, String paramString2)
    {
      this(3, paramString1, new ArrayList(paramCollection), paramInt, paramString2);
    }
    
    public int bN()
    {
      return this.rd;
    }
    
    public String bO()
    {
      return this.rf;
    }
    
    public List<String> bP()
    {
      return new ArrayList(this.tv);
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public String getAccountName()
    {
      return this.pU;
    }
    
    public int getVersionCode()
    {
      return this.oj;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      as.a(this, paramParcel, paramInt);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ai
 * JD-Core Version:    0.7.0.1
 */