package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public final class am
  implements Handler.Callback
{
  private static final Object tS = new Object();
  private static am tT;
  private final Handler mHandler = new Handler(paramContext.getMainLooper(), this);
  private final Context tU;
  private final HashMap<String, a> tV = new HashMap();
  
  private am(Context paramContext)
  {
    this.tU = paramContext.getApplicationContext();
  }
  
  public static am t(Context paramContext)
  {
    synchronized (tS)
    {
      if (tT == null) {
        tT = new am(paramContext.getApplicationContext());
      }
      return tT;
    }
  }
  
  public boolean a(String paramString, ak<?>.e paramak)
  {
    for (;;)
    {
      a locala;
      synchronized (this.tV)
      {
        locala = (a)this.tV.get(paramString);
        if (locala == null)
        {
          locala = new a(paramString);
          locala.a(paramak);
          Intent localIntent1 = new Intent(paramString).setPackage("com.google.android.gms");
          locala.g(this.tU.bindService(localIntent1, locala.bW(), 129));
          this.tV.put(paramString, locala);
          boolean bool = locala.isBound();
          return bool;
        }
        this.mHandler.removeMessages(0, locala);
        if (locala.c(paramak)) {
          throw new IllegalStateException("Trying to bind a GmsServiceConnection that was already connected before.  startServiceAction=" + paramString);
        }
      }
      locala.a(paramak);
      switch (locala.getState())
      {
      case 1: 
        paramak.onServiceConnected(locala.getComponentName(), locala.getBinder());
        break;
      case 2: 
        Intent localIntent2 = new Intent(paramString).setPackage("com.google.android.gms");
        locala.g(this.tU.bindService(localIntent2, locala.bW(), 129));
      }
    }
  }
  
  public void b(String paramString, ak<?>.e paramak)
  {
    a locala;
    synchronized (this.tV)
    {
      locala = (a)this.tV.get(paramString);
      if (locala == null) {
        throw new IllegalStateException("Nonexistent connection status for service action: " + paramString);
      }
    }
    if (!locala.c(paramak)) {
      throw new IllegalStateException("Trying to unbind a GmsServiceConnection  that was not bound before.  startServiceAction=" + paramString);
    }
    locala.b(paramak);
    if (locala.bY())
    {
      Message localMessage = this.mHandler.obtainMessage(0, locala);
      this.mHandler.sendMessageDelayed(localMessage, 5000L);
    }
  }
  
  public boolean handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default: 
      return false;
    }
    a locala = (a)paramMessage.obj;
    synchronized (this.tV)
    {
      if (locala.bY())
      {
        this.tU.unbindService(locala.bW());
        this.tV.remove(locala.bX());
      }
      return true;
    }
  }
  
  final class a
  {
    private int mState;
    private final String tW;
    private final a tX;
    private final HashSet<ak<?>.e> tY;
    private boolean tZ;
    private IBinder ua;
    private ComponentName ub;
    
    public a(String paramString)
    {
      this.tW = paramString;
      this.tX = new a();
      this.tY = new HashSet();
      this.mState = 0;
    }
    
    public void a(ak<?>.e paramak)
    {
      this.tY.add(paramak);
    }
    
    public void b(ak<?>.e paramak)
    {
      this.tY.remove(paramak);
    }
    
    public a bW()
    {
      return this.tX;
    }
    
    public String bX()
    {
      return this.tW;
    }
    
    public boolean bY()
    {
      return this.tY.isEmpty();
    }
    
    public boolean c(ak<?>.e paramak)
    {
      return this.tY.contains(paramak);
    }
    
    public void g(boolean paramBoolean)
    {
      this.tZ = paramBoolean;
    }
    
    public IBinder getBinder()
    {
      return this.ua;
    }
    
    public ComponentName getComponentName()
    {
      return this.ub;
    }
    
    public int getState()
    {
      return this.mState;
    }
    
    public boolean isBound()
    {
      return this.tZ;
    }
    
    public class a
      implements ServiceConnection
    {
      public a() {}
      
      public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
      {
        synchronized (am.a(am.this))
        {
          am.a.a(am.a.this, paramIBinder);
          am.a.a(am.a.this, paramComponentName);
          Iterator localIterator = am.a.a(am.a.this).iterator();
          if (localIterator.hasNext()) {
            ((ak.e)localIterator.next()).onServiceConnected(paramComponentName, paramIBinder);
          }
        }
        am.a.a(am.a.this, 1);
      }
      
      public void onServiceDisconnected(ComponentName paramComponentName)
      {
        synchronized (am.a(am.this))
        {
          am.a.a(am.a.this, null);
          am.a.a(am.a.this, paramComponentName);
          Iterator localIterator = am.a.a(am.a.this).iterator();
          if (localIterator.hasNext()) {
            ((ak.e)localIterator.next()).onServiceDisconnected(paramComponentName);
          }
        }
        am.a.a(am.a.this, 2);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.am
 * JD-Core Version:    0.7.0.1
 */