package com.google.android.gms.internal;

import java.util.ArrayList;

public class dh
{
  private final String Cw;
  private final ArrayList<Long> Cx = new ArrayList();
  private final ArrayList<String> Cy = new ArrayList();
  
  private dh(String paramString)
  {
    this.Cw = paramString;
    ad("");
  }
  
  public static dh ac(String paramString)
  {
    return new dh(paramString);
  }
  
  public static dh dD()
  {
    return a.Cz;
  }
  
  public void ad(String paramString)
  {
    try
    {
      this.Cx.add(Long.valueOf(System.currentTimeMillis()));
      this.Cy.add(paramString);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  public void g(String paramString, int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 27
    //   5: invokevirtual 30	com/google/android/gms/internal/dh:ad	(Ljava/lang/String;)V
    //   8: aload_0
    //   9: getfield 21	com/google/android/gms/internal/dh:Cx	Ljava/util/ArrayList;
    //   12: iconst_0
    //   13: invokevirtual 65	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   16: checkcast 51	java/lang/Long
    //   19: invokevirtual 68	java/lang/Long:longValue	()J
    //   22: lstore 4
    //   24: aload_0
    //   25: getfield 21	com/google/android/gms/internal/dh:Cx	Ljava/util/ArrayList;
    //   28: iconst_m1
    //   29: aload_0
    //   30: getfield 21	com/google/android/gms/internal/dh:Cx	Ljava/util/ArrayList;
    //   33: invokevirtual 72	java/util/ArrayList:size	()I
    //   36: iadd
    //   37: invokevirtual 65	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   40: checkcast 51	java/lang/Long
    //   43: invokevirtual 68	java/lang/Long:longValue	()J
    //   46: lstore 6
    //   48: lload 6
    //   50: lload 4
    //   52: lsub
    //   53: lstore 8
    //   55: lload 8
    //   57: iload_2
    //   58: i2l
    //   59: lcmp
    //   60: ifge +6 -> 66
    //   63: aload_0
    //   64: monitorexit
    //   65: return
    //   66: invokestatic 78	com/google/android/gms/internal/de:dA	()Ljava/lang/StringBuilder;
    //   69: astore 10
    //   71: aload 10
    //   73: aload_0
    //   74: getfield 25	com/google/android/gms/internal/dh:Cw	Ljava/lang/String;
    //   77: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload 10
    //   83: ldc 86
    //   85: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload 10
    //   91: lload 8
    //   93: invokevirtual 89	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   96: pop
    //   97: aload 10
    //   99: ldc 91
    //   101: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: pop
    //   105: lload 4
    //   107: lstore 15
    //   109: iconst_1
    //   110: istore 17
    //   112: iload 17
    //   114: aload_0
    //   115: getfield 21	com/google/android/gms/internal/dh:Cx	Ljava/util/ArrayList;
    //   118: invokevirtual 72	java/util/ArrayList:size	()I
    //   121: if_icmpge +75 -> 196
    //   124: aload_0
    //   125: getfield 21	com/google/android/gms/internal/dh:Cx	Ljava/util/ArrayList;
    //   128: iload 17
    //   130: invokevirtual 65	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   133: checkcast 51	java/lang/Long
    //   136: invokevirtual 68	java/lang/Long:longValue	()J
    //   139: lstore 18
    //   141: aload 10
    //   143: aload_0
    //   144: getfield 23	com/google/android/gms/internal/dh:Cy	Ljava/util/ArrayList;
    //   147: iload 17
    //   149: invokevirtual 65	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   152: checkcast 93	java/lang/String
    //   155: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: pop
    //   159: aload 10
    //   161: ldc 86
    //   163: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: pop
    //   167: aload 10
    //   169: lload 18
    //   171: lload 15
    //   173: lsub
    //   174: invokevirtual 89	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   177: pop
    //   178: aload 10
    //   180: ldc 95
    //   182: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: pop
    //   186: iinc 17 1
    //   189: lload 18
    //   191: lstore 15
    //   193: goto -81 -> 112
    //   196: aload_1
    //   197: aload 10
    //   199: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   202: invokestatic 105	com/google/android/gms/internal/dd:h	(Ljava/lang/String;Ljava/lang/String;)V
    //   205: goto -142 -> 63
    //   208: astore_3
    //   209: aload_0
    //   210: monitorexit
    //   211: aload_3
    //   212: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	213	0	this	dh
    //   0	213	1	paramString	String
    //   0	213	2	paramInt	int
    //   208	4	3	localObject	Object
    //   22	84	4	l1	long
    //   46	3	6	l2	long
    //   53	39	8	l3	long
    //   69	129	10	localStringBuilder	java.lang.StringBuilder
    //   107	85	15	l4	long
    //   110	77	17	i	int
    //   139	51	18	l5	long
    // Exception table:
    //   from	to	target	type
    //   2	48	208	finally
    //   66	105	208	finally
    //   112	186	208	finally
    //   196	205	208	finally
  }
  
  private static class a
    extends dh
  {
    public static final a Cz = new a();
    
    public a()
    {
      super(null);
    }
    
    public void ad(String paramString) {}
    
    public void g(String paramString, int paramInt) {}
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dh
 * JD-Core Version:    0.7.0.1
 */