package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class eb<M extends eb<M>>
  extends ef
{
  protected List<eh> Jd;
  
  protected final boolean a(dz paramdz, int paramInt)
    throws IOException
  {
    int i = paramdz.getPosition();
    if (!paramdz.bx(paramInt)) {
      return false;
    }
    if (this.Jd == null) {
      this.Jd = new ArrayList();
    }
    byte[] arrayOfByte = paramdz.c(i, paramdz.getPosition() - i);
    this.Jd.add(new eh(paramInt, arrayOfByte));
    return true;
  }
  
  public final <T> T getExtension(ec<M, T> paramec)
  {
    return paramec.i(this.Jd);
  }
  
  public int getSerializedSize()
  {
    if (this.Jd == null) {}
    int k;
    for (int i = 0;; i = this.Jd.size())
    {
      int j = 0;
      k = 0;
      while (j < i)
      {
        eh localeh = (eh)this.Jd.get(j);
        k = k + ea.bI(localeh.tag) + localeh.Ji.length;
        j++;
      }
    }
    this.Jh = k;
    return k;
  }
  
  public final <T> M setExtension(ec<M, T> paramec, T paramT)
  {
    this.Jd = paramec.a(paramT, this.Jd);
    return this;
  }
  
  public void writeTo(ea paramea)
    throws IOException
  {
    if (this.Jd == null) {}
    for (int i = 0;; i = this.Jd.size()) {
      for (int j = 0; j < i; j++)
      {
        eh localeh = (eh)this.Jd.get(j);
        paramea.bH(localeh.tag);
        paramea.u(localeh.Ji);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.eb
 * JD-Core Version:    0.7.0.1
 */