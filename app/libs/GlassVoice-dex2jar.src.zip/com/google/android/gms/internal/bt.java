package com.google.android.gms.internal;

import android.app.PendingIntent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.ActivityRecognition;
import com.google.android.gms.location.ActivityRecognitionServices.a;

public class bt
  implements ActivityRecognition
{
  public void removeActivityUpdates(GoogleApiClient paramGoogleApiClient, final PendingIntent paramPendingIntent)
  {
    paramGoogleApiClient.a(new a(paramPendingIntent)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.removeActivityUpdates(paramPendingIntent);
        a(Status.rF);
      }
    });
  }
  
  public void requestActivityUpdates(GoogleApiClient paramGoogleApiClient, final long paramLong, PendingIntent paramPendingIntent)
  {
    paramGoogleApiClient.a(new a(paramLong)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.requestActivityUpdates(paramLong, this.wS);
        a(Status.rF);
      }
    });
  }
  
  private static abstract class a
    extends ActivityRecognitionServices.a<Status>
  {
    public int bo()
    {
      return 1;
    }
    
    public Status c(Status paramStatus)
    {
      return paramStatus;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bt
 * JD-Core Version:    0.7.0.1
 */