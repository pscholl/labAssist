package com.google.android.gms.internal;

import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class cm
{
  private static int yA = 1000;
  private static int yz = 10000;
  private final cc<bx> xj;
  private final String yB;
  private final BlockingQueue<ch.a> yC;
  private final Object yD = new Object();
  private Thread yE;
  private int yF;
  private final int ys;
  
  public cm(cc<bx> paramcc, String paramString, int paramInt)
  {
    this.xj = paramcc;
    this.yB = paramString;
    this.ys = paramInt;
    this.yC = new LinkedBlockingQueue(yz);
    this.yF = yA;
  }
  
  public void a(ch.a.a parama)
  {
    parama.P(this.yB);
    parama.aS(this.ys);
    this.yC.offer(parama.cM());
  }
  
  public void cO()
  {
    synchronized (this.yD)
    {
      at.a(this.yE, "Disconnect called when not connected");
      at.a(this.yE.isAlive(), "Disconnect called when not connected");
      this.yE.interrupt();
      try
      {
        this.yE.join();
        this.yE = null;
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        for (;;)
        {
          Thread.currentThread().interrupt();
        }
      }
    }
  }
  
  public void onConnected()
  {
    for (;;)
    {
      synchronized (this.yD)
      {
        if (this.yE != null)
        {
          if (this.yE.isAlive()) {
            break label66;
          }
          break label61;
          at.a(bool, "Connect called when connected");
          this.yE = new a(null);
          this.yE.start();
          return;
        }
      }
      label61:
      boolean bool = true;
      continue;
      label66:
      bool = false;
    }
  }
  
  private class a
    extends Thread
  {
    private a() {}
    
    private void c(List<ch.a> paramList)
    {
      if (paramList.isEmpty()) {
        return;
      }
      try
      {
        ((bx)cm.c(cm.this).bS()).b(paramList);
        return;
      }
      catch (RemoteException localRemoteException) {}
    }
    
    public void run()
    {
      ArrayList localArrayList = new ArrayList();
      try
      {
        for (;;)
        {
          localArrayList.clear();
          localArrayList.add(cm.a(cm.this).take());
          sleep(cm.b(cm.this));
          cm.a(cm.this).drainTo(localArrayList);
          c(localArrayList);
        }
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        cm.a(cm.this).drainTo(localArrayList);
        c(localArrayList);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cm
 * JD-Core Version:    0.7.0.1
 */