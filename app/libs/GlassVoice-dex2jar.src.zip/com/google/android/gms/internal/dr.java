package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.people.model.PhoneNumber;

public class dr
  implements PhoneNumber
{
  private String Dw;
  private final String mValue;
  private final String xK;
  
  public dr(String paramString1, String paramString2)
  {
    this.xK = paramString1;
    this.mValue = paramString2;
  }
  
  static String aj(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return "";
    }
    StringBuilder localStringBuilder = de.dA();
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if ((Character.digit(c, 10) != -1) || (c == '+') || (c == ',') || (c == ';') || (('a' <= c) && (c <= 'z')) || (('A' <= c) && (c <= 'Z'))) {
        localStringBuilder.append(c);
      }
    }
    return localStringBuilder.toString();
  }
  
  private String dU()
  {
    if (this.Dw == null) {
      this.Dw = aj(this.mValue);
    }
    return this.Dw;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof dr))
    {
      dr localdr = (dr)paramObject;
      return ar.equal(dU(), localdr.dU());
    }
    return false;
  }
  
  public String getType()
  {
    return this.xK;
  }
  
  public String getValue()
  {
    return this.mValue;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("PhoneNumber:[Value=");
    String str1;
    StringBuilder localStringBuilder2;
    if (this.mValue != null)
    {
      str1 = this.mValue;
      localStringBuilder2 = localStringBuilder1.append(str1).append(" Type=");
      if (this.xK == null) {
        break label70;
      }
    }
    label70:
    for (String str2 = this.xK;; str2 = "null")
    {
      return str2 + "]";
      str1 = "null";
      break;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dr
 * JD-Core Version:    0.7.0.1
 */