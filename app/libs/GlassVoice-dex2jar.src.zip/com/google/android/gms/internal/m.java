package com.google.android.gms.internal;

public class m
  extends Exception
{
  public m() {}
  
  public m(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.m
 * JD-Core Version:    0.7.0.1
 */