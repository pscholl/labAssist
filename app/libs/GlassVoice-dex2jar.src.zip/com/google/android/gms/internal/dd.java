package com.google.android.gms.internal;

import android.util.Log;

public final class dd
{
  public static void a(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (bf(5)) {
      Log.w(paramString1, paramString2, paramThrowable);
    }
  }
  
  public static void b(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (bf(6)) {
      Log.e(paramString1, paramString2, paramThrowable);
    }
  }
  
  public static boolean bf(int paramInt)
  {
    return Log.isLoggable("PeopleService", paramInt);
  }
  
  public static boolean dz()
  {
    return bf(3);
  }
  
  public static void g(String paramString1, String paramString2)
  {
    if (bf(3)) {
      Log.d(paramString1, paramString2);
    }
  }
  
  public static void h(String paramString1, String paramString2)
  {
    if (bf(2)) {
      Log.v(paramString1, paramString2);
    }
  }
  
  public static void i(String paramString1, String paramString2)
  {
    if (bf(5)) {
      Log.w(paramString1, paramString2);
    }
  }
  
  public static void j(String paramString1, String paramString2)
  {
    if (bf(6)) {
      Log.e(paramString1, paramString2);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dd
 * JD-Core Version:    0.7.0.1
 */