package com.google.android.gms.internal;

import android.os.RemoteException;

public class bp
  extends br.a
{
  public void h(byte[] paramArrayOfByte)
    throws RemoteException
  {}
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bp
 * JD-Core Version:    0.7.0.1
 */