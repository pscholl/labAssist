package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class de
{
  public static final Map<String, Integer> Ch = new HashMap() {};
  public static final Handler Ci = new Handler(Looper.getMainLooper());
  public static final String[] Cj = new String[0];
  public static final Pattern Ck = Pattern.compile("\\,");
  public static final Pattern Cl = Pattern.compile("[     ᠎             　\t\013\f\034\035\036\037\n\r]+");
  public static final SecureRandom Cm = new SecureRandom();
  private static final ThreadLocal<StringBuilder> Cn = new ThreadLocal()
  {
    protected StringBuilder dB()
    {
      return new StringBuilder();
    }
  };
  private static final ThreadLocal<String[]> Co = new ThreadLocal()
  {
    protected String[] dC()
    {
      return new String[1];
    }
  };
  private static final ThreadLocal<String[]> Cp = new ThreadLocal()
  {
    protected String[] dC()
    {
      return new String[2];
    }
  };
  private static final ThreadLocal<String[]> Cq = new ThreadLocal()
  {
    protected String[] dC()
    {
      return new String[3];
    }
  };
  private static final ThreadLocal<String[]> Cr = new ThreadLocal()
  {
    protected String[] dC()
    {
      return new String[4];
    }
  };
  private static final ThreadLocal<String[]> Cs = new ThreadLocal()
  {
    protected String[] dC()
    {
      return new String[5];
    }
  };
  
  public static String W(String paramString)
  {
    at.f(paramString);
    return "g:" + paramString;
  }
  
  public static String X(String paramString)
  {
    if ((paramString == null) || (!paramString.startsWith("e:"))) {
      return null;
    }
    return paramString.substring("e:".length());
  }
  
  public static String Y(String paramString)
  {
    at.C(paramString);
    return "e:" + paramString;
  }
  
  public static boolean Z(String paramString)
  {
    return (paramString != null) && (paramString.startsWith("e:"));
  }
  
  public static StringBuilder dA()
  {
    StringBuilder localStringBuilder = (StringBuilder)Cn.get();
    localStringBuilder.setLength(0);
    return localStringBuilder;
  }
  
  public static void k(String paramString1, String paramString2)
  {
    at.b(paramString1, paramString2);
    if ((paramString1.startsWith("g:")) || (paramString1.startsWith("e:"))) {}
    for (boolean bool = true;; bool = false)
    {
      at.b(bool, paramString2 + ": Expecting qualified-id, not gaia-id");
      return;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.de
 * JD-Core Version:    0.7.0.1
 */