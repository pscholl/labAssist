package com.google.android.gms.internal;

import android.content.Context;

public abstract interface h
{
  public abstract String a(Context paramContext);
  
  public abstract String a(Context paramContext, String paramString);
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.h
 * JD-Core Version:    0.7.0.1
 */