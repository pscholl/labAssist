package com.google.android.gms.internal;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.common.data.b;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.model.Circle;

public final class ct
  extends b
  implements Circle
{
  private final Bundle sk;
  
  public ct(d paramd, int paramInt, Bundle paramBundle)
  {
    super(paramd, paramInt);
    this.sk = paramBundle;
  }
  
  private int dr()
  {
    return getInteger("client_policies");
  }
  
  @Deprecated
  public String getAccountName()
  {
    return getOwnerAccountName();
  }
  
  public String getCircleId()
  {
    return getString("circle_id");
  }
  
  public String getCircleName()
  {
    int i = getCircleType();
    if (i != -1)
    {
      Bundle localBundle = this.sk.getBundle("localized_group_names");
      if (localBundle != null)
      {
        String str = localBundle.getString(String.valueOf(i));
        if (!TextUtils.isEmpty(str)) {
          return str;
        }
      }
    }
    return getString("name");
  }
  
  public int getCircleType()
  {
    int i = getInteger("type");
    switch (i)
    {
    case 0: 
    default: 
      i = -2;
    }
    return i;
  }
  
  public long getLastModifiedTime()
  {
    return getLong("last_modified");
  }
  
  public String getOwnerAccountName()
  {
    return this.sk.getString("account");
  }
  
  public String getOwnerPlusPageId()
  {
    return this.sk.getString("pagegaiaid");
  }
  
  public int getPeopleCount()
  {
    return getInteger("people_count");
  }
  
  @Deprecated
  public String getPlusPageGaiaId()
  {
    return getOwnerPlusPageId();
  }
  
  public String getSortKey()
  {
    return getString("sort_key");
  }
  
  public int getVisibility()
  {
    Bundle localBundle = this.sk.getBundle("circlevisibility");
    if (localBundle == null) {}
    while (!localBundle.containsKey(getCircleId())) {
      return 0;
    }
    return localBundle.getInt(getCircleId());
  }
  
  public boolean isEnabledForSharing()
  {
    return getBoolean("for_sharing");
  }
  
  public boolean isSyncToContactsEnabled()
  {
    return getBoolean("sync_to_contacts");
  }
  
  public boolean policyCannotAclTo()
  {
    return (0x8 & dr()) != 0;
  }
  
  public boolean policyCannotModifyMembership()
  {
    return (0x2 & dr()) != 0;
  }
  
  public boolean policyCannotViewMembership()
  {
    return (0x1 & dr()) != 0;
  }
  
  public boolean policyVisibleOnlyWhenPopulated()
  {
    return (0x10 & dr()) != 0;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ct
 * JD-Core Version:    0.7.0.1
 */