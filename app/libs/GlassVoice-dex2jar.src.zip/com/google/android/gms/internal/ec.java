package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ec<M extends eb<M>, T>
{
  protected final Class<T> Je;
  protected final boolean Jf;
  protected final int tag;
  protected final int type;
  
  private ec(int paramInt1, Class<T> paramClass, int paramInt2, boolean paramBoolean)
  {
    this.type = paramInt1;
    this.Je = paramClass;
    this.tag = paramInt2;
    this.Jf = paramBoolean;
  }
  
  public static <M extends eb<M>, T extends ef> ec<M, T> a(int paramInt1, Class<T> paramClass, int paramInt2)
  {
    return new ec(paramInt1, paramClass, paramInt2, false);
  }
  
  final List<eh> a(T paramT, List<eh> paramList)
  {
    if (paramList != null) {
      for (int i = -1 + paramList.size(); i >= 0; i--) {
        if (bK(((eh)paramList.get(i)).tag)) {
          paramList.remove(i);
        }
      }
    }
    if (paramT != null)
    {
      if (paramList == null) {
        paramList = new ArrayList();
      }
      if (!this.Jf) {
        break label97;
      }
      b(paramT, paramList);
    }
    for (;;)
    {
      if (paramList.size() == 0) {
        paramList = null;
      }
      return paramList;
      label97:
      paramList.add(u(paramT));
    }
  }
  
  protected void a(eh parameh, List<Object> paramList)
  {
    paramList.add(m(dz.q(parameh.Ji)));
  }
  
  protected void b(T paramT, List<eh> paramList)
  {
    int i = Array.getLength(paramT);
    for (int j = 0; j < i; j++)
    {
      Object localObject = Array.get(paramT, j);
      if (localObject != null) {
        paramList.add(u(localObject));
      }
    }
  }
  
  protected boolean bK(int paramInt)
  {
    return paramInt == this.tag;
  }
  
  final T i(List<eh> paramList)
  {
    int i = 0;
    Object localObject1;
    if (paramList == null) {
      localObject1 = null;
    }
    for (;;)
    {
      return localObject1;
      if (!this.Jf) {
        break;
      }
      ArrayList localArrayList = new ArrayList();
      for (int j = 0; j < paramList.size(); j++)
      {
        eh localeh = (eh)paramList.get(j);
        if ((bK(localeh.tag)) && (localeh.Ji.length != 0)) {
          a(localeh, localArrayList);
        }
      }
      int k = localArrayList.size();
      if (k == 0) {
        return null;
      }
      localObject1 = this.Je.cast(Array.newInstance(this.Je.getComponentType(), k));
      while (i < k)
      {
        Array.set(localObject1, i, localArrayList.get(i));
        i++;
      }
    }
    int m = -1 + paramList.size();
    Object localObject2 = null;
    Object localObject3;
    if ((localObject2 == null) && (m >= 0))
    {
      localObject3 = (eh)paramList.get(m);
      if ((!bK(((eh)localObject3).tag)) || (((eh)localObject3).Ji.length == 0)) {
        break label243;
      }
    }
    for (;;)
    {
      m--;
      localObject2 = localObject3;
      break;
      if (localObject2 == null) {
        return null;
      }
      return this.Je.cast(m(dz.q(localObject2.Ji)));
      label243:
      localObject3 = localObject2;
    }
  }
  
  protected Object m(dz paramdz)
  {
    Class localClass;
    if (this.Jf) {
      localClass = this.Je.getComponentType();
    }
    try
    {
      switch (this.type)
      {
      default: 
        throw new IllegalArgumentException("Unknown type " + this.type);
      }
    }
    catch (InstantiationException localInstantiationException)
    {
      for (;;)
      {
        throw new IllegalArgumentException("Error creating instance of class " + localClass, localInstantiationException);
        localClass = this.Je;
      }
      ef localef2 = (ef)localClass.newInstance();
      paramdz.a(localef2, ei.bM(this.tag));
      return localef2;
      ef localef1 = (ef)localClass.newInstance();
      paramdz.a(localef1);
      return localef1;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalArgumentException("Error creating instance of class " + localClass, localIllegalAccessException);
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("Error reading extension field", localIOException);
    }
  }
  
  protected eh u(Object paramObject)
  {
    try
    {
      switch (this.type)
      {
      default: 
        throw new IllegalArgumentException("Unknown type " + this.type);
      }
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException);
    }
    ef localef2 = (ef)paramObject;
    int i = ei.bM(this.tag);
    byte[] arrayOfByte = new byte[ea.d(localef2) + ea.bG(i)];
    ea localea = ea.r(arrayOfByte);
    localea.b(localef2);
    localea.f(i, 4);
    for (;;)
    {
      return new eh(this.tag, arrayOfByte);
      ef localef1 = (ef)paramObject;
      arrayOfByte = new byte[ea.e(localef1)];
      ea.r(arrayOfByte).c(localef1);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ec
 * JD-Core Version:    0.7.0.1
 */