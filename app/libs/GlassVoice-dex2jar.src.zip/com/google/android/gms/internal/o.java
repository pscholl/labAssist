package com.google.android.gms.internal;

import java.io.IOException;

abstract interface o
{
  public abstract void b(int paramInt, long paramLong)
    throws IOException;
  
  public abstract void b(int paramInt, String paramString)
    throws IOException;
  
  public abstract void reset();
  
  public abstract byte[] w()
    throws IOException;
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.o
 * JD-Core Version:    0.7.0.1
 */