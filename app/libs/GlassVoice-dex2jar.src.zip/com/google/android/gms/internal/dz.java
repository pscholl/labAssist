package com.google.android.gms.internal;

import java.io.IOException;

public final class dz
{
  private int IT;
  private int IU;
  private int IV;
  private int IW;
  private int IX;
  private int IY = 2147483647;
  private int IZ;
  private int Ja = 64;
  private int Jb = 67108864;
  private final byte[] buffer;
  
  private dz(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.buffer = paramArrayOfByte;
    this.IT = paramInt1;
    this.IU = (paramInt1 + paramInt2);
    this.IW = paramInt1;
  }
  
  public static dz a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return new dz(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  private void gj()
  {
    this.IU += this.IV;
    int i = this.IU;
    if (i > this.IY)
    {
      this.IV = (i - this.IY);
      this.IU -= this.IV;
      return;
    }
    this.IV = 0;
  }
  
  public static dz q(byte[] paramArrayOfByte)
  {
    return a(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void a(ef paramef)
    throws IOException
  {
    int i = gf();
    if (this.IZ >= this.Ja) {
      throw ee.gv();
    }
    int j = by(i);
    this.IZ = (1 + this.IZ);
    paramef.mergeFrom(this);
    bw(0);
    this.IZ = (-1 + this.IZ);
    bz(j);
  }
  
  public void a(ef paramef, int paramInt)
    throws IOException
  {
    if (this.IZ >= this.Ja) {
      throw ee.gv();
    }
    this.IZ = (1 + this.IZ);
    paramef.mergeFrom(this);
    bw(ei.g(paramInt, 4));
    this.IZ = (-1 + this.IZ);
  }
  
  public void bA(int paramInt)
  {
    if (paramInt > this.IW - this.IT) {
      throw new IllegalArgumentException("Position " + paramInt + " is beyond current " + (this.IW - this.IT));
    }
    if (paramInt < 0) {
      throw new IllegalArgumentException("Bad position " + paramInt);
    }
    this.IW = (paramInt + this.IT);
  }
  
  public byte[] bB(int paramInt)
    throws IOException
  {
    if (paramInt < 0) {
      throw ee.gq();
    }
    if (paramInt + this.IW > this.IY)
    {
      bC(this.IY - this.IW);
      throw ee.gp();
    }
    if (paramInt <= this.IU - this.IW)
    {
      byte[] arrayOfByte = new byte[paramInt];
      System.arraycopy(this.buffer, this.IW, arrayOfByte, 0, paramInt);
      this.IW = (paramInt + this.IW);
      return arrayOfByte;
    }
    throw ee.gp();
  }
  
  public void bC(int paramInt)
    throws IOException
  {
    if (paramInt < 0) {
      throw ee.gq();
    }
    if (paramInt + this.IW > this.IY)
    {
      bC(this.IY - this.IW);
      throw ee.gp();
    }
    if (paramInt <= this.IU - this.IW)
    {
      this.IW = (paramInt + this.IW);
      return;
    }
    throw ee.gp();
  }
  
  public void bw(int paramInt)
    throws ee
  {
    if (this.IX != paramInt) {
      throw ee.gt();
    }
  }
  
  public boolean bx(int paramInt)
    throws IOException
  {
    switch (ei.bL(paramInt))
    {
    default: 
      throw ee.gu();
    case 0: 
      gd();
      return true;
    case 1: 
      gi();
      return true;
    case 2: 
      bC(gf());
      return true;
    case 3: 
      gb();
      bw(ei.g(ei.bM(paramInt), 4));
      return true;
    case 4: 
      return false;
    }
    gh();
    return true;
  }
  
  public int by(int paramInt)
    throws ee
  {
    if (paramInt < 0) {
      throw ee.gq();
    }
    int i = paramInt + this.IW;
    int j = this.IY;
    if (i > j) {
      throw ee.gp();
    }
    this.IY = i;
    gj();
    return j;
  }
  
  public void bz(int paramInt)
  {
    this.IY = paramInt;
    gj();
  }
  
  public byte[] c(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      return ei.Jq;
    }
    byte[] arrayOfByte = new byte[paramInt2];
    int i = paramInt1 + this.IT;
    System.arraycopy(this.buffer, i, arrayOfByte, 0, paramInt2);
    return arrayOfByte;
  }
  
  public int ga()
    throws IOException
  {
    if (gl())
    {
      this.IX = 0;
      return 0;
    }
    this.IX = gf();
    if (this.IX == 0) {
      throw ee.gs();
    }
    return this.IX;
  }
  
  public void gb()
    throws IOException
  {
    int i;
    do
    {
      i = ga();
    } while ((i != 0) && (bx(i)));
  }
  
  public long gc()
    throws IOException
  {
    return gg();
  }
  
  public int gd()
    throws IOException
  {
    return gf();
  }
  
  public boolean ge()
    throws IOException
  {
    return gf() != 0;
  }
  
  public int getPosition()
  {
    return this.IW - this.IT;
  }
  
  public int gf()
    throws IOException
  {
    int i = gm();
    if (i >= 0) {}
    int i4;
    do
    {
      return i;
      int j = i & 0x7F;
      int k = gm();
      if (k >= 0) {
        return j | k << 7;
      }
      int m = j | (k & 0x7F) << 7;
      int n = gm();
      if (n >= 0) {
        return m | n << 14;
      }
      int i1 = m | (n & 0x7F) << 14;
      int i2 = gm();
      if (i2 >= 0) {
        return i1 | i2 << 21;
      }
      int i3 = i1 | (i2 & 0x7F) << 21;
      i4 = gm();
      i = i3 | i4 << 28;
    } while (i4 >= 0);
    for (int i5 = 0;; i5++)
    {
      if (i5 >= 5) {
        break label151;
      }
      if (gm() >= 0) {
        break;
      }
    }
    label151:
    throw ee.gr();
  }
  
  public long gg()
    throws IOException
  {
    int i = 0;
    long l = 0L;
    while (i < 64)
    {
      int j = gm();
      l |= (j & 0x7F) << i;
      if ((j & 0x80) == 0) {
        return l;
      }
      i += 7;
    }
    throw ee.gr();
  }
  
  public int gh()
    throws IOException
  {
    int i = gm();
    int j = gm();
    int k = gm();
    int m = gm();
    return i & 0xFF | (j & 0xFF) << 8 | (k & 0xFF) << 16 | (m & 0xFF) << 24;
  }
  
  public long gi()
    throws IOException
  {
    int i = gm();
    int j = gm();
    int k = gm();
    int m = gm();
    int n = gm();
    int i1 = gm();
    int i2 = gm();
    int i3 = gm();
    return 0xFF & i | (0xFF & j) << 8 | (0xFF & k) << 16 | (0xFF & m) << 24 | (0xFF & n) << 32 | (0xFF & i1) << 40 | (0xFF & i2) << 48 | (0xFF & i3) << 56;
  }
  
  public int gk()
  {
    if (this.IY == 2147483647) {
      return -1;
    }
    int i = this.IW;
    return this.IY - i;
  }
  
  public boolean gl()
  {
    return this.IW == this.IU;
  }
  
  public byte gm()
    throws IOException
  {
    if (this.IW == this.IU) {
      throw ee.gp();
    }
    byte[] arrayOfByte = this.buffer;
    int i = this.IW;
    this.IW = (i + 1);
    return arrayOfByte[i];
  }
  
  public byte[] readBytes()
    throws IOException
  {
    int i = gf();
    if ((i <= this.IU - this.IW) && (i > 0))
    {
      byte[] arrayOfByte = new byte[i];
      System.arraycopy(this.buffer, this.IW, arrayOfByte, 0, i);
      this.IW = (i + this.IW);
      return arrayOfByte;
    }
    return bB(i);
  }
  
  public float readFloat()
    throws IOException
  {
    return Float.intBitsToFloat(gh());
  }
  
  public String readString()
    throws IOException
  {
    int i = gf();
    if ((i <= this.IU - this.IW) && (i > 0))
    {
      String str = new String(this.buffer, this.IW, i, "UTF-8");
      this.IW = (i + this.IW);
      return str;
    }
    return new String(bB(i), "UTF-8");
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dz
 * JD-Core Version:    0.7.0.1
 */