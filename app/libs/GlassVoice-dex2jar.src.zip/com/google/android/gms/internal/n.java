package com.google.android.gms.internal;

public abstract interface n
{
  public abstract String a(byte[] paramArrayOfByte, boolean paramBoolean);
  
  public abstract byte[] a(String paramString, boolean paramBoolean)
    throws IllegalArgumentException;
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.n
 * JD-Core Version:    0.7.0.1
 */