package com.google.android.gms.internal;

import java.io.IOException;

public class ee
  extends IOException
{
  public ee(String paramString)
  {
    super(paramString);
  }
  
  static ee gp()
  {
    return new ee("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either than the input has been truncated or that an embedded message misreported its own length.");
  }
  
  static ee gq()
  {
    return new ee("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
  }
  
  static ee gr()
  {
    return new ee("CodedInputStream encountered a malformed varint.");
  }
  
  static ee gs()
  {
    return new ee("Protocol message contained an invalid tag (zero).");
  }
  
  static ee gt()
  {
    return new ee("Protocol message end-group tag did not match expected tag.");
  }
  
  static ee gu()
  {
    return new ee("Protocol message tag had invalid wire type.");
  }
  
  static ee gv()
  {
    return new ee("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ee
 * JD-Core Version:    0.7.0.1
 */