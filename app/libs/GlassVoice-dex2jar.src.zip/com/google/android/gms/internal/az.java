package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class az
  implements SafeParcelable
{
  public static final ba CREATOR = new ba();
  final int oj;
  public final int uA;
  public final String uz;
  
  public az(int paramInt1, String paramString, int paramInt2)
  {
    this.oj = paramInt1;
    this.uz = paramString;
    this.uA = paramInt2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    ba.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.az
 * JD-Core Version:    0.7.0.1
 */