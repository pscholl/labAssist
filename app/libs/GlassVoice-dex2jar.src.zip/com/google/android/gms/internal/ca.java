package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.location.Geofence;
import java.util.Locale;

public class ca
  implements SafeParcelable, Geofence
{
  public static final cb CREATOR = new cb();
  private final int oj;
  private final String wA;
  private final int wB;
  private final short wD;
  private final double wE;
  private final double wF;
  private final float wG;
  private final int wH;
  private final int wI;
  private final long xy;
  
  public ca(int paramInt1, String paramString, int paramInt2, short paramShort, double paramDouble1, double paramDouble2, float paramFloat, long paramLong, int paramInt3, int paramInt4)
  {
    N(paramString);
    b(paramFloat);
    a(paramDouble1, paramDouble2);
    int i = aI(paramInt2);
    this.oj = paramInt1;
    this.wD = paramShort;
    this.wA = paramString;
    this.wE = paramDouble1;
    this.wF = paramDouble2;
    this.wG = paramFloat;
    this.xy = paramLong;
    this.wB = i;
    this.wH = paramInt3;
    this.wI = paramInt4;
  }
  
  public ca(String paramString, int paramInt1, short paramShort, double paramDouble1, double paramDouble2, float paramFloat, long paramLong, int paramInt2, int paramInt3)
  {
    this(1, paramString, paramInt1, paramShort, paramDouble1, paramDouble2, paramFloat, paramLong, paramInt2, paramInt3);
  }
  
  private static void N(String paramString)
  {
    if ((paramString == null) || (paramString.length() > 100)) {
      throw new IllegalArgumentException("requestId is null or too long: " + paramString);
    }
  }
  
  private static void a(double paramDouble1, double paramDouble2)
  {
    if ((paramDouble1 > 90.0D) || (paramDouble1 < -90.0D)) {
      throw new IllegalArgumentException("invalid latitude: " + paramDouble1);
    }
    if ((paramDouble2 > 180.0D) || (paramDouble2 < -180.0D)) {
      throw new IllegalArgumentException("invalid longitude: " + paramDouble2);
    }
  }
  
  private static int aI(int paramInt)
  {
    int i = paramInt & 0x7;
    if (i == 0) {
      throw new IllegalArgumentException("No supported transition specified: " + paramInt);
    }
    return i;
  }
  
  private static String aJ(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return null;
    }
    return "CIRCLE";
  }
  
  private static void b(float paramFloat)
  {
    if (paramFloat <= 0.0F) {
      throw new IllegalArgumentException("invalid radius: " + paramFloat);
    }
  }
  
  public static ca k(byte[] paramArrayOfByte)
  {
    Parcel localParcel = Parcel.obtain();
    localParcel.unmarshall(paramArrayOfByte, 0, paramArrayOfByte.length);
    localParcel.setDataPosition(0);
    ca localca = CREATOR.am(localParcel);
    localParcel.recycle();
    return localca;
  }
  
  public float cA()
  {
    return this.wG;
  }
  
  public int cB()
  {
    return this.wB;
  }
  
  public int cC()
  {
    return this.wI;
  }
  
  public short cz()
  {
    return this.wD;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    ca localca;
    do
    {
      return true;
      if (paramObject == null) {
        return false;
      }
      if (!(paramObject instanceof ca)) {
        return false;
      }
      localca = (ca)paramObject;
      if (this.wG != localca.wG) {
        return false;
      }
      if (this.wE != localca.wE) {
        return false;
      }
      if (this.wF != localca.wF) {
        return false;
      }
    } while (this.wD == localca.wD);
    return false;
  }
  
  public long getExpirationTime()
  {
    return this.xy;
  }
  
  public double getLatitude()
  {
    return this.wE;
  }
  
  public double getLongitude()
  {
    return this.wF;
  }
  
  public int getNotificationResponsiveness()
  {
    return this.wH;
  }
  
  public String getRequestId()
  {
    return this.wA;
  }
  
  public int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    long l1 = Double.doubleToLongBits(this.wE);
    int i = 31 + (int)(l1 ^ l1 >>> 32);
    long l2 = Double.doubleToLongBits(this.wF);
    return 31 * (31 * (31 * (i * 31 + (int)(l2 ^ l2 >>> 32)) + Float.floatToIntBits(this.wG)) + this.wD) + this.wB;
  }
  
  public String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[9];
    arrayOfObject[0] = aJ(this.wD);
    arrayOfObject[1] = this.wA;
    arrayOfObject[2] = Integer.valueOf(this.wB);
    arrayOfObject[3] = Double.valueOf(this.wE);
    arrayOfObject[4] = Double.valueOf(this.wF);
    arrayOfObject[5] = Float.valueOf(this.wG);
    arrayOfObject[6] = Integer.valueOf(this.wH / 1000);
    arrayOfObject[7] = Integer.valueOf(this.wI);
    arrayOfObject[8] = Long.valueOf(this.xy);
    return String.format(localLocale, "Geofence[%s id:%s transitions:%d %.6f, %.6f %.0fm, resp=%ds, dwell=%dms, @%d]", arrayOfObject);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    cb.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ca
 * JD-Core Version:    0.7.0.1
 */