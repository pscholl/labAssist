package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class dj<T>
{
  private final HashMap<String, Object> Bh = new HashMap();
  
  private String[] dE()
  {
    String[] arrayOfString = (String[])new ArrayList(this.Bh.keySet()).toArray(de.Cj);
    Arrays.sort(arrayOfString);
    return arrayOfString;
  }
  
  public int ae(String paramString)
  {
    at.f(paramString);
    Object localObject = this.Bh.get(paramString);
    if (localObject == null) {
      return 0;
    }
    if ((localObject instanceof ArrayList)) {
      return ((ArrayList)localObject).size();
    }
    return 1;
  }
  
  public T i(String paramString, int paramInt)
  {
    at.f(paramString);
    if (paramInt >= 0) {}
    Object localObject;
    for (boolean bool = true;; bool = false)
    {
      at.h(bool);
      localObject = this.Bh.get(paramString);
      if (localObject != null) {
        break;
      }
      throw new IndexOutOfBoundsException("Size=0, requested=" + paramInt);
    }
    if ((localObject instanceof ArrayList))
    {
      localArrayList = (ArrayList)localObject;
      if (paramInt > localArrayList.size()) {
        throw new IndexOutOfBoundsException("Size=" + localArrayList.size() + ", requested=" + paramInt);
      }
      localObject = localArrayList.get(paramInt);
    }
    while (paramInt <= 0)
    {
      ArrayList localArrayList;
      return localObject;
    }
    throw new IndexOutOfBoundsException("Size=1, requested=" + paramInt);
  }
  
  public void put(String paramString, T paramT)
  {
    at.f(paramString);
    Object localObject = this.Bh.get(paramString);
    if (localObject == null)
    {
      this.Bh.put(paramString, paramT);
      return;
    }
    if ((localObject instanceof ArrayList))
    {
      ((ArrayList)localObject).add(paramT);
      return;
    }
    ArrayList localArrayList = new ArrayList(4);
    localArrayList.add(localObject);
    localArrayList.add(paramT);
    this.Bh.put(paramString, localArrayList);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = de.dA();
    for (String str : dE())
    {
      if (localStringBuilder.length() > 0) {
        localStringBuilder.append(",");
      }
      localStringBuilder.append(str);
      localStringBuilder.append("=");
      int k = ae(str);
      for (int m = 0; m < k; m++)
      {
        if (m > 0) {
          localStringBuilder.append(".");
        }
        localStringBuilder.append(i(str, m));
      }
      localStringBuilder.append("");
    }
    return localStringBuilder.toString();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dj
 * JD-Core Version:    0.7.0.1
 */