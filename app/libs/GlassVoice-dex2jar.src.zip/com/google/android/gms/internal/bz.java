package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationClient.OnAddGeofencesResultListener;
import com.google.android.gms.location.LocationClient.OnRemoveGeofencesResultListener;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationStatus;
import com.google.android.gms.location.LocationStatusCodes;
import java.util.List;
import java.util.Locale;

public class bz
  extends ak<bx>
{
  private final String pU;
  private final cc<bx> xj = new c(null);
  private final by xp = new by(paramContext, this.xj);
  private final cl xq;
  private final String xr;
  
  public bz(Context paramContext, Looper paramLooper, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString)
  {
    this(paramContext, paramLooper, paramConnectionCallbacks, paramOnConnectionFailedListener, paramString, null, Locale.getDefault());
  }
  
  public bz(Context paramContext, Looper paramLooper, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString1, String paramString2, Locale paramLocale)
  {
    super(paramContext, paramLooper, paramConnectionCallbacks, paramOnConnectionFailedListener, new String[0]);
    this.xr = paramString1;
    this.pU = paramString2;
    this.xq = new cl(getContext(), paramLocale, this.xj);
  }
  
  public bz(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString)
  {
    super(paramContext, paramConnectionCallbacks, paramOnConnectionFailedListener, new String[0]);
    this.xr = paramString;
    this.pU = null;
    this.xq = new cl(getContext(), Locale.getDefault(), this.xj);
  }
  
  protected bx C(IBinder paramIBinder)
  {
    return bx.a.B(paramIBinder);
  }
  
  protected void a(ap paramap, ak.d paramd)
    throws RemoteException
  {
    Bundle localBundle = new Bundle();
    localBundle.putString("client_name", this.xr);
    paramap.e(paramd, 4324000, getContext().getPackageName(), localBundle);
  }
  
  public void addGeofences(List<ca> paramList, PendingIntent paramPendingIntent, LocationClient.OnAddGeofencesResultListener paramOnAddGeofencesResultListener)
  {
    M();
    if ((paramList != null) && (paramList.size() > 0)) {}
    for (boolean bool = true;; bool = false)
    {
      at.b(bool, "At least one geofence must be specified.");
      at.a(paramPendingIntent, "PendingIntent must be specified.");
      at.a(paramOnAddGeofencesResultListener, "OnAddGeofencesResultListener not provided.");
      if (paramOnAddGeofencesResultListener == null) {}
      for (Object localObject = null;; localObject = localb)
      {
        try
        {
          ((bx)bS()).a(paramList, paramPendingIntent, (bw)localObject, getContext().getPackageName());
          return;
        }
        catch (RemoteException localRemoteException)
        {
          b localb;
          throw new IllegalStateException(localRemoteException);
        }
        localb = new b(paramOnAddGeofencesResultListener, this);
      }
    }
  }
  
  protected String bQ()
  {
    return "com.google.android.location.internal.GoogleLocationManagerService.START";
  }
  
  protected String bR()
  {
    return "com.google.android.gms.location.internal.IGoogleLocationManagerService";
  }
  
  public cl cx()
  {
    return this.xq;
  }
  
  public void disconnect()
  {
    synchronized (this.xp)
    {
      if (isConnected())
      {
        this.xp.removeAllListeners();
        this.xp.cw();
      }
      super.disconnect();
      return;
    }
  }
  
  public Location getLastLocation()
  {
    return this.xp.getLastLocation();
  }
  
  public LocationStatus getLastLocationStatus()
  {
    return this.xp.getLastLocationStatus();
  }
  
  public void injectLocation(Location paramLocation, int paramInt)
  {
    this.xp.injectLocation(paramLocation, paramInt);
  }
  
  public void removeActivityUpdates(PendingIntent paramPendingIntent)
  {
    M();
    at.f(paramPendingIntent);
    try
    {
      ((bx)bS()).removeActivityUpdates(paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void removeGeofences(PendingIntent paramPendingIntent, LocationClient.OnRemoveGeofencesResultListener paramOnRemoveGeofencesResultListener)
  {
    M();
    at.a(paramPendingIntent, "PendingIntent must be specified.");
    at.a(paramOnRemoveGeofencesResultListener, "OnRemoveGeofencesResultListener not provided.");
    if (paramOnRemoveGeofencesResultListener == null) {}
    for (Object localObject = null;; localObject = localb)
    {
      try
      {
        ((bx)bS()).a(paramPendingIntent, (bw)localObject, getContext().getPackageName());
        return;
      }
      catch (RemoteException localRemoteException)
      {
        b localb;
        throw new IllegalStateException(localRemoteException);
      }
      localb = new b(paramOnRemoveGeofencesResultListener, this);
    }
  }
  
  public void removeGeofences(List<String> paramList, LocationClient.OnRemoveGeofencesResultListener paramOnRemoveGeofencesResultListener)
  {
    M();
    if ((paramList != null) && (paramList.size() > 0)) {}
    for (boolean bool = true;; bool = false)
    {
      at.b(bool, "geofenceRequestIds can't be null nor empty.");
      at.a(paramOnRemoveGeofencesResultListener, "OnRemoveGeofencesResultListener not provided.");
      String[] arrayOfString = (String[])paramList.toArray(new String[0]);
      if (paramOnRemoveGeofencesResultListener == null) {}
      for (Object localObject = null;; localObject = localb)
      {
        try
        {
          ((bx)bS()).a(arrayOfString, (bw)localObject, getContext().getPackageName());
          return;
        }
        catch (RemoteException localRemoteException)
        {
          b localb;
          throw new IllegalStateException(localRemoteException);
        }
        localb = new b(paramOnRemoveGeofencesResultListener, this);
      }
    }
  }
  
  public void removeLocationUpdates(PendingIntent paramPendingIntent)
  {
    this.xp.removeLocationUpdates(paramPendingIntent);
  }
  
  public void removeLocationUpdates(LocationListener paramLocationListener)
  {
    this.xp.removeLocationUpdates(paramLocationListener);
  }
  
  public void requestActivityUpdates(long paramLong, PendingIntent paramPendingIntent)
  {
    boolean bool = true;
    M();
    at.f(paramPendingIntent);
    if (paramLong >= 0L) {}
    for (;;)
    {
      at.b(bool, "detectionIntervalMillis must be >= 0");
      try
      {
        ((bx)bS()).a(paramLong, true, paramPendingIntent);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new IllegalStateException(localRemoteException);
      }
      bool = false;
    }
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, PendingIntent paramPendingIntent)
  {
    this.xp.requestLocationUpdates(paramLocationRequest, paramPendingIntent);
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, LocationListener paramLocationListener)
  {
    requestLocationUpdates(paramLocationRequest, paramLocationListener, null);
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, LocationListener paramLocationListener, Looper paramLooper)
  {
    synchronized (this.xp)
    {
      this.xp.requestLocationUpdates(paramLocationRequest, paramLocationListener, paramLooper);
      return;
    }
  }
  
  public void setMockLocation(Location paramLocation)
  {
    this.xp.setMockLocation(paramLocation);
  }
  
  public void setMockMode(boolean paramBoolean)
  {
    this.xp.setMockMode(paramBoolean);
  }
  
  private final class a
    extends ak<bx>.b<LocationClient.OnAddGeofencesResultListener>
  {
    private final int qx;
    private final String[] xs;
    
    public a(LocationClient.OnAddGeofencesResultListener paramOnAddGeofencesResultListener, int paramInt, String[] paramArrayOfString)
    {
      super(paramOnAddGeofencesResultListener);
      this.qx = LocationStatusCodes.aF(paramInt);
      this.xs = paramArrayOfString;
    }
    
    protected void a(LocationClient.OnAddGeofencesResultListener paramOnAddGeofencesResultListener)
    {
      if (paramOnAddGeofencesResultListener != null) {
        paramOnAddGeofencesResultListener.onAddGeofencesResult(this.qx, this.xs);
      }
    }
    
    protected void bT() {}
  }
  
  private static final class b
    extends bw.a
  {
    private LocationClient.OnAddGeofencesResultListener xu;
    private LocationClient.OnRemoveGeofencesResultListener xv;
    private bz xw;
    
    public b(LocationClient.OnAddGeofencesResultListener paramOnAddGeofencesResultListener, bz parambz)
    {
      this.xu = paramOnAddGeofencesResultListener;
      this.xv = null;
      this.xw = parambz;
    }
    
    public b(LocationClient.OnRemoveGeofencesResultListener paramOnRemoveGeofencesResultListener, bz parambz)
    {
      this.xv = paramOnRemoveGeofencesResultListener;
      this.xu = null;
      this.xw = parambz;
    }
    
    public void onAddGeofencesResult(int paramInt, String[] paramArrayOfString)
      throws RemoteException
    {
      if (this.xw == null)
      {
        Log.wtf("LocationClientImpl", "onAddGeofenceResult called multiple times");
        return;
      }
      bz localbz1 = this.xw;
      bz localbz2 = this.xw;
      localbz2.getClass();
      localbz1.a(new bz.a(localbz2, this.xu, paramInt, paramArrayOfString));
      this.xw = null;
      this.xu = null;
      this.xv = null;
    }
    
    public void onRemoveGeofencesByPendingIntentResult(int paramInt, PendingIntent paramPendingIntent)
    {
      if (this.xw == null)
      {
        Log.wtf("LocationClientImpl", "onRemoveGeofencesByPendingIntentResult called multiple times");
        return;
      }
      bz localbz1 = this.xw;
      bz localbz2 = this.xw;
      localbz2.getClass();
      localbz1.a(new bz.d(localbz2, 1, this.xv, paramInt, paramPendingIntent));
      this.xw = null;
      this.xu = null;
      this.xv = null;
    }
    
    public void onRemoveGeofencesByRequestIdsResult(int paramInt, String[] paramArrayOfString)
    {
      if (this.xw == null)
      {
        Log.wtf("LocationClientImpl", "onRemoveGeofencesByRequestIdsResult called multiple times");
        return;
      }
      bz localbz1 = this.xw;
      bz localbz2 = this.xw;
      localbz2.getClass();
      localbz1.a(new bz.d(localbz2, 2, this.xv, paramInt, paramArrayOfString));
      this.xw = null;
      this.xu = null;
      this.xv = null;
    }
  }
  
  private final class c
    implements cc<bx>
  {
    private c() {}
    
    public void M()
    {
      bz.b(bz.this);
    }
    
    public bx cy()
    {
      return (bx)bz.c(bz.this);
    }
  }
  
  private final class d
    extends ak<bx>.b<LocationClient.OnRemoveGeofencesResultListener>
  {
    private final PendingIntent mPendingIntent;
    private final int qx;
    private final String[] xs;
    private final int xx;
    
    public d(int paramInt1, LocationClient.OnRemoveGeofencesResultListener paramOnRemoveGeofencesResultListener, int paramInt2, PendingIntent paramPendingIntent)
    {
      super(paramOnRemoveGeofencesResultListener);
      if (paramInt1 == i) {}
      for (;;)
      {
        ah.f(i);
        this.xx = paramInt1;
        this.qx = LocationStatusCodes.aF(paramInt2);
        this.mPendingIntent = paramPendingIntent;
        this.xs = null;
        return;
        i = 0;
      }
    }
    
    public d(int paramInt1, LocationClient.OnRemoveGeofencesResultListener paramOnRemoveGeofencesResultListener, int paramInt2, String[] paramArrayOfString)
    {
      super(paramOnRemoveGeofencesResultListener);
      if (paramInt1 == 2) {}
      for (boolean bool = true;; bool = false)
      {
        ah.f(bool);
        this.xx = paramInt1;
        this.qx = LocationStatusCodes.aF(paramInt2);
        this.xs = paramArrayOfString;
        this.mPendingIntent = null;
        return;
      }
    }
    
    protected void a(LocationClient.OnRemoveGeofencesResultListener paramOnRemoveGeofencesResultListener)
    {
      if (paramOnRemoveGeofencesResultListener != null) {}
      switch (this.xx)
      {
      default: 
        Log.wtf("LocationClientImpl", "Unsupported action: " + this.xx);
        return;
      case 1: 
        paramOnRemoveGeofencesResultListener.onRemoveGeofencesByPendingIntentResult(this.qx, this.mPendingIntent);
        return;
      }
      paramOnRemoveGeofencesResultListener.onRemoveGeofencesByRequestIdsResult(this.qx, this.xs);
    }
    
    protected void bT() {}
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bz
 * JD-Core Version:    0.7.0.1
 */