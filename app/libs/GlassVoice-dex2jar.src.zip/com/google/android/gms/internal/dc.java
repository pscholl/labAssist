package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.PeopleClient.ExpOnLoadPeopleForAggregationListener;
import com.google.android.gms.people.PeopleClient.LoadPeopleOptions;
import com.google.android.gms.people.PeopleClient.OnAddCircleFinishedListener;
import com.google.android.gms.people.PeopleClient.OnAddToCircleConsentLoadedListener;
import com.google.android.gms.people.PeopleClient.OnAggregatedPeopleLoadedListener;
import com.google.android.gms.people.PeopleClient.OnAvatarSetListener;
import com.google.android.gms.people.PeopleClient.OnCirclesLoadedListener;
import com.google.android.gms.people.PeopleClient.OnContactsGaiaIdsLoadedListener;
import com.google.android.gms.people.PeopleClient.OnDataChangedListener;
import com.google.android.gms.people.PeopleClient.OnImageLoadedListener;
import com.google.android.gms.people.PeopleClient.OnOperationFinishedListener;
import com.google.android.gms.people.PeopleClient.OnOwnersLoadedListener;
import com.google.android.gms.people.PeopleClient.OnPeopleLoadedListener;
import com.google.android.gms.people.PeopleClient.OnUpdatePersonCirclesFinishedListener;
import com.google.android.gms.people.PeopleClient.a;
import com.google.android.gms.people.PeopleClient.b;
import com.google.android.gms.people.PeopleClient.c;
import com.google.android.gms.people.PeopleClient.d;
import com.google.android.gms.people.PeopleClient.e;
import com.google.android.gms.people.PeopleConstants;
import com.google.android.gms.people.exp.ContactGaiaIdRawBuffer;
import com.google.android.gms.people.exp.PersonForAggregationRawBuffer;
import com.google.android.gms.people.model.AggregatedPersonBuffer;
import com.google.android.gms.people.model.CircleBuffer;
import com.google.android.gms.people.model.ContactGaiaIdBuffer;
import com.google.android.gms.people.model.OwnerBuffer;
import com.google.android.gms.people.model.PersonBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class dc
  extends ak<cx>
{
  private static volatile Bundle Bp;
  private static volatile Bundle Bq;
  private final String Bn;
  private final HashMap<PeopleClient.OnDataChangedListener, p> Bo = new HashMap();
  private final String rf;
  
  public dc(Context paramContext, Looper paramLooper, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString1, String paramString2)
  {
    super(paramContext, paramLooper, paramConnectionCallbacks, paramOnConnectionFailedListener, new String[0]);
    this.Bn = paramString1;
    this.rf = paramString2;
  }
  
  @Deprecated
  public dc(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString1, String paramString2)
  {
    this(paramContext, paramContext.getMainLooper(), new ak.c(paramConnectionCallbacks), new ak.f(paramOnConnectionFailedListener), paramString1, paramString2);
  }
  
  private static ConnectionResult a(int paramInt, Bundle paramBundle)
  {
    return new ConnectionResult(paramInt, e(paramBundle));
  }
  
  private p a(PeopleClient.OnDataChangedListener paramOnDataChangedListener)
  {
    synchronized (this.Bo)
    {
      if (this.Bo.containsKey(paramOnDataChangedListener))
      {
        p localp2 = (p)this.Bo.get(paramOnDataChangedListener);
        return localp2;
      }
      p localp1 = new p(paramOnDataChangedListener);
      this.Bo.put(paramOnDataChangedListener, localp1);
      return localp1;
    }
  }
  
  private static PendingIntent e(Bundle paramBundle)
  {
    if (paramBundle == null) {
      return null;
    }
    return (PendingIntent)paramBundle.getParcelable("pendingIntent");
  }
  
  protected void a(int paramInt, IBinder paramIBinder, Bundle paramBundle)
  {
    if ((paramInt == 0) && (paramBundle != null)) {
      d(paramBundle.getBundle("post_init_configuration"));
    }
    if (paramBundle == null) {}
    for (Bundle localBundle = null;; localBundle = paramBundle.getBundle("post_init_resolution"))
    {
      super.a(paramInt, paramIBinder, localBundle);
      return;
    }
  }
  
  protected void a(ap paramap, ak.d paramd)
    throws RemoteException
  {
    Bundle localBundle = new Bundle();
    localBundle.putString("social_client_application_id", this.Bn);
    localBundle.putString("real_client_package_name", this.rf);
    paramap.b(paramd, 4326000, getContext().getPackageName(), localBundle);
  }
  
  public void a(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener, String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    dw();
    u localu = new u(paramOnOperationFinishedListener);
    try
    {
      dv().a(localu, paramString1, paramString2, paramString3, paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localu.a(8, null, null);
    }
  }
  
  public void a(PeopleClient.OnOwnersLoadedListener paramOnOwnersLoadedListener, boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, int paramInt)
  {
    dw();
    w localw = new w(paramOnOwnersLoadedListener);
    try
    {
      dv().a(localw, paramBoolean1, paramBoolean2, paramString1, paramString2, paramInt);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localw.a(8, null, null);
    }
  }
  
  public boolean a(PeopleClient.OnDataChangedListener paramOnDataChangedListener, String paramString1, String paramString2, int paramInt)
  {
    dw();
    synchronized (this.Bo)
    {
      p localp = a(paramOnDataChangedListener);
      try
      {
        dv().a(localp, true, paramString1, paramString2, paramInt);
        return true;
      }
      catch (RemoteException localRemoteException)
      {
        dd.b("PeopleClient", "Failed to register listener", localRemoteException);
        return false;
      }
    }
  }
  
  public void addCircle(PeopleClient.OnAddCircleFinishedListener paramOnAddCircleFinishedListener, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    dw();
    e locale = new e(paramOnAddCircleFinishedListener);
    try
    {
      dv().a(locale, paramString1, paramString2, paramString3, paramString4);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      locale.a(8, null, null);
    }
  }
  
  public void addPeopleToCircle(PeopleClient.b paramb, String paramString1, String paramString2, String paramString3, List<String> paramList)
  {
    dw();
    g localg = new g(paramb);
    try
    {
      dv().a(localg, paramString1, paramString2, paramString3, paramList);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localg.a(8, null, null);
    }
  }
  
  protected cx al(IBinder paramIBinder)
  {
    return cx.a.ak(paramIBinder);
  }
  
  public void b(ak<cx>.b<?> paramak)
  {
    super.a(paramak);
  }
  
  public boolean b(String paramString1, String paramString2, long paramLong, boolean paramBoolean1, boolean paramBoolean2)
  {
    dw();
    try
    {
      dv().a(paramString1, paramString2, paramLong, paramBoolean1, paramBoolean2);
      return true;
    }
    catch (RemoteException localRemoteException)
    {
      dd.b("PeopleClient", "Service call failed.", localRemoteException);
    }
    return false;
  }
  
  protected String bQ()
  {
    return "com.google.android.gms.people.service.START";
  }
  
  protected String bR()
  {
    return "com.google.android.gms.people.internal.IPeopleService";
  }
  
  public void d(Bundle paramBundle)
  {
    if (paramBundle == null) {
      return;
    }
    dn.i(paramBundle.getBoolean("use_contactables_api", true));
    db.Bk.c(paramBundle);
    Bp = paramBundle.getBundle("config.email_type_map");
    Bq = paramBundle.getBundle("config.phone_type_map");
  }
  
  public void disconnect()
  {
    synchronized (this.Bo)
    {
      try
      {
        if (isConnected())
        {
          Iterator localIterator = this.Bo.values().iterator();
          while (localIterator.hasNext())
          {
            p localp = (p)localIterator.next();
            dv().a(localp, false, null, null, 0);
          }
        }
        localObject = finally;
      }
      catch (RemoteException localRemoteException)
      {
        dd.a("PeopleClient", "Failed to unregister listener", localRemoteException);
        this.Bo.clear();
        super.disconnect();
        return;
      }
      catch (IllegalStateException localIllegalStateException)
      {
        for (;;)
        {
          dd.a("PeopleClient", "PeopleService is in unexpected state", localIllegalStateException);
        }
      }
    }
  }
  
  protected cx dv()
  {
    return (cx)super.bS();
  }
  
  protected void dw()
  {
    super.M();
  }
  
  public Bundle expGetEmailTypeMapBundle()
  {
    dw();
    return Bp;
  }
  
  public Bundle expGetPhoneTypeMapBundle()
  {
    dw();
    return Bq;
  }
  
  public void expLoadPeopleForAggregation(PeopleClient.ExpOnLoadPeopleForAggregationListener paramExpOnLoadPeopleForAggregationListener, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean1, int paramInt2, int paramInt3, String paramString4, boolean paramBoolean2, int paramInt4)
  {
    dw();
    af localaf = new af(paramExpOnLoadPeopleForAggregationListener);
    try
    {
      dv().a(localaf, paramString1, paramString2, paramString3, paramInt1, paramBoolean1, paramInt2, paramInt3, paramString4, paramBoolean2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localaf.a(8, null, null);
    }
  }
  
  public void internalCall(PeopleClient.c paramc, Bundle paramBundle)
  {
    dw();
    q localq = new q(paramc);
    try
    {
      dv().b(localq, paramBundle);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localq.a(8, null, null);
    }
  }
  
  public boolean isSyncToContactsEnabled()
    throws RemoteException
  {
    dw();
    return dv().isSyncToContactsEnabled();
  }
  
  public void loadAddToCircleConsent(PeopleClient.OnAddToCircleConsentLoadedListener paramOnAddToCircleConsentLoadedListener, String paramString1, String paramString2)
  {
    dw();
    i locali = new i(paramOnAddToCircleConsentLoadedListener);
    try
    {
      dv().b(locali, paramString1, paramString2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      locali.a(8, null, null);
    }
  }
  
  public void loadAggregatedPeople(PeopleClient.OnAggregatedPeopleLoadedListener paramOnAggregatedPeopleLoadedListener, String paramString1, String paramString2, boolean paramBoolean1, String paramString3, boolean paramBoolean2, int paramInt1, int paramInt2, String paramString4, boolean paramBoolean3)
  {
    dw();
    dn localdn = dn.a(getContext(), new ae(paramOnAggregatedPeopleLoadedListener), paramBoolean1, paramInt2, Bp, Bq, paramString3, paramString4);
    k localk = new k(localdn);
    try
    {
      dv().a(localk, paramString1, paramString2, paramString3, 7, paramBoolean2, paramInt1, paramInt2, paramString4, paramBoolean3);
      localdn.dL();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        localk.a(8, null, null);
      }
    }
  }
  
  public void loadAvatarByUrl(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, String paramString, int paramInt1, int paramInt2)
  {
    dw();
    x localx = new x(paramOnImageLoadedListener);
    try
    {
      dv().a(localx, paramString, paramInt1, paramInt2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localx.a(8, null, null);
    }
  }
  
  public void loadCircles(PeopleClient.OnCirclesLoadedListener paramOnCirclesLoadedListener, String paramString1, String paramString2, String paramString3, int paramInt, String paramString4, boolean paramBoolean)
  {
    dw();
    n localn = new n(paramOnCirclesLoadedListener);
    try
    {
      dv().a(localn, paramString1, paramString2, paramString3, paramInt, paramString4, paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localn.a(8, null, null);
    }
  }
  
  public void loadContactThumbnailByContactId(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, long paramLong)
  {
    dw();
    x localx = new x(paramOnImageLoadedListener);
    try
    {
      dv().a(localx, paramLong, true);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localx.a(8, null, null);
    }
  }
  
  public void loadContactsGaiaIds(PeopleClient.OnContactsGaiaIdsLoadedListener paramOnContactsGaiaIdsLoadedListener, String paramString1, String paramString2)
  {
    dw();
    o localo = new o(paramOnContactsGaiaIdsLoadedListener);
    try
    {
      dv().a(localo, paramString1, paramString2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localo.a(8, null, null);
    }
  }
  
  public void loadLog(PeopleClient.d paramd, Bundle paramBundle)
  {
    dw();
    s locals = new s(paramd);
    try
    {
      dv().a(locals, paramBundle);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      locals.a(8, null, null);
    }
  }
  
  public void loadOwnerAvatar(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    x localx = new x(paramOnImageLoadedListener);
    try
    {
      dv().a(localx, paramString1, paramString2, paramInt1, paramInt2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localx.a(8, null, null);
    }
  }
  
  public void loadOwnerCoverPhoto(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, String paramString1, String paramString2, int paramInt)
  {
    x localx = new x(paramOnImageLoadedListener);
    try
    {
      dv().a(localx, paramString1, paramString2, paramInt);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localx.a(8, null, null);
    }
  }
  
  public void loadPeople(PeopleClient.OnPeopleLoadedListener paramOnPeopleLoadedListener, String paramString1, String paramString2, PeopleClient.LoadPeopleOptions paramLoadPeopleOptions)
  {
    dw();
    y localy = new y(paramOnPeopleLoadedListener);
    try
    {
      dv().a(localy, paramString1, paramString2, paramLoadPeopleOptions.getCircleId(), bg.b(paramLoadPeopleOptions.getQualifiedIds()), paramLoadPeopleOptions.getProjection(), paramLoadPeopleOptions.isPeopleOnly(), paramLoadPeopleOptions.getChangedSince(), paramLoadPeopleOptions.getQuery(), paramLoadPeopleOptions.getSearchFields());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localy.a(8, null, null);
    }
  }
  
  public void loadPeopleLive(PeopleClient.e parame, String paramString1, String paramString2, PeopleClient.a parama)
  {
    dw();
    z localz = new z(parame);
    try
    {
      dv().b(localz, paramString1, paramString2, parama.getQuery(), parama.dp(), parama.dq());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localz.a(8, null, null);
    }
  }
  
  public void loadRemoteImage(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, String paramString)
  {
    dw();
    x localx = new x(paramOnImageLoadedListener);
    try
    {
      dv().a(localx, paramString);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localx.a(8, null, null);
    }
  }
  
  public void removeCircle(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener, String paramString1, String paramString2, String paramString3)
  {
    dw();
    u localu = new u(paramOnOperationFinishedListener);
    try
    {
      dv().a(localu, paramString1, paramString2, paramString3);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localu.a(8, null, null);
    }
  }
  
  public void setAvatar(PeopleClient.OnAvatarSetListener paramOnAvatarSetListener, String paramString1, String paramString2, Uri paramUri, boolean paramBoolean)
  {
    dw();
    l locall = new l(paramOnAvatarSetListener);
    try
    {
      dv().a(locall, paramString1, paramString2, paramUri, paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      locall.a(8, null, null);
    }
  }
  
  public void setHasShownAddToCircleConsent(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener, String paramString1, String paramString2)
  {
    dw();
    u localu = new u(paramOnOperationFinishedListener);
    try
    {
      dv().c(localu, paramString1, paramString2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localu.a(8, null, null);
    }
  }
  
  public void setSyncToContactsEnabled(boolean paramBoolean)
    throws RemoteException
  {
    dw();
    dv().setSyncToContactsEnabled(paramBoolean);
  }
  
  public void setSyncToContactsSettings(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener, String paramString, boolean paramBoolean, String[] paramArrayOfString)
  {
    dw();
    u localu = new u(paramOnOperationFinishedListener);
    try
    {
      dv().a(localu, paramString, paramBoolean, paramArrayOfString);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localu.a(8, null, null);
    }
  }
  
  public boolean syncRawContact(Uri paramUri)
  {
    dw();
    try
    {
      dv().c(paramUri);
      return true;
    }
    catch (RemoteException localRemoteException)
    {
      dd.b("PeopleClient", "Cannot refresh raw contact: " + paramUri, localRemoteException);
    }
    return false;
  }
  
  /* Error */
  public void unregisterOnDataChangedListener(PeopleClient.OnDataChangedListener paramOnDataChangedListener)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 28	com/google/android/gms/internal/dc:Bo	Ljava/util/HashMap;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: invokevirtual 147	com/google/android/gms/internal/dc:dw	()V
    //   11: aload_0
    //   12: getfield 28	com/google/android/gms/internal/dc:Bo	Ljava/util/HashMap;
    //   15: aload_1
    //   16: invokevirtual 68	java/util/HashMap:containsKey	(Ljava/lang/Object;)Z
    //   19: istore 6
    //   21: iload 6
    //   23: ifne +15 -> 38
    //   26: aload_0
    //   27: getfield 28	com/google/android/gms/internal/dc:Bo	Ljava/util/HashMap;
    //   30: aload_1
    //   31: invokevirtual 545	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   34: pop
    //   35: aload_2
    //   36: monitorexit
    //   37: return
    //   38: aload_0
    //   39: getfield 28	com/google/android/gms/internal/dc:Bo	Ljava/util/HashMap;
    //   42: aload_1
    //   43: invokevirtual 72	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   46: checkcast 74	com/google/android/gms/internal/dc$p
    //   49: astore 7
    //   51: aload_0
    //   52: invokevirtual 156	com/google/android/gms/internal/dc:dv	()Lcom/google/android/gms/internal/cx;
    //   55: aload 7
    //   57: iconst_0
    //   58: aconst_null
    //   59: aconst_null
    //   60: iconst_0
    //   61: invokeinterface 182 6 0
    //   66: pop
    //   67: aload_0
    //   68: getfield 28	com/google/android/gms/internal/dc:Bo	Ljava/util/HashMap;
    //   71: aload_1
    //   72: invokevirtual 545	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   75: pop
    //   76: aload_2
    //   77: monitorexit
    //   78: return
    //   79: astore 5
    //   81: aload_2
    //   82: monitorexit
    //   83: aload 5
    //   85: athrow
    //   86: astore 8
    //   88: ldc 184
    //   90: ldc_w 288
    //   93: aload 8
    //   95: invokestatic 191	com/google/android/gms/internal/dd:b	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   98: goto -31 -> 67
    //   101: astore_3
    //   102: aload_0
    //   103: getfield 28	com/google/android/gms/internal/dc:Bo	Ljava/util/HashMap;
    //   106: aload_1
    //   107: invokevirtual 545	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   110: pop
    //   111: aload_3
    //   112: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	113	0	this	dc
    //   0	113	1	paramOnDataChangedListener	PeopleClient.OnDataChangedListener
    //   4	78	2	localHashMap	HashMap
    //   101	11	3	localObject1	Object
    //   79	5	5	localObject2	Object
    //   19	3	6	bool	boolean
    //   49	7	7	localp	p
    //   86	8	8	localRemoteException	RemoteException
    // Exception table:
    //   from	to	target	type
    //   26	37	79	finally
    //   67	78	79	finally
    //   81	83	79	finally
    //   102	113	79	finally
    //   51	67	86	android/os/RemoteException
    //   7	21	101	finally
    //   38	51	101	finally
    //   51	67	101	finally
    //   88	98	101	finally
  }
  
  public void updateCircle(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener, String paramString1, String paramString2, String paramString3, String paramString4, Boolean paramBoolean, String paramString5)
  {
    dw();
    u localu = new u(paramOnOperationFinishedListener);
    try
    {
      dv().a(localu, paramString1, paramString2, paramString3, paramString4, PeopleConstants.booleanToTriState(paramBoolean), paramString5);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localu.a(8, null, null);
    }
  }
  
  public void updatePersonCircles(PeopleClient.OnUpdatePersonCirclesFinishedListener paramOnUpdatePersonCirclesFinishedListener, String paramString1, String paramString2, String paramString3, List<String> paramList1, List<String> paramList2, az paramaz)
  {
    dw();
    aa localaa = new aa(paramOnUpdatePersonCirclesFinishedListener);
    try
    {
      dv().a(localaa, paramString1, paramString2, paramString3, paramList1, paramList2, paramaz);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localaa.a(8, null, null);
    }
  }
  
  private final class a
    extends ak<cx>.b<PeopleClient.OnAggregatedPeopleLoadedListener>
  {
    private final ConnectionResult Br;
    private final AggregatedPersonBuffer Bs;
    
    public a(PeopleClient.OnAggregatedPeopleLoadedListener paramOnAggregatedPeopleLoadedListener, ConnectionResult paramConnectionResult, AggregatedPersonBuffer paramAggregatedPersonBuffer)
    {
      super(paramOnAggregatedPeopleLoadedListener);
      this.Br = paramConnectionResult;
      this.Bs = paramAggregatedPersonBuffer;
    }
    
    protected void a(PeopleClient.OnAggregatedPeopleLoadedListener paramOnAggregatedPeopleLoadedListener)
    {
      if (paramOnAggregatedPeopleLoadedListener != null) {
        paramOnAggregatedPeopleLoadedListener.onAggregatedPeopleLoaded(this.Br, this.Bs);
      }
    }
    
    protected void bT()
    {
      if (this.Bs != null) {
        this.Bs.close();
      }
    }
  }
  
  private final class aa
    extends cs
  {
    private final PeopleClient.OnUpdatePersonCirclesFinishedListener BW;
    
    public aa(PeopleClient.OnUpdatePersonCirclesFinishedListener paramOnUpdatePersonCirclesFinishedListener)
    {
      this.BW = paramOnUpdatePersonCirclesFinishedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      ArrayList localArrayList1;
      if (localConnectionResult.isSuccess()) {
        localArrayList1 = paramBundle2.getStringArrayList("added_circles");
      }
      for (ArrayList localArrayList2 = paramBundle2.getStringArrayList("removed_circles");; localArrayList2 = null)
      {
        dc.this.b(new dc.ab(dc.this, this.BW, localConnectionResult, localArrayList1, localArrayList2));
        return;
        localArrayList1 = null;
      }
    }
  }
  
  private final class ab
    extends ak<cx>.b<PeopleClient.OnUpdatePersonCirclesFinishedListener>
  {
    private final List<String> BX;
    private final List<String> BY;
    private final ConnectionResult Br;
    
    public ab(ConnectionResult paramConnectionResult, List<String> paramList1, List<String> paramList2)
    {
      super(paramConnectionResult);
      this.Br = paramList1;
      this.BX = paramList2;
      Object localObject;
      this.BY = localObject;
    }
    
    protected void a(PeopleClient.OnUpdatePersonCirclesFinishedListener paramOnUpdatePersonCirclesFinishedListener)
    {
      if (paramOnUpdatePersonCirclesFinishedListener != null) {
        paramOnUpdatePersonCirclesFinishedListener.onOperationFinished(this.Br, this.BX, this.BY);
      }
    }
    
    protected void bT() {}
  }
  
  private final class ac
    extends ak<cx>.b<PeopleClient.OnOwnersLoadedListener>
  {
    private final OwnerBuffer BZ;
    private final ConnectionResult Br;
    
    public ac(PeopleClient.OnOwnersLoadedListener paramOnOwnersLoadedListener, ConnectionResult paramConnectionResult, OwnerBuffer paramOwnerBuffer)
    {
      super(paramOnOwnersLoadedListener);
      this.Br = paramConnectionResult;
      this.BZ = paramOwnerBuffer;
    }
    
    protected void a(PeopleClient.OnOwnersLoadedListener paramOnOwnersLoadedListener)
    {
      if (paramOnOwnersLoadedListener != null) {
        paramOnOwnersLoadedListener.onOwnersLoaded(this.Br, this.BZ);
      }
    }
    
    protected void bT()
    {
      if (this.BZ != null) {
        this.BZ.close();
      }
    }
  }
  
  private final class ad
    extends ak<cx>.b<PeopleClient.OnImageLoadedListener>
  {
    private final ConnectionResult Br;
    private final ParcelFileDescriptor Ca;
    
    public ad(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, ConnectionResult paramConnectionResult, ParcelFileDescriptor paramParcelFileDescriptor)
    {
      super(paramOnImageLoadedListener);
      this.Br = paramConnectionResult;
      this.Ca = paramParcelFileDescriptor;
    }
    
    protected void a(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener)
    {
      if (paramOnImageLoadedListener != null) {
        paramOnImageLoadedListener.onImageLoaded(this.Br, this.Ca);
      }
    }
    
    protected void bT()
    {
      if (this.Ca != null) {
        bk.a(this.Ca);
      }
    }
  }
  
  private final class ae
    implements dn.d
  {
    private final PeopleClient.OnAggregatedPeopleLoadedListener Cb;
    
    public ae(PeopleClient.OnAggregatedPeopleLoadedListener paramOnAggregatedPeopleLoadedListener)
    {
      this.Cb = paramOnAggregatedPeopleLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, AggregatedPersonBuffer paramAggregatedPersonBuffer)
    {
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      dc.this.b(new dc.a(dc.this, this.Cb, localConnectionResult, paramAggregatedPersonBuffer));
    }
  }
  
  private final class af
    extends cs
  {
    private final PeopleClient.ExpOnLoadPeopleForAggregationListener Cc;
    
    public af(PeopleClient.ExpOnLoadPeopleForAggregationListener paramExpOnLoadPeopleForAggregationListener)
    {
      this.Cc = paramExpOnLoadPeopleForAggregationListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, d[] paramArrayOfd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "People callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholders=" + paramArrayOfd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      if (paramArrayOfd != null)
      {
        dc.this.b(new dc.ag(dc.this, this.Cc, localConnectionResult, new PersonForAggregationRawBuffer(paramArrayOfd[0], new dq.b(dc.dx()), new dq.a(dc.dy())), new ContactGaiaIdRawBuffer(paramArrayOfd[1])));
        return;
      }
      dc.this.b(new dc.ag(dc.this, this.Cc, localConnectionResult, null, null));
    }
  }
  
  private final class ag
    extends ak<cx>.b<PeopleClient.ExpOnLoadPeopleForAggregationListener>
  {
    private final ConnectionResult Br;
    private final PersonForAggregationRawBuffer Cd;
    private final ContactGaiaIdRawBuffer Ce;
    
    public ag(PeopleClient.ExpOnLoadPeopleForAggregationListener paramExpOnLoadPeopleForAggregationListener, ConnectionResult paramConnectionResult, PersonForAggregationRawBuffer paramPersonForAggregationRawBuffer, ContactGaiaIdRawBuffer paramContactGaiaIdRawBuffer)
    {
      super(paramExpOnLoadPeopleForAggregationListener);
      this.Br = paramConnectionResult;
      this.Cd = paramPersonForAggregationRawBuffer;
      this.Ce = paramContactGaiaIdRawBuffer;
    }
    
    protected void a(PeopleClient.ExpOnLoadPeopleForAggregationListener paramExpOnLoadPeopleForAggregationListener)
    {
      if (paramExpOnLoadPeopleForAggregationListener != null) {
        paramExpOnLoadPeopleForAggregationListener.expOnPeopleForAggregationLoaded(this.Br, this.Cd, this.Ce);
      }
    }
    
    protected void bT() {}
  }
  
  private final class ah
    extends ak<cx>.b<PeopleClient.OnPeopleLoadedListener>
  {
    private final ConnectionResult Br;
    private final PersonBuffer Cf;
    
    public ah(PeopleClient.OnPeopleLoadedListener paramOnPeopleLoadedListener, ConnectionResult paramConnectionResult, PersonBuffer paramPersonBuffer)
    {
      super(paramOnPeopleLoadedListener);
      this.Br = paramConnectionResult;
      this.Cf = paramPersonBuffer;
    }
    
    protected void a(PeopleClient.OnPeopleLoadedListener paramOnPeopleLoadedListener)
    {
      if (paramOnPeopleLoadedListener != null) {
        paramOnPeopleLoadedListener.onPeopleLoaded(this.Br, this.Cf);
      }
    }
    
    protected void bT()
    {
      if (this.Cf != null) {
        this.Cf.close();
      }
    }
  }
  
  private final class ai
    extends ak<cx>.b<PeopleClient.e>
  {
    private final ConnectionResult Br;
    private final PersonBuffer Cf;
    private final String Cg;
    
    public ai(PeopleClient.e parame, ConnectionResult paramConnectionResult, PersonBuffer paramPersonBuffer, String paramString)
    {
      super(parame);
      this.Br = paramConnectionResult;
      this.Cf = paramPersonBuffer;
      this.Cg = paramString;
    }
    
    protected void a(PeopleClient.e parame)
    {
      if (parame != null) {
        parame.a(this.Br, this.Cf, this.Cg);
      }
    }
    
    protected void bT()
    {
      if (this.Cf != null) {
        this.Cf.close();
      }
    }
  }
  
  private final class b
    extends ak<cx>.b<PeopleClient.OnCirclesLoadedListener>
  {
    private final ConnectionResult Br;
    private final CircleBuffer Bu;
    
    public b(PeopleClient.OnCirclesLoadedListener paramOnCirclesLoadedListener, ConnectionResult paramConnectionResult, CircleBuffer paramCircleBuffer)
    {
      super(paramOnCirclesLoadedListener);
      this.Br = paramConnectionResult;
      this.Bu = paramCircleBuffer;
    }
    
    protected void a(PeopleClient.OnCirclesLoadedListener paramOnCirclesLoadedListener)
    {
      if (paramOnCirclesLoadedListener != null) {
        paramOnCirclesLoadedListener.onCirclesLoaded(this.Br, this.Bu);
      }
    }
    
    protected void bT()
    {
      if (this.Bu != null) {
        this.Bu.close();
      }
    }
  }
  
  private final class c
    extends ak<cx>.b<PeopleClient.OnContactsGaiaIdsLoadedListener>
  {
    private final ConnectionResult Br;
    private final ContactGaiaIdBuffer Bv;
    
    public c(PeopleClient.OnContactsGaiaIdsLoadedListener paramOnContactsGaiaIdsLoadedListener, ConnectionResult paramConnectionResult, ContactGaiaIdBuffer paramContactGaiaIdBuffer)
    {
      super(paramOnContactsGaiaIdsLoadedListener);
      this.Br = paramConnectionResult;
      this.Bv = paramContactGaiaIdBuffer;
    }
    
    protected void a(PeopleClient.OnContactsGaiaIdsLoadedListener paramOnContactsGaiaIdsLoadedListener)
    {
      if (paramOnContactsGaiaIdsLoadedListener != null) {
        paramOnContactsGaiaIdsLoadedListener.onContactsGaiaIdsLoaded(this.Br, this.Bv);
      }
    }
    
    protected void bT()
    {
      if (this.Bv == null) {
        this.Bv.close();
      }
    }
  }
  
  private final class d
    extends ak<cx>.b<PeopleClient.OnDataChangedListener>
  {
    private final String Bw;
    private final int Bx;
    private final String mAccount;
    
    public d(PeopleClient.OnDataChangedListener paramOnDataChangedListener, String paramString1, String paramString2, int paramInt)
    {
      super(paramOnDataChangedListener);
      this.mAccount = paramString1;
      this.Bw = paramString2;
      this.Bx = paramInt;
    }
    
    protected void b(PeopleClient.OnDataChangedListener paramOnDataChangedListener)
    {
      if (paramOnDataChangedListener != null) {
        synchronized (dc.a(dc.this))
        {
          if (!dc.a(dc.this).containsKey(paramOnDataChangedListener)) {
            return;
          }
          paramOnDataChangedListener.onDataChanged(this.mAccount, this.Bw, this.Bx);
          return;
        }
      }
    }
    
    protected void bT() {}
  }
  
  private final class e
    extends cs
  {
    private final PeopleClient.OnAddCircleFinishedListener By;
    
    public e(PeopleClient.OnAddCircleFinishedListener paramOnAddCircleFinishedListener)
    {
      this.By = paramOnAddCircleFinishedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      String str1;
      String str2;
      if (paramBundle2 == null)
      {
        str1 = null;
        str2 = null;
        if (paramBundle2 != null) {
          break label109;
        }
      }
      for (;;)
      {
        dc.this.b(new dc.f(dc.this, this.By, localConnectionResult, str1, str2));
        return;
        str1 = paramBundle2.getString("circle_id");
        break;
        label109:
        str2 = paramBundle2.getString("circle_name");
      }
    }
  }
  
  private final class f
    extends ak<cx>.b<PeopleClient.OnAddCircleFinishedListener>
  {
    private final ConnectionResult Br;
    private final String Bz;
    private final String uv;
    
    public f(PeopleClient.OnAddCircleFinishedListener paramOnAddCircleFinishedListener, ConnectionResult paramConnectionResult, String paramString1, String paramString2)
    {
      super(paramOnAddCircleFinishedListener);
      this.Br = paramConnectionResult;
      this.uv = paramString1;
      this.Bz = paramString2;
    }
    
    protected void a(PeopleClient.OnAddCircleFinishedListener paramOnAddCircleFinishedListener)
    {
      if (paramOnAddCircleFinishedListener != null) {
        paramOnAddCircleFinishedListener.onAddCircleFinished(this.Br, this.uv, this.Bz);
      }
    }
    
    protected void bT() {}
  }
  
  private final class g
    extends cs
  {
    private final PeopleClient.b BA;
    
    public g(PeopleClient.b paramb)
    {
      this.BA = paramb;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      String str1;
      String str2;
      label69:
      String[] arrayOfString;
      if (paramBundle2 == null)
      {
        str1 = null;
        if (paramBundle2 != null) {
          break label118;
        }
        str2 = null;
        arrayOfString = null;
        if (paramBundle2 != null) {
          break label129;
        }
      }
      for (;;)
      {
        dc.this.b(new dc.h(dc.this, this.BA, localConnectionResult, str1, str2, arrayOfString));
        return;
        str1 = paramBundle2.getString("circle_id");
        break;
        label118:
        str2 = paramBundle2.getString("circle_name");
        break label69;
        label129:
        arrayOfString = paramBundle2.getStringArray("added_people");
      }
    }
  }
  
  private final class h
    extends ak<cx>.b<PeopleClient.b>
  {
    private final String[] BB;
    private final ConnectionResult Br;
    private final String Bz;
    private final String uv;
    
    public h(PeopleClient.b paramb, ConnectionResult paramConnectionResult, String paramString1, String paramString2, String[] paramArrayOfString)
    {
      super(paramb);
      this.Br = paramConnectionResult;
      this.uv = paramString1;
      this.Bz = paramString2;
      this.BB = paramArrayOfString;
    }
    
    protected void a(PeopleClient.b paramb)
    {
      if (paramb != null) {
        paramb.a(this.Br, this.uv, this.Bz, this.BB);
      }
    }
    
    protected void bT() {}
  }
  
  private final class i
    extends cs
  {
    private final PeopleClient.OnAddToCircleConsentLoadedListener BC;
    
    public i(PeopleClient.OnAddToCircleConsentLoadedListener paramOnAddToCircleConsentLoadedListener)
    {
      this.BC = paramOnAddToCircleConsentLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      boolean bool;
      String str1;
      String str2;
      if (paramBundle2 != null)
      {
        bool = paramBundle2.getBoolean("circles.first_time_add_need_consent");
        str1 = paramBundle2.getString("circles.first_time_add_text");
        str2 = paramBundle2.getString("circles.first_time_add_title_text");
      }
      for (String str3 = paramBundle2.getString("circles.first_time_add_ok_text");; str3 = null)
      {
        dc.this.b(new dc.j(dc.this, this.BC, localConnectionResult, bool, str1, str2, str3));
        return;
        bool = false;
        str1 = null;
        str2 = null;
      }
    }
  }
  
  private final class j
    extends ak<cx>.b<PeopleClient.OnAddToCircleConsentLoadedListener>
  {
    private final boolean BD;
    private final String BE;
    private final String BF;
    private final String BG;
    private final ConnectionResult Br;
    
    public j(PeopleClient.OnAddToCircleConsentLoadedListener paramOnAddToCircleConsentLoadedListener, ConnectionResult paramConnectionResult, boolean paramBoolean, String paramString1, String paramString2, String paramString3)
    {
      super(paramOnAddToCircleConsentLoadedListener);
      this.Br = paramConnectionResult;
      this.BD = paramBoolean;
      this.BE = paramString1;
      this.BF = paramString2;
      this.BG = paramString3;
    }
    
    protected void a(PeopleClient.OnAddToCircleConsentLoadedListener paramOnAddToCircleConsentLoadedListener)
    {
      if (paramOnAddToCircleConsentLoadedListener != null) {
        paramOnAddToCircleConsentLoadedListener.onAddToCircleConsentLoaded(this.Br, this.BD, this.BE, this.BF, this.BG);
      }
    }
    
    protected void bT() {}
  }
  
  private final class k
    extends cs
  {
    private final dn BH;
    
    public k(dn paramdn)
    {
      this.BH = paramdn;
    }
    
    public void a(int paramInt, Bundle paramBundle, d[] paramArrayOfd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "People callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholders=" + paramArrayOfd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      this.BH.a(localConnectionResult, paramArrayOfd);
    }
  }
  
  private final class l
    extends cs
  {
    private final PeopleClient.OnAvatarSetListener BI;
    
    public l(PeopleClient.OnAvatarSetListener paramOnAvatarSetListener)
    {
      this.BI = paramOnAvatarSetListener;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      if (paramBundle2 == null) {}
      for (String str = null;; str = paramBundle2.getString("avatarurl"))
      {
        dc.this.b(new dc.m(dc.this, this.BI, localConnectionResult, str));
        return;
      }
    }
  }
  
  private final class m
    extends ak<cx>.b<PeopleClient.OnAvatarSetListener>
  {
    private final String BJ;
    private final ConnectionResult Br;
    
    public m(PeopleClient.OnAvatarSetListener paramOnAvatarSetListener, ConnectionResult paramConnectionResult, String paramString)
    {
      super(paramOnAvatarSetListener);
      this.Br = paramConnectionResult;
      this.BJ = paramString;
    }
    
    protected void a(PeopleClient.OnAvatarSetListener paramOnAvatarSetListener)
    {
      if (paramOnAvatarSetListener != null) {
        paramOnAvatarSetListener.onAvatarSet(this.Br, this.BJ);
      }
    }
    
    protected void bT() {}
  }
  
  private final class n
    extends cs
  {
    private final PeopleClient.OnCirclesLoadedListener BK;
    
    public n(PeopleClient.OnCirclesLoadedListener paramOnCirclesLoadedListener)
    {
      this.BK = paramOnCirclesLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, d paramd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Circles callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholder=" + paramd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      if (paramd == null) {}
      for (CircleBuffer localCircleBuffer = null;; localCircleBuffer = new CircleBuffer(paramd))
      {
        dc.this.b(new dc.b(dc.this, this.BK, localConnectionResult, localCircleBuffer));
        return;
      }
    }
  }
  
  private final class o
    extends cs
  {
    private final PeopleClient.OnContactsGaiaIdsLoadedListener BL;
    
    public o(PeopleClient.OnContactsGaiaIdsLoadedListener paramOnContactsGaiaIdsLoadedListener)
    {
      this.BL = paramOnContactsGaiaIdsLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, d paramd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "GaiaId callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholder=" + paramd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      if (paramd == null) {}
      for (ContactGaiaIdBuffer localContactGaiaIdBuffer = null;; localContactGaiaIdBuffer = new ContactGaiaIdBuffer(paramd))
      {
        dc.this.b(new dc.c(dc.this, this.BL, localConnectionResult, localContactGaiaIdBuffer));
        return;
      }
    }
  }
  
  private final class p
    extends cs
  {
    private final PeopleClient.OnDataChangedListener BM;
    
    public p(PeopleClient.OnDataChangedListener paramOnDataChangedListener)
    {
      this.BM = paramOnDataChangedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      if (paramInt != 0)
      {
        dd.i("PeopleClient", "Non-success data changed callback received.");
        return;
      }
      dc.this.b(new dc.d(dc.this, this.BM, paramBundle2.getString("account"), paramBundle2.getString("pagegaiaid"), paramBundle2.getInt("scope")));
    }
  }
  
  private final class q
    extends cs
  {
    private final PeopleClient.c BN;
    
    public q(PeopleClient.c paramc)
    {
      this.BN = paramc;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      dc.this.b(new dc.r(dc.this, this.BN, localConnectionResult, paramBundle2));
    }
  }
  
  private final class r
    extends ak<cx>.b<PeopleClient.c>
  {
    private final Bundle BO;
    private final ConnectionResult Br;
    
    public r(PeopleClient.c paramc, ConnectionResult paramConnectionResult, Bundle paramBundle)
    {
      super(paramc);
      this.Br = paramConnectionResult;
      this.BO = paramBundle;
    }
    
    protected void a(PeopleClient.c paramc)
    {
      if (paramc != null) {
        paramc.a(this.Br, this.BO);
      }
    }
    
    protected void bT() {}
  }
  
  private final class s
    extends cs
  {
    private final PeopleClient.d BP;
    
    public s(PeopleClient.d paramd)
    {
      this.BP = paramd;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      dc localdc1 = dc.this;
      dc localdc2 = dc.this;
      PeopleClient.d locald = this.BP;
      if (paramBundle2 == null) {}
      for (String str = null;; str = paramBundle2.getString("log_text"))
      {
        localdc1.b(new dc.t(localdc2, locald, localConnectionResult, str));
        return;
      }
    }
  }
  
  private final class t
    extends ak<cx>.b<PeopleClient.d>
  {
    private final String BQ;
    private final ConnectionResult Br;
    
    public t(PeopleClient.d paramd, ConnectionResult paramConnectionResult, String paramString)
    {
      super(paramd);
      this.Br = paramConnectionResult;
      this.BQ = paramString;
    }
    
    protected void a(PeopleClient.d paramd)
    {
      if (paramd != null) {
        paramd.a(this.Br, this.BQ);
      }
    }
    
    protected void bT() {}
  }
  
  private final class u
    extends cs
  {
    private final PeopleClient.OnOperationFinishedListener BR;
    
    public u(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener)
    {
      this.BR = paramOnOperationFinishedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Bundle callback: status=" + paramInt + "\nresolution=" + paramBundle1 + "\nbundle=" + paramBundle2);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle1);
      dc.this.b(new dc.v(dc.this, this.BR, localConnectionResult));
    }
  }
  
  private final class v
    extends ak<cx>.b<PeopleClient.OnOperationFinishedListener>
  {
    private final ConnectionResult Br;
    
    public v(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener, ConnectionResult paramConnectionResult)
    {
      super(paramOnOperationFinishedListener);
      this.Br = paramConnectionResult;
    }
    
    protected void a(PeopleClient.OnOperationFinishedListener paramOnOperationFinishedListener)
    {
      if (paramOnOperationFinishedListener != null) {
        paramOnOperationFinishedListener.onOperationFinished(this.Br);
      }
    }
    
    protected void bT() {}
  }
  
  private final class w
    extends cs
  {
    private final PeopleClient.OnOwnersLoadedListener BS;
    
    public w(PeopleClient.OnOwnersLoadedListener paramOnOwnersLoadedListener)
    {
      this.BS = paramOnOwnersLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, d paramd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Owner callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholder=" + paramd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      if (paramd == null) {}
      for (OwnerBuffer localOwnerBuffer = null;; localOwnerBuffer = new OwnerBuffer(paramd))
      {
        dc.this.b(new dc.ac(dc.this, this.BS, localConnectionResult, localOwnerBuffer));
        return;
      }
    }
  }
  
  private final class x
    extends cs
  {
    private final PeopleClient.OnImageLoadedListener BT;
    
    public x(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener)
    {
      this.BT = paramOnImageLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, ParcelFileDescriptor paramParcelFileDescriptor)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "Avatar callback: status=" + paramInt + " resolution=" + paramBundle + " pfd=" + paramParcelFileDescriptor);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      dc.this.b(new dc.ad(dc.this, this.BT, localConnectionResult, paramParcelFileDescriptor));
    }
  }
  
  private final class y
    extends cs
  {
    private final PeopleClient.OnPeopleLoadedListener BU;
    
    public y(PeopleClient.OnPeopleLoadedListener paramOnPeopleLoadedListener)
    {
      this.BU = paramOnPeopleLoadedListener;
    }
    
    public void a(int paramInt, Bundle paramBundle, d paramd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "People callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholder=" + paramd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      if (paramd == null) {}
      for (PersonBuffer localPersonBuffer = null;; localPersonBuffer = new PersonBuffer(paramd))
      {
        dc.this.b(new dc.ah(dc.this, this.BU, localConnectionResult, localPersonBuffer));
        return;
      }
    }
  }
  
  private final class z
    extends cs
  {
    private final PeopleClient.e BV;
    
    public z(PeopleClient.e parame)
    {
      this.BV = parame;
    }
    
    public void a(int paramInt, Bundle paramBundle, d paramd)
    {
      if (dd.dz()) {
        dd.g("PeopleClient", "People callback: status=" + paramInt + "\nresolution=" + paramBundle + "\nholder=" + paramd);
      }
      ConnectionResult localConnectionResult = dc.b(paramInt, paramBundle);
      PersonBuffer localPersonBuffer;
      String str;
      if (paramd == null)
      {
        localPersonBuffer = null;
        str = null;
        if (paramd != null) {
          break label111;
        }
      }
      for (;;)
      {
        dc.this.b(new dc.ai(dc.this, this.BV, localConnectionResult, localPersonBuffer, str));
        return;
        localPersonBuffer = new PersonBuffer(paramd);
        break;
        label111:
        str = paramd.getMetadata().getString("pageToken");
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dc
 * JD-Core Version:    0.7.0.1
 */