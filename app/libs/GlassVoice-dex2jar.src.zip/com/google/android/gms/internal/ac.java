package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.people.data.AudienceMember;
import com.google.android.gms.common.people.data.b;

public abstract interface ac
  extends IInterface
{
  public abstract void a(ad paramad, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void editAudience()
    throws RemoteException;
  
  public abstract void removeAudienceMember(AudienceMember paramAudienceMember)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements ac
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
    }
    
    public static ac m(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
      if ((localIInterface != null) && ((localIInterface instanceof ac))) {
        return (ac)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
        return true;
      case 2: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
        a(ad.a.n(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 3: 
        paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
        if (paramParcel1.readInt() != 0) {}
        for (AudienceMember localAudienceMember = AudienceMember.CREATOR.ab(paramParcel1);; localAudienceMember = null)
        {
          removeAudienceMember(localAudienceMember);
          paramParcel2.writeNoException();
          return true;
        }
      }
      paramParcel1.enforceInterface("com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
      editAudience();
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class a
      implements ac
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      /* Error */
      public void a(ad paramad, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +69 -> 87
        //   21: aload_1
        //   22: invokeinterface 37 1 0
        //   27: astore 8
        //   29: aload 5
        //   31: aload 8
        //   33: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   36: aload 5
        //   38: aload_2
        //   39: invokevirtual 43	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   42: aload 5
        //   44: iload_3
        //   45: invokevirtual 47	android/os/Parcel:writeInt	(I)V
        //   48: aload 5
        //   50: iload 4
        //   52: invokevirtual 47	android/os/Parcel:writeInt	(I)V
        //   55: aload_0
        //   56: getfield 15	com/google/android/gms/internal/ac$a$a:jR	Landroid/os/IBinder;
        //   59: iconst_2
        //   60: aload 5
        //   62: aload 6
        //   64: iconst_0
        //   65: invokeinterface 53 5 0
        //   70: pop
        //   71: aload 6
        //   73: invokevirtual 56	android/os/Parcel:readException	()V
        //   76: aload 6
        //   78: invokevirtual 59	android/os/Parcel:recycle	()V
        //   81: aload 5
        //   83: invokevirtual 59	android/os/Parcel:recycle	()V
        //   86: return
        //   87: aconst_null
        //   88: astore 8
        //   90: goto -61 -> 29
        //   93: astore 7
        //   95: aload 6
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 5
        //   102: invokevirtual 59	android/os/Parcel:recycle	()V
        //   105: aload 7
        //   107: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	108	0	this	a
        //   0	108	1	paramad	ad
        //   0	108	2	paramString	String
        //   0	108	3	paramInt1	int
        //   0	108	4	paramInt2	int
        //   3	98	5	localParcel1	Parcel
        //   8	88	6	localParcel2	Parcel
        //   93	13	7	localObject	Object
        //   27	62	8	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	17	93	finally
        //   21	29	93	finally
        //   29	76	93	finally
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public void editAudience()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.common.audience.dynamite.IAudienceViewCallbacks");
          this.jR.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void removeAudienceMember(AudienceMember paramAudienceMember)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +41 -> 56
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 47	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 68	com/google/android/gms/common/people/data/AudienceMember:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	com/google/android/gms/internal/ac$a$a:jR	Landroid/os/IBinder;
        //   33: iconst_3
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 53 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 56	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 59	android/os/Parcel:recycle	()V
        //   51: aload_2
        //   52: invokevirtual 59	android/os/Parcel:recycle	()V
        //   55: return
        //   56: aload_2
        //   57: iconst_0
        //   58: invokevirtual 47	android/os/Parcel:writeInt	(I)V
        //   61: goto -32 -> 29
        //   64: astore 4
        //   66: aload_3
        //   67: invokevirtual 59	android/os/Parcel:recycle	()V
        //   70: aload_2
        //   71: invokevirtual 59	android/os/Parcel:recycle	()V
        //   74: aload 4
        //   76: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	77	0	this	a
        //   0	77	1	paramAudienceMember	AudienceMember
        //   3	68	2	localParcel1	Parcel
        //   7	60	3	localParcel2	Parcel
        //   64	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	64	finally
        //   18	29	64	finally
        //   29	47	64	finally
        //   56	61	64	finally
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ac
 * JD-Core Version:    0.7.0.1
 */