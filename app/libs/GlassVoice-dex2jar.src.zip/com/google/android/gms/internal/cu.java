package com.google.android.gms.internal;

import com.google.android.gms.common.data.b;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.model.ContactGaiaId;

public class cu
  extends b
  implements ContactGaiaId
{
  public cu(d paramd, int paramInt)
  {
    super(paramd, paramInt);
  }
  
  public String getContactInfo()
  {
    return getString("value");
  }
  
  public String getGaiaId()
  {
    return getString("gaia_id");
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cu
 * JD-Core Version:    0.7.0.1
 */