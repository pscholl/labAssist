package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.Api.a;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import java.util.ArrayList;

public abstract class ak<T extends IInterface>
  implements GooglePlayServicesClient, Api.a, al.b
{
  public static final String[] GOOGLE_PLUS_REQUIRED_FEATURES = { "service_esmobile", "service_googleme" };
  private final Context mContext;
  final Handler mHandler;
  private final Looper rh;
  private final al rm;
  private ak<T>.e tA;
  private volatile int tB = 1;
  private final String[] tC;
  boolean tD = false;
  private T ty;
  private final ArrayList<ak<T>.b<?>> tz = new ArrayList();
  
  protected ak(Context paramContext)
  {
    this.mContext = ((Context)at.f(paramContext));
    this.rh = paramContext.getMainLooper();
    this.rm = new al(paramContext, this.rh, this);
    this.mHandler = new a(this.rh);
    this.tC = new String[0];
  }
  
  protected ak(Context paramContext, Looper paramLooper, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String... paramVarArgs)
  {
    this.mContext = ((Context)at.f(paramContext));
    this.rh = ((Looper)at.a(paramLooper, "Looper must not be null"));
    this.rm = new al(paramContext, paramLooper, this);
    this.mHandler = new a(paramLooper);
    c(paramVarArgs);
    this.tC = paramVarArgs;
    registerConnectionCallbacks((GoogleApiClient.ConnectionCallbacks)at.f(paramConnectionCallbacks));
    registerConnectionFailedListener((GoogleApiClient.OnConnectionFailedListener)at.f(paramOnConnectionFailedListener));
  }
  
  protected ak(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String... paramVarArgs)
  {
    this(paramContext, paramContext.getMainLooper(), new c(paramConnectionCallbacks), new f(paramOnConnectionFailedListener), paramVarArgs);
  }
  
  protected final void M()
  {
    if (!isConnected()) {
      throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
    }
  }
  
  protected void a(int paramInt, IBinder paramIBinder, Bundle paramBundle)
  {
    this.mHandler.sendMessage(this.mHandler.obtainMessage(1, new g(paramInt, paramIBinder, paramBundle)));
  }
  
  public final void a(ak<T>.b<?> paramak)
  {
    synchronized (this.tz)
    {
      this.tz.add(paramak);
      this.mHandler.sendMessage(this.mHandler.obtainMessage(2, paramak));
      return;
    }
  }
  
  protected abstract void a(ap paramap, d paramd)
    throws RemoteException;
  
  public Bundle bA()
  {
    return null;
  }
  
  protected abstract String bQ();
  
  protected abstract String bR();
  
  protected final T bS()
  {
    M();
    return this.ty;
  }
  
  public boolean bz()
  {
    return this.tD;
  }
  
  protected void c(String... paramVarArgs) {}
  
  public void connect()
  {
    this.tD = true;
    this.tB = 2;
    int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.mContext);
    if (i != 0)
    {
      this.tB = 1;
      this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(i)));
    }
    do
    {
      return;
      if (this.tA != null)
      {
        Log.e("GmsClient", "Calling connect() while still connected, missing disconnect().");
        this.ty = null;
        am.t(this.mContext).b(bQ(), this.tA);
      }
      this.tA = new e();
    } while (am.t(this.mContext).a(bQ(), this.tA));
    Log.e("GmsClient", "unable to connect to service: " + bQ());
    this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(9)));
  }
  
  public void disconnect()
  {
    this.tD = false;
    synchronized (this.tz)
    {
      int i = this.tz.size();
      for (int j = 0; j < i; j++) {
        ((b)this.tz.get(j)).bV();
      }
      this.tz.clear();
      this.tB = 1;
      this.ty = null;
      if (this.tA != null)
      {
        am.t(this.mContext).b(bQ(), this.tA);
        this.tA = null;
      }
      return;
    }
  }
  
  public final Context getContext()
  {
    return this.mContext;
  }
  
  public final Looper getLooper()
  {
    return this.rh;
  }
  
  public boolean isConnected()
  {
    return this.tB == 3;
  }
  
  public boolean isConnecting()
  {
    return this.tB == 2;
  }
  
  public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    return this.rm.isConnectionCallbacksRegistered(new c(paramConnectionCallbacks));
  }
  
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    return this.rm.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  protected abstract T o(IBinder paramIBinder);
  
  protected final void p(IBinder paramIBinder)
  {
    try
    {
      a(ap.a.r(paramIBinder), new d(this));
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w("GmsClient", "service died");
    }
  }
  
  public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.rm.registerConnectionCallbacks(new c(paramConnectionCallbacks));
  }
  
  public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.rm.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.rm.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void registerConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.rm.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.rm.unregisterConnectionCallbacks(new c(paramConnectionCallbacks));
  }
  
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.rm.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  final class a
    extends Handler
  {
    public a(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      if ((paramMessage.what == 1) && (!ak.this.isConnecting()))
      {
        ak.b localb2 = (ak.b)paramMessage.obj;
        localb2.bT();
        localb2.unregister();
        return;
      }
      if (paramMessage.what == 3)
      {
        ak.a(ak.this).a(new ConnectionResult(((Integer)paramMessage.obj).intValue(), null));
        return;
      }
      if (paramMessage.what == 4)
      {
        ak.a(ak.this, 1);
        ak.a(ak.this, null);
        ak.a(ak.this).aj(((Integer)paramMessage.obj).intValue());
        return;
      }
      if ((paramMessage.what == 2) && (!ak.this.isConnected()))
      {
        ak.b localb1 = (ak.b)paramMessage.obj;
        localb1.bT();
        localb1.unregister();
        return;
      }
      if ((paramMessage.what == 2) || (paramMessage.what == 1))
      {
        ((ak.b)paramMessage.obj).bU();
        return;
      }
      Log.wtf("GmsClient", "Don't know how to handle this message.");
    }
  }
  
  protected abstract class b<TListener>
  {
    private TListener mListener;
    private boolean tF;
    
    public b()
    {
      Object localObject;
      this.mListener = localObject;
      this.tF = false;
    }
    
    protected abstract void bT();
    
    /* Error */
    public void bU()
    {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield 21	com/google/android/gms/internal/ak$b:mListener	Ljava/lang/Object;
      //   6: astore_2
      //   7: aload_0
      //   8: getfield 23	com/google/android/gms/internal/ak$b:tF	Z
      //   11: ifeq +33 -> 44
      //   14: ldc 29
      //   16: new 31	java/lang/StringBuilder
      //   19: dup
      //   20: invokespecial 32	java/lang/StringBuilder:<init>	()V
      //   23: ldc 34
      //   25: invokevirtual 38	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   28: aload_0
      //   29: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   32: ldc 43
      //   34: invokevirtual 38	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   37: invokevirtual 47	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   40: invokestatic 53	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
      //   43: pop
      //   44: aload_0
      //   45: monitorexit
      //   46: aload_2
      //   47: ifnull +36 -> 83
      //   50: aload_0
      //   51: aload_2
      //   52: invokevirtual 57	com/google/android/gms/internal/ak$b:d	(Ljava/lang/Object;)V
      //   55: aload_0
      //   56: monitorenter
      //   57: aload_0
      //   58: iconst_1
      //   59: putfield 23	com/google/android/gms/internal/ak$b:tF	Z
      //   62: aload_0
      //   63: monitorexit
      //   64: aload_0
      //   65: invokevirtual 60	com/google/android/gms/internal/ak$b:unregister	()V
      //   68: return
      //   69: astore_1
      //   70: aload_0
      //   71: monitorexit
      //   72: aload_1
      //   73: athrow
      //   74: astore 4
      //   76: aload_0
      //   77: invokevirtual 62	com/google/android/gms/internal/ak$b:bT	()V
      //   80: aload 4
      //   82: athrow
      //   83: aload_0
      //   84: invokevirtual 62	com/google/android/gms/internal/ak$b:bT	()V
      //   87: goto -32 -> 55
      //   90: astore_3
      //   91: aload_0
      //   92: monitorexit
      //   93: aload_3
      //   94: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	95	0	this	b
      //   69	4	1	localObject1	Object
      //   6	46	2	localObject2	Object
      //   90	4	3	localObject3	Object
      //   74	7	4	localRuntimeException	java.lang.RuntimeException
      // Exception table:
      //   from	to	target	type
      //   2	44	69	finally
      //   44	46	69	finally
      //   70	72	69	finally
      //   50	55	74	java/lang/RuntimeException
      //   57	64	90	finally
      //   91	93	90	finally
    }
    
    public void bV()
    {
      try
      {
        this.mListener = null;
        return;
      }
      finally {}
    }
    
    protected abstract void d(TListener paramTListener);
    
    public void unregister()
    {
      bV();
      synchronized (ak.b(ak.this))
      {
        ak.b(ak.this).remove(this);
        return;
      }
    }
  }
  
  public static final class c
    implements GoogleApiClient.ConnectionCallbacks
  {
    private final GooglePlayServicesClient.ConnectionCallbacks tG;
    
    public c(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
    {
      this.tG = paramConnectionCallbacks;
    }
    
    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof c)) {
        return this.tG.equals(((c)paramObject).tG);
      }
      return this.tG.equals(paramObject);
    }
    
    public void onConnected(Bundle paramBundle)
    {
      this.tG.onConnected(paramBundle);
    }
    
    public void onConnectionSuspended(int paramInt)
    {
      this.tG.onDisconnected();
    }
  }
  
  public static final class d
    extends ao.a
  {
    private ak tH;
    
    public d(ak paramak)
    {
      this.tH = paramak;
    }
    
    public void b(int paramInt, IBinder paramIBinder, Bundle paramBundle)
    {
      at.a("onPostInitComplete can be called only once per call to getServiceFromBroker", this.tH);
      this.tH.a(paramInt, paramIBinder, paramBundle);
      this.tH = null;
    }
  }
  
  final class e
    implements ServiceConnection
  {
    e() {}
    
    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      ak.this.p(paramIBinder);
    }
    
    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      ak.this.mHandler.sendMessage(ak.this.mHandler.obtainMessage(4, Integer.valueOf(1)));
    }
  }
  
  public static final class f
    implements GoogleApiClient.OnConnectionFailedListener
  {
    private final GooglePlayServicesClient.OnConnectionFailedListener tI;
    
    public f(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
    {
      this.tI = paramOnConnectionFailedListener;
    }
    
    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof f)) {
        return this.tI.equals(((f)paramObject).tI);
      }
      return this.tI.equals(paramObject);
    }
    
    public void onConnectionFailed(ConnectionResult paramConnectionResult)
    {
      this.tI.onConnectionFailed(paramConnectionResult);
    }
  }
  
  protected final class g
    extends ak<T>.b<Boolean>
  {
    public final int statusCode;
    public final Bundle tJ;
    public final IBinder tK;
    
    public g(int paramInt, IBinder paramIBinder, Bundle paramBundle)
    {
      super(Boolean.valueOf(true));
      this.statusCode = paramInt;
      this.tK = paramIBinder;
      this.tJ = paramBundle;
    }
    
    protected void a(Boolean paramBoolean)
    {
      if (paramBoolean == null)
      {
        ak.a(ak.this, 1);
        return;
      }
      switch (this.statusCode)
      {
      default: 
        if (this.tJ == null) {
          break;
        }
      }
      for (PendingIntent localPendingIntent = (PendingIntent)this.tJ.getParcelable("pendingIntent");; localPendingIntent = null)
      {
        if (ak.d(ak.this) != null)
        {
          am.t(ak.e(ak.this)).b(ak.this.bQ(), ak.d(ak.this));
          ak.a(ak.this, null);
        }
        ak.a(ak.this, 1);
        ak.a(ak.this, null);
        ak.a(ak.this).a(new ConnectionResult(this.statusCode, localPendingIntent));
        return;
        try
        {
          String str = this.tK.getInterfaceDescriptor();
          if (ak.this.bR().equals(str))
          {
            ak.a(ak.this, ak.this.o(this.tK));
            if (ak.c(ak.this) != null)
            {
              ak.a(ak.this, 3);
              ak.a(ak.this).O();
              return;
            }
          }
        }
        catch (RemoteException localRemoteException)
        {
          am.t(ak.e(ak.this)).b(ak.this.bQ(), ak.d(ak.this));
          ak.a(ak.this, null);
          ak.a(ak.this, 1);
          ak.a(ak.this, null);
          ak.a(ak.this).a(new ConnectionResult(8, null));
          return;
        }
        ak.a(ak.this, 1);
        throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
      }
    }
    
    protected void bT() {}
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ak
 * JD-Core Version:    0.7.0.1
 */