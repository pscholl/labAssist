package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class cy
{
  private static final Integer[] Bi = new Integer[0];
  private final HashMap<Integer, Object> Bh = new HashMap();
  
  private Integer[] ds()
  {
    Integer[] arrayOfInteger = (Integer[])new ArrayList(this.Bh.keySet()).toArray(Bi);
    Arrays.sort(arrayOfInteger);
    return arrayOfInteger;
  }
  
  public String a(int paramInt1, int paramInt2)
  {
    at.f(Integer.valueOf(paramInt1));
    if (paramInt2 >= 0) {}
    Object localObject;
    for (boolean bool = true;; bool = false)
    {
      at.h(bool);
      localObject = this.Bh.get(Integer.valueOf(paramInt1));
      if (localObject != null) {
        break;
      }
      throw new IndexOutOfBoundsException("Size=0, requested=" + paramInt2);
    }
    if ((localObject instanceof String))
    {
      if (paramInt2 > 0) {
        throw new IndexOutOfBoundsException("Size=1, requested=" + paramInt2);
      }
      return (String)localObject;
    }
    ArrayList localArrayList = (ArrayList)localObject;
    if (paramInt2 > localArrayList.size()) {
      throw new IndexOutOfBoundsException("Size=" + localArrayList.size() + ", requested=" + paramInt2);
    }
    return (String)localArrayList.get(paramInt2);
  }
  
  public void a(Integer paramInteger, String paramString)
  {
    at.f(paramInteger);
    Object localObject = this.Bh.get(paramInteger);
    if (localObject == null)
    {
      this.Bh.put(paramInteger, paramString);
      return;
    }
    if ((localObject instanceof String))
    {
      ArrayList localArrayList = new ArrayList(4);
      localArrayList.add((String)localObject);
      localArrayList.add(paramString);
      this.Bh.put(paramInteger, localArrayList);
      return;
    }
    ((ArrayList)localObject).add(paramString);
  }
  
  public int bd(int paramInt)
  {
    at.f(Integer.valueOf(paramInt));
    Object localObject = this.Bh.get(Integer.valueOf(paramInt));
    if (localObject == null) {
      return 0;
    }
    if ((localObject instanceof String)) {
      return 1;
    }
    return ((ArrayList)localObject).size();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = de.dA();
    for (Integer localInteger : ds())
    {
      if (localStringBuilder.length() > 0) {
        localStringBuilder.append(",");
      }
      localStringBuilder.append(localInteger);
      localStringBuilder.append("=");
      int k = bd(localInteger.intValue());
      for (int m = 0; m < k; m++)
      {
        if (m > 0) {
          localStringBuilder.append(".");
        }
        localStringBuilder.append(a(localInteger.intValue(), m));
      }
      localStringBuilder.append("");
    }
    return localStringBuilder.toString();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cy
 * JD-Core Version:    0.7.0.1
 */