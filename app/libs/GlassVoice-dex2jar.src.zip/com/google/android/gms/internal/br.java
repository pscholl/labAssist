package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface br
  extends IInterface
{
  public abstract void h(byte[] paramArrayOfByte)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements br
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.droidguard.internal.IDroidGuardCallbacks");
    }
    
    public static br v(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.droidguard.internal.IDroidGuardCallbacks");
      if ((localIInterface != null) && ((localIInterface instanceof br))) {
        return (br)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.droidguard.internal.IDroidGuardCallbacks");
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.droidguard.internal.IDroidGuardCallbacks");
      h(paramParcel1.createByteArray());
      return true;
    }
    
    private static class a
      implements br
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public void h(byte[] paramArrayOfByte)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.droidguard.internal.IDroidGuardCallbacks");
          localParcel.writeByteArray(paramArrayOfByte);
          this.jR.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.br
 * JD-Core Version:    0.7.0.1
 */