package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.data.d;

public class cs
  extends cw.a
{
  public void a(int paramInt, Bundle paramBundle1, Bundle paramBundle2) {}
  
  public void a(int paramInt, Bundle paramBundle, ParcelFileDescriptor paramParcelFileDescriptor) {}
  
  public void a(int paramInt, Bundle paramBundle, d paramd) {}
  
  public void a(int paramInt, Bundle paramBundle, d[] paramArrayOfd) {}
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cs
 * JD-Core Version:    0.7.0.1
 */