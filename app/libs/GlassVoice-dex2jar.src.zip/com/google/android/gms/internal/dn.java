package com.google.android.gms.internal;

import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.model.AggregatedPersonBuffer;
import java.text.Collator;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class dn
{
  static boolean Dk = true;
  private d CC;
  private Cursor CD;
  private final d CX;
  protected final boolean CY;
  protected final int CZ;
  protected final Bundle Da;
  protected final Bundle Db;
  protected final boolean Dc;
  protected final String Dd;
  protected final dh De;
  private boolean Df;
  private ConnectionResult Dg;
  private d Dh;
  private boolean Di;
  private Exception Dj;
  private boolean Dl;
  private final Collator Dm = Collator.getInstance();
  protected final Context mContext;
  private final Object yD = new Object();
  
  protected dn(Context paramContext, d paramd, boolean paramBoolean, int paramInt, Bundle paramBundle1, Bundle paramBundle2, String paramString)
  {
    this.mContext = paramContext;
    this.CX = paramd;
    this.CY = paramBoolean;
    this.CZ = paramInt;
    this.Da = paramBundle1;
    this.Db = paramBundle2;
    boolean bool;
    if (!TextUtils.isEmpty(paramString))
    {
      bool = true;
      this.Dc = bool;
      if (!this.Dc) {
        break label111;
      }
      label79:
      this.Dd = paramString;
      if (!dd.dz()) {
        break label117;
      }
    }
    label111:
    label117:
    for (dh localdh = dh.ac("aggregator");; localdh = dh.dD())
    {
      this.De = localdh;
      return;
      bool = false;
      break;
      paramString = null;
      break label79;
    }
  }
  
  public static dn a(Context paramContext, d paramd, boolean paramBoolean, int paramInt, Bundle paramBundle1, Bundle paramBundle2, String paramString1, String paramString2)
  {
    if (TextUtils.isEmpty(paramString1)) {
      return new do(paramContext, paramd, paramBoolean, paramInt, paramBundle1, paramBundle2, paramString2);
    }
    if (!TextUtils.isEmpty(paramString2)) {
      throw new IllegalArgumentException("Search aggregation doesn't support filtering by gaia-id");
    }
    return new dp(paramContext, paramd, paramBoolean, paramInt, paramBundle1, paramBundle2, paramString1);
  }
  
  protected static void a(c paramc, HashMap<String, Integer> paramHashMap)
  {
    paramc.bh(-1);
    while (paramc.moveToNext())
    {
      String str = paramc.getString("gaia_id");
      if (!TextUtils.isEmpty(str)) {
        paramHashMap.put(str, Integer.valueOf(paramc.getPosition()));
      }
    }
  }
  
  private void dM()
  {
    try
    {
      new b().start();
      return;
    }
    catch (Exception localException)
    {
      dd.b("PeopleAggregator", "Unable to start thread", localException);
      a(null, localException);
    }
  }
  
  private void dO()
  {
    synchronized (this.yD)
    {
      at.h(this.Df);
      at.h(this.Di);
      if (this.CC != null) {
        this.CC.close();
      }
      if (this.Dh != null) {
        this.Dh.close();
      }
      if (this.CD != null) {
        this.CD.close();
      }
      if (this.Dl) {
        return;
      }
      this.Dl = true;
      this.CX.a(8, null, null);
      return;
    }
  }
  
  private void dP()
  {
    synchronized (this.yD)
    {
      if ((!this.Df) || (!this.Di)) {
        return;
      }
      if (!this.Dg.isSuccess())
      {
        dO();
        return;
      }
    }
    try
    {
      new a().start();
      return;
    }
    catch (Exception localException)
    {
      dd.b("PeopleAggregator", "Unable to start thread", localException);
      dO();
    }
  }
  
  private void dQ()
  {
    at.h(this.Dg.isSuccess());
    this.De.ad("agg start");
    if (this.CD != null) {}
    for (Object localObject = this.CD;; localObject = new MatrixCursor(dl.CU))
    {
      dk localdk = a(new c(this.CC), new c(this.Dh), (Cursor)localObject);
      this.De.ad("agg finish");
      this.De.g("PeopleAggregator", 0);
      this.CX.a(0, null, localdk);
      return;
    }
  }
  
  public static void i(boolean paramBoolean)
  {
    Dk = paramBoolean;
  }
  
  protected int a(Cursor paramCursor, di paramdi, cy paramcy, HashMap<String, String> paramHashMap)
  {
    int i = 0;
    long l1 = -1L;
    int j = -1;
    paramCursor.moveToPosition(-1);
    ArrayList localArrayList1 = new ArrayList(3);
    ArrayList localArrayList2 = new ArrayList(6);
    int m;
    int k;
    long l3;
    if (paramCursor.moveToNext())
    {
      long l2 = paramCursor.getLong(0);
      if (l2 == l1) {
        break label265;
      }
      localArrayList1.clear();
      localArrayList2.clear();
      m = paramCursor.getPosition();
      k = i + 1;
      l3 = l2;
    }
    for (;;)
    {
      String str1 = paramCursor.getString(2);
      if (("vnd.android.cursor.item/email_v2".equals(str1)) || ("vnd.android.cursor.item/phone_v2".equals(str1)))
      {
        String str2 = paramCursor.getString(3);
        if (TextUtils.isEmpty(str2))
        {
          j = m;
          l1 = l3;
          i = k;
          break;
        }
        if (localArrayList2.contains(str2))
        {
          j = m;
          l1 = l3;
          i = k;
          break;
        }
        localArrayList2.add(str2);
        String str3 = (String)paramHashMap.get(str2);
        if ((!TextUtils.isEmpty(str3)) && (!localArrayList1.contains(str3)))
        {
          localArrayList1.add(str3);
          paramdi.put(str3, m);
          paramcy.a(Integer.valueOf(m), str3);
        }
      }
      j = m;
      l1 = l3;
      i = k;
      break;
      return i;
      label265:
      k = i;
      l3 = l1;
      m = j;
    }
  }
  
  protected abstract dk a(c paramc1, c paramc2, Cursor paramCursor);
  
  void a(Cursor paramCursor, Exception paramException)
  {
    if (paramCursor != null) {
      this.De.ad("contacts loaded");
    }
    for (;;)
    {
      int i;
      if (dd.dz())
      {
        StringBuilder localStringBuilder = new StringBuilder().append("Contacts loaded.  exception=").append(paramException).append("  size=");
        if (paramCursor != null) {
          break label109;
        }
        i = -1;
        dd.g("PeopleAggregator", i);
      }
      synchronized (this.yD)
      {
        this.Di = true;
        this.CD = paramCursor;
        this.Dj = paramException;
        dP();
        return;
        this.De.ad("contacts load failure");
        continue;
        label109:
        i = paramCursor.getCount();
      }
    }
  }
  
  public void a(ConnectionResult paramConnectionResult, d[] paramArrayOfd)
  {
    if (paramConnectionResult.isSuccess()) {
      this.De.ad("people loaded");
    }
    for (;;)
    {
      int i;
      if (dd.dz())
      {
        StringBuilder localStringBuilder = new StringBuilder().append("People loaded.  status=").append(paramConnectionResult).append("  size=");
        if ((paramArrayOfd != null) && (paramArrayOfd.length >= 2) && (paramArrayOfd[0] != null)) {
          break label150;
        }
        i = -1;
        dd.g("PeopleAggregator", i);
      }
      synchronized (this.yD)
      {
        this.Df = true;
        this.Dg = paramConnectionResult;
        if (this.Dg.isSuccess())
        {
          this.CC = paramArrayOfd[0];
          this.Dh = paramArrayOfd[1];
        }
        if (!this.Dc)
        {
          dP();
          return;
          this.De.ad("people load failure");
          continue;
          label150:
          i = paramArrayOfd[0].getCount();
        }
      }
    }
    if (this.Dg.isSuccess())
    {
      dM();
      return;
    }
    synchronized (this.yD)
    {
      this.Di = true;
      dO();
      return;
    }
  }
  
  protected void b(c paramc, HashMap<String, String> paramHashMap)
  {
    paramc.bh(-1);
    while (paramc.moveToNext()) {
      paramHashMap.put(paramc.getString("value"), paramc.getString("gaia_id"));
    }
  }
  
  protected d dK()
  {
    return this.Dh;
  }
  
  public void dL()
  {
    if (!this.Dc) {
      dM();
    }
  }
  
  protected abstract Cursor dN();
  
  protected int l(String paramString1, String paramString2)
  {
    if (TextUtils.isEmpty(paramString1))
    {
      if (TextUtils.isEmpty(paramString2)) {
        return 0;
      }
      return -1;
    }
    if (TextUtils.isEmpty(paramString2)) {
      return 1;
    }
    return this.Dm.compare(paramString1, paramString2);
  }
  
  private class a
    extends Thread
  {
    public a()
    {
      super();
    }
    
    public final void run()
    {
      try
      {
        dn.a(dn.this);
        return;
      }
      catch (Exception localException)
      {
        dd.b("PeopleAggregator", "Unknown exception during aggregation", localException);
        dn.b(dn.this);
      }
    }
  }
  
  private class b
    extends Thread
  {
    public b()
    {
      super();
    }
    
    public final void run()
    {
      dn.this.De.ad("contacts query start");
      try
      {
        dn.this.a(dn.this.dN(), null);
        return;
      }
      catch (Exception localException)
      {
        dd.b("PeopleAggregator", "Error while quering contacts", localException);
        dn.this.a(null, localException);
      }
    }
  }
  
  protected static class c
  {
    public final d Do;
    private final int Dp;
    private int sc = -1;
    
    public c(d paramd)
    {
      this.Do = paramd;
      this.Dp = paramd.getCount();
    }
    
    public void bh(int paramInt)
    {
      this.sc = paramInt;
    }
    
    public int getCount()
    {
      return this.Dp;
    }
    
    public int getPosition()
    {
      return this.sc;
    }
    
    public String getString(String paramString)
    {
      return this.Do.c(paramString, this.sc, this.Do.ad(this.sc));
    }
    
    public boolean isAfterLast()
    {
      return this.sc >= this.Dp;
    }
    
    public boolean moveToNext()
    {
      this.sc = (1 + this.sc);
      return (this.sc >= 0) && (this.sc < this.Dp);
    }
  }
  
  public static abstract interface d
  {
    public abstract void a(int paramInt, Bundle paramBundle, AggregatedPersonBuffer paramAggregatedPersonBuffer);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dn
 * JD-Core Version:    0.7.0.1
 */