package com.google.android.gms.internal;

import android.text.TextUtils;

public class dg
{
  private final StringBuilder Cu = new StringBuilder();
  private boolean Cv = false;
  
  public void aa(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return;
    }
    this.Cu.append(paramString);
  }
  
  public void ab(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return;
    }
    if (this.Cv) {
      this.Cu.append(" AND ");
    }
    this.Cu.append(paramString);
    this.Cv = true;
  }
  
  public String toString()
  {
    return this.Cu.toString();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dg
 * JD-Core Version:    0.7.0.1
 */