package com.google.android.gms.internal;

import android.content.Context;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Locale;

public class cn
  implements SafeParcelable
{
  public static final co CREATOR = new co();
  public final int versionCode;
  public final String yH;
  public final String yI;
  
  public cn(int paramInt, String paramString1, String paramString2)
  {
    this.versionCode = paramInt;
    this.yH = paramString1;
    this.yI = paramString2;
  }
  
  public cn(Context paramContext, Locale paramLocale)
  {
    this.versionCode = 0;
    this.yH = paramContext.getPackageName();
    this.yI = paramLocale.toString();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    cn localcn;
    do
    {
      return true;
      if ((paramObject == null) || (!(paramObject instanceof cn))) {
        return false;
      }
      localcn = (cn)paramObject;
    } while ((this.yI.equals(localcn.yI)) && (this.yH.equals(localcn.yH)));
    return false;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = this.yH;
    arrayOfObject[1] = this.yI;
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    return ar.e(this).a("clientPackageName", this.yH).a("locale", this.yI).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    co.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cn
 * JD-Core Version:    0.7.0.1
 */