package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Base64;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.droidguard.DroidGuardResultsCallback;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class bq
  extends ak<bs>
{
  public bq(Context paramContext)
  {
    super(paramContext);
  }
  
  private static String I(String paramString)
  {
    return i(("ERROR : " + paramString).getBytes());
  }
  
  private static String i(byte[] paramArrayOfByte)
  {
    return Base64.encodeToString(paramArrayOfByte, 11);
  }
  
  public String a(String paramString, Map<String, String> paramMap)
  {
    at.x("getResults() must not be called on the main thread.");
    final LinkedBlockingQueue localLinkedBlockingQueue = new LinkedBlockingQueue();
    a(paramString, paramMap, new DroidGuardResultsCallback()
    {
      public void onDroidGuardResults(String paramAnonymousString)
      {
        try
        {
          localLinkedBlockingQueue.put(paramAnonymousString);
          return;
        }
        catch (InterruptedException localInterruptedException) {}
      }
    });
    try
    {
      Object localObject = (String)localLinkedBlockingQueue.poll(30000L, TimeUnit.MILLISECONDS);
      if (localObject == null)
      {
        String str = I("Timeout: 30000ms");
        localObject = str;
      }
      return localObject;
    }
    catch (InterruptedException localInterruptedException)
    {
      return I("Interrupted: " + localInterruptedException);
    }
  }
  
  protected void a(ap paramap, ak.d paramd)
    throws RemoteException
  {
    paramap.h(paramd, 4326000, getContext().getPackageName(), new Bundle());
  }
  
  public void a(final String paramString, final Map<String, String> paramMap, final DroidGuardResultsCallback paramDroidGuardResultsCallback)
  {
    final DroidGuardResultsCallback local1 = new DroidGuardResultsCallback()
    {
      boolean vv = false;
      
      public void onDroidGuardResults(String paramAnonymousString)
      {
        try
        {
          if (this.vv) {
            return;
          }
          this.vv = true;
          paramDroidGuardResultsCallback.onDroidGuardResults(paramAnonymousString);
          return;
        }
        finally {}
      }
    };
    GooglePlayServicesClient.ConnectionCallbacks local3 = new GooglePlayServicesClient.ConnectionCallbacks()
    {
      public void h(final byte[] paramAnonymousArrayOfByte)
        throws RemoteException
      {
        ak.b local1 = new ak.b(local1, paramAnonymousArrayOfByte)
        {
          protected void a(DroidGuardResultsCallback paramAnonymous2DroidGuardResultsCallback)
          {
            if (paramAnonymous2DroidGuardResultsCallback != null) {
              paramAnonymous2DroidGuardResultsCallback.onDroidGuardResults(bq.j(paramAnonymousArrayOfByte));
            }
            bq.this.disconnect();
          }
          
          protected void bT()
          {
            bq.this.disconnect();
          }
        };
        bq.this.a(local1);
      }
    }
    {
      public void onConnected(Bundle paramAnonymousBundle)
      {
        try
        {
          ((bs)bq.a(bq.this)).a(this.vB, paramString, paramMap);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          local1.onDroidGuardResults(bq.J("RemoteException: " + localRemoteException));
        }
      }
      
      public void onDisconnected()
      {
        local1.onDroidGuardResults(bq.J("Disconnected."));
      }
    };
    GooglePlayServicesClient.OnConnectionFailedListener local4 = new GooglePlayServicesClient.OnConnectionFailedListener()
    {
      public void onConnectionFailed(ConnectionResult paramAnonymousConnectionResult)
      {
        local1.onDroidGuardResults(bq.J("Connection failed: " + paramAnonymousConnectionResult));
      }
    };
    registerConnectionCallbacks(local3);
    registerConnectionFailedListener(local4);
    connect();
  }
  
  protected String bQ()
  {
    return "com.google.android.gms.droidguard.service.START";
  }
  
  protected String bR()
  {
    return "com.google.android.gms.droidguard.internal.IDroidGuardService";
  }
  
  protected bs u(IBinder paramIBinder)
  {
    return bs.a.w(paramIBinder);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bq
 * JD-Core Version:    0.7.0.1
 */