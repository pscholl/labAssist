package com.google.android.gms.internal;

import java.io.IOException;

public final class ei
{
  public static final int[] Jj = new int[0];
  public static final long[] Jk = new long[0];
  public static final float[] Jl = new float[0];
  public static final double[] Jm = new double[0];
  public static final boolean[] Jn = new boolean[0];
  public static final String[] Jo = new String[0];
  public static final byte[][] Jp = new byte[0][];
  public static final byte[] Jq = new byte[0];
  
  public static final int b(dz paramdz, int paramInt)
    throws IOException
  {
    int i = 1;
    int j = paramdz.getPosition();
    paramdz.bx(paramInt);
    for (;;)
    {
      if ((paramdz.gk() <= 0) || (paramdz.ga() != paramInt))
      {
        paramdz.bA(j);
        return i;
      }
      paramdz.bx(paramInt);
      i++;
    }
  }
  
  static int bL(int paramInt)
  {
    return paramInt & 0x7;
  }
  
  public static int bM(int paramInt)
  {
    return paramInt >>> 3;
  }
  
  static int g(int paramInt1, int paramInt2)
  {
    return paramInt2 | paramInt1 << 3;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ei
 * JD-Core Version:    0.7.0.1
 */