package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse.FieldConverter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public final class bd
  implements SafeParcelable, FastJsonResponse.FieldConverter<String, Integer>
{
  public static final be CREATOR = new be();
  private final int oj;
  private final HashMap<String, Integer> uC;
  private final HashMap<Integer, String> uD;
  private final ArrayList<a> uE;
  
  public bd()
  {
    this.oj = 1;
    this.uC = new HashMap();
    this.uD = new HashMap();
    this.uE = null;
  }
  
  bd(int paramInt, ArrayList<a> paramArrayList)
  {
    this.oj = paramInt;
    this.uC = new HashMap();
    this.uD = new HashMap();
    this.uE = null;
    a(paramArrayList);
  }
  
  private void a(ArrayList<a> paramArrayList)
  {
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      a locala = (a)localIterator.next();
      e(locala.uF, locala.uG);
    }
  }
  
  public Integer D(String paramString)
  {
    Integer localInteger = (Integer)this.uC.get(paramString);
    if (localInteger == null) {
      localInteger = (Integer)this.uC.get("gms_unknown");
    }
    return localInteger;
  }
  
  public String a(Integer paramInteger)
  {
    String str = (String)this.uD.get(paramInteger);
    if ((str == null) && (this.uC.containsKey("gms_unknown"))) {
      str = "gms_unknown";
    }
    return str;
  }
  
  ArrayList<a> cd()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.uC.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localArrayList.add(new a(str, ((Integer)this.uC.get(str)).intValue()));
    }
    return localArrayList;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public bd e(String paramString, int paramInt)
  {
    this.uC.put(paramString, Integer.valueOf(paramInt));
    this.uD.put(Integer.valueOf(paramInt), paramString);
    return this;
  }
  
  public int getTypeIn()
  {
    return 7;
  }
  
  public int getTypeOut()
  {
    return 0;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    be.a(this, paramParcel, paramInt);
  }
  
  public static final class a
    implements SafeParcelable
  {
    public static final bf CREATOR = new bf();
    final String uF;
    final int uG;
    final int versionCode;
    
    a(int paramInt1, String paramString, int paramInt2)
    {
      this.versionCode = paramInt1;
      this.uF = paramString;
      this.uG = paramInt2;
    }
    
    a(String paramString, int paramInt)
    {
      this.versionCode = 1;
      this.uF = paramString;
      this.uG = paramInt;
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      bf.a(this, paramParcel, paramInt);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bd
 * JD-Core Version:    0.7.0.1
 */