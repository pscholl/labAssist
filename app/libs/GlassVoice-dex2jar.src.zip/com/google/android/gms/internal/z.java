package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class z
  implements Parcelable
{
  @Deprecated
  public static final Parcelable.Creator<z> CREATOR = new Parcelable.Creator()
  {
    @Deprecated
    public z a(Parcel paramAnonymousParcel)
    {
      return new z(paramAnonymousParcel);
    }
    
    @Deprecated
    public z[] f(int paramAnonymousInt)
    {
      return new z[paramAnonymousInt];
    }
  };
  private String mValue;
  private String oh;
  private String oi;
  
  @Deprecated
  public z() {}
  
  @Deprecated
  z(Parcel paramParcel)
  {
    readFromParcel(paramParcel);
  }
  
  public z(String paramString1, String paramString2, String paramString3)
  {
    this.oh = paramString1;
    this.oi = paramString2;
    this.mValue = paramString3;
  }
  
  @Deprecated
  private void readFromParcel(Parcel paramParcel)
  {
    this.oh = paramParcel.readString();
    this.oi = paramParcel.readString();
    this.mValue = paramParcel.readString();
  }
  
  @Deprecated
  public int describeContents()
  {
    return 0;
  }
  
  public String getId()
  {
    return this.oh;
  }
  
  public String getValue()
  {
    return this.mValue;
  }
  
  @Deprecated
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.oh);
    paramParcel.writeString(this.oi);
    paramParcel.writeString(this.mValue);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.z
 * JD-Core Version:    0.7.0.1
 */