package com.google.android.gms.internal;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.ContactsContract.Data;
import android.text.TextUtils;

public final class dl
{
  public static final String[] CU = { "contact_id", "display_name", "mimetype", "data1", "data2", "data3" };
  private static boolean CV = false;
  private static boolean CW = false;
  
  public static final void a(dg paramdg)
  {
    paramdg.ab("(mimetype IN ('vnd.android.cursor.item/email_v2','vnd.android.cursor.item/phone_v2'))");
  }
  
  public static final void a(dg paramdg, boolean paramBoolean, Context paramContext)
  {
    if (!paramBoolean)
    {
      if (Build.VERSION.SDK_INT < 11) {
        break label42;
      }
      if (y(paramContext)) {
        paramdg.ab("(contact_id IN (SELECT _id FROM default_directory))");
      }
    }
    for (;;)
    {
      String str = dJ();
      if (!TextUtils.isEmpty(str)) {
        paramdg.ab(str);
      }
      return;
      label42:
      paramdg.ab("(in_visible_group=1)");
    }
  }
  
  public static boolean a(Cursor paramCursor)
  {
    if (paramCursor.isAfterLast()) {}
    long l;
    do
    {
      while (!paramCursor.moveToNext())
      {
        return false;
        l = paramCursor.getLong(0);
      }
    } while (l == paramCursor.getLong(0));
    return true;
  }
  
  public static boolean b(Cursor paramCursor)
  {
    boolean bool1 = true;
    boolean bool2;
    if (!paramCursor.isBeforeFirst())
    {
      bool2 = bool1;
      at.h(bool2);
      if (!paramCursor.isAfterLast()) {
        break label33;
      }
    }
    label33:
    long l;
    do
    {
      return false;
      bool2 = false;
      break;
      l = paramCursor.getLong(0);
    } while (!paramCursor.moveToNext());
    if (l == paramCursor.getLong(0)) {}
    for (;;)
    {
      return bool1;
      bool1 = false;
    }
  }
  
  public static final String dJ()
  {
    if (Build.VERSION.SDK_INT < 14) {
      return null;
    }
    return "((data_set IS NULL) OR (account_type='com.google' AND data_set!='plus'))";
  }
  
  /* Error */
  private static final boolean y(Context paramContext)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: getstatic 31	com/google/android/gms/internal/dl:CW	Z
    //   6: ifeq +14 -> 20
    //   9: getstatic 29	com/google/android/gms/internal/dl:CV	Z
    //   12: istore 5
    //   14: ldc 2
    //   16: monitorexit
    //   17: iload 5
    //   19: ireturn
    //   20: iconst_1
    //   21: putstatic 31	com/google/android/gms/internal/dl:CW	Z
    //   24: aload_0
    //   25: invokevirtual 100	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   28: getstatic 106	android/provider/ContactsContract$Groups:CONTENT_URI	Landroid/net/Uri;
    //   31: aconst_null
    //   32: ldc 108
    //   34: aconst_null
    //   35: aconst_null
    //   36: invokevirtual 114	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   39: astore 6
    //   41: aload 6
    //   43: astore_3
    //   44: aload_3
    //   45: ifnull +7 -> 52
    //   48: iconst_1
    //   49: putstatic 29	com/google/android/gms/internal/dl:CV	Z
    //   52: aload_3
    //   53: ifnull +9 -> 62
    //   56: aload_3
    //   57: invokeinterface 117 1 0
    //   62: getstatic 29	com/google/android/gms/internal/dl:CV	Z
    //   65: istore 5
    //   67: goto -53 -> 14
    //   70: astore 4
    //   72: aconst_null
    //   73: astore_3
    //   74: ldc 119
    //   76: ldc 121
    //   78: invokestatic 127	com/google/android/gms/internal/dd:g	(Ljava/lang/String;Ljava/lang/String;)V
    //   81: ldc 119
    //   83: aload 4
    //   85: invokevirtual 130	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   88: invokestatic 127	com/google/android/gms/internal/dd:g	(Ljava/lang/String;Ljava/lang/String;)V
    //   91: aload_3
    //   92: ifnull -30 -> 62
    //   95: aload_3
    //   96: invokeinterface 117 1 0
    //   101: goto -39 -> 62
    //   104: astore_1
    //   105: ldc 2
    //   107: monitorexit
    //   108: aload_1
    //   109: athrow
    //   110: astore_2
    //   111: aconst_null
    //   112: astore_3
    //   113: aload_3
    //   114: ifnull +9 -> 123
    //   117: aload_3
    //   118: invokeinterface 117 1 0
    //   123: aload_2
    //   124: athrow
    //   125: astore_2
    //   126: goto -13 -> 113
    //   129: astore 4
    //   131: goto -57 -> 74
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	134	0	paramContext	Context
    //   104	5	1	localObject1	Object
    //   110	14	2	localObject2	Object
    //   125	1	2	localObject3	Object
    //   43	75	3	localCursor1	Cursor
    //   70	14	4	localException1	java.lang.Exception
    //   129	1	4	localException2	java.lang.Exception
    //   12	54	5	bool	boolean
    //   39	3	6	localCursor2	Cursor
    // Exception table:
    //   from	to	target	type
    //   24	41	70	java/lang/Exception
    //   3	14	104	finally
    //   20	24	104	finally
    //   56	62	104	finally
    //   62	67	104	finally
    //   95	101	104	finally
    //   117	123	104	finally
    //   123	125	104	finally
    //   24	41	110	finally
    //   48	52	125	finally
    //   74	91	125	finally
    //   48	52	129	java/lang/Exception
  }
  
  public static abstract interface a
  {
    public static final Uri CONTENT_FILTER_URI = Uri.withAppendedPath(CONTENT_URI, "filter");
    public static final Uri CONTENT_URI = Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, "contactables");
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dl
 * JD-Core Version:    0.7.0.1
 */