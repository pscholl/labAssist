package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import java.util.ArrayList;

public final class al
{
  private final Handler mHandler;
  private final b tL;
  private ArrayList<GoogleApiClient.ConnectionCallbacks> tM = new ArrayList();
  final ArrayList<GoogleApiClient.ConnectionCallbacks> tN = new ArrayList();
  private boolean tO = false;
  private ArrayList<GooglePlayServicesClient.OnConnectionFailedListener> tP = new ArrayList();
  private boolean tQ = false;
  
  public al(Context paramContext, Looper paramLooper, b paramb)
  {
    this.tL = paramb;
    this.mHandler = new a(paramLooper);
  }
  
  protected void O()
  {
    synchronized (this.tM)
    {
      a(this.tL.bA());
      return;
    }
  }
  
  public void a(Bundle paramBundle)
  {
    boolean bool1 = true;
    for (;;)
    {
      int j;
      synchronized (this.tM)
      {
        if (!this.tO)
        {
          bool2 = bool1;
          at.f(bool2);
          this.mHandler.removeMessages(1);
          this.tO = true;
          if (this.tN.size() != 0) {
            break label170;
          }
          at.f(bool1);
          ArrayList localArrayList2 = this.tM;
          int i = localArrayList2.size();
          j = 0;
          if ((j >= i) || (!this.tL.bz()) || (!this.tL.isConnected()))
          {
            this.tN.clear();
            this.tO = false;
            return;
          }
          this.tN.size();
          if (this.tN.contains(localArrayList2.get(j))) {
            break label175;
          }
          ((GoogleApiClient.ConnectionCallbacks)localArrayList2.get(j)).onConnected(paramBundle);
        }
      }
      boolean bool2 = false;
      continue;
      label170:
      bool1 = false;
      continue;
      label175:
      j++;
    }
  }
  
  public void a(ConnectionResult paramConnectionResult)
  {
    this.mHandler.removeMessages(1);
    for (;;)
    {
      int j;
      synchronized (this.tP)
      {
        this.tQ = true;
        ArrayList localArrayList2 = this.tP;
        int i = localArrayList2.size();
        j = 0;
        if (j < i)
        {
          if (!this.tL.bz()) {
            return;
          }
          if (this.tP.contains(localArrayList2.get(j))) {
            ((GooglePlayServicesClient.OnConnectionFailedListener)localArrayList2.get(j)).onConnectionFailed(paramConnectionResult);
          }
        }
        else
        {
          this.tQ = false;
          return;
        }
      }
      j++;
    }
  }
  
  public void aj(int paramInt)
  {
    this.mHandler.removeMessages(1);
    for (;;)
    {
      int j;
      synchronized (this.tM)
      {
        this.tO = true;
        ArrayList localArrayList2 = this.tM;
        int i = localArrayList2.size();
        j = 0;
        if ((j >= i) || (!this.tL.bz()))
        {
          this.tO = false;
          return;
        }
        if (this.tM.contains(localArrayList2.get(j))) {
          ((GoogleApiClient.ConnectionCallbacks)localArrayList2.get(j)).onConnectionSuspended(paramInt);
        }
      }
      j++;
    }
  }
  
  public boolean isConnectionCallbacksRegistered(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    at.f(paramConnectionCallbacks);
    synchronized (this.tM)
    {
      boolean bool = this.tM.contains(paramConnectionCallbacks);
      return bool;
    }
  }
  
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    at.f(paramOnConnectionFailedListener);
    synchronized (this.tP)
    {
      boolean bool = this.tP.contains(paramOnConnectionFailedListener);
      return bool;
    }
  }
  
  public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    at.f(paramConnectionCallbacks);
    synchronized (this.tM)
    {
      if (this.tM.contains(paramConnectionCallbacks))
      {
        Log.w("GmsClientEvents", "registerConnectionCallbacks(): listener " + paramConnectionCallbacks + " is already registered");
        if (this.tL.isConnected()) {
          this.mHandler.sendMessage(this.mHandler.obtainMessage(1, paramConnectionCallbacks));
        }
        return;
      }
      if (this.tO) {
        this.tM = new ArrayList(this.tM);
      }
      this.tM.add(paramConnectionCallbacks);
    }
  }
  
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    at.f(paramOnConnectionFailedListener);
    synchronized (this.tP)
    {
      if (this.tP.contains(paramOnConnectionFailedListener))
      {
        Log.w("GmsClientEvents", "registerConnectionFailedListener(): listener " + paramOnConnectionFailedListener + " is already registered");
        return;
      }
      if (this.tQ) {
        this.tP = new ArrayList(this.tP);
      }
      this.tP.add(paramOnConnectionFailedListener);
    }
  }
  
  public void unregisterConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    at.f(paramConnectionCallbacks);
    synchronized (this.tM)
    {
      if (this.tM != null)
      {
        if (this.tO) {
          this.tM = new ArrayList(this.tM);
        }
        if (this.tM.remove(paramConnectionCallbacks)) {
          break label85;
        }
        Log.w("GmsClientEvents", "unregisterConnectionCallbacks(): listener " + paramConnectionCallbacks + " not found");
      }
      label85:
      while ((!this.tO) || (this.tN.contains(paramConnectionCallbacks))) {
        return;
      }
      this.tN.add(paramConnectionCallbacks);
    }
  }
  
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    at.f(paramOnConnectionFailedListener);
    synchronized (this.tP)
    {
      if (this.tP != null)
      {
        if (this.tQ) {
          this.tP = new ArrayList(this.tP);
        }
        if (!this.tP.remove(paramOnConnectionFailedListener)) {
          Log.w("GmsClientEvents", "unregisterConnectionFailedListener(): listener " + paramOnConnectionFailedListener + " not found");
        }
      }
      return;
    }
  }
  
  final class a
    extends Handler
  {
    public a(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      if (paramMessage.what == 1) {
        synchronized (al.a(al.this))
        {
          if ((al.b(al.this).bz()) && (al.b(al.this).isConnected()) && (al.a(al.this).contains(paramMessage.obj)))
          {
            Bundle localBundle = al.b(al.this).bA();
            ((GoogleApiClient.ConnectionCallbacks)paramMessage.obj).onConnected(localBundle);
          }
          return;
        }
      }
      Log.wtf("GmsClientEvents", "Don't know how to handle this message.");
    }
  }
  
  public static abstract interface b
  {
    public abstract Bundle bA();
    
    public abstract boolean bz();
    
    public abstract boolean isConnected();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.al
 * JD-Core Version:    0.7.0.1
 */