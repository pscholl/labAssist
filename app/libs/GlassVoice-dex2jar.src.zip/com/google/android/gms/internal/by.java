package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationStatus;
import com.google.android.gms.location.a.a;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class by
{
  private final Context mContext;
  private final cc<bx> xj;
  private ContentProviderClient xk = null;
  private boolean xl = false;
  private HashMap<LocationListener, b> xm = new HashMap();
  
  public by(Context paramContext, cc<bx> paramcc)
  {
    this.mContext = paramContext;
    this.xj = paramcc;
  }
  
  public void cw()
  {
    if (this.xl) {
      setMockMode(false);
    }
  }
  
  public Location getLastLocation()
  {
    this.xj.M();
    try
    {
      Location localLocation = ((bx)this.xj.bS()).L(this.mContext.getPackageName());
      return localLocation;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public LocationStatus getLastLocationStatus()
  {
    this.xj.M();
    try
    {
      LocationStatus localLocationStatus = ((bx)this.xj.bS()).M(this.mContext.getPackageName());
      return localLocationStatus;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void injectLocation(Location paramLocation, int paramInt)
  {
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).injectLocation(paramLocation, paramInt);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void removeAllListeners()
  {
    try
    {
      synchronized (this.xm)
      {
        Iterator localIterator = this.xm.values().iterator();
        while (localIterator.hasNext())
        {
          b localb = (b)localIterator.next();
          if (localb != null) {
            ((bx)this.xj.bS()).a(localb);
          }
        }
      }
      this.xm.clear();
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void removeLocationUpdates(PendingIntent paramPendingIntent)
  {
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).a(paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void removeLocationUpdates(LocationListener paramLocationListener)
  {
    this.xj.M();
    at.a(paramLocationListener, "Invalid null listener");
    synchronized (this.xm)
    {
      b localb = (b)this.xm.remove(paramLocationListener);
      if ((this.xk != null) && (this.xm.isEmpty()))
      {
        this.xk.release();
        this.xk = null;
      }
      if (localb != null) {
        localb.release();
      }
      try
      {
        ((bx)this.xj.bS()).a(localb);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new IllegalStateException(localRemoteException);
      }
    }
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, PendingIntent paramPendingIntent)
  {
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).a(paramLocationRequest, paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void requestLocationUpdates(LocationRequest paramLocationRequest, LocationListener paramLocationListener, Looper paramLooper)
  {
    this.xj.M();
    if (paramLooper == null) {
      at.a(Looper.myLooper(), "Can't create handler inside thread that has not called Looper.prepare()");
    }
    for (;;)
    {
      b localb1;
      synchronized (this.xm)
      {
        localb1 = (b)this.xm.get(paramLocationListener);
        if (localb1 == null)
        {
          localb2 = new b(paramLocationListener, paramLooper);
          this.xm.put(paramLocationListener, localb2);
          try
          {
            ((bx)this.xj.bS()).a(paramLocationRequest, localb2, this.mContext.getPackageName());
            return;
          }
          catch (RemoteException localRemoteException)
          {
            throw new IllegalStateException(localRemoteException);
          }
        }
      }
      b localb2 = localb1;
    }
  }
  
  public void setMockLocation(Location paramLocation)
  {
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).setMockLocation(paramLocation);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void setMockMode(boolean paramBoolean)
  {
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).setMockMode(paramBoolean);
      this.xl = paramBoolean;
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  private static class a
    extends Handler
  {
    private final LocationListener xn;
    
    public a(LocationListener paramLocationListener)
    {
      this.xn = paramLocationListener;
    }
    
    public a(LocationListener paramLocationListener, Looper paramLooper)
    {
      super();
      this.xn = paramLocationListener;
    }
    
    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default: 
        Log.e("LocationClientHelper", "unknown message in LocationHandler.handleMessage");
        return;
      }
      Location localLocation = new Location((Location)paramMessage.obj);
      this.xn.onLocationChanged(localLocation);
    }
  }
  
  private static class b
    extends a.a
  {
    private Handler xo;
    
    b(LocationListener paramLocationListener, Looper paramLooper)
    {
      if (paramLooper == null) {}
      for (by.a locala = new by.a(paramLocationListener);; locala = new by.a(paramLocationListener, paramLooper))
      {
        this.xo = locala;
        return;
      }
    }
    
    public void onLocationChanged(Location paramLocation)
    {
      if (this.xo == null)
      {
        Log.e("LocationClientHelper", "Received a location in client after calling removeLocationUpdates.");
        return;
      }
      Message localMessage = Message.obtain();
      localMessage.what = 1;
      localMessage.obj = paramLocation;
      this.xo.sendMessage(localMessage);
    }
    
    public void release()
    {
      this.xo = null;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.by
 * JD-Core Version:    0.7.0.1
 */