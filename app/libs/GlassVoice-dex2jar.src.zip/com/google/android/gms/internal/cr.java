package com.google.android.gms.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.location.places.PlaceReport;
import com.google.android.gms.location.reporting.OptInResult;
import com.google.android.gms.location.reporting.ReportingState;
import com.google.android.gms.location.reporting.UploadRequest;
import com.google.android.gms.location.reporting.UploadRequestResult;
import java.io.IOException;

public class cr
  extends ak<cp>
{
  public cr(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String... paramVarArgs)
  {
    super(paramContext, paramConnectionCallbacks, paramOnConnectionFailedListener, paramVarArgs);
  }
  
  protected cp F(IBinder paramIBinder)
  {
    return cp.a.E(paramIBinder);
  }
  
  protected void a(ap paramap, ak.d paramd)
    throws RemoteException
  {
    Bundle localBundle = new Bundle();
    paramap.c(paramd, 4326000, getContext().getPackageName(), localBundle);
  }
  
  protected String bQ()
  {
    return "com.google.android.gms.location.reporting.service.START";
  }
  
  protected String bR()
  {
    return "com.google.android.gms.location.reporting.internal.IReportingService";
  }
  
  public int cancelUpload(long paramLong)
    throws IOException
  {
    M();
    try
    {
      int i = ((cp)bS()).c(paramLong);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      IOException localIOException = new IOException();
      localIOException.initCause(localRemoteException);
      throw localIOException;
    }
  }
  
  public ReportingState getReportingState(Account paramAccount)
    throws IOException
  {
    M();
    try
    {
      ReportingState localReportingState = ((cp)bS()).getReportingState(paramAccount);
      return localReportingState;
    }
    catch (RemoteException localRemoteException)
    {
      IOException localIOException = new IOException();
      localIOException.initCause(localRemoteException);
      throw localIOException;
    }
  }
  
  public int reportPlace(Account paramAccount, PlaceReport paramPlaceReport)
    throws IOException
  {
    M();
    try
    {
      int i = ((cp)bS()).reportPlace(paramAccount, paramPlaceReport);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IOException(localRemoteException);
    }
  }
  
  public UploadRequestResult requestUpload(UploadRequest paramUploadRequest)
    throws IOException
  {
    M();
    if (paramUploadRequest.getAccount() == null) {
      throw new IllegalArgumentException();
    }
    try
    {
      UploadRequestResult localUploadRequestResult = ((cp)bS()).requestUpload(paramUploadRequest);
      return localUploadRequestResult;
    }
    catch (RemoteException localRemoteException)
    {
      IOException localIOException = new IOException();
      localIOException.initCause(localRemoteException);
      throw localIOException;
    }
  }
  
  public int tryOptIn(Account paramAccount)
  {
    M();
    try
    {
      int j = ((cp)bS()).tryOptIn(paramAccount);
      i = j;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        int i = 9;
      }
    }
    return OptInResult.sanitize(i);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cr
 * JD-Core Version:    0.7.0.1
 */