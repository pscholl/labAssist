package com.google.android.gms.internal;

import android.util.Base64;

class e
  implements n
{
  public String a(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (int i = 11;; i = 2) {
      return Base64.encodeToString(paramArrayOfByte, i);
    }
  }
  
  public byte[] a(String paramString, boolean paramBoolean)
    throws IllegalArgumentException
  {
    if (paramBoolean) {}
    for (int i = 11;; i = 2) {
      return Base64.decode(paramString, i);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.e
 * JD-Core Version:    0.7.0.1
 */