package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class ce
  implements Parcelable.Creator<ch.a>
{
  static void a(ch.a parama, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.a(paramParcel, 1, parama.getPlaceId(), false);
    b.c(paramParcel, 1000, parama.oj);
    b.a(paramParcel, 2, parama.getTag(), false);
    b.a(paramParcel, 3, parama.cK(), false);
    b.c(paramParcel, 4, parama.cL());
    b.C(paramParcel, i);
  }
  
  public ch.a[] aQ(int paramInt)
  {
    return new ch.a[paramInt];
  }
  
  public ch.a as(Parcel paramParcel)
  {
    int i = 0;
    String str1 = null;
    int j = a.Y(paramParcel);
    String str2 = null;
    String str3 = null;
    int k = 0;
    while (paramParcel.dataPosition() < j)
    {
      int m = a.X(paramParcel);
      switch (a.al(m))
      {
      default: 
        a.b(paramParcel, m);
        break;
      case 1: 
        str3 = a.l(paramParcel, m);
        break;
      case 1000: 
        k = a.f(paramParcel, m);
        break;
      case 2: 
        str2 = a.l(paramParcel, m);
        break;
      case 3: 
        str1 = a.l(paramParcel, m);
        break;
      case 4: 
        i = a.f(paramParcel, m);
      }
    }
    if (paramParcel.dataPosition() != j) {
      throw new a.a("Overread allowed size end=" + j, paramParcel);
    }
    return new ch.a(k, str3, str2, str1, i);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ce
 * JD-Core Version:    0.7.0.1
 */