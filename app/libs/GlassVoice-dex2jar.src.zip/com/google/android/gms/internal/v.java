package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.dynamic.e;
import com.google.android.gms.dynamic.e.a;

public final class v
  extends e<x>
{
  private static final v jV = new v();
  
  private v()
  {
    super("com.google.android.gms.ads.adshield.AdShieldCreatorImpl");
  }
  
  public static w b(String paramString, Context paramContext)
  {
    try
    {
      w localw = jV.c(paramString, paramContext);
      return localw;
    }
    catch (RemoteException localRemoteException)
    {
      return new u(paramString, paramContext);
    }
    catch (e.a locala)
    {
      label14:
      break label14;
    }
  }
  
  private w c(String paramString, Context paramContext)
    throws e.a, RemoteException
  {
    b localb = c.g(paramContext);
    return w.a.e(((x)u(paramContext)).a(paramString, localb));
  }
  
  protected x c(IBinder paramIBinder)
  {
    return x.a.f(paramIBinder);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.v
 * JD-Core Version:    0.7.0.1
 */