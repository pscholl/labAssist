package com.google.android.gms.internal;

import java.io.IOException;

class q
  implements o
{
  private ea jO;
  private byte[] jP;
  private final int jQ;
  
  public q(int paramInt)
  {
    this.jQ = paramInt;
    reset();
  }
  
  public void b(int paramInt, long paramLong)
    throws IOException
  {
    this.jO.b(paramInt, paramLong);
  }
  
  public void b(int paramInt, String paramString)
    throws IOException
  {
    this.jO.b(paramInt, paramString);
  }
  
  public void reset()
  {
    this.jP = new byte[this.jQ];
    this.jO = ea.r(this.jP);
  }
  
  public byte[] w()
    throws IOException
  {
    int i = this.jO.gn();
    if (i < 0) {
      throw new IOException();
    }
    if (i == 0) {
      return this.jP;
    }
    byte[] arrayOfByte = new byte[this.jP.length - i];
    System.arraycopy(this.jP, 0, arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.q
 * JD-Core Version:    0.7.0.1
 */