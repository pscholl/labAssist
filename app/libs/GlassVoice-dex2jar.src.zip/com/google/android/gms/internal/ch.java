package com.google.android.gms.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.location.places.OpeningHours;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public final class ch
  extends Place
  implements SafeParcelable
{
  public static final ci CREATOR = new ci();
  private final String oh;
  final int oj;
  private final Bundle yb;
  private final cj yc;
  private final LatLng yd;
  private final float ye;
  private final LatLngBounds yf;
  private final String yg;
  private final Uri yh;
  private final boolean yi;
  private final float yj;
  private final int yk;
  private final long yl;
  private final List<PlaceType> ym;
  private final Map<PlaceType, String> yn;
  private final TimeZone yo;
  private Locale yp;
  private cm yq;
  
  ch(int paramInt1, String paramString1, List<PlaceType> paramList, Bundle paramBundle, cj paramcj, LatLng paramLatLng, float paramFloat1, LatLngBounds paramLatLngBounds, String paramString2, Uri paramUri, boolean paramBoolean, float paramFloat2, int paramInt2, long paramLong)
  {
    this.oj = paramInt1;
    this.oh = paramString1;
    this.ym = Collections.unmodifiableList(paramList);
    this.yb = paramBundle;
    this.yc = paramcj;
    this.yd = paramLatLng;
    this.ye = paramFloat1;
    this.yf = paramLatLngBounds;
    this.yg = paramString2;
    this.yh = paramUri;
    this.yi = paramBoolean;
    this.yj = paramFloat2;
    this.yk = paramInt2;
    this.yl = paramLong;
    HashMap localHashMap = new HashMap();
    Iterator localIterator = paramBundle.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localHashMap.put(PlaceType.create(str), paramBundle.getString(str));
    }
    this.yn = Collections.unmodifiableMap(localHashMap);
    this.yo = TimeZone.getTimeZone(this.yg);
    this.yp = null;
    this.yq = null;
  }
  
  private void O(String paramString)
  {
    if (this.yq != null) {
      this.yq.a(new ch.a.a(this.oh, paramString));
    }
  }
  
  public long cG()
  {
    return this.yl;
  }
  
  public Bundle cH()
  {
    return this.yb;
  }
  
  public cj cI()
  {
    return this.yc;
  }
  
  public String cJ()
  {
    return this.yg;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    ch localch;
    do
    {
      return true;
      if (!(paramObject instanceof ch)) {
        return false;
      }
      localch = (ch)paramObject;
    } while ((this.oh.equals(localch.oh)) && (ar.equal(this.yp, localch.yp)) && (this.yl == localch.yl));
    return false;
  }
  
  public String getAddress()
  {
    O("getAddress");
    return this.yc.yt;
  }
  
  public Map<PlaceType, String> getAddressComponents()
  {
    O("getAddressComponents");
    return this.yn;
  }
  
  public String getId()
  {
    O("getId");
    return this.oh;
  }
  
  public LatLng getLatLng()
  {
    O("getLatLng");
    return this.yd;
  }
  
  public float getLevelNumber()
  {
    O("getLevelNumber");
    return this.ye;
  }
  
  public Locale getLocale()
  {
    O("mLocale");
    return this.yp;
  }
  
  public String getName()
  {
    O("getName");
    return this.yc.name;
  }
  
  public OpeningHours getOpeningHours()
  {
    O("getOpeningHours");
    return null;
  }
  
  public String getPhoneNumber()
  {
    O("getPhoneNumber");
    return this.yc.yu;
  }
  
  public int getPriceLevel()
  {
    O("getPriceLevel");
    return this.yk;
  }
  
  public float getRating()
  {
    O("getRating");
    return this.yj;
  }
  
  public TimeZone getTimeZone()
  {
    O("getTimeZone");
    return this.yo;
  }
  
  public List<PlaceType> getTypes()
  {
    O("getTypes");
    return this.ym;
  }
  
  public LatLngBounds getViewport()
  {
    O("getViewport");
    return this.yf;
  }
  
  public Uri getWebsiteUri()
  {
    O("getWebsiteUri");
    return this.yh;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = this.oh;
    arrayOfObject[1] = this.yp;
    arrayOfObject[2] = Long.valueOf(this.yl);
    return ar.hashCode(arrayOfObject);
  }
  
  public boolean isPermanentlyClosed()
  {
    O("isPermanentlyClosed");
    return this.yi;
  }
  
  public String toString()
  {
    return ar.e(this).a("id", this.oh).a("localization", this.yc).a("locale", this.yp).a("latlng", this.yd).a("levelNumber", Float.valueOf(this.ye)).a("viewport", this.yf).a("timeZone", this.yg).a("websiteUri", this.yh).a("isPermanentlyClosed", Boolean.valueOf(this.yi)).a("priceLevel", Integer.valueOf(this.yk)).a("timestampSecs", Long.valueOf(this.yl)).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    ci.a(this, paramParcel, paramInt);
  }
  
  public static final class a
    implements SafeParcelable
  {
    public static final ce CREATOR = new ce();
    private final String mTag;
    final int oj;
    private final String xH;
    private final String yr;
    private final int ys;
    
    a(int paramInt1, String paramString1, String paramString2, String paramString3, int paramInt2)
    {
      this.oj = paramInt1;
      this.xH = paramString1;
      this.mTag = paramString2;
      this.yr = paramString3;
      this.ys = paramInt2;
    }
    
    public String cK()
    {
      return this.yr;
    }
    
    public int cL()
    {
      return this.ys;
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {}
      a locala;
      do
      {
        return true;
        if (!(paramObject instanceof a)) {
          return false;
        }
        locala = (a)paramObject;
      } while ((this.xH.equals(locala.xH)) && (ar.equal(this.mTag, locala.mTag)));
      return false;
    }
    
    public String getPlaceId()
    {
      return this.xH;
    }
    
    public String getTag()
    {
      return this.mTag;
    }
    
    public int hashCode()
    {
      Object[] arrayOfObject = new Object[4];
      arrayOfObject[0] = this.xH;
      arrayOfObject[1] = this.mTag;
      arrayOfObject[2] = this.yr;
      arrayOfObject[3] = Integer.valueOf(this.ys);
      return ar.hashCode(arrayOfObject);
    }
    
    public String toString()
    {
      return ar.e(this).a("placeId", this.xH).a("tag", this.mTag).a("callingAppPackageName", this.yr).a("callingAppVersionCode", Integer.valueOf(this.ys)).toString();
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      ce.a(this, paramParcel, paramInt);
    }
    
    public static class a
    {
      private final String mTag;
      private final String xH;
      private String yr;
      private int ys;
      
      public a(String paramString1, String paramString2)
      {
        this.xH = paramString1;
        this.mTag = paramString2;
      }
      
      public a P(String paramString)
      {
        this.yr = paramString;
        return this;
      }
      
      public a aS(int paramInt)
      {
        this.ys = paramInt;
        return this;
      }
      
      public ch.a cM()
      {
        return new ch.a(0, this.xH, this.mTag, this.yr, this.ys);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ch
 * JD-Core Version:    0.7.0.1
 */