package com.google.android.gms.internal;

public class di
{
  private final dj<Integer> CA = new dj();
  
  public int ae(String paramString)
  {
    return this.CA.ae(paramString);
  }
  
  public int h(String paramString, int paramInt)
  {
    return ((Integer)this.CA.i(paramString, paramInt)).intValue();
  }
  
  public void put(String paramString, int paramInt)
  {
    this.CA.put(paramString, Integer.valueOf(paramInt));
  }
  
  public String toString()
  {
    return this.CA.toString();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.di
 * JD-Core Version:    0.7.0.1
 */