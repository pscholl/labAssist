package com.google.android.gms.internal;

import android.app.PendingIntent;

public abstract class ds
  extends dv.a
{
  public void a(int paramInt, PendingIntent paramPendingIntent) {}
  
  public void a(int paramInt, boolean paramBoolean, String paramString) {}
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ds
 * JD-Core Version:    0.7.0.1
 */