package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;

public final class u
  extends w.a
{
  private final h jT;
  private final l jU;
  
  public u(String paramString, Context paramContext)
  {
    this.jT = k.a(paramString, paramContext);
    this.jU = new l(this.jT);
  }
  
  public b a(b paramb1, b paramb2)
  {
    try
    {
      Uri localUri = (Uri)c.d(paramb1);
      Context localContext = (Context)c.d(paramb2);
      b localb = c.g(this.jU.a(localUri, localContext));
      return localb;
    }
    catch (m localm) {}
    return null;
  }
  
  public boolean a(b paramb)
  {
    Uri localUri = (Uri)c.d(paramb);
    return this.jU.a(localUri);
  }
  
  public boolean b(b paramb)
  {
    Uri localUri = (Uri)c.d(paramb);
    return this.jU.isGoogleAdUrl(localUri);
  }
  
  public String c(b paramb)
  {
    Context localContext = (Context)c.d(paramb);
    return this.jT.a(localContext);
  }
  
  public String getSignalsUrlKey()
  {
    return "ms";
  }
  
  public void setAdSenseDomainAndPath(String paramString1, String paramString2)
  {
    this.jU.setAdSenseDomainAndPath(paramString1, paramString2);
  }
  
  public void setGoogleAdUrlSuffixes(String paramString)
  {
    this.jU.setGoogleAdUrlSuffixes(paramString);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.u
 * JD-Core Version:    0.7.0.1
 */