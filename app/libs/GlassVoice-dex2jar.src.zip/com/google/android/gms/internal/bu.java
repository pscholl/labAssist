package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.location.Location;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProvider;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationServices.a;
import com.google.android.gms.location.LocationStatus;

public class bu
  implements FusedLocationProvider
{
  public Location getLastLocation(GoogleApiClient paramGoogleApiClient)
  {
    bz localbz = LocationServices.getConnectedClientImpl(paramGoogleApiClient);
    try
    {
      Location localLocation = localbz.getLastLocation();
      return localLocation;
    }
    catch (Exception localException) {}
    return null;
  }
  
  public LocationStatus getLastLocationStatus(GoogleApiClient paramGoogleApiClient)
  {
    bz localbz = LocationServices.getConnectedClientImpl(paramGoogleApiClient);
    try
    {
      LocationStatus localLocationStatus = localbz.getLastLocationStatus();
      return localLocationStatus;
    }
    catch (Exception localException) {}
    return null;
  }
  
  public void injectLocation(GoogleApiClient paramGoogleApiClient, final Location paramLocation, final int paramInt)
  {
    paramGoogleApiClient.a(new a(paramLocation)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.injectLocation(paramLocation, paramInt);
        a(Status.rF);
      }
    });
  }
  
  public void removeLocationUpdates(GoogleApiClient paramGoogleApiClient, final PendingIntent paramPendingIntent)
  {
    paramGoogleApiClient.a(new a(paramPendingIntent)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.removeLocationUpdates(paramPendingIntent);
        a(Status.rF);
      }
      
      public int bo()
      {
        return 1;
      }
    });
  }
  
  public void removeLocationUpdates(GoogleApiClient paramGoogleApiClient, final LocationListener paramLocationListener)
  {
    paramGoogleApiClient.a(new a(paramLocationListener)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.removeLocationUpdates(paramLocationListener);
        a(Status.rF);
      }
    });
  }
  
  public void requestLocationUpdates(GoogleApiClient paramGoogleApiClient, final LocationRequest paramLocationRequest, final PendingIntent paramPendingIntent)
  {
    paramGoogleApiClient.a(new a(paramLocationRequest)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.requestLocationUpdates(paramLocationRequest, paramPendingIntent);
        a(Status.rF);
      }
      
      public int bo()
      {
        return 1;
      }
    });
  }
  
  public void requestLocationUpdates(GoogleApiClient paramGoogleApiClient, final LocationRequest paramLocationRequest, final LocationListener paramLocationListener)
  {
    paramGoogleApiClient.a(new a(paramLocationRequest)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.requestLocationUpdates(paramLocationRequest, paramLocationListener);
        a(Status.rF);
      }
    });
  }
  
  public void requestLocationUpdates(GoogleApiClient paramGoogleApiClient, final LocationRequest paramLocationRequest, final LocationListener paramLocationListener, final Looper paramLooper)
  {
    paramGoogleApiClient.a(new a(paramLocationRequest)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.requestLocationUpdates(paramLocationRequest, paramLocationListener, paramLooper);
        a(Status.rF);
      }
    });
  }
  
  public void setMockLocation(GoogleApiClient paramGoogleApiClient, final Location paramLocation)
  {
    paramGoogleApiClient.a(new a(paramLocation)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.setMockLocation(paramLocation);
        a(Status.rF);
      }
    });
  }
  
  public void setMockMode(GoogleApiClient paramGoogleApiClient, final boolean paramBoolean)
  {
    paramGoogleApiClient.a(new a(paramBoolean)
    {
      protected void a(bz paramAnonymousbz)
      {
        paramAnonymousbz.setMockMode(paramBoolean);
        a(Status.rF);
      }
    });
  }
  
  private static abstract class a
    extends LocationServices.a<Status>
  {
    public Status c(Status paramStatus)
    {
      return paramStatus;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bu
 * JD-Core Version:    0.7.0.1
 */