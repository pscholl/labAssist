package com.google.android.gms.internal;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.database.MergeCursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Data;
import java.util.ArrayList;
import java.util.HashMap;

class dp
  extends dn
{
  public static final String[] Dr = { "contact_id" };
  private final String AW;
  
  public dp(Context paramContext, dn.d paramd, boolean paramBoolean, int paramInt, Bundle paramBundle1, Bundle paramBundle2, String paramString)
  {
    super(paramContext, paramd, paramBoolean, paramInt, paramBundle1, paramBundle2, null);
    this.AW = paramString;
  }
  
  private Cursor dT()
  {
    Uri localUri1 = ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI.buildUpon().appendPath(this.AW).appendQueryParameter("limit", Integer.toString(100)).build();
    Cursor localCursor1 = this.mContext.getContentResolver().query(localUri1, Dr, null, null, null);
    Uri localUri2 = ContactsContract.CommonDataKinds.Email.CONTENT_FILTER_URI.buildUpon().appendPath(this.AW).appendQueryParameter("limit", Integer.toString(100)).build();
    Cursor localCursor2 = this.mContext.getContentResolver().query(localUri2, Dr, null, null, null);
    return new MergeCursor(new Cursor[] { new a(localCursor1, 100), new a(localCursor2, 100) });
  }
  
  protected dk a(dn.c paramc1, dn.c paramc2, Cursor paramCursor)
  {
    at.f(paramc1);
    at.f(paramCursor);
    cz localcz1 = new cz();
    cz localcz2 = new cz();
    int i = paramc1.getCount();
    paramCursor.getCount();
    HashMap localHashMap1 = new HashMap();
    this.De.ad("people-map start");
    a(paramc1, localHashMap1);
    this.De.ad("people-map finish");
    di localdi = new di();
    cy localcy = new cy();
    HashMap localHashMap2 = new HashMap();
    b(paramc2, localHashMap2);
    this.De.ad("contact-map start");
    int j = a(paramCursor, localdi, localcy, localHashMap2);
    this.De.ad("contact-map finish");
    if (dd.dz()) {
      dd.g("PeopleAggregator", "#people=" + i + ", #contacts=" + j);
    }
    this.De.ad("merge start");
    ArrayList localArrayList = bg.ck();
    paramc1.bh(-1);
    while (paramc1.moveToNext())
    {
      int i1 = paramc1.getPosition();
      String str2 = paramc1.getString("gaia_id");
      localcz1.be(i1);
      localArrayList.add(str2);
      if ((str2 == null) || (localdi.ae(str2) == 0)) {
        localcz2.dt();
      } else {
        localcz2.a(localdi, str2);
      }
    }
    paramCursor.moveToPosition(0);
    if (paramCursor.isAfterLast())
    {
      this.De.ad("merge finish");
      return new dk(paramc1.Do, paramCursor, this.mContext, localcz1.size(), localcz1, localcz2, localArrayList, localHashMap2, this.CZ, this.Da, this.Db);
    }
    int k = paramCursor.getPosition();
    int m = localcy.bd(k);
    if (m == 0)
    {
      localcz1.dt();
      localcz2.be(k);
      localArrayList.add(null);
    }
    for (;;)
    {
      dl.a(paramCursor);
      break;
      for (int n = 0; n < m; n++)
      {
        String str1 = localcy.a(k, n);
        if (!localHashMap1.containsKey(str1))
        {
          localcz1.dt();
          localcz2.be(k);
          localArrayList.add(str1);
        }
      }
    }
  }
  
  protected Cursor dN()
  {
    Cursor localCursor2;
    if ((Dk) && (Build.VERSION.SDK_INT >= 18))
    {
      Uri.Builder localBuilder = dl.a.CONTENT_FILTER_URI.buildUpon().appendPath(this.AW);
      boolean bool1 = this.CY;
      boolean bool2 = false;
      if (!bool1) {
        bool2 = true;
      }
      Uri localUri = localBuilder.appendQueryParameter("visible_contacts_only", String.valueOf(bool2)).build();
      localCursor2 = this.mContext.getContentResolver().query(localUri, dl.CU, dl.dJ(), null, "display_name COLLATE LOCALIZED,contact_id");
    }
    for (;;)
    {
      if (localCursor2 != null) {
        localCursor2.getCount();
      }
      dg localdg;
      Cursor localCursor1;
      do
      {
        return localCursor2;
        localdg = new dg();
        dl.a(localdg, this.CY, this.mContext);
        dl.a(localdg);
        this.De.ad("lookup start");
        localCursor1 = dT();
        localCursor2 = null;
      } while (localCursor1 == null);
      try
      {
        int i = localCursor1.getCount();
        this.De.ad("lookup finish");
        if (i == 0) {
          return null;
        }
        localdg.ab("contact_id IN (");
        for (String str = ""; localCursor1.moveToNext(); str = ",")
        {
          localdg.aa(str);
          localdg.aa(Long.toString(localCursor1.getLong(0)));
        }
        localdg.aa(")");
        localCursor1.close();
        localCursor2 = this.mContext.getContentResolver().query(ContactsContract.Data.CONTENT_URI, dl.CU, localdg.toString(), null, "display_name COLLATE LOCALIZED,contact_id");
      }
      finally
      {
        localCursor1.close();
      }
    }
  }
  
  private static class a
    extends CursorWrapper
  {
    private int Ds;
    
    public a(Cursor paramCursor, int paramInt)
    {
      super();
      this.Ds = paramInt;
    }
    
    public int getCount()
    {
      return Math.min(super.getCount(), this.Ds);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dp
 * JD-Core Version:    0.7.0.1
 */