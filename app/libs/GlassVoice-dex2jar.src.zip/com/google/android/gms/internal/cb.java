package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class cb
  implements Parcelable.Creator<ca>
{
  static void a(ca paramca, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.a(paramParcel, 1, paramca.getRequestId(), false);
    b.c(paramParcel, 1000, paramca.getVersionCode());
    b.a(paramParcel, 2, paramca.getExpirationTime());
    b.a(paramParcel, 3, paramca.cz());
    b.a(paramParcel, 4, paramca.getLatitude());
    b.a(paramParcel, 5, paramca.getLongitude());
    b.a(paramParcel, 6, paramca.cA());
    b.c(paramParcel, 7, paramca.cB());
    b.c(paramParcel, 8, paramca.getNotificationResponsiveness());
    b.c(paramParcel, 9, paramca.cC());
    b.C(paramParcel, i);
  }
  
  public ca[] aK(int paramInt)
  {
    return new ca[paramInt];
  }
  
  public ca am(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    String str = null;
    int k = 0;
    short s = 0;
    double d1 = 0.0D;
    double d2 = 0.0D;
    float f = 0.0F;
    long l = 0L;
    int m = 0;
    int n = -1;
    while (paramParcel.dataPosition() < i)
    {
      int i1 = a.X(paramParcel);
      switch (a.al(i1))
      {
      default: 
        a.b(paramParcel, i1);
        break;
      case 1: 
        str = a.l(paramParcel, i1);
        break;
      case 1000: 
        j = a.f(paramParcel, i1);
        break;
      case 2: 
        l = a.g(paramParcel, i1);
        break;
      case 3: 
        s = a.e(paramParcel, i1);
        break;
      case 4: 
        d1 = a.j(paramParcel, i1);
        break;
      case 5: 
        d2 = a.j(paramParcel, i1);
        break;
      case 6: 
        f = a.i(paramParcel, i1);
        break;
      case 7: 
        k = a.f(paramParcel, i1);
        break;
      case 8: 
        m = a.f(paramParcel, i1);
        break;
      case 9: 
        n = a.f(paramParcel, i1);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new ca(j, str, k, s, d1, d2, f, l, m, n);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cb
 * JD-Core Version:    0.7.0.1
 */