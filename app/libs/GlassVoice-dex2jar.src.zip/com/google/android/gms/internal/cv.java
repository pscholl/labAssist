package com.google.android.gms.internal;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class cv<T>
  implements Iterable<T>, Iterator<T>
{
  public boolean hasNext()
  {
    return false;
  }
  
  public Iterator<T> iterator()
  {
    return this;
  }
  
  public T next()
  {
    throw new NoSuchElementException();
  }
  
  public void remove()
  {
    throw new UnsupportedOperationException();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cv
 * JD-Core Version:    0.7.0.1
 */