package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface dv
  extends IInterface
{
  public abstract void a(int paramInt, PendingIntent paramPendingIntent)
    throws RemoteException;
  
  public abstract void a(int paramInt, boolean paramBoolean, String paramString)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements dv
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.photos.autobackup.internal.IAutoBackupCallbacks");
    }
    
    public static dv an(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.photos.autobackup.internal.IAutoBackupCallbacks");
      if ((localIInterface != null) && ((localIInterface instanceof dv))) {
        return (dv)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.photos.autobackup.internal.IAutoBackupCallbacks");
        return true;
      case 1: 
        paramParcel1.enforceInterface("com.google.android.gms.photos.autobackup.internal.IAutoBackupCallbacks");
        int j = paramParcel1.readInt();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool = true;; bool = false)
        {
          a(j, bool, paramParcel1.readString());
          paramParcel2.writeNoException();
          return true;
        }
      }
      paramParcel1.enforceInterface("com.google.android.gms.photos.autobackup.internal.IAutoBackupCallbacks");
      int i = paramParcel1.readInt();
      if (paramParcel1.readInt() != 0) {}
      for (PendingIntent localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localPendingIntent = null)
      {
        a(i, localPendingIntent);
        paramParcel2.writeNoException();
        return true;
      }
    }
    
    private static class a
      implements dv
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      /* Error */
      public void a(int paramInt, PendingIntent paramPendingIntent)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: iload_1
        //   17: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   20: aload_2
        //   21: ifnull +44 -> 65
        //   24: aload_3
        //   25: iconst_1
        //   26: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   29: aload_2
        //   30: aload_3
        //   31: iconst_0
        //   32: invokevirtual 41	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
        //   35: aload_0
        //   36: getfield 15	com/google/android/gms/internal/dv$a$a:jR	Landroid/os/IBinder;
        //   39: iconst_2
        //   40: aload_3
        //   41: aload 4
        //   43: iconst_0
        //   44: invokeinterface 47 5 0
        //   49: pop
        //   50: aload 4
        //   52: invokevirtual 50	android/os/Parcel:readException	()V
        //   55: aload 4
        //   57: invokevirtual 53	android/os/Parcel:recycle	()V
        //   60: aload_3
        //   61: invokevirtual 53	android/os/Parcel:recycle	()V
        //   64: return
        //   65: aload_3
        //   66: iconst_0
        //   67: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   70: goto -35 -> 35
        //   73: astore 5
        //   75: aload 4
        //   77: invokevirtual 53	android/os/Parcel:recycle	()V
        //   80: aload_3
        //   81: invokevirtual 53	android/os/Parcel:recycle	()V
        //   84: aload 5
        //   86: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	87	0	this	a
        //   0	87	1	paramInt	int
        //   0	87	2	paramPendingIntent	PendingIntent
        //   3	78	3	localParcel1	Parcel
        //   7	69	4	localParcel2	Parcel
        //   73	12	5	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   9	20	73	finally
        //   24	35	73	finally
        //   35	55	73	finally
        //   65	70	73	finally
      }
      
      /* Error */
      public void a(int paramInt, boolean paramBoolean, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: iconst_1
        //   1: istore 4
        //   3: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   6: astore 5
        //   8: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   11: astore 6
        //   13: aload 5
        //   15: ldc 27
        //   17: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   20: aload 5
        //   22: iload_1
        //   23: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   26: iload_2
        //   27: ifeq +48 -> 75
        //   30: aload 5
        //   32: iload 4
        //   34: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   37: aload 5
        //   39: aload_3
        //   40: invokevirtual 57	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   43: aload_0
        //   44: getfield 15	com/google/android/gms/internal/dv$a$a:jR	Landroid/os/IBinder;
        //   47: iconst_1
        //   48: aload 5
        //   50: aload 6
        //   52: iconst_0
        //   53: invokeinterface 47 5 0
        //   58: pop
        //   59: aload 6
        //   61: invokevirtual 50	android/os/Parcel:readException	()V
        //   64: aload 6
        //   66: invokevirtual 53	android/os/Parcel:recycle	()V
        //   69: aload 5
        //   71: invokevirtual 53	android/os/Parcel:recycle	()V
        //   74: return
        //   75: iconst_0
        //   76: istore 4
        //   78: goto -48 -> 30
        //   81: astore 7
        //   83: aload 6
        //   85: invokevirtual 53	android/os/Parcel:recycle	()V
        //   88: aload 5
        //   90: invokevirtual 53	android/os/Parcel:recycle	()V
        //   93: aload 7
        //   95: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	96	0	this	a
        //   0	96	1	paramInt	int
        //   0	96	2	paramBoolean	boolean
        //   0	96	3	paramString	String
        //   1	76	4	i	int
        //   6	83	5	localParcel1	Parcel
        //   11	73	6	localParcel2	Parcel
        //   81	13	7	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   13	26	81	finally
        //   30	64	81	finally
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dv
 * JD-Core Version:    0.7.0.1
 */