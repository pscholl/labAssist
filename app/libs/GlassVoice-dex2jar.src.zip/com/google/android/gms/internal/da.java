package com.google.android.gms.internal;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.common.data.b;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.model.AccountMetadata;
import com.google.android.gms.people.model.Owner;

public final class da
  extends b
  implements Owner
{
  public da(d paramd, int paramInt)
  {
    super(paramd, paramInt);
  }
  
  private AccountMetadata du()
  {
    Bundle localBundle = (Bundle)this.mDataHolder.getMetadata().getParcelable("account_metadata");
    if (localBundle == null) {
      return null;
    }
    localBundle.setClassLoader(getClass().getClassLoader());
    return (AccountMetadata)localBundle.getParcelable(getAccountName());
  }
  
  @Deprecated
  public String getAccountGaiaId()
  {
    return getAccountId();
  }
  
  public String getAccountId()
  {
    return getString("gaia_id");
  }
  
  public String getAccountName()
  {
    return getString("account_name");
  }
  
  public String getAvatarUrl()
  {
    return db.Bk.V(getString("avatar"));
  }
  
  public int getCoverPhotoHeight()
  {
    return getInteger("cover_photo_height");
  }
  
  public String getCoverPhotoId()
  {
    return getString("cover_photo_id");
  }
  
  public String getCoverPhotoUrl()
  {
    return db.Bk.V(getString("cover_photo_url"));
  }
  
  public int getCoverPhotoWidth()
  {
    return getInteger("cover_photo_width");
  }
  
  public String getDasherDomain()
  {
    return getString("dasher_domain");
  }
  
  public String getDisplayName()
  {
    String str = getString("display_name");
    if (TextUtils.isEmpty(str)) {
      str = getAccountName();
    }
    return str;
  }
  
  public long getLastSuccessfulSyncFinishTimestamp()
  {
    return getLong("last_successful_sync_time");
  }
  
  public long getLastSyncFinishTimestamp()
  {
    return getLong("last_sync_finish_time");
  }
  
  public long getLastSyncStartTimestamp()
  {
    return getLong("last_sync_start_time");
  }
  
  public int getLastSyncStatus()
  {
    return getInteger("last_sync_status");
  }
  
  @Deprecated
  public String getPlusPageGaiaId()
  {
    return getPlusPageId();
  }
  
  public String getPlusPageId()
  {
    return getString("page_gaia_id");
  }
  
  public int isDasherAccount()
  {
    return getInteger("is_dasher");
  }
  
  public boolean isPeriodicSyncEnabled()
  {
    AccountMetadata localAccountMetadata = du();
    if (localAccountMetadata == null) {
      return false;
    }
    if (isPlusPage()) {
      return localAccountMetadata.isPagePeriodicSyncEnabled;
    }
    return localAccountMetadata.isSyncEnabled;
  }
  
  public boolean isPlusEnabled()
  {
    if (isPlusPage()) {
      return true;
    }
    AccountMetadata localAccountMetadata = du();
    if (localAccountMetadata == null) {
      return false;
    }
    return localAccountMetadata.isPlusEnabled;
  }
  
  public boolean isPlusPage()
  {
    return getPlusPageId() != null;
  }
  
  public boolean isSyncCirclesToContactsEnabled()
  {
    return getBoolean("sync_circles_to_contacts");
  }
  
  public boolean isSyncEnabled()
  {
    AccountMetadata localAccountMetadata = du();
    if (localAccountMetadata == null) {
      return false;
    }
    if (isPlusPage()) {
      return localAccountMetadata.isPageTickleSyncEnabled;
    }
    return localAccountMetadata.isSyncEnabled;
  }
  
  public boolean isSyncEvergreenToContactsEnabled()
  {
    return getBoolean("sync_evergreen_to_contacts");
  }
  
  public boolean isSyncToContactsEnabled()
  {
    return getBoolean("sync_to_contacts");
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.da
 * JD-Core Version:    0.7.0.1
 */