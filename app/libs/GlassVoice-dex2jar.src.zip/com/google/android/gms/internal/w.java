package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.b.a;

public abstract interface w
  extends IInterface
{
  public abstract b a(b paramb1, b paramb2)
    throws RemoteException;
  
  public abstract boolean a(b paramb)
    throws RemoteException;
  
  public abstract boolean b(b paramb)
    throws RemoteException;
  
  public abstract String c(b paramb)
    throws RemoteException;
  
  public abstract String getSignalsUrlKey()
    throws RemoteException;
  
  public abstract void setAdSenseDomainAndPath(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void setGoogleAdUrlSuffixes(String paramString)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements w
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.ads.adshield.internal.IAdShieldClient");
    }
    
    public static w e(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
      if ((localIInterface != null) && ((localIInterface instanceof w))) {
        return (w)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        return true;
      case 1: 
        paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        String str2 = getSignalsUrlKey();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str2);
        return true;
      case 2: 
        paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        setAdSenseDomainAndPath(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 3: 
        paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        boolean bool2 = a(b.a.x(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        int j = 0;
        if (bool2) {
          j = 1;
        }
        paramParcel2.writeInt(j);
        return true;
      case 4: 
        paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        boolean bool1 = b(b.a.x(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        int i = 0;
        if (bool1) {
          i = 1;
        }
        paramParcel2.writeInt(i);
        return true;
      case 5: 
        paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        setGoogleAdUrlSuffixes(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 6: 
        paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
        b localb = a(b.a.x(paramParcel1.readStrongBinder()), b.a.x(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        if (localb != null) {}
        for (IBinder localIBinder = localb.asBinder();; localIBinder = null)
        {
          paramParcel2.writeStrongBinder(localIBinder);
          return true;
        }
      }
      paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
      String str1 = c(b.a.x(paramParcel1.readStrongBinder()));
      paramParcel2.writeNoException();
      paramParcel2.writeString(str1);
      return true;
    }
    
    private static class a
      implements w
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      /* Error */
      public b a(b paramb1, b paramb2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +81 -> 97
        //   19: aload_1
        //   20: invokeinterface 37 1 0
        //   25: astore 6
        //   27: aload_3
        //   28: aload 6
        //   30: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   33: aconst_null
        //   34: astore 7
        //   36: aload_2
        //   37: ifnull +11 -> 48
        //   40: aload_2
        //   41: invokeinterface 37 1 0
        //   46: astore 7
        //   48: aload_3
        //   49: aload 7
        //   51: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   54: aload_0
        //   55: getfield 15	com/google/android/gms/internal/w$a$a:jR	Landroid/os/IBinder;
        //   58: bipush 6
        //   60: aload_3
        //   61: aload 4
        //   63: iconst_0
        //   64: invokeinterface 46 5 0
        //   69: pop
        //   70: aload 4
        //   72: invokevirtual 49	android/os/Parcel:readException	()V
        //   75: aload 4
        //   77: invokevirtual 52	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
        //   80: invokestatic 58	com/google/android/gms/dynamic/b$a:x	(Landroid/os/IBinder;)Lcom/google/android/gms/dynamic/b;
        //   83: astore 9
        //   85: aload 4
        //   87: invokevirtual 61	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 61	android/os/Parcel:recycle	()V
        //   94: aload 9
        //   96: areturn
        //   97: aconst_null
        //   98: astore 6
        //   100: goto -73 -> 27
        //   103: astore 5
        //   105: aload 4
        //   107: invokevirtual 61	android/os/Parcel:recycle	()V
        //   110: aload_3
        //   111: invokevirtual 61	android/os/Parcel:recycle	()V
        //   114: aload 5
        //   116: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	117	0	this	a
        //   0	117	1	paramb1	b
        //   0	117	2	paramb2	b
        //   3	108	3	localParcel1	Parcel
        //   7	99	4	localParcel2	Parcel
        //   103	12	5	localObject	Object
        //   25	74	6	localIBinder1	IBinder
        //   34	16	7	localIBinder2	IBinder
        //   83	12	9	localb	b
        // Exception table:
        //   from	to	target	type
        //   9	15	103	finally
        //   19	27	103	finally
        //   27	33	103	finally
        //   40	48	103	finally
        //   48	85	103	finally
      }
      
      /* Error */
      public boolean a(b paramb)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +63 -> 78
        //   18: aload_1
        //   19: invokeinterface 37 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	com/google/android/gms/internal/w$a$a:jR	Landroid/os/IBinder;
        //   36: iconst_3
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 46 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 49	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 66	android/os/Parcel:readInt	()I
        //   54: istore 7
        //   56: iconst_0
        //   57: istore 8
        //   59: iload 7
        //   61: ifeq +6 -> 67
        //   64: iconst_1
        //   65: istore 8
        //   67: aload_3
        //   68: invokevirtual 61	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 61	android/os/Parcel:recycle	()V
        //   75: iload 8
        //   77: ireturn
        //   78: aconst_null
        //   79: astore 5
        //   81: goto -55 -> 26
        //   84: astore 4
        //   86: aload_3
        //   87: invokevirtual 61	android/os/Parcel:recycle	()V
        //   90: aload_2
        //   91: invokevirtual 61	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	a
        //   0	97	1	paramb	b
        //   3	88	2	localParcel1	Parcel
        //   7	80	3	localParcel2	Parcel
        //   84	11	4	localObject	Object
        //   24	56	5	localIBinder	IBinder
        //   54	6	7	i	int
        //   57	19	8	bool	boolean
        // Exception table:
        //   from	to	target	type
        //   8	14	84	finally
        //   18	26	84	finally
        //   26	56	84	finally
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      /* Error */
      public boolean b(b paramb)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +63 -> 78
        //   18: aload_1
        //   19: invokeinterface 37 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	com/google/android/gms/internal/w$a$a:jR	Landroid/os/IBinder;
        //   36: iconst_4
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 46 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 49	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 66	android/os/Parcel:readInt	()I
        //   54: istore 7
        //   56: iconst_0
        //   57: istore 8
        //   59: iload 7
        //   61: ifeq +6 -> 67
        //   64: iconst_1
        //   65: istore 8
        //   67: aload_3
        //   68: invokevirtual 61	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 61	android/os/Parcel:recycle	()V
        //   75: iload 8
        //   77: ireturn
        //   78: aconst_null
        //   79: astore 5
        //   81: goto -55 -> 26
        //   84: astore 4
        //   86: aload_3
        //   87: invokevirtual 61	android/os/Parcel:recycle	()V
        //   90: aload_2
        //   91: invokevirtual 61	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	a
        //   0	97	1	paramb	b
        //   3	88	2	localParcel1	Parcel
        //   7	80	3	localParcel2	Parcel
        //   84	11	4	localObject	Object
        //   24	56	5	localIBinder	IBinder
        //   54	6	7	i	int
        //   57	19	8	bool	boolean
        // Exception table:
        //   from	to	target	type
        //   8	14	84	finally
        //   18	26	84	finally
        //   26	56	84	finally
      }
      
      /* Error */
      public String c(b paramb)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +53 -> 68
        //   18: aload_1
        //   19: invokeinterface 37 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	com/google/android/gms/internal/w$a$a:jR	Landroid/os/IBinder;
        //   36: bipush 7
        //   38: aload_2
        //   39: aload_3
        //   40: iconst_0
        //   41: invokeinterface 46 5 0
        //   46: pop
        //   47: aload_3
        //   48: invokevirtual 49	android/os/Parcel:readException	()V
        //   51: aload_3
        //   52: invokevirtual 73	android/os/Parcel:readString	()Ljava/lang/String;
        //   55: astore 7
        //   57: aload_3
        //   58: invokevirtual 61	android/os/Parcel:recycle	()V
        //   61: aload_2
        //   62: invokevirtual 61	android/os/Parcel:recycle	()V
        //   65: aload 7
        //   67: areturn
        //   68: aconst_null
        //   69: astore 5
        //   71: goto -45 -> 26
        //   74: astore 4
        //   76: aload_3
        //   77: invokevirtual 61	android/os/Parcel:recycle	()V
        //   80: aload_2
        //   81: invokevirtual 61	android/os/Parcel:recycle	()V
        //   84: aload 4
        //   86: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	87	0	this	a
        //   0	87	1	paramb	b
        //   3	78	2	localParcel1	Parcel
        //   7	70	3	localParcel2	Parcel
        //   74	11	4	localObject	Object
        //   24	46	5	localIBinder	IBinder
        //   55	11	7	str	String
        // Exception table:
        //   from	to	target	type
        //   8	14	74	finally
        //   18	26	74	finally
        //   26	57	74	finally
      }
      
      public String getSignalsUrlKey()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
          this.jR.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setAdSenseDomainAndPath(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.jR.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setGoogleAdUrlSuffixes(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.adshield.internal.IAdShieldClient");
          localParcel1.writeString(paramString);
          this.jR.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.w
 * JD-Core Version:    0.7.0.1
 */