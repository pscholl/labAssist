package com.google.android.gms.internal;

import java.io.IOException;
import java.util.List;

public abstract interface d
{
  public static final class a
    extends eb<a>
  {
    private static volatile a[] fq;
    public int[] fA;
    public boolean fB;
    public String fr;
    public a[] fs;
    public a[] ft;
    public a[] fu;
    public String fv;
    public String fw;
    public long fx;
    public boolean fy;
    public a[] fz;
    public int type;
    
    public a()
    {
      q();
    }
    
    public static a[] p()
    {
      if (fq == null) {}
      synchronized (ed.Jg)
      {
        if (fq == null) {
          fq = new a[0];
        }
        return fq;
      }
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      a locala;
      label69:
      do
      {
        String str2;
        do
        {
          boolean bool5;
          do
          {
            boolean bool4;
            do
            {
              boolean bool3;
              do
              {
                String str3;
                do
                {
                  int i;
                  int j;
                  do
                  {
                    boolean bool1;
                    do
                    {
                      return bool2;
                      bool1 = paramObject instanceof a;
                      bool2 = false;
                    } while (!bool1);
                    locala = (a)paramObject;
                    i = this.type;
                    j = locala.type;
                    bool2 = false;
                  } while (i != j);
                  if (this.fr != null) {
                    break;
                  }
                  str3 = locala.fr;
                  bool2 = false;
                } while (str3 != null);
                bool3 = ed.equals(this.fs, locala.fs);
                bool2 = false;
              } while (!bool3);
              bool4 = ed.equals(this.ft, locala.ft);
              bool2 = false;
            } while (!bool4);
            bool5 = ed.equals(this.fu, locala.fu);
            bool2 = false;
          } while (!bool5);
          if (this.fv != null) {
            break label344;
          }
          str2 = locala.fv;
          bool2 = false;
        } while (str2 != null);
        if (this.fw != null) {
          break label361;
        }
        str1 = locala.fw;
        bool2 = false;
      } while (str1 != null);
      label153:
      label344:
      label361:
      while (this.fw.equals(locala.fw))
      {
        String str1;
        boolean bool6 = this.fx < locala.fx;
        bool2 = false;
        if (bool6) {
          break;
        }
        boolean bool7 = this.fy;
        boolean bool8 = locala.fy;
        bool2 = false;
        if (bool7 != bool8) {
          break;
        }
        boolean bool9 = ed.equals(this.fz, locala.fz);
        bool2 = false;
        if (!bool9) {
          break;
        }
        boolean bool10 = ed.equals(this.fA, locala.fA);
        bool2 = false;
        if (!bool10) {
          break;
        }
        boolean bool11 = this.fB;
        boolean bool12 = locala.fB;
        bool2 = false;
        if (bool11 != bool12) {
          break;
        }
        if ((this.Jd != null) && (!this.Jd.isEmpty())) {
          break label378;
        }
        if (locala.Jd != null)
        {
          boolean bool13 = locala.Jd.isEmpty();
          bool2 = false;
          if (!bool13) {
            break;
          }
        }
        return true;
        if (this.fr.equals(locala.fr)) {
          break label69;
        }
        return false;
        if (this.fv.equals(locala.fv)) {
          break label153;
        }
        return false;
      }
      return false;
      label378:
      return this.Jd.equals(locala.Jd);
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize() + ea.e(1, this.type);
      if (!this.fr.equals("")) {
        i += ea.c(2, this.fr);
      }
      if ((this.fs != null) && (this.fs.length > 0))
      {
        int i5 = i;
        for (int i6 = 0; i6 < this.fs.length; i6++)
        {
          a locala4 = this.fs[i6];
          if (locala4 != null) {
            i5 += ea.b(3, locala4);
          }
        }
        i = i5;
      }
      if ((this.ft != null) && (this.ft.length > 0))
      {
        int i3 = i;
        for (int i4 = 0; i4 < this.ft.length; i4++)
        {
          a locala3 = this.ft[i4];
          if (locala3 != null) {
            i3 += ea.b(4, locala3);
          }
        }
        i = i3;
      }
      if ((this.fu != null) && (this.fu.length > 0))
      {
        int i1 = i;
        for (int i2 = 0; i2 < this.fu.length; i2++)
        {
          a locala2 = this.fu[i2];
          if (locala2 != null) {
            i1 += ea.b(5, locala2);
          }
        }
        i = i1;
      }
      if (!this.fv.equals("")) {
        i += ea.c(6, this.fv);
      }
      if (!this.fw.equals("")) {
        i += ea.c(7, this.fw);
      }
      if (this.fx != 0L) {
        i += ea.c(8, this.fx);
      }
      if (this.fB) {
        i += ea.b(9, this.fB);
      }
      if ((this.fA != null) && (this.fA.length > 0))
      {
        int m = 0;
        int n = 0;
        while (m < this.fA.length)
        {
          n += ea.bE(this.fA[m]);
          m++;
        }
        i = i + n + 1 * this.fA.length;
      }
      if (this.fz != null)
      {
        int j = this.fz.length;
        int k = 0;
        if (j > 0) {
          while (k < this.fz.length)
          {
            a locala1 = this.fz[k];
            if (locala1 != null) {
              i += ea.b(11, locala1);
            }
            k++;
          }
        }
      }
      if (this.fy) {
        i += ea.b(12, this.fy);
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i = 1231;
      int j = 31 * (527 + this.type);
      int k;
      int n;
      label76:
      int i2;
      label96:
      int i4;
      label133:
      label172:
      int i6;
      int i7;
      if (this.fr == null)
      {
        k = 0;
        int m = 31 * (31 * (31 * (31 * (k + j) + ed.hashCode(this.fs)) + ed.hashCode(this.ft)) + ed.hashCode(this.fu));
        if (this.fv != null) {
          break label231;
        }
        n = 0;
        int i1 = 31 * (n + m);
        if (this.fw != null) {
          break label243;
        }
        i2 = 0;
        int i3 = 31 * (31 * (i2 + i1) + (int)(this.fx ^ this.fx >>> 32));
        if (!this.fy) {
          break label255;
        }
        i4 = i;
        int i5 = 31 * (31 * (31 * (i4 + i3) + ed.hashCode(this.fz)) + ed.hashCode(this.fA));
        if (!this.fB) {
          break label263;
        }
        i6 = 31 * (i5 + i);
        List localList = this.Jd;
        i7 = 0;
        if (localList != null)
        {
          boolean bool = this.Jd.isEmpty();
          i7 = 0;
          if (!bool) {
            break label270;
          }
        }
      }
      for (;;)
      {
        return i6 + i7;
        k = this.fr.hashCode();
        break;
        label231:
        n = this.fv.hashCode();
        break label76;
        label243:
        i2 = this.fw.hashCode();
        break label96;
        label255:
        i4 = 1237;
        break label133;
        label263:
        i = 1237;
        break label172;
        label270:
        i7 = this.Jd.hashCode();
      }
    }
    
    public a k(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          int i17 = paramdz.gd();
          switch (i17)
          {
          default: 
            break;
          }
          this.type = i17;
          break;
        case 18: 
          this.fr = paramdz.readString();
          break;
        case 26: 
          int i15 = ei.b(paramdz, 26);
          if (this.fs == null) {}
          a[] arrayOfa4;
          for (int i16 = 0;; i16 = this.fs.length)
          {
            arrayOfa4 = new a[i15 + i16];
            if (i16 != 0) {
              System.arraycopy(this.fs, 0, arrayOfa4, 0, i16);
            }
            while (i16 < -1 + arrayOfa4.length)
            {
              arrayOfa4[i16] = new a();
              paramdz.a(arrayOfa4[i16]);
              paramdz.ga();
              i16++;
            }
          }
          arrayOfa4[i16] = new a();
          paramdz.a(arrayOfa4[i16]);
          this.fs = arrayOfa4;
          break;
        case 34: 
          int i13 = ei.b(paramdz, 34);
          if (this.ft == null) {}
          a[] arrayOfa3;
          for (int i14 = 0;; i14 = this.ft.length)
          {
            arrayOfa3 = new a[i13 + i14];
            if (i14 != 0) {
              System.arraycopy(this.ft, 0, arrayOfa3, 0, i14);
            }
            while (i14 < -1 + arrayOfa3.length)
            {
              arrayOfa3[i14] = new a();
              paramdz.a(arrayOfa3[i14]);
              paramdz.ga();
              i14++;
            }
          }
          arrayOfa3[i14] = new a();
          paramdz.a(arrayOfa3[i14]);
          this.ft = arrayOfa3;
          break;
        case 42: 
          int i11 = ei.b(paramdz, 42);
          if (this.fu == null) {}
          a[] arrayOfa2;
          for (int i12 = 0;; i12 = this.fu.length)
          {
            arrayOfa2 = new a[i11 + i12];
            if (i12 != 0) {
              System.arraycopy(this.fu, 0, arrayOfa2, 0, i12);
            }
            while (i12 < -1 + arrayOfa2.length)
            {
              arrayOfa2[i12] = new a();
              paramdz.a(arrayOfa2[i12]);
              paramdz.ga();
              i12++;
            }
          }
          arrayOfa2[i12] = new a();
          paramdz.a(arrayOfa2[i12]);
          this.fu = arrayOfa2;
          break;
        case 50: 
          this.fv = paramdz.readString();
          break;
        case 58: 
          this.fw = paramdz.readString();
          break;
        case 64: 
          this.fx = paramdz.gc();
          break;
        case 72: 
          this.fB = paramdz.ge();
          break;
        case 80: 
          int i5 = ei.b(paramdz, 80);
          int[] arrayOfInt2 = new int[i5];
          int i6 = 0;
          int i7 = 0;
          if (i6 < i5)
          {
            if (i6 != 0) {
              paramdz.ga();
            }
            int i9 = paramdz.gd();
            int i10;
            switch (i9)
            {
            default: 
              i10 = i7;
            }
            for (;;)
            {
              i6++;
              i7 = i10;
              break;
              i10 = i7 + 1;
              arrayOfInt2[i7] = i9;
            }
          }
          if (i7 == 0) {
            continue;
          }
          if (this.fA == null) {}
          for (int i8 = 0;; i8 = this.fA.length)
          {
            if ((i8 != 0) || (i7 != arrayOfInt2.length)) {
              break label849;
            }
            this.fA = arrayOfInt2;
            break;
          }
          int[] arrayOfInt3 = new int[i8 + i7];
          if (i8 != 0) {
            System.arraycopy(this.fA, 0, arrayOfInt3, 0, i8);
          }
          System.arraycopy(arrayOfInt2, 0, arrayOfInt3, i8, i7);
          this.fA = arrayOfInt3;
          break;
        case 82: 
          int m = paramdz.by(paramdz.gf());
          int n = paramdz.getPosition();
          int i1 = 0;
          while (paramdz.gk() > 0) {
            switch (paramdz.gd())
            {
            default: 
              break;
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 14: 
            case 15: 
            case 16: 
            case 17: 
              i1++;
            }
          }
          if (i1 != 0)
          {
            paramdz.bA(n);
            if (this.fA == null) {}
            int[] arrayOfInt1;
            for (int i2 = 0;; i2 = this.fA.length)
            {
              arrayOfInt1 = new int[i1 + i2];
              if (i2 != 0) {
                System.arraycopy(this.fA, 0, arrayOfInt1, 0, i2);
              }
              while (paramdz.gk() > 0)
              {
                int i3 = paramdz.gd();
                switch (i3)
                {
                default: 
                  break;
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 6: 
                case 7: 
                case 8: 
                case 9: 
                case 10: 
                case 11: 
                case 12: 
                case 13: 
                case 14: 
                case 15: 
                case 16: 
                case 17: 
                  int i4 = i2 + 1;
                  arrayOfInt1[i2] = i3;
                  i2 = i4;
                }
              }
            }
            this.fA = arrayOfInt1;
          }
          paramdz.bz(m);
          break;
        case 90: 
          label849:
          int j = ei.b(paramdz, 90);
          if (this.fz == null) {}
          a[] arrayOfa1;
          for (int k = 0;; k = this.fz.length)
          {
            arrayOfa1 = new a[j + k];
            if (k != 0) {
              System.arraycopy(this.fz, 0, arrayOfa1, 0, k);
            }
            while (k < -1 + arrayOfa1.length)
            {
              arrayOfa1[k] = new a();
              paramdz.a(arrayOfa1[k]);
              paramdz.ga();
              k++;
            }
          }
          arrayOfa1[k] = new a();
          paramdz.a(arrayOfa1[k]);
          this.fz = arrayOfa1;
          break;
        }
        this.fy = paramdz.ge();
      }
    }
    
    public a q()
    {
      this.type = 1;
      this.fr = "";
      this.fs = p();
      this.ft = p();
      this.fu = p();
      this.fv = "";
      this.fw = "";
      this.fx = 0L;
      this.fy = false;
      this.fz = p();
      this.fA = ei.Jj;
      this.fB = false;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      paramea.d(1, this.type);
      if (!this.fr.equals("")) {
        paramea.b(2, this.fr);
      }
      if ((this.fs != null) && (this.fs.length > 0)) {
        for (int i1 = 0; i1 < this.fs.length; i1++)
        {
          a locala4 = this.fs[i1];
          if (locala4 != null) {
            paramea.a(3, locala4);
          }
        }
      }
      if ((this.ft != null) && (this.ft.length > 0)) {
        for (int n = 0; n < this.ft.length; n++)
        {
          a locala3 = this.ft[n];
          if (locala3 != null) {
            paramea.a(4, locala3);
          }
        }
      }
      if ((this.fu != null) && (this.fu.length > 0)) {
        for (int m = 0; m < this.fu.length; m++)
        {
          a locala2 = this.fu[m];
          if (locala2 != null) {
            paramea.a(5, locala2);
          }
        }
      }
      if (!this.fv.equals("")) {
        paramea.b(6, this.fv);
      }
      if (!this.fw.equals("")) {
        paramea.b(7, this.fw);
      }
      if (this.fx != 0L) {
        paramea.b(8, this.fx);
      }
      if (this.fB) {
        paramea.a(9, this.fB);
      }
      if ((this.fA != null) && (this.fA.length > 0)) {
        for (int k = 0; k < this.fA.length; k++) {
          paramea.d(10, this.fA[k]);
        }
      }
      if (this.fz != null)
      {
        int i = this.fz.length;
        int j = 0;
        if (i > 0) {
          while (j < this.fz.length)
          {
            a locala1 = this.fz[j];
            if (locala1 != null) {
              paramea.a(11, locala1);
            }
            j++;
          }
        }
      }
      if (this.fy) {
        paramea.a(12, this.fy);
      }
      super.writeTo(paramea);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.d
 * JD-Core Version:    0.7.0.1
 */