package com.google.android.gms.internal;

import android.content.Intent;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceEstimate;
import java.util.Arrays;

@Deprecated
public final class cf
  extends PlaceEstimate
  implements SafeParcelable
{
  public static final cg CREATOR = new cg();
  final int oj;
  private final ch[] xY;
  private final float[] xZ;
  private final long ya;
  
  cf(int paramInt, ch[] paramArrayOfch, float[] paramArrayOfFloat, long paramLong)
  {
    if (paramArrayOfch.length == paramArrayOfFloat.length) {}
    for (boolean bool = true;; bool = false)
    {
      at.b(bool, "mismatched places to probabilities arrays");
      this.oj = paramInt;
      this.xY = paramArrayOfch;
      this.xZ = paramArrayOfFloat;
      this.ya = paramLong;
      return;
    }
  }
  
  public static cf d(Intent paramIntent)
  {
    return l(paramIntent.getByteArrayExtra("com.google.android.gms.location.internal.intent.PlaceEstimateImpl"));
  }
  
  public static cf l(byte[] paramArrayOfByte)
  {
    Parcel localParcel = Parcel.obtain();
    localParcel.unmarshall(paramArrayOfByte, 0, paramArrayOfByte.length);
    localParcel.setDataPosition(0);
    cf localcf = CREATOR.at(localParcel);
    localParcel.recycle();
    return localcf;
  }
  
  public ch[] cE()
  {
    return this.xY;
  }
  
  public float[] cF()
  {
    return this.xZ;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    cf localcf;
    do
    {
      return true;
      if (!(paramObject instanceof cf)) {
        return false;
      }
      localcf = (cf)paramObject;
    } while ((Arrays.equals(this.xY, localcf.xY)) && (Arrays.equals(this.xZ, localcf.xZ)));
    return false;
  }
  
  public Place getPlace(int paramInt)
  {
    return this.xY[paramInt];
  }
  
  public int getPlaceCount()
  {
    return this.xY.length;
  }
  
  public float getProbability(int paramInt)
  {
    return this.xZ[paramInt];
  }
  
  public long getTimestampMillis()
  {
    return this.ya;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = this.xY;
    arrayOfObject[1] = this.xZ;
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("PlaceEstimate{");
    for (int i = 0; i < this.xY.length; i++)
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Float.valueOf(this.xZ[i]);
      arrayOfObject[1] = this.xY[i].toString();
      localStringBuilder.append(String.format("(%f, %s)", arrayOfObject));
      if (i != -1 + this.xY.length) {
        localStringBuilder.append(",");
      }
    }
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    cg.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cf
 * JD-Core Version:    0.7.0.1
 */