package com.google.android.gms.internal;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.people.model.EmailAddress;
import com.google.android.gms.people.model.PhoneNumber;
import java.util.ArrayList;

public abstract class dq<T>
{
  private final char Dt;
  private final char Du;
  private final Bundle Dv;
  
  dq(Bundle paramBundle, char paramChar1, char paramChar2)
  {
    this.Dv = paramBundle;
    this.Dt = paramChar1;
    this.Du = paramChar2;
  }
  
  private static int a(String paramString, char paramChar, int paramInt1, int paramInt2)
  {
    int i = paramString.indexOf(paramChar, paramInt1);
    if ((i >= 0) && (i < paramInt2)) {
      return i;
    }
    return -1;
  }
  
  private void a(ArrayList<T> paramArrayList, String paramString1, String paramString2, String paramString3)
  {
    if (TextUtils.isEmpty(paramString3)) {
      return;
    }
    String str = this.Dv.getString(paramString1);
    if (TextUtils.isEmpty(str)) {}
    for (;;)
    {
      paramArrayList.add(m(paramString3, paramString2));
      return;
      paramString2 = str;
    }
  }
  
  public final ArrayList<T> ai(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    if (TextUtils.isEmpty(paramString)) {
      return localArrayList;
    }
    int i = paramString.length();
    int j = 0;
    if (j < i)
    {
      int k = paramString.indexOf(this.Du, j);
      if (k >= 0) {}
      for (;;)
      {
        int m = a(paramString, this.Dt, j, k);
        int n = a(paramString, this.Dt, m + 1, k);
        if ((m >= 0) && (n >= 0)) {
          a(localArrayList, paramString.substring(j, m), paramString.substring(m + 1, n), paramString.substring(n + 1, k));
        }
        j = k + 1;
        break;
        k = paramString.length();
      }
    }
    return localArrayList;
  }
  
  protected abstract T m(String paramString1, String paramString2);
  
  public static class a
    extends dq<EmailAddress>
  {
    public a(Bundle paramBundle)
    {
      super('\001', '\002');
    }
    
    protected EmailAddress n(String paramString1, String paramString2)
    {
      return new dm(paramString2, paramString1);
    }
  }
  
  public static class b
    extends dq<PhoneNumber>
  {
    public b(Bundle paramBundle)
    {
      super('\001', '\002');
    }
    
    protected PhoneNumber o(String paramString1, String paramString2)
    {
      return new dr(paramString2, paramString1);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dq
 * JD-Core Version:    0.7.0.1
 */