package com.google.android.gms.internal;

import java.io.IOException;

public abstract class ef
{
  protected int Jh = -1;
  
  public static final <T extends ef> T mergeFrom(T paramT, byte[] paramArrayOfByte)
    throws ee
  {
    return mergeFrom(paramT, paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static final <T extends ef> T mergeFrom(T paramT, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws ee
  {
    try
    {
      dz localdz = dz.a(paramArrayOfByte, paramInt1, paramInt2);
      paramT.mergeFrom(localdz);
      localdz.bw(0);
      return paramT;
    }
    catch (ee localee)
    {
      throw localee;
    }
    catch (IOException localIOException)
    {
      throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).");
    }
  }
  
  public static final void toByteArray(ef paramef, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    try
    {
      ea localea = ea.b(paramArrayOfByte, paramInt1, paramInt2);
      paramef.writeTo(localea);
      localea.go();
      return;
    }
    catch (IOException localIOException)
    {
      throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", localIOException);
    }
  }
  
  public static final byte[] toByteArray(ef paramef)
  {
    byte[] arrayOfByte = new byte[paramef.getSerializedSize()];
    toByteArray(paramef, arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public int getCachedSize()
  {
    if (this.Jh < 0) {
      getSerializedSize();
    }
    return this.Jh;
  }
  
  public int getSerializedSize()
  {
    this.Jh = 0;
    return 0;
  }
  
  public abstract ef mergeFrom(dz paramdz)
    throws IOException;
  
  public String toString()
  {
    return eg.f(this);
  }
  
  public void writeTo(ea paramea)
    throws IOException
  {}
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ef
 * JD-Core Version:    0.7.0.1
 */