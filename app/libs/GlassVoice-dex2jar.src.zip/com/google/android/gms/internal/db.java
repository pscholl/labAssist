package com.google.android.gms.internal;

import android.os.Bundle;
import android.text.TextUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class db
{
  public static final db Bk = new db();
  private Pattern[] Bl = new Pattern[0];
  private String[] Bm = new String[0];
  
  public String V(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      paramString = null;
    }
    for (;;)
    {
      return paramString;
      for (int i = 0; i < this.Bl.length; i++) {
        paramString = this.Bl[i].matcher(paramString).replaceAll(this.Bm[i]);
      }
    }
  }
  
  public void a(String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    int i = 0;
    if (paramArrayOfString1.length == paramArrayOfString2.length) {}
    for (boolean bool = true;; bool = false)
    {
      at.h(bool);
      this.Bl = new Pattern[paramArrayOfString1.length];
      this.Bm = paramArrayOfString2;
      while (i < paramArrayOfString1.length)
      {
        this.Bl[i] = Pattern.compile(paramArrayOfString1[i]);
        i++;
      }
    }
  }
  
  public void c(Bundle paramBundle)
  {
    a(paramBundle.getStringArray("config.url_uncompress.patterns"), paramBundle.getStringArray("config.url_uncompress.replacements"));
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.db
 * JD-Core Version:    0.7.0.1
 */