package com.google.android.gms.internal;

import android.os.ParcelFileDescriptor;
import java.io.Closeable;
import java.io.IOException;

public final class bk
{
  public static final void a(ParcelFileDescriptor paramParcelFileDescriptor)
  {
    if (paramParcelFileDescriptor != null) {}
    try
    {
      paramParcelFileDescriptor.close();
      return;
    }
    catch (IOException localIOException) {}
  }
  
  public static final void a(Closeable paramCloseable)
  {
    if (paramCloseable != null) {}
    try
    {
      paramCloseable.close();
      return;
    }
    catch (IOException localIOException) {}
  }
  
  public static final boolean g(byte[] paramArrayOfByte)
  {
    return (paramArrayOfByte.length > 1) && ((0xFF & paramArrayOfByte[0] | (0xFF & paramArrayOfByte[1]) << 8) == 35615);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bk
 * JD-Core Version:    0.7.0.1
 */