package com.google.android.gms.internal;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.text.TextUtils;
import com.google.android.gms.common.data.d;
import com.google.android.gms.people.model.AggregatedPerson;
import com.google.android.gms.people.model.AggregatedPersonBuffer;
import com.google.android.gms.people.model.EmailAddress;
import com.google.android.gms.people.model.PhoneNumber;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

class dk
  extends AggregatedPersonBuffer
{
  private dq.b Bf;
  private final int CB;
  private d CC;
  private Cursor CD;
  private cz CE;
  private cz CF;
  private ArrayList<String> CG;
  private HashMap<String, String> CH;
  private b CI;
  private b CJ;
  private final boolean CK;
  private volatile boolean mClosed;
  private Context mContext;
  
  public dk(d paramd, Cursor paramCursor, Context paramContext, int paramInt1, cz paramcz1, cz paramcz2, ArrayList<String> paramArrayList, HashMap<String, String> paramHashMap, int paramInt2, Bundle paramBundle1, Bundle paramBundle2)
  {
    super(paramd);
    at.f(paramd);
    at.f(paramCursor);
    at.f(paramHashMap);
    boolean bool2;
    boolean bool3;
    label57:
    boolean bool4;
    if (paramInt1 == paramcz1.size())
    {
      bool2 = bool1;
      at.h(bool2);
      if (paramInt1 != paramcz2.size()) {
        break label211;
      }
      bool3 = bool1;
      at.h(bool3);
      if (paramInt1 != paramArrayList.size()) {
        break label217;
      }
      bool4 = bool1;
      label76:
      at.h(bool4);
      this.CC = paramd;
      this.CD = paramCursor;
      this.CB = paramInt1;
      this.CG = paramArrayList;
      this.mContext = paramContext;
      this.CH = paramHashMap;
      this.CI = new b(this.mContext.getResources())
      {
        protected String a(Resources paramAnonymousResources, int paramAnonymousInt)
        {
          return (String)ContactsContract.CommonDataKinds.Email.getTypeLabel(paramAnonymousResources, paramAnonymousInt, null);
        }
      };
      this.CJ = new b(this.mContext.getResources())
      {
        protected String a(Resources paramAnonymousResources, int paramAnonymousInt)
        {
          return (String)ContactsContract.CommonDataKinds.Phone.getTypeLabel(paramAnonymousResources, paramAnonymousInt, null);
        }
      };
      this.CE = paramcz1;
      this.CF = paramcz2;
      if ((paramInt2 & 0x1) != 0) {
        dd.j("PeopleAggregator", "PeopleExtraColumnBitmask.EMAILS is not supported in aggregation.  Ignored.");
      }
      if ((paramInt2 & 0x2) == 0) {
        break label223;
      }
    }
    for (;;)
    {
      this.CK = bool1;
      this.Bf = new dq.b(paramBundle2);
      return;
      bool2 = false;
      break;
      label211:
      bool3 = false;
      break label57;
      label217:
      bool4 = false;
      break label76;
      label223:
      bool1 = false;
    }
  }
  
  private void dF()
  {
    if (this.mClosed) {
      throw new IllegalStateException("Already closed");
    }
  }
  
  public AggregatedPerson bg(int paramInt)
  {
    dF();
    return new a(paramInt);
  }
  
  public void close()
  {
    if (this.mClosed) {
      return;
    }
    this.mClosed = true;
    this.CC.close();
    this.CD.close();
    this.CC = null;
    this.CD = null;
    this.CE = null;
    this.CF = null;
    this.CG = null;
    this.CH = null;
    this.mContext = null;
    this.CI = null;
    this.CJ = null;
    this.Bf = null;
  }
  
  public int getCount()
  {
    dF();
    return this.CB;
  }
  
  private class a
    implements AggregatedPerson
  {
    private boolean CM;
    private ArrayList<Long> CN;
    private ArrayList<EmailAddress> CO;
    private ArrayList<PhoneNumber> CP;
    private EmailAddress CQ;
    private final boolean CR;
    private final int sc;
    
    public a(int paramInt)
    {
      this.sc = paramInt;
      if (!TextUtils.isEmpty(getGaiaId())) {}
      for (boolean bool = true;; bool = false)
      {
        this.CR = bool;
        return;
      }
    }
    
    private Iterable<EmailAddress> a(EmailAddress paramEmailAddress)
    {
      ArrayList localArrayList = new ArrayList(1);
      localArrayList.add(paramEmailAddress);
      return localArrayList;
    }
    
    private String a(Cursor paramCursor, dk.b paramb)
    {
      int i = dk.e(dk.this).getInt(4);
      if (i == 0) {
        return paramCursor.getString(5);
      }
      return paramb.getLabel(i);
    }
    
    private String af(String paramString)
    {
      if (hasPlusPerson())
      {
        int i = dk.a(dk.this).get(this.sc, 0);
        return dk.d(dk.this).c(paramString, i, dk.d(dk.this).ad(i));
      }
      return null;
    }
    
    private long ag(String paramString)
    {
      if (hasPlusPerson())
      {
        int i = dk.a(dk.this).get(this.sc, 0);
        return dk.d(dk.this).a(paramString, i, dk.d(dk.this).ad(i));
      }
      return 0L;
    }
    
    private int ah(String paramString)
    {
      boolean bool = hasPlusPerson();
      int i = 0;
      if (bool)
      {
        int j = dk.a(dk.this).get(this.sc, 0);
        i = dk.d(dk.this).b(paramString, j, dk.d(dk.this).ad(j));
      }
      return i;
    }
    
    private int dG()
    {
      return dk.a(dk.this).bd(this.sc);
    }
    
    private int dH()
    {
      return dk.b(dk.this).bd(this.sc);
    }
    
    private void dI()
    {
      if (this.CM) {
        return;
      }
      this.CM = true;
      int i = dH();
      this.CN = new ArrayList(i);
      this.CO = new ArrayList();
      this.CP = null;
      if ((hasPlusPerson()) && (dk.g(dk.this))) {
        this.CP = dk.h(dk.this).ai(af("v_phones"));
      }
      if (this.CP == null) {
        this.CP = new ArrayList();
      }
      this.CQ = null;
      String str1 = getGaiaId();
      int j = 0;
      label113:
      if (j < i)
      {
        int k = dk.b(dk.this).get(this.sc, j);
        if (dk.e(dk.this).moveToPosition(k))
        {
          long l = dk.e(dk.this).getLong(0);
          this.CN.add(Long.valueOf(l));
        }
      }
      label465:
      for (;;)
      {
        String str2 = dk.e(dk.this).getString(2);
        String str5;
        String str6;
        if (("vnd.android.cursor.item/email_v2".equals(str2)) && (this.CQ == null))
        {
          str5 = a(dk.e(dk.this), dk.i(dk.this));
          str6 = dk.e(dk.this).getString(3);
          if (!TextUtils.isEmpty(str6)) {}
        }
        for (;;)
        {
          if (dl.b(dk.e(dk.this))) {
            break label465;
          }
          j++;
          break label113;
          break;
          dm localdm = new dm(str5, str6);
          if (!this.CO.contains(localdm)) {
            if ((str1 != null) && (dk.j(dk.this).containsKey(localdm.getValue())) && (str1.equals(dk.j(dk.this).get(localdm.getValue()))))
            {
              this.CQ = localdm;
              this.CO.clear();
            }
            else
            {
              this.CO.add(localdm);
              continue;
              if ("vnd.android.cursor.item/phone_v2".equals(str2))
              {
                String str3 = a(dk.e(dk.this), dk.k(dk.this));
                String str4 = dk.e(dk.this).getString(3);
                if (!TextUtils.isEmpty(str4))
                {
                  dr localdr = new dr(str3, str4);
                  if (!this.CP.contains(localdr)) {
                    this.CP.add(localdr);
                  }
                }
              }
            }
          }
        }
      }
    }
    
    @Deprecated
    public String getAccountName()
    {
      dk.c(dk.this);
      return getOwnerAccountName();
    }
    
    public String getAvatarUrl()
    {
      dk.c(dk.this);
      return db.Bk.V(af("avatar"));
    }
    
    public String[] getBelongingCircleIds()
    {
      dk.c(dk.this);
      String str = af("v_circle_ids");
      if (TextUtils.isEmpty(str)) {
        return de.Cj;
      }
      return de.Ck.split(str, -1);
    }
    
    public Iterable<Long> getContactIds()
    {
      dk.c(dk.this);
      dI();
      return this.CN;
    }
    
    public Iterable<EmailAddress> getEmailAddresses()
    {
      dk.c(dk.this);
      String str = de.X(getQualifiedId());
      if (!TextUtils.isEmpty(str)) {
        return a(new dm("", str));
      }
      dI();
      if (this.CR)
      {
        if (this.CQ != null) {
          return a(this.CQ);
        }
        return EmailAddress.EMPTY_EMAILS;
      }
      if (!hasContact())
      {
        if (dd.dz()) {
          dd.g("PeopleAggregator", "Row should have a contact: " + getQualifiedId());
        }
        return EmailAddress.EMPTY_EMAILS;
      }
      return this.CO;
    }
    
    public String getFamilyName()
    {
      dk.c(dk.this);
      return af("family_name");
    }
    
    public String getGaiaId()
    {
      dk.c(dk.this);
      return (String)dk.f(dk.this).get(this.sc);
    }
    
    public String getGivenName()
    {
      dk.c(dk.this);
      return af("given_name");
    }
    
    public int getInViewerDomain()
    {
      dk.c(dk.this);
      return ah("in_viewer_domain");
    }
    
    public String getInteractionRankSortKey()
    {
      dk.c(dk.this);
      return af("sort_key_irank");
    }
    
    public long getLastModifiedTime()
    {
      dk.c(dk.this);
      return ag("last_modified");
    }
    
    public String getName()
    {
      dk.c(dk.this);
      if (hasPlusPerson()) {
        return af("name");
      }
      dk.e(dk.this).moveToPosition(dk.b(dk.this).get(this.sc, 0));
      return dk.e(dk.this).getString(1);
    }
    
    public String getNameSortKey()
    {
      dk.c(dk.this);
      return af("sort_key");
    }
    
    public String getOwnerAccountName()
    {
      dk.c(dk.this);
      if (hasPlusPerson()) {
        return dk.d(dk.this).getMetadata().getString("account");
      }
      return null;
    }
    
    public String getOwnerPlusPageId()
    {
      dk.c(dk.this);
      if (hasPlusPerson()) {
        return dk.d(dk.this).getMetadata().getString("pagegaiaid");
      }
      return null;
    }
    
    public Iterable<PhoneNumber> getPhoneNumbers()
    {
      dk.c(dk.this);
      if (de.Z(getQualifiedId())) {
        return PhoneNumber.EMPTY_PHONES;
      }
      dI();
      return this.CP;
    }
    
    @Deprecated
    public String getPlusPageGaiaId()
    {
      dk.c(dk.this);
      return getOwnerPlusPageId();
    }
    
    public int getProfileType()
    {
      dk.c(dk.this);
      return ah("profile_type");
    }
    
    public String getQualifiedId()
    {
      dk.c(dk.this);
      return af("qualified_id");
    }
    
    public boolean hasContact()
    {
      dk.c(dk.this);
      return dH() > 0;
    }
    
    public boolean hasPlusPerson()
    {
      dk.c(dk.this);
      return dG() > 0;
    }
    
    public boolean isBlocked()
    {
      dk.c(dk.this);
      return ah("blocked") != 0;
    }
    
    public boolean isNameVerified()
    {
      dk.c(dk.this);
      return ah("name_verified") != 0;
    }
  }
  
  private static abstract class b
  {
    private final ConcurrentHashMap<Integer, String> CS = new ConcurrentHashMap();
    private final Resources CT;
    
    public b(Resources paramResources)
    {
      this.CT = paramResources;
    }
    
    protected abstract String a(Resources paramResources, int paramInt);
    
    public String getLabel(int paramInt)
    {
      String str1;
      if (paramInt == 0) {
        str1 = null;
      }
      do
      {
        return str1;
        str1 = (String)this.CS.get(Integer.valueOf(paramInt));
      } while (str1 != null);
      String str2 = a(this.CT, paramInt);
      this.CS.put(Integer.valueOf(paramInt), str2);
      return str2;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dk
 * JD-Core Version:    0.7.0.1
 */