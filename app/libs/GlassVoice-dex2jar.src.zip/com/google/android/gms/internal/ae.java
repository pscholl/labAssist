package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.SystemClock;

public final class ae
  extends Drawable
  implements Drawable.Callback
{
  private boolean sS = true;
  private int sY = 0;
  private long sZ;
  private int ta;
  private int tb;
  private int tc = 255;
  private int td;
  private int te = 0;
  private boolean tf;
  private b tg;
  private Drawable th;
  private Drawable ti;
  private boolean tj;
  private boolean tk;
  private boolean tl;
  private int tm;
  
  public ae(Drawable paramDrawable1, Drawable paramDrawable2)
  {
    this(null);
    if (paramDrawable1 == null) {
      paramDrawable1 = a.bL();
    }
    this.th = paramDrawable1;
    paramDrawable1.setCallback(this);
    b localb1 = this.tg;
    localb1.tq |= paramDrawable1.getChangingConfigurations();
    if (paramDrawable2 == null) {
      paramDrawable2 = a.bL();
    }
    this.ti = paramDrawable2;
    paramDrawable2.setCallback(this);
    b localb2 = this.tg;
    localb2.tq |= paramDrawable2.getChangingConfigurations();
  }
  
  ae(b paramb)
  {
    this.tg = new b(paramb);
  }
  
  public Drawable bK()
  {
    return this.ti;
  }
  
  public boolean canConstantState()
  {
    if (!this.tj) {
      if ((this.th.getConstantState() == null) || (this.ti.getConstantState() == null)) {
        break label44;
      }
    }
    label44:
    for (boolean bool = true;; bool = false)
    {
      this.tk = bool;
      this.tj = true;
      return this.tk;
    }
  }
  
  public void draw(Canvas paramCanvas)
  {
    int i = 1;
    switch (this.sY)
    {
    }
    int k;
    boolean bool;
    Drawable localDrawable1;
    Drawable localDrawable2;
    do
    {
      for (int j = i;; j = 0)
      {
        k = this.te;
        bool = this.sS;
        localDrawable1 = this.th;
        localDrawable2 = this.ti;
        if (j == 0) {
          break;
        }
        if ((!bool) || (k == 0)) {
          localDrawable1.draw(paramCanvas);
        }
        if (k == this.tc)
        {
          localDrawable2.setAlpha(this.tc);
          localDrawable2.draw(paramCanvas);
        }
        return;
        this.sZ = SystemClock.uptimeMillis();
        this.sY = 2;
      }
    } while (this.sZ < 0L);
    float f1 = (float)(SystemClock.uptimeMillis() - this.sZ) / this.td;
    if (f1 >= 1.0F) {}
    for (;;)
    {
      if (i != 0) {
        this.sY = 0;
      }
      float f2 = Math.min(f1, 1.0F);
      this.te = ((int)(this.ta + f2 * (this.tb - this.ta)));
      break;
      i = 0;
    }
    if (bool) {
      localDrawable1.setAlpha(this.tc - k);
    }
    localDrawable1.draw(paramCanvas);
    if (bool) {
      localDrawable1.setAlpha(this.tc);
    }
    if (k > 0)
    {
      localDrawable2.setAlpha(k);
      localDrawable2.draw(paramCanvas);
      localDrawable2.setAlpha(this.tc);
    }
    invalidateSelf();
  }
  
  public int getChangingConfigurations()
  {
    return super.getChangingConfigurations() | this.tg.tp | this.tg.tq;
  }
  
  public Drawable.ConstantState getConstantState()
  {
    if (canConstantState())
    {
      this.tg.tp = getChangingConfigurations();
      return this.tg;
    }
    return null;
  }
  
  public int getIntrinsicHeight()
  {
    return Math.max(this.th.getIntrinsicHeight(), this.ti.getIntrinsicHeight());
  }
  
  public int getIntrinsicWidth()
  {
    return Math.max(this.th.getIntrinsicWidth(), this.ti.getIntrinsicWidth());
  }
  
  public int getOpacity()
  {
    if (!this.tl)
    {
      this.tm = Drawable.resolveOpacity(this.th.getOpacity(), this.ti.getOpacity());
      this.tl = true;
    }
    return this.tm;
  }
  
  public void invalidateDrawable(Drawable paramDrawable)
  {
    if (bn.cm())
    {
      Drawable.Callback localCallback = getCallback();
      if (localCallback != null) {
        localCallback.invalidateDrawable(this);
      }
    }
  }
  
  public Drawable mutate()
  {
    if ((!this.tf) && (super.mutate() == this))
    {
      if (!canConstantState()) {
        throw new IllegalStateException("One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated.");
      }
      this.th.mutate();
      this.ti.mutate();
      this.tf = true;
    }
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect)
  {
    this.th.setBounds(paramRect);
    this.ti.setBounds(paramRect);
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong)
  {
    if (bn.cm())
    {
      Drawable.Callback localCallback = getCallback();
      if (localCallback != null) {
        localCallback.scheduleDrawable(this, paramRunnable, paramLong);
      }
    }
  }
  
  public void setAlpha(int paramInt)
  {
    if (this.te == this.tc) {
      this.te = paramInt;
    }
    this.tc = paramInt;
    invalidateSelf();
  }
  
  public void setColorFilter(ColorFilter paramColorFilter)
  {
    this.th.setColorFilter(paramColorFilter);
    this.ti.setColorFilter(paramColorFilter);
  }
  
  public void startTransition(int paramInt)
  {
    this.ta = 0;
    this.tb = this.tc;
    this.te = 0;
    this.td = paramInt;
    this.sY = 1;
    invalidateSelf();
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable)
  {
    if (bn.cm())
    {
      Drawable.Callback localCallback = getCallback();
      if (localCallback != null) {
        localCallback.unscheduleDrawable(this, paramRunnable);
      }
    }
  }
  
  private static final class a
    extends Drawable
  {
    private static final a tn = new a();
    private static final a to = new a(null);
    
    public void draw(Canvas paramCanvas) {}
    
    public Drawable.ConstantState getConstantState()
    {
      return to;
    }
    
    public int getOpacity()
    {
      return -2;
    }
    
    public void setAlpha(int paramInt) {}
    
    public void setColorFilter(ColorFilter paramColorFilter) {}
    
    private static final class a
      extends Drawable.ConstantState
    {
      public int getChangingConfigurations()
      {
        return 0;
      }
      
      public Drawable newDrawable()
      {
        return ae.a.bL();
      }
    }
  }
  
  static final class b
    extends Drawable.ConstantState
  {
    int tp;
    int tq;
    
    b(b paramb)
    {
      if (paramb != null)
      {
        this.tp = paramb.tp;
        this.tq = paramb.tq;
      }
    }
    
    public int getChangingConfigurations()
    {
      return this.tp;
    }
    
    public Drawable newDrawable()
    {
      return new ae(this);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ae
 * JD-Core Version:    0.7.0.1
 */