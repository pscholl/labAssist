package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.Map;

public abstract interface bs
  extends IInterface
{
  public abstract void a(br parambr, String paramString, Map paramMap)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements bs
  {
    public static bs w(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.droidguard.internal.IDroidGuardService");
      if ((localIInterface != null) && ((localIInterface instanceof bs))) {
        return (bs)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.droidguard.internal.IDroidGuardService");
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.droidguard.internal.IDroidGuardService");
      a(br.a.v(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readHashMap(getClass().getClassLoader()));
      return true;
    }
    
    private static class a
      implements bs
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      public void a(br parambr, String paramString, Map paramMap)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.droidguard.internal.IDroidGuardService");
          IBinder localIBinder = null;
          if (parambr != null) {
            localIBinder = parambr.asBinder();
          }
          localParcel.writeStrongBinder(localIBinder);
          localParcel.writeString(paramString);
          localParcel.writeMap(paramMap);
          this.jR.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bs
 * JD-Core Version:    0.7.0.1
 */