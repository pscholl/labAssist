package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.R.string;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a.c;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceFilter;
import com.google.android.gms.location.places.PlaceReport;
import com.google.android.gms.location.places.PlaceRequest;
import com.google.android.gms.location.places.f.b;
import com.google.android.gms.maps.model.LatLngBounds;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public class cl
{
  private static final String TAG = cl.class.getSimpleName();
  private final Context mContext;
  private final cc<bx> xj;
  private final Locale yp;
  private final cm yq;
  private final cn yx;
  private final LinkedHashSet<String> yy;
  
  public cl(Context paramContext, Locale paramLocale, cc<bx> paramcc)
  {
    this.mContext = paramContext;
    this.xj = paramcc;
    this.yp = paramLocale;
    this.yx = new cn(paramContext, paramLocale);
    this.yy = new LinkedHashSet();
    this.yy.add(paramContext.getString(R.string.location_client_powered_by_google));
    String str = this.mContext.getPackageName();
    try
    {
      i = this.mContext.getPackageManager().getPackageInfo(str, 0).versionCode;
      this.yq = new cm(this.xj, str, i);
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;)
      {
        int i = -1;
      }
    }
  }
  
  public static cf e(Intent paramIntent)
  {
    return cf.d(paramIntent);
  }
  
  public void a(a.c<Status> paramc, PlaceReport paramPlaceReport)
  {
    at.f(paramPlaceReport);
    try
    {
      ((bx)this.xj.bS()).a(paramPlaceReport, this.yx);
      paramc.a(Status.rF);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      if (Log.isLoggable(TAG, 5)) {
        Log.w(TAG, "Could not report place", localRemoteException);
      }
      paramc.a(new Status(13));
    }
  }
  
  public void a(f.b paramb, PlaceFilter paramPlaceFilter)
    throws RemoteException
  {
    if (paramPlaceFilter == null) {
      paramPlaceFilter = PlaceFilter.getDefaultFilter();
    }
    ((bx)this.xj.bS()).a(paramPlaceFilter, this.yx, paramb);
  }
  
  public void a(f.b paramb, LatLngBounds paramLatLngBounds, int paramInt, PlaceFilter paramPlaceFilter)
    throws RemoteException
  {
    at.a(paramLatLngBounds, "bounds == null");
    at.a(paramb, "callback == null");
    boolean bool;
    if (paramInt > 0)
    {
      bool = true;
      at.b(bool, "maxResults should be > 0");
      this.xj.M();
      if (paramPlaceFilter != null) {
        break label80;
      }
    }
    label80:
    for (PlaceFilter localPlaceFilter = PlaceFilter.getDefaultFilter();; localPlaceFilter = paramPlaceFilter)
    {
      ((bx)this.xj.bS()).a(paramLatLngBounds, paramInt, localPlaceFilter, this.yx, paramb);
      return;
      bool = false;
      break;
    }
  }
  
  public void a(f.b paramb, String paramString)
    throws RemoteException
  {
    ((bx)this.xj.bS()).b(paramString, this.yx, paramb);
  }
  
  public boolean arePlaceIdsEquivalent(String paramString1, String paramString2)
  {
    return false;
  }
  
  public String cN()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    synchronized (this.yy)
    {
      ArrayList localArrayList = new ArrayList(this.yy);
      Iterator localIterator = localArrayList.iterator();
      if (localIterator.hasNext()) {
        localStringBuilder.append((String)localIterator.next());
      }
      if (localIterator.hasNext()) {
        localStringBuilder.append("<br>").append((String)localIterator.next());
      }
    }
    return localStringBuilder.toString();
  }
  
  public void cO()
  {
    this.yq.cO();
  }
  
  public void onConnected()
  {
    this.yq.onConnected();
  }
  
  public void removePlaceUpdates(PendingIntent paramPendingIntent)
  {
    at.a(paramPendingIntent, "callbackIntent == null");
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).a(this.yx, paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public void requestPlaceUpdates(PlaceRequest paramPlaceRequest, PendingIntent paramPendingIntent)
  {
    at.a(paramPlaceRequest, "request == null");
    at.a(paramPendingIntent, "callbackIntent == null");
    this.xj.M();
    try
    {
      ((bx)this.xj.bS()).a(paramPlaceRequest, this.yx, paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new IllegalStateException(localRemoteException);
    }
  }
  
  public List<Place> searchByPhoneNumber(String paramString)
    throws IOException
  {
    return null;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cl
 * JD-Core Version:    0.7.0.1
 */