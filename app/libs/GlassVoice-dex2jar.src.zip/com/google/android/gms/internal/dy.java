package com.google.android.gms.internal;

public class dy
{
  private final byte[] IQ = new byte[256];
  private int IR;
  private int IS;
  
  public dy(byte[] paramArrayOfByte)
  {
    for (int i = 0; i < 256; i++) {
      this.IQ[i] = ((byte)i);
    }
    int j = 0;
    for (int k = 0; k < 256; k++)
    {
      j = 0xFF & j + this.IQ[k] + paramArrayOfByte[(k % paramArrayOfByte.length)];
      int m = this.IQ[k];
      this.IQ[k] = this.IQ[j];
      this.IQ[j] = m;
    }
    this.IR = 0;
    this.IS = 0;
  }
  
  public void p(byte[] paramArrayOfByte)
  {
    int i = this.IR;
    int j = this.IS;
    for (int k = 0; k < paramArrayOfByte.length; k++)
    {
      i = 0xFF & i + 1;
      j = 0xFF & j + this.IQ[i];
      int m = this.IQ[i];
      this.IQ[i] = this.IQ[j];
      this.IQ[j] = m;
      paramArrayOfByte[k] = ((byte)(paramArrayOfByte[k] ^ this.IQ[(0xFF & this.IQ[i] + this.IQ[j])]));
    }
    this.IR = i;
    this.IS = j;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dy
 * JD-Core Version:    0.7.0.1
 */