package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class bc
  implements Parcelable.Creator<bb>
{
  static void a(bb parambb, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, parambb.getVersionCode());
    b.a(paramParcel, 2, parambb.cb(), paramInt, false);
    b.C(paramParcel, i);
  }
  
  public bb ad(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    bd localbd = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localbd = (bd)a.a(paramParcel, k, bd.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new bb(j, localbd);
  }
  
  public bb[] aq(int paramInt)
  {
    return new bb[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bc
 * JD-Core Version:    0.7.0.1
 */