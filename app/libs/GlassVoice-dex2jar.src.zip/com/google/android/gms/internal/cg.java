package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class cg
  implements Parcelable.Creator<cf>
{
  static void a(cf paramcf, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.a(paramParcel, 1, paramcf.cE(), paramInt, false);
    b.c(paramParcel, 1000, paramcf.oj);
    b.a(paramParcel, 2, paramcf.cF(), false);
    b.a(paramParcel, 3, paramcf.getTimestampMillis());
    b.C(paramParcel, i);
  }
  
  public cf[] aR(int paramInt)
  {
    return new cf[paramInt];
  }
  
  public cf at(Parcel paramParcel)
  {
    float[] arrayOfFloat = null;
    int i = a.Y(paramParcel);
    int j = 0;
    long l = 0L;
    ch[] arrayOfch = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        arrayOfch = (ch[])a.b(paramParcel, k, ch.CREATOR);
        break;
      case 1000: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        arrayOfFloat = a.t(paramParcel, k);
        break;
      case 3: 
        l = a.g(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new cf(j, arrayOfch, arrayOfFloat, l);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cg
 * JD-Core Version:    0.7.0.1
 */