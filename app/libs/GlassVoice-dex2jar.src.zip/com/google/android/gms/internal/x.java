package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.b.a;

public abstract interface x
  extends IInterface
{
  public abstract IBinder a(String paramString, b paramb)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements x
  {
    public static x f(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.adshield.internal.IAdShieldCreator");
      if ((localIInterface != null) && ((localIInterface instanceof x))) {
        return (x)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.ads.adshield.internal.IAdShieldCreator");
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.ads.adshield.internal.IAdShieldCreator");
      IBinder localIBinder = a(paramParcel1.readString(), b.a.x(paramParcel1.readStrongBinder()));
      paramParcel2.writeNoException();
      paramParcel2.writeStrongBinder(localIBinder);
      return true;
    }
    
    private static class a
      implements x
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      /* Error */
      public IBinder a(String paramString, b paramb)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_2
        //   21: ifnull +56 -> 77
        //   24: aload_2
        //   25: invokeinterface 40 1 0
        //   30: astore 6
        //   32: aload_3
        //   33: aload 6
        //   35: invokevirtual 43	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   38: aload_0
        //   39: getfield 15	com/google/android/gms/internal/x$a$a:jR	Landroid/os/IBinder;
        //   42: iconst_1
        //   43: aload_3
        //   44: aload 4
        //   46: iconst_0
        //   47: invokeinterface 49 5 0
        //   52: pop
        //   53: aload 4
        //   55: invokevirtual 52	android/os/Parcel:readException	()V
        //   58: aload 4
        //   60: invokevirtual 55	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
        //   63: astore 8
        //   65: aload 4
        //   67: invokevirtual 58	android/os/Parcel:recycle	()V
        //   70: aload_3
        //   71: invokevirtual 58	android/os/Parcel:recycle	()V
        //   74: aload 8
        //   76: areturn
        //   77: aconst_null
        //   78: astore 6
        //   80: goto -48 -> 32
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 58	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 58	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	a
        //   0	97	1	paramString	String
        //   0	97	2	paramb	b
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   30	49	6	localIBinder1	IBinder
        //   63	12	8	localIBinder2	IBinder
        // Exception table:
        //   from	to	target	type
        //   9	20	83	finally
        //   24	32	83	finally
        //   32	65	83	finally
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.x
 * JD-Core Version:    0.7.0.1
 */