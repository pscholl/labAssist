package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a.c;
import com.google.android.gms.photos.autobackup.AutoBackupApi.AutoBackupSettingsResult;
import com.google.android.gms.photos.autobackup.AutoBackupApi.PendingIntentResult;

public class du
  extends ak<dw>
{
  private String DB;
  
  public du(Context paramContext, Looper paramLooper, ai paramai, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    super(paramContext, paramLooper, paramConnectionCallbacks, paramOnConnectionFailedListener, (String[])null);
    at.f(paramai.getAccountName());
    this.DB = paramai.getAccountName();
  }
  
  public void a(a.c<AutoBackupApi.AutoBackupSettingsResult> paramc)
  {
    M();
    a locala = new a(paramc, null);
    try
    {
      ((dw)bS()).a(locala);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      locala.a(8, false, null);
    }
  }
  
  protected void a(ap paramap, ak.d paramd)
    throws RemoteException
  {
    Bundle localBundle = new Bundle();
    paramap.n(paramd, 4324000, getContext().getPackageName(), localBundle);
  }
  
  protected dw am(IBinder paramIBinder)
  {
    return dw.a.ao(paramIBinder);
  }
  
  public void b(a.c<AutoBackupApi.PendingIntentResult> paramc)
  {
    M();
    c localc = new c(paramc, null);
    try
    {
      ((dw)bS()).b(localc);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localc.a(8, null);
    }
  }
  
  protected String bQ()
  {
    return "com.google.android.gms.photos.autobackup.service.START";
  }
  
  protected String bR()
  {
    return "com.google.android.gms.photos.autobackup.internal.IAutoBackupService";
  }
  
  public void c(a.c<AutoBackupApi.PendingIntentResult> paramc)
  {
    M();
    c localc = new c(paramc, null);
    try
    {
      ((dw)bS()).a(localc, this.DB);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      localc.a(8, null);
    }
  }
  
  private final class a
    extends ds
  {
    private final a.c<AutoBackupApi.AutoBackupSettingsResult> DC;
    
    private a()
    {
      Object localObject;
      this.DC = localObject;
    }
    
    public void a(int paramInt, boolean paramBoolean, String paramString)
    {
      if (this.DC != null)
      {
        Status localStatus = new Status(paramInt);
        du.this.a(new du.b(du.this, this.DC, localStatus, paramBoolean, paramString, null));
      }
    }
  }
  
  private final class b
    extends ak<dw>.b<a.c<AutoBackupApi.AutoBackupSettingsResult>>
    implements AutoBackupApi.AutoBackupSettingsResult
  {
    private final boolean DE;
    private final String pU;
    private final Status xz;
    
    private b(Status paramStatus, boolean paramBoolean, String paramString)
    {
      super(paramStatus);
      this.xz = paramBoolean;
      this.DE = paramString;
      Object localObject;
      this.pU = localObject;
    }
    
    protected void bT() {}
    
    protected void d(a.c<AutoBackupApi.AutoBackupSettingsResult> paramc)
    {
      paramc.a(this);
    }
    
    public String getAccountName()
    {
      return this.pU;
    }
    
    public Status getStatus()
    {
      return this.xz;
    }
    
    public boolean isEnabled()
    {
      return this.DE;
    }
  }
  
  private final class c
    extends ds
  {
    private final a.c<AutoBackupApi.PendingIntentResult> DC;
    
    private c()
    {
      Object localObject;
      this.DC = localObject;
    }
    
    public void a(int paramInt, PendingIntent paramPendingIntent)
    {
      if (this.DC != null)
      {
        Status localStatus = new Status(paramInt);
        du.this.a(new du.d(du.this, this.DC, localStatus, paramPendingIntent, null));
      }
    }
  }
  
  private final class d
    extends ak<dw>.b<a.c<AutoBackupApi.PendingIntentResult>>
    implements AutoBackupApi.PendingIntentResult
  {
    private final PendingIntent mPendingIntent;
    private final Status xz;
    
    private d(Status paramStatus, PendingIntent paramPendingIntent)
    {
      super(paramStatus);
      this.xz = paramPendingIntent;
      Object localObject;
      this.mPendingIntent = localObject;
    }
    
    protected void bT() {}
    
    protected void d(a.c<AutoBackupApi.PendingIntentResult> paramc)
    {
      paramc.a(this);
    }
    
    public PendingIntent getPendingIntent()
    {
      return this.mPendingIntent;
    }
    
    public Status getStatus()
    {
      return this.xz;
    }
    
    public void launchPendingIntent(Context paramContext)
    {
      try
      {
        paramContext.startIntentSender(getPendingIntent().getIntentSender(), null, 0, 0, 0);
        return;
      }
      catch (IntentSender.SendIntentException localSendIntentException)
      {
        localSendIntentException.printStackTrace();
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.du
 * JD-Core Version:    0.7.0.1
 */