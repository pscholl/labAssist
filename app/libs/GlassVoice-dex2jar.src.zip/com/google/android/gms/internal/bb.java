package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse.FieldConverter;

public class bb
  implements SafeParcelable
{
  public static final bc CREATOR = new bc();
  private final int oj;
  private final bd uB;
  
  bb(int paramInt, bd parambd)
  {
    this.oj = paramInt;
    this.uB = parambd;
  }
  
  private bb(bd parambd)
  {
    this.oj = 1;
    this.uB = parambd;
  }
  
  public static bb a(FastJsonResponse.FieldConverter<?, ?> paramFieldConverter)
  {
    if ((paramFieldConverter instanceof bd)) {
      return new bb((bd)paramFieldConverter);
    }
    throw new IllegalArgumentException("Unsupported safe parcelable field converter class.");
  }
  
  bd cb()
  {
    return this.uB;
  }
  
  public FastJsonResponse.FieldConverter<?, ?> cc()
  {
    if (this.uB != null) {
      return this.uB;
    }
    throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    bc.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bb
 * JD-Core Version:    0.7.0.1
 */