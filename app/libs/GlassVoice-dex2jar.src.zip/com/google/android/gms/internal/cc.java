package com.google.android.gms.internal;

import android.os.IInterface;

public abstract interface cc<T extends IInterface>
{
  public abstract void M();
  
  public abstract T bS();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cc
 * JD-Core Version:    0.7.0.1
 */