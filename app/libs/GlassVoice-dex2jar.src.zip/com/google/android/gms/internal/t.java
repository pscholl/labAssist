package com.google.android.gms.internal;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.google.android.gms.auth.RecoveryDecision;
import com.google.android.gms.auth.RecoveryReadResponse;
import com.google.android.gms.auth.RecoveryWriteRequest;
import com.google.android.gms.auth.RecoveryWriteResponse;
import com.google.android.gms.auth.b;
import com.google.android.gms.auth.d;
import com.google.android.gms.auth.e;

public abstract interface t
  extends IInterface
{
  public abstract RecoveryDecision a(String paramString1, String paramString2, boolean paramBoolean, Bundle paramBundle)
    throws RemoteException;
  
  public abstract RecoveryReadResponse a(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract RecoveryWriteResponse a(RecoveryWriteRequest paramRecoveryWriteRequest, String paramString)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements t
  {
    public static t b(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.auth.IRecoveryService");
      if ((localIInterface != null) && ((localIInterface instanceof t))) {
        return (t)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.auth.IRecoveryService");
        return true;
      case 1: 
        paramParcel1.enforceInterface("com.google.android.auth.IRecoveryService");
        String str1 = paramParcel1.readString();
        String str2 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool = true;; bool = false)
        {
          int j = paramParcel1.readInt();
          Bundle localBundle = null;
          if (j != 0) {
            localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          }
          RecoveryDecision localRecoveryDecision = a(str1, str2, bool, localBundle);
          paramParcel2.writeNoException();
          if (localRecoveryDecision == null) {
            break;
          }
          paramParcel2.writeInt(1);
          localRecoveryDecision.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 2: 
        paramParcel1.enforceInterface("com.google.android.auth.IRecoveryService");
        RecoveryReadResponse localRecoveryReadResponse = a(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localRecoveryReadResponse != null)
        {
          paramParcel2.writeInt(1);
          localRecoveryReadResponse.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.auth.IRecoveryService");
      int i = paramParcel1.readInt();
      RecoveryWriteRequest localRecoveryWriteRequest = null;
      if (i != 0) {
        localRecoveryWriteRequest = RecoveryWriteRequest.CREATOR.e(paramParcel1);
      }
      RecoveryWriteResponse localRecoveryWriteResponse = a(localRecoveryWriteRequest, paramParcel1.readString());
      paramParcel2.writeNoException();
      if (localRecoveryWriteResponse != null)
      {
        paramParcel2.writeInt(1);
        localRecoveryWriteResponse.writeToParcel(paramParcel2, 1);
        return true;
      }
      paramParcel2.writeInt(0);
      return true;
    }
    
    private static class a
      implements t
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      public RecoveryDecision a(String paramString1, String paramString2, boolean paramBoolean, Bundle paramBundle)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        label148:
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.auth.IRecoveryService");
            localParcel1.writeString(paramString1);
            localParcel1.writeString(paramString2);
            if (paramBoolean)
            {
              localParcel1.writeInt(i);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                this.jR.transact(1, localParcel1, localParcel2, 0);
                localParcel2.readException();
                if (localParcel2.readInt() == 0) {
                  break label148;
                }
                RecoveryDecision localRecoveryDecision2 = RecoveryDecision.CREATOR.c(localParcel2);
                localRecoveryDecision1 = localRecoveryDecision2;
                return localRecoveryDecision1;
              }
            }
            else
            {
              i = 0;
              continue;
            }
            localParcel1.writeInt(0);
            continue;
            RecoveryDecision localRecoveryDecision1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public RecoveryReadResponse a(String paramString1, String paramString2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_3
        //   21: aload_2
        //   22: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   25: aload_0
        //   26: getfield 15	com/google/android/gms/internal/t$a$a:jR	Landroid/os/IBinder;
        //   29: iconst_2
        //   30: aload_3
        //   31: aload 4
        //   33: iconst_0
        //   34: invokeinterface 50 5 0
        //   39: pop
        //   40: aload 4
        //   42: invokevirtual 53	android/os/Parcel:readException	()V
        //   45: aload 4
        //   47: invokevirtual 57	android/os/Parcel:readInt	()I
        //   50: ifeq +29 -> 79
        //   53: getstatic 78	com/google/android/gms/auth/RecoveryReadResponse:CREATOR	Lcom/google/android/gms/auth/c;
        //   56: aload 4
        //   58: invokevirtual 84	com/google/android/gms/auth/c:d	(Landroid/os/Parcel;)Lcom/google/android/gms/auth/RecoveryReadResponse;
        //   61: astore 8
        //   63: aload 8
        //   65: astore 7
        //   67: aload 4
        //   69: invokevirtual 72	android/os/Parcel:recycle	()V
        //   72: aload_3
        //   73: invokevirtual 72	android/os/Parcel:recycle	()V
        //   76: aload 7
        //   78: areturn
        //   79: aconst_null
        //   80: astore 7
        //   82: goto -15 -> 67
        //   85: astore 5
        //   87: aload 4
        //   89: invokevirtual 72	android/os/Parcel:recycle	()V
        //   92: aload_3
        //   93: invokevirtual 72	android/os/Parcel:recycle	()V
        //   96: aload 5
        //   98: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	99	0	this	a
        //   0	99	1	paramString1	String
        //   0	99	2	paramString2	String
        //   3	90	3	localParcel1	Parcel
        //   7	81	4	localParcel2	Parcel
        //   85	12	5	localObject	Object
        //   65	16	7	localRecoveryReadResponse1	RecoveryReadResponse
        //   61	3	8	localRecoveryReadResponse2	RecoveryReadResponse
        // Exception table:
        //   from	to	target	type
        //   9	63	85	finally
      }
      
      public RecoveryWriteResponse a(RecoveryWriteRequest paramRecoveryWriteRequest, String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.auth.IRecoveryService");
            if (paramRecoveryWriteRequest != null)
            {
              localParcel1.writeInt(1);
              paramRecoveryWriteRequest.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              this.jR.transact(3, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                RecoveryWriteResponse localRecoveryWriteResponse2 = RecoveryWriteResponse.CREATOR.f(localParcel2);
                localRecoveryWriteResponse1 = localRecoveryWriteResponse2;
                return localRecoveryWriteResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            RecoveryWriteResponse localRecoveryWriteResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.t
 * JD-Core Version:    0.7.0.1
 */