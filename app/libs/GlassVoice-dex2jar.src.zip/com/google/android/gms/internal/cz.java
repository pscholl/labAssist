package com.google.android.gms.internal;

import java.util.ArrayList;

public class cz
{
  private final ArrayList<Object> Bj = new ArrayList();
  
  private static IndexOutOfBoundsException b(int paramInt1, int paramInt2)
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = Integer.valueOf(paramInt1);
    arrayOfObject[1] = Integer.valueOf(paramInt2);
    return new IndexOutOfBoundsException(String.format("Size=%d, requested=%d", arrayOfObject));
  }
  
  public void a(di paramdi, String paramString)
  {
    int i = 0;
    int j = paramdi.ae(paramString);
    if (j == 0) {
      return;
    }
    if (j == 1)
    {
      this.Bj.add(Integer.valueOf(paramdi.h(paramString, 0)));
      return;
    }
    ArrayList localArrayList = new ArrayList(j);
    while (i < j)
    {
      localArrayList.add(Integer.valueOf(paramdi.h(paramString, i)));
      i++;
    }
    this.Bj.add(localArrayList);
  }
  
  public int bd(int paramInt)
  {
    Object localObject = this.Bj.get(paramInt);
    if (localObject == null) {
      return 0;
    }
    if ((localObject instanceof Integer)) {
      return 1;
    }
    return ((ArrayList)localObject).size();
  }
  
  public void be(int paramInt)
  {
    this.Bj.add(Integer.valueOf(paramInt));
  }
  
  public void dt()
  {
    this.Bj.add(null);
  }
  
  public int get(int paramInt1, int paramInt2)
  {
    Object localObject = this.Bj.get(paramInt1);
    if (localObject == null) {
      throw b(0, paramInt2);
    }
    if ((localObject instanceof Integer))
    {
      if (paramInt2 > 0) {
        throw b(1, paramInt2);
      }
      return ((Integer)localObject).intValue();
    }
    ArrayList localArrayList = (ArrayList)localObject;
    if (paramInt2 > localArrayList.size()) {
      throw b(localArrayList.size(), paramInt2);
    }
    return ((Integer)localArrayList.get(paramInt2)).intValue();
  }
  
  public int size()
  {
    return this.Bj.size();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = de.dA();
    for (int i = 0; i < size(); i++)
    {
      if (i > 0) {
        localStringBuilder.append(",");
      }
      localStringBuilder.append("[");
      int j = bd(i);
      for (int k = 0; k < j; k++)
      {
        if (k > 0) {
          localStringBuilder.append(",");
        }
        localStringBuilder.append(get(i, k));
      }
      localStringBuilder.append("]");
    }
    return localStringBuilder.toString();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cz
 * JD-Core Version:    0.7.0.1
 */