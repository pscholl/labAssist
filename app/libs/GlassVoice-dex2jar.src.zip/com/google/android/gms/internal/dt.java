package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.photos.autobackup.AutoBackup;
import com.google.android.gms.photos.autobackup.AutoBackupApi;
import com.google.android.gms.photos.autobackup.AutoBackupApi.AutoBackupSettingsResult;
import com.google.android.gms.photos.autobackup.AutoBackupApi.PendingIntentResult;

public class dt
  implements AutoBackupApi
{
  public PendingResult<AutoBackupApi.PendingIntentResult> getAutoBackupPromoActivity(GoogleApiClient paramGoogleApiClient)
  {
    paramGoogleApiClient.a(new c()
    {
      protected void a(du paramAnonymousdu)
        throws RemoteException
      {
        paramAnonymousdu.c(this);
      }
    });
  }
  
  public PendingResult<AutoBackupApi.AutoBackupSettingsResult> getAutoBackupSettings(GoogleApiClient paramGoogleApiClient)
  {
    paramGoogleApiClient.a(new b()
    {
      protected void a(du paramAnonymousdu)
        throws RemoteException
      {
        paramAnonymousdu.a(this);
      }
    });
  }
  
  public PendingResult<AutoBackupApi.PendingIntentResult> getAutoBackupSettingsActivity(GoogleApiClient paramGoogleApiClient)
  {
    paramGoogleApiClient.a(new c()
    {
      protected void a(du paramAnonymousdu)
        throws RemoteException
      {
        paramAnonymousdu.b(this);
      }
    });
  }
  
  private static abstract class a<R extends Result>
    extends a.a<R, du>
  {
    public a(Api.b<du> paramb)
    {
      super();
    }
  }
  
  private static abstract class b
    extends dt.a<AutoBackupApi.AutoBackupSettingsResult>
  {
    public b()
    {
      super();
    }
    
    protected AutoBackupApi.AutoBackupSettingsResult e(final Status paramStatus)
    {
      new AutoBackupApi.AutoBackupSettingsResult()
      {
        public String getAccountName()
        {
          return null;
        }
        
        public Status getStatus()
        {
          return paramStatus;
        }
        
        public boolean isEnabled()
        {
          return false;
        }
      };
    }
  }
  
  private static abstract class c
    extends dt.a<AutoBackupApi.PendingIntentResult>
  {
    protected c()
    {
      super();
    }
    
    protected AutoBackupApi.PendingIntentResult f(final Status paramStatus)
    {
      new AutoBackupApi.PendingIntentResult()
      {
        public PendingIntent getPendingIntent()
        {
          return null;
        }
        
        public Status getStatus()
        {
          return paramStatus;
        }
        
        public void launchPendingIntent(Context paramAnonymousContext) {}
      };
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dt
 * JD-Core Version:    0.7.0.1
 */