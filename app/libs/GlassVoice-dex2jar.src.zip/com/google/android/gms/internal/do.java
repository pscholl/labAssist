package com.google.android.gms.internal;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.ContactsContract.Data;
import com.google.android.gms.common.data.d;
import java.util.ArrayList;
import java.util.HashMap;

class do
  extends dn
{
  private static final String[] Dq = { "contact_id" };
  
  public do(Context paramContext, dn.d paramd, boolean paramBoolean, int paramInt, Bundle paramBundle1, Bundle paramBundle2, String paramString)
  {
    super(paramContext, paramd, paramBoolean, paramInt, paramBundle1, paramBundle2, paramString);
  }
  
  private String dR()
  {
    String str;
    if (!this.Dc) {
      str = "";
    }
    StringBuilder localStringBuilder;
    Cursor localCursor;
    do
    {
      return str;
      localStringBuilder = new StringBuilder();
      localStringBuilder.append("contact_id IN(");
      localCursor = this.mContext.getContentResolver().query(ContactsContract.Data.CONTENT_URI, Dq, dS(), null, null);
      str = null;
    } while (localCursor == null);
    int i = 1;
    try
    {
      while (localCursor.moveToNext())
      {
        if (i == 0) {
          localStringBuilder.append(",");
        }
        localStringBuilder.append(localCursor.getLong(0));
        i = 0;
      }
      localStringBuilder.append(")");
      return localStringBuilder.toString();
    }
    finally
    {
      localCursor.close();
    }
  }
  
  private String dS()
  {
    at.f(this.Dc);
    d locald = dK();
    at.f(locald);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("data1 IN(");
    dn.c localc = new dn.c(locald);
    for (int i = 1; localc.moveToNext(); i = 0)
    {
      if (i == 0) {
        localStringBuilder.append(",");
      }
      DatabaseUtils.appendEscapedSQLString(localStringBuilder, localc.getString("value"));
    }
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
  
  protected dk a(dn.c paramc1, dn.c paramc2, Cursor paramCursor)
  {
    at.f(paramc1);
    at.f(paramCursor);
    cz localcz1 = new cz();
    cz localcz2 = new cz();
    int i = paramc1.getCount();
    paramCursor.getCount();
    HashMap localHashMap1 = new HashMap();
    this.De.ad("people-map start");
    a(paramc1, localHashMap1);
    this.De.ad("people-map finish");
    di localdi = new di();
    cy localcy = new cy();
    HashMap localHashMap2 = new HashMap();
    b(paramc2, localHashMap2);
    this.De.ad("contact-map start");
    int j = a(paramCursor, localdi, localcy, localHashMap2);
    this.De.ad("contact-map finish");
    if (dd.dz()) {
      dd.g("PeopleAggregator", "#people=" + i + ", #contacts=" + j);
    }
    this.De.ad("merge start");
    paramc1.bh(0);
    paramCursor.moveToPosition(0);
    ArrayList localArrayList = bg.ck();
    int k;
    if (!paramc1.isAfterLast())
    {
      k = 1;
      if (paramCursor.isAfterLast()) {
        break label296;
      }
    }
    label296:
    for (int m = 1;; m = 0)
    {
      if ((k != 0) || (m != 0)) {
        break label302;
      }
      this.De.ad("merge finish");
      return new dk(paramc1.Do, paramCursor, this.mContext, localcz1.size(), localcz1, localcz2, localArrayList, localHashMap2, this.CZ, this.Da, this.Db);
      k = 0;
      break;
    }
    label302:
    String str1;
    label315:
    String str2;
    label329:
    int n;
    label349:
    String str4;
    if (k != 0)
    {
      str1 = paramc1.getString("name");
      if (m == 0) {
        break label468;
      }
      str2 = paramCursor.getString(1);
      if ((k == 0) || (m == 0)) {
        break label474;
      }
      n = l(str1, str2);
      if (n <= 0)
      {
        int i4 = paramc1.getPosition();
        str4 = paramc1.getString("gaia_id");
        localcz1.be(i4);
        localArrayList.add(str4);
        if ((str4 != null) && (localdi.ae(str4) != 0)) {
          break label491;
        }
        localcz2.dt();
      }
    }
    int i1;
    int i2;
    for (;;)
    {
      paramc1.moveToNext();
      if (n < 0) {
        break;
      }
      i1 = paramCursor.getPosition();
      i2 = localcy.bd(i1);
      if (i2 != 0) {
        break label503;
      }
      localcz1.dt();
      localcz2.be(i1);
      localArrayList.add(null);
      dl.a(paramCursor);
      break;
      str1 = null;
      break label315;
      label468:
      str2 = null;
      break label329;
      label474:
      if (k != 0)
      {
        n = -1;
        break label349;
      }
      n = 1;
      break label349;
      label491:
      localcz2.a(localdi, str4);
    }
    label503:
    int i3 = 0;
    label506:
    String str3;
    if (i3 < i2)
    {
      str3 = localcy.a(i1, i3);
      if (!localHashMap1.containsKey(str3)) {
        break label540;
      }
    }
    for (;;)
    {
      i3++;
      break label506;
      break;
      label540:
      localcz1.dt();
      localcz2.be(i1);
      localArrayList.add(str3);
    }
  }
  
  protected Cursor dN()
  {
    String str = dR();
    Cursor localCursor = null;
    if (str == null) {}
    label185:
    for (;;)
    {
      return localCursor;
      boolean bool;
      Uri localUri;
      dg localdg2;
      if ((Dk) && (Build.VERSION.SDK_INT >= 18))
      {
        Uri.Builder localBuilder = dl.a.CONTENT_URI.buildUpon();
        if (!this.CY)
        {
          bool = true;
          localUri = localBuilder.appendQueryParameter("visible_contacts_only", String.valueOf(bool)).build();
          localdg2 = new dg();
          localdg2.ab(dl.dJ());
          localdg2.ab(str);
        }
      }
      dg localdg1;
      for (localCursor = this.mContext.getContentResolver().query(localUri, dl.CU, localdg2.toString(), null, "display_name COLLATE LOCALIZED,contact_id");; localCursor = this.mContext.getContentResolver().query(ContactsContract.Data.CONTENT_URI, dl.CU, localdg1.toString(), null, "display_name COLLATE LOCALIZED,contact_id"))
      {
        if (localCursor == null) {
          break label185;
        }
        localCursor.getCount();
        return localCursor;
        bool = false;
        break;
        localdg1 = new dg();
        dl.a(localdg1, this.CY, this.mContext);
        dl.a(localdg1);
        localdg1.ab(str);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.do
 * JD-Core Version:    0.7.0.1
 */