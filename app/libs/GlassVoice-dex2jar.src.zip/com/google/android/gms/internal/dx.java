package com.google.android.gms.internal;

import java.io.IOException;
import java.util.List;

public abstract interface dx
{
  public static final class a
    extends eb<a>
  {
    public long IO;
    public c.j IP;
    public c.f fo;
    
    public a()
    {
      fZ();
    }
    
    public static a o(byte[] paramArrayOfByte)
      throws ee
    {
      return (a)ef.mergeFrom(new a(), paramArrayOfByte);
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool2;
      if (paramObject == this) {
        bool2 = true;
      }
      a locala;
      label66:
      c.j localj;
      do
      {
        c.f localf;
        do
        {
          boolean bool3;
          do
          {
            boolean bool1;
            do
            {
              return bool2;
              bool1 = paramObject instanceof a;
              bool2 = false;
            } while (!bool1);
            locala = (a)paramObject;
            bool3 = this.IO < locala.IO;
            bool2 = false;
          } while (bool3);
          if (this.fo != null) {
            break;
          }
          localf = locala.fo;
          bool2 = false;
        } while (localf != null);
        if (this.IP != null) {
          break label152;
        }
        localj = locala.IP;
        bool2 = false;
      } while (localj != null);
      for (;;)
      {
        if ((this.Jd == null) || (this.Jd.isEmpty()))
        {
          if (locala.Jd != null)
          {
            boolean bool4 = locala.Jd.isEmpty();
            bool2 = false;
            if (!bool4) {
              break;
            }
          }
          return true;
          if (this.fo.equals(locala.fo)) {
            break label66;
          }
          return false;
          label152:
          if (!this.IP.equals(locala.IP)) {
            return false;
          }
        }
      }
      return this.Jd.equals(locala.Jd);
    }
    
    public a fZ()
    {
      this.IO = 0L;
      this.fo = null;
      this.IP = null;
      this.Jd = null;
      this.Jh = -1;
      return this;
    }
    
    public int getSerializedSize()
    {
      int i = super.getSerializedSize() + ea.c(1, this.IO);
      if (this.fo != null) {
        i += ea.b(2, this.fo);
      }
      if (this.IP != null) {
        i += ea.b(3, this.IP);
      }
      this.Jh = i;
      return i;
    }
    
    public int hashCode()
    {
      int i = 31 * (527 + (int)(this.IO ^ this.IO >>> 32));
      int j;
      int m;
      label47:
      int n;
      int i1;
      if (this.fo == null)
      {
        j = 0;
        int k = 31 * (j + i);
        if (this.IP != null) {
          break label106;
        }
        m = 0;
        n = 31 * (m + k);
        List localList = this.Jd;
        i1 = 0;
        if (localList != null)
        {
          boolean bool = this.Jd.isEmpty();
          i1 = 0;
          if (!bool) {
            break label118;
          }
        }
      }
      for (;;)
      {
        return n + i1;
        j = this.fo.hashCode();
        break;
        label106:
        m = this.IP.hashCode();
        break label47;
        label118:
        i1 = this.Jd.hashCode();
      }
    }
    
    public a l(dz paramdz)
      throws IOException
    {
      for (;;)
      {
        int i = paramdz.ga();
        switch (i)
        {
        default: 
          if (a(paramdz, i)) {
            continue;
          }
        case 0: 
          return this;
        case 8: 
          this.IO = paramdz.gc();
          break;
        case 18: 
          if (this.fo == null) {
            this.fo = new c.f();
          }
          paramdz.a(this.fo);
          break;
        }
        if (this.IP == null) {
          this.IP = new c.j();
        }
        paramdz.a(this.IP);
      }
    }
    
    public void writeTo(ea paramea)
      throws IOException
    {
      paramea.b(1, this.IO);
      if (this.fo != null) {
        paramea.a(2, this.fo);
      }
      if (this.IP != null) {
        paramea.a(3, this.IP);
      }
      super.writeTo(paramea);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dx
 * JD-Core Version:    0.7.0.1
 */