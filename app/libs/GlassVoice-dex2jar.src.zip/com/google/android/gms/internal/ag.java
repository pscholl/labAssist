package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;

public final class ag
  extends ImageView
{
  private Uri tr;
  private int ts;
  private int tt;
  
  public void ai(int paramInt)
  {
    this.ts = paramInt;
  }
  
  public void b(Uri paramUri)
  {
    this.tr = paramUri;
  }
  
  public int bM()
  {
    return this.ts;
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if (this.tt != 0) {
      paramCanvas.drawColor(this.tt);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ag
 * JD-Core Version:    0.7.0.1
 */