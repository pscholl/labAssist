package com.google.android.gms.internal;

import java.util.Arrays;

public final class eh
{
  final byte[] Ji;
  final int tag;
  
  eh(int paramInt, byte[] paramArrayOfByte)
  {
    this.tag = paramInt;
    this.Ji = paramArrayOfByte;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {}
    eh localeh;
    do
    {
      return true;
      if (!(paramObject instanceof eh)) {
        return false;
      }
      localeh = (eh)paramObject;
    } while ((this.tag == localeh.tag) && (Arrays.equals(this.Ji, localeh.Ji)));
    return false;
  }
  
  public int hashCode()
  {
    return 31 * (527 + this.tag) + Arrays.hashCode(this.Ji);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.eh
 * JD-Core Version:    0.7.0.1
 */