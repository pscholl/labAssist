package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public final class cj
  implements SafeParcelable
{
  public static final ck CREATOR = new ck();
  public final String name;
  public final int versionCode;
  public final String yt;
  public final String yu;
  public final String yv;
  public final List<String> yw;
  
  public cj(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, List<String> paramList)
  {
    this.versionCode = paramInt;
    this.name = paramString1;
    this.yt = paramString2;
    this.yu = paramString3;
    this.yv = paramString4;
    this.yw = paramList;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    cj localcj;
    do
    {
      return true;
      if (!(paramObject instanceof cj)) {
        return false;
      }
      localcj = (cj)paramObject;
    } while ((ar.equal(this.name, localcj.name)) && (ar.equal(this.yt, localcj.yt)) && (ar.equal(this.yu, localcj.yu)) && (ar.equal(this.yv, localcj.yv)) && (ar.equal(this.yw, localcj.yw)));
    return false;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = this.name;
    arrayOfObject[1] = this.yt;
    arrayOfObject[2] = this.yu;
    arrayOfObject[3] = this.yv;
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    return ar.e(this).a("name", this.name).a("address", this.yt).a("internationalPhoneNumber", this.yu).a("regularOpenHours", this.yv).a("attributions", this.yw).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    ck.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cj
 * JD-Core Version:    0.7.0.1
 */