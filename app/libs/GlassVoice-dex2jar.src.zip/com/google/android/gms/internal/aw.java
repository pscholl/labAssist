package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.view.View;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.dynamic.e;
import com.google.android.gms.dynamic.e.a;

public final class aw
  extends e<aq>
{
  private static final aw ui = new aw();
  
  private aw()
  {
    super("com.google.android.gms.common.ui.SignInButtonCreatorImpl");
  }
  
  public static View c(Context paramContext, int paramInt1, int paramInt2)
    throws e.a
  {
    return ui.d(paramContext, paramInt1, paramInt2);
  }
  
  private View d(Context paramContext, int paramInt1, int paramInt2)
    throws e.a
  {
    try
    {
      b localb = c.g(paramContext);
      View localView = (View)c.d(((aq)u(paramContext)).a(localb, paramInt1, paramInt2));
      return localView;
    }
    catch (Exception localException)
    {
      throw new e.a("Could not get button with size " + paramInt1 + " and color " + paramInt2, localException);
    }
  }
  
  public aq t(IBinder paramIBinder)
  {
    return aq.a.s(paramIBinder);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.aw
 * JD-Core Version:    0.7.0.1
 */