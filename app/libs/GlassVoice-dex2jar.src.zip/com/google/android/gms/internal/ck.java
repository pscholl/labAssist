package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class ck
  implements Parcelable.Creator<cj>
{
  static void a(cj paramcj, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.a(paramParcel, 1, paramcj.name, false);
    b.c(paramParcel, 1000, paramcj.versionCode);
    b.a(paramParcel, 2, paramcj.yt, false);
    b.a(paramParcel, 3, paramcj.yu, false);
    b.a(paramParcel, 4, paramcj.yv, false);
    b.a(paramParcel, 5, paramcj.yw, false);
    b.C(paramParcel, i);
  }
  
  public cj[] aU(int paramInt)
  {
    return new cj[paramInt];
  }
  
  public cj av(Parcel paramParcel)
  {
    ArrayList localArrayList = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        str4 = a.l(paramParcel, k);
        break;
      case 1000: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str3 = a.l(paramParcel, k);
        break;
      case 3: 
        str2 = a.l(paramParcel, k);
        break;
      case 4: 
        str1 = a.l(paramParcel, k);
        break;
      case 5: 
        localArrayList = a.x(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new cj(j, str4, str3, str2, str1, localArrayList);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ck
 * JD-Core Version:    0.7.0.1
 */