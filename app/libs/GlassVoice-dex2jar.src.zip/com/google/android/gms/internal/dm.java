package com.google.android.gms.internal;

import com.google.android.gms.people.model.EmailAddress;

public class dm
  implements EmailAddress
{
  private final String mValue;
  private final String xK;
  
  public dm(String paramString1, String paramString2)
  {
    this.xK = paramString1;
    this.mValue = paramString2;
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof dm))
    {
      dm localdm = (dm)paramObject;
      return ar.equal(this.mValue, localdm.mValue);
    }
    return false;
  }
  
  public String getType()
  {
    return this.xK;
  }
  
  public String getValue()
  {
    return this.mValue;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("EmailAddress:[Value=");
    String str1;
    StringBuilder localStringBuilder2;
    if (this.mValue != null)
    {
      str1 = this.mValue;
      localStringBuilder2 = localStringBuilder1.append(str1).append(" Type=");
      if (this.xK == null) {
        break label70;
      }
    }
    label70:
    for (String str2 = this.xK;; str2 = "null")
    {
      return str2 + "]";
      str1 = "null";
      break;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dm
 * JD-Core Version:    0.7.0.1
 */