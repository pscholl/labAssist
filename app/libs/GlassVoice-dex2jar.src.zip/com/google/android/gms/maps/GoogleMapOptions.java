package com.google.android.gms.maps;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.util.AttributeSet;
import com.google.android.gms.R.styleable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.internal.r;
import com.google.android.gms.maps.model.CameraPosition;

public final class GoogleMapOptions
  implements SafeParcelable
{
  public static final GoogleMapOptionsCreator CREATOR = new GoogleMapOptionsCreator();
  private final int oj;
  private CameraPosition zA;
  private Boolean zB;
  private Boolean zC;
  private Boolean zD;
  private Boolean zE;
  private Boolean zF;
  private Boolean zG;
  private Boolean zx;
  private Boolean zy;
  private int zz = -1;
  
  public GoogleMapOptions()
  {
    this.oj = 1;
  }
  
  GoogleMapOptions(int paramInt1, byte paramByte1, byte paramByte2, int paramInt2, CameraPosition paramCameraPosition, byte paramByte3, byte paramByte4, byte paramByte5, byte paramByte6, byte paramByte7, byte paramByte8)
  {
    this.oj = paramInt1;
    this.zx = com.google.android.gms.maps.internal.a.a(paramByte1);
    this.zy = com.google.android.gms.maps.internal.a.a(paramByte2);
    this.zz = paramInt2;
    this.zA = paramCameraPosition;
    this.zB = com.google.android.gms.maps.internal.a.a(paramByte3);
    this.zC = com.google.android.gms.maps.internal.a.a(paramByte4);
    this.zD = com.google.android.gms.maps.internal.a.a(paramByte5);
    this.zE = com.google.android.gms.maps.internal.a.a(paramByte6);
    this.zF = com.google.android.gms.maps.internal.a.a(paramByte7);
    this.zG = com.google.android.gms.maps.internal.a.a(paramByte8);
  }
  
  public static GoogleMapOptions createFromAttributes(Context paramContext, AttributeSet paramAttributeSet)
  {
    if (paramAttributeSet == null) {
      return null;
    }
    TypedArray localTypedArray = paramContext.getResources().obtainAttributes(paramAttributeSet, R.styleable.MapAttrs);
    GoogleMapOptions localGoogleMapOptions = new GoogleMapOptions();
    if (localTypedArray.hasValue(0)) {
      localGoogleMapOptions.mapType(localTypedArray.getInt(0, -1));
    }
    if (localTypedArray.hasValue(13)) {
      localGoogleMapOptions.zOrderOnTop(localTypedArray.getBoolean(13, false));
    }
    if (localTypedArray.hasValue(12)) {
      localGoogleMapOptions.useViewLifecycleInFragment(localTypedArray.getBoolean(12, false));
    }
    if (localTypedArray.hasValue(6)) {
      localGoogleMapOptions.compassEnabled(localTypedArray.getBoolean(6, true));
    }
    if (localTypedArray.hasValue(7)) {
      localGoogleMapOptions.rotateGesturesEnabled(localTypedArray.getBoolean(7, true));
    }
    if (localTypedArray.hasValue(8)) {
      localGoogleMapOptions.scrollGesturesEnabled(localTypedArray.getBoolean(8, true));
    }
    if (localTypedArray.hasValue(9)) {
      localGoogleMapOptions.tiltGesturesEnabled(localTypedArray.getBoolean(9, true));
    }
    if (localTypedArray.hasValue(11)) {
      localGoogleMapOptions.zoomGesturesEnabled(localTypedArray.getBoolean(11, true));
    }
    if (localTypedArray.hasValue(10)) {
      localGoogleMapOptions.zoomControlsEnabled(localTypedArray.getBoolean(10, true));
    }
    localGoogleMapOptions.camera(CameraPosition.createFromAttributes(paramContext, paramAttributeSet));
    localTypedArray.recycle();
    return localGoogleMapOptions;
  }
  
  byte cS()
  {
    return com.google.android.gms.maps.internal.a.b(this.zx);
  }
  
  byte cT()
  {
    return com.google.android.gms.maps.internal.a.b(this.zy);
  }
  
  byte cU()
  {
    return com.google.android.gms.maps.internal.a.b(this.zB);
  }
  
  byte cV()
  {
    return com.google.android.gms.maps.internal.a.b(this.zC);
  }
  
  byte cW()
  {
    return com.google.android.gms.maps.internal.a.b(this.zD);
  }
  
  byte cX()
  {
    return com.google.android.gms.maps.internal.a.b(this.zE);
  }
  
  byte cY()
  {
    return com.google.android.gms.maps.internal.a.b(this.zF);
  }
  
  byte cZ()
  {
    return com.google.android.gms.maps.internal.a.b(this.zG);
  }
  
  public GoogleMapOptions camera(CameraPosition paramCameraPosition)
  {
    this.zA = paramCameraPosition;
    return this;
  }
  
  public GoogleMapOptions compassEnabled(boolean paramBoolean)
  {
    this.zC = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public CameraPosition getCamera()
  {
    return this.zA;
  }
  
  public Boolean getCompassEnabled()
  {
    return this.zC;
  }
  
  public int getMapType()
  {
    return this.zz;
  }
  
  public Boolean getRotateGesturesEnabled()
  {
    return this.zG;
  }
  
  public Boolean getScrollGesturesEnabled()
  {
    return this.zD;
  }
  
  public Boolean getTiltGesturesEnabled()
  {
    return this.zF;
  }
  
  public Boolean getUseViewLifecycleInFragment()
  {
    return this.zy;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public Boolean getZOrderOnTop()
  {
    return this.zx;
  }
  
  public Boolean getZoomControlsEnabled()
  {
    return this.zB;
  }
  
  public Boolean getZoomGesturesEnabled()
  {
    return this.zE;
  }
  
  public GoogleMapOptions mapType(int paramInt)
  {
    this.zz = paramInt;
    return this;
  }
  
  public GoogleMapOptions rotateGesturesEnabled(boolean paramBoolean)
  {
    this.zG = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public GoogleMapOptions scrollGesturesEnabled(boolean paramBoolean)
  {
    this.zD = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public GoogleMapOptions tiltGesturesEnabled(boolean paramBoolean)
  {
    this.zF = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public GoogleMapOptions useViewLifecycleInFragment(boolean paramBoolean)
  {
    this.zy = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    if (r.dh())
    {
      a.a(this, paramParcel, paramInt);
      return;
    }
    GoogleMapOptionsCreator.a(this, paramParcel, paramInt);
  }
  
  public GoogleMapOptions zOrderOnTop(boolean paramBoolean)
  {
    this.zx = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public GoogleMapOptions zoomControlsEnabled(boolean paramBoolean)
  {
    this.zB = Boolean.valueOf(paramBoolean);
    return this;
  }
  
  public GoogleMapOptions zoomGesturesEnabled(boolean paramBoolean)
  {
    this.zE = Boolean.valueOf(paramBoolean);
    return this;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.maps.GoogleMapOptions
 * JD-Core Version:    0.7.0.1
 */