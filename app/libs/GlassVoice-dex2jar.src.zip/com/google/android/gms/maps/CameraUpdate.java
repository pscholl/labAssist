package com.google.android.gms.maps;

import com.google.android.gms.dynamic.b;
import com.google.android.gms.internal.at;

public final class CameraUpdate
{
  private final b zd;
  
  CameraUpdate(b paramb)
  {
    this.zd = ((b)at.f(paramb));
  }
  
  b cP()
  {
    return this.zd;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.maps.CameraUpdate
 * JD-Core Version:    0.7.0.1
 */