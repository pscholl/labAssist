package com.google.android.gms.maps;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.b;

public class a
{
  static void a(GoogleMapOptions paramGoogleMapOptions, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramGoogleMapOptions.getVersionCode());
    b.a(paramParcel, 2, paramGoogleMapOptions.cS());
    b.a(paramParcel, 3, paramGoogleMapOptions.cT());
    b.c(paramParcel, 4, paramGoogleMapOptions.getMapType());
    b.a(paramParcel, 5, paramGoogleMapOptions.getCamera(), paramInt, false);
    b.a(paramParcel, 6, paramGoogleMapOptions.cU());
    b.a(paramParcel, 7, paramGoogleMapOptions.cV());
    b.a(paramParcel, 8, paramGoogleMapOptions.cW());
    b.a(paramParcel, 9, paramGoogleMapOptions.cX());
    b.a(paramParcel, 10, paramGoogleMapOptions.cY());
    b.a(paramParcel, 11, paramGoogleMapOptions.cZ());
    b.C(paramParcel, i);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.maps.a
 * JD-Core Version:    0.7.0.1
 */