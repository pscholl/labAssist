package com.google.android.gms.maps;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.dynamic.LifecycleDelegate;
import com.google.android.gms.dynamic.a;
import com.google.android.gms.dynamic.d;
import com.google.android.gms.internal.at;
import com.google.android.gms.maps.internal.IMapViewDelegate;
import com.google.android.gms.maps.internal.q;
import com.google.android.gms.maps.model.RuntimeRemoteException;

public class MapView
  extends FrameLayout
{
  private GoogleMap zI;
  private final b zM;
  
  public MapView(Context paramContext)
  {
    super(paramContext);
    this.zM = new b(this, paramContext, null);
  }
  
  public MapView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.zM = new b(this, paramContext, GoogleMapOptions.createFromAttributes(paramContext, paramAttributeSet));
  }
  
  public MapView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.zM = new b(this, paramContext, GoogleMapOptions.createFromAttributes(paramContext, paramAttributeSet));
  }
  
  public MapView(Context paramContext, GoogleMapOptions paramGoogleMapOptions)
  {
    super(paramContext);
    this.zM = new b(this, paramContext, paramGoogleMapOptions);
  }
  
  public final GoogleMap getMap()
  {
    if (this.zI != null) {
      return this.zI;
    }
    this.zM.db();
    if (this.zM.cq() == null) {
      return null;
    }
    try
    {
      this.zI = new GoogleMap(((a)this.zM.cq()).dc().getMap());
      return this.zI;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeRemoteException(localRemoteException);
    }
  }
  
  public final void onCreate(Bundle paramBundle)
  {
    this.zM.onCreate(paramBundle);
    if (this.zM.cq() == null) {
      b.b(this);
    }
  }
  
  public final void onDestroy()
  {
    this.zM.onDestroy();
  }
  
  public final void onLowMemory()
  {
    this.zM.onLowMemory();
  }
  
  public final void onPause()
  {
    this.zM.onPause();
  }
  
  public final void onResume()
  {
    this.zM.onResume();
  }
  
  public final void onSaveInstanceState(Bundle paramBundle)
  {
    this.zM.onSaveInstanceState(paramBundle);
  }
  
  static class a
    implements LifecycleDelegate
  {
    private final ViewGroup zN;
    private final IMapViewDelegate zO;
    private View zP;
    
    public a(ViewGroup paramViewGroup, IMapViewDelegate paramIMapViewDelegate)
    {
      this.zO = ((IMapViewDelegate)at.f(paramIMapViewDelegate));
      this.zN = ((ViewGroup)at.f(paramViewGroup));
    }
    
    public IMapViewDelegate dc()
    {
      return this.zO;
    }
    
    public void onCreate(Bundle paramBundle)
    {
      try
      {
        this.zO.onCreate(paramBundle);
        this.zP = ((View)com.google.android.gms.dynamic.c.d(this.zO.getView()));
        this.zN.removeAllViews();
        this.zN.addView(this.zP);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
    }
    
    public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
    {
      throw new UnsupportedOperationException("onCreateView not allowed on MapViewDelegate");
    }
    
    public void onDestroy()
    {
      try
      {
        this.zO.onDestroy();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
    }
    
    public void onDestroyView()
    {
      throw new UnsupportedOperationException("onDestroyView not allowed on MapViewDelegate");
    }
    
    public void onInflate(Activity paramActivity, Bundle paramBundle1, Bundle paramBundle2)
    {
      throw new UnsupportedOperationException("onInflate not allowed on MapViewDelegate");
    }
    
    public void onLowMemory()
    {
      try
      {
        this.zO.onLowMemory();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
    }
    
    public void onPause()
    {
      try
      {
        this.zO.onPause();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
    }
    
    public void onResume()
    {
      try
      {
        this.zO.onResume();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
    }
    
    public void onSaveInstanceState(Bundle paramBundle)
    {
      try
      {
        this.zO.onSaveInstanceState(paramBundle);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
    }
    
    public void onStart() {}
    
    public void onStop() {}
  }
  
  static class b
    extends a<MapView.a>
  {
    private final Context mContext;
    protected d<MapView.a> zL;
    private final ViewGroup zQ;
    private final GoogleMapOptions zR;
    
    b(ViewGroup paramViewGroup, Context paramContext, GoogleMapOptions paramGoogleMapOptions)
    {
      this.zQ = paramViewGroup;
      this.mContext = paramContext;
      this.zR = paramGoogleMapOptions;
    }
    
    protected void a(d<MapView.a> paramd)
    {
      this.zL = paramd;
      db();
    }
    
    public void db()
    {
      if ((this.zL != null) && (cq() == null)) {}
      try
      {
        IMapViewDelegate localIMapViewDelegate = q.v(this.mContext).a(com.google.android.gms.dynamic.c.g(this.mContext), this.zR);
        this.zL.a(new MapView.a(this.zQ, localIMapViewDelegate));
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeRemoteException(localRemoteException);
      }
      catch (GooglePlayServicesNotAvailableException localGooglePlayServicesNotAvailableException) {}
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.maps.MapView
 * JD-Core Version:    0.7.0.1
 */