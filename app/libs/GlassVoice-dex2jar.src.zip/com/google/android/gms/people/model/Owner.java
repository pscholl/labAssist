package com.google.android.gms.people.model;

public abstract interface Owner
{
  @Deprecated
  public abstract String getAccountGaiaId();
  
  public abstract String getAccountId();
  
  public abstract String getAccountName();
  
  public abstract String getAvatarUrl();
  
  public abstract int getCoverPhotoHeight();
  
  public abstract String getCoverPhotoId();
  
  public abstract String getCoverPhotoUrl();
  
  public abstract int getCoverPhotoWidth();
  
  public abstract String getDasherDomain();
  
  public abstract String getDisplayName();
  
  public abstract long getLastSuccessfulSyncFinishTimestamp();
  
  public abstract long getLastSyncFinishTimestamp();
  
  public abstract long getLastSyncStartTimestamp();
  
  public abstract int getLastSyncStatus();
  
  @Deprecated
  public abstract String getPlusPageGaiaId();
  
  public abstract String getPlusPageId();
  
  public abstract int isDasherAccount();
  
  public abstract boolean isPeriodicSyncEnabled();
  
  public abstract boolean isPlusEnabled();
  
  public abstract boolean isPlusPage();
  
  public abstract boolean isSyncCirclesToContactsEnabled();
  
  public abstract boolean isSyncEnabled();
  
  public abstract boolean isSyncEvergreenToContactsEnabled();
  
  public abstract boolean isSyncToContactsEnabled();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.Owner
 * JD-Core Version:    0.7.0.1
 */