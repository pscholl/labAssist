package com.google.android.gms.people.model;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.d;

public abstract class AggregatedPersonBuffer
  extends DataBuffer<AggregatedPerson>
{
  public AggregatedPersonBuffer(d paramd)
  {
    super(paramd);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.AggregatedPersonBuffer
 * JD-Core Version:    0.7.0.1
 */