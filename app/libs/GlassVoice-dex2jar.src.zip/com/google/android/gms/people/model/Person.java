package com.google.android.gms.people.model;

public abstract interface Person
{
  @Deprecated
  public abstract String getAccountName();
  
  public abstract String getAvatarUrl();
  
  public abstract String[] getBelongingCircleIds();
  
  public abstract String getFamilyName();
  
  public abstract String getGaiaId();
  
  public abstract String getGivenName();
  
  public abstract int getInViewerDomain();
  
  public abstract String getInteractionRankSortKey();
  
  public abstract long getLastModifiedTime();
  
  public abstract String getName();
  
  public abstract String getNameSortKey();
  
  public abstract String getOwnerAccountName();
  
  public abstract String getOwnerPlusPageId();
  
  @Deprecated
  public abstract String getPlusPageGaiaId();
  
  public abstract int getProfileType();
  
  public abstract String getQualifiedId();
  
  public abstract boolean isBlocked();
  
  public abstract boolean isNameVerified();
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.Person
 * JD-Core Version:    0.7.0.1
 */