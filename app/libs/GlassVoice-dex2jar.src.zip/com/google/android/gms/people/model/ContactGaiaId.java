package com.google.android.gms.people.model;

public abstract interface ContactGaiaId
{
  public abstract String getContactInfo();
  
  public abstract String getGaiaId();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.ContactGaiaId
 * JD-Core Version:    0.7.0.1
 */