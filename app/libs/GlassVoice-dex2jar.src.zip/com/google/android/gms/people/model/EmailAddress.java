package com.google.android.gms.people.model;

import com.google.android.gms.internal.cv;

public abstract interface EmailAddress
  extends ValueAndType
{
  public static final Iterable<EmailAddress> EMPTY_EMAILS = new cv();
  
  public abstract String getType();
  
  public abstract String getValue();
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.EmailAddress
 * JD-Core Version:    0.7.0.1
 */