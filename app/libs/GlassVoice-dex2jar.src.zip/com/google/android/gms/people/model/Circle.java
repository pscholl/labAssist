package com.google.android.gms.people.model;

public abstract interface Circle
{
  @Deprecated
  public abstract String getAccountName();
  
  public abstract String getCircleId();
  
  public abstract String getCircleName();
  
  public abstract int getCircleType();
  
  public abstract long getLastModifiedTime();
  
  public abstract String getOwnerAccountName();
  
  public abstract String getOwnerPlusPageId();
  
  public abstract int getPeopleCount();
  
  @Deprecated
  public abstract String getPlusPageGaiaId();
  
  public abstract String getSortKey();
  
  public abstract int getVisibility();
  
  public abstract boolean isEnabledForSharing();
  
  public abstract boolean isSyncToContactsEnabled();
  
  public abstract boolean policyCannotAclTo();
  
  public abstract boolean policyCannotModifyMembership();
  
  public abstract boolean policyCannotViewMembership();
  
  public abstract boolean policyVisibleOnlyWhenPopulated();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.Circle
 * JD-Core Version:    0.7.0.1
 */