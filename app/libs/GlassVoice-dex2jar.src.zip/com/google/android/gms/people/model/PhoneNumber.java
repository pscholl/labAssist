package com.google.android.gms.people.model;

import com.google.android.gms.internal.cv;

public abstract interface PhoneNumber
  extends ValueAndType
{
  public static final Iterable<PhoneNumber> EMPTY_PHONES = new cv();
  
  public abstract String getType();
  
  public abstract String getValue();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.PhoneNumber
 * JD-Core Version:    0.7.0.1
 */