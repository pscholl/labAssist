package com.google.android.gms.people.model;

public abstract interface ValueAndType
{
  public abstract String getType();
  
  public abstract String getValue();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.ValueAndType
 * JD-Core Version:    0.7.0.1
 */