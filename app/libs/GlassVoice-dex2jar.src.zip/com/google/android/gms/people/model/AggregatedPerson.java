package com.google.android.gms.people.model;

public abstract interface AggregatedPerson
  extends Person
{
  @Deprecated
  public abstract String getAccountName();
  
  public abstract String getAvatarUrl();
  
  public abstract Iterable<Long> getContactIds();
  
  public abstract Iterable<EmailAddress> getEmailAddresses();
  
  public abstract String getFamilyName();
  
  public abstract String getGaiaId();
  
  public abstract String getGivenName();
  
  public abstract String getName();
  
  public abstract String getOwnerAccountName();
  
  public abstract String getOwnerPlusPageId();
  
  public abstract Iterable<PhoneNumber> getPhoneNumbers();
  
  @Deprecated
  public abstract String getPlusPageGaiaId();
  
  public abstract String getQualifiedId();
  
  public abstract boolean hasContact();
  
  public abstract boolean hasPlusPerson();
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.people.model.AggregatedPerson
 * JD-Core Version:    0.7.0.1
 */