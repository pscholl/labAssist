package com.google.android.gms.common.server.response;

import android.content.ContentValues;

public abstract class FastContentValuesJsonResponse
  extends FastJsonResponse
{
  private final ContentValues uH;
  
  public FastContentValuesJsonResponse()
  {
    this.uH = new ContentValues();
  }
  
  public FastContentValuesJsonResponse(ContentValues paramContentValues)
  {
    this.uH = paramContentValues;
  }
  
  protected Object getValueObject(String paramString)
  {
    return this.uH.get(paramString);
  }
  
  public ContentValues getValues()
  {
    return this.uH;
  }
  
  protected boolean isPrimitiveFieldSet(String paramString)
  {
    return this.uH.containsKey(paramString);
  }
  
  protected void setBoolean(String paramString, boolean paramBoolean)
  {
    this.uH.put(paramString, Boolean.valueOf(paramBoolean));
  }
  
  protected void setDecodedBytes(String paramString, byte[] paramArrayOfByte)
  {
    this.uH.put(paramString, paramArrayOfByte);
  }
  
  protected void setDouble(String paramString, double paramDouble)
  {
    this.uH.put(paramString, Double.valueOf(paramDouble));
  }
  
  protected void setFloat(String paramString, float paramFloat)
  {
    this.uH.put(paramString, Float.valueOf(paramFloat));
  }
  
  protected void setInteger(String paramString, int paramInt)
  {
    this.uH.put(paramString, Integer.valueOf(paramInt));
  }
  
  protected void setLong(String paramString, long paramLong)
  {
    this.uH.put(paramString, Long.valueOf(paramLong));
  }
  
  protected void setString(String paramString1, String paramString2)
  {
    this.uH.put(paramString1, paramString2);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.FastContentValuesJsonResponse
 * JD-Core Version:    0.7.0.1
 */