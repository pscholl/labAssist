package com.google.android.gms.common;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.R.string;
import com.google.android.gms.internal.aj;
import com.google.android.gms.internal.an;
import com.google.android.gms.internal.bn;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.Arrays;

public final class GooglePlayServicesUtil
{
  public static final String GMS_ERROR_DIALOG = "GooglePlayServicesErrorDialog";
  public static final String GOOGLE_PLAY_SERVICES_PACKAGE = "com.google.android.gms";
  public static final int GOOGLE_PLAY_SERVICES_VERSION_CODE = 4324000;
  public static final String GOOGLE_PLAY_STORE_PACKAGE = "com.android.vending";
  static final byte[][] qA;
  static final byte[][] qB;
  static final byte[][] qC;
  static final byte[][] qD;
  private static final byte[][] qE;
  private static final byte[][] qF;
  static final byte[][] qG;
  public static boolean qH = false;
  public static boolean qI = false;
  static boolean qJ = false;
  private static int qK = -1;
  private static final Object qL = new Object();
  static final byte[][] qz;
  
  static
  {
    byte[][] arrayOfByte1 = new byte[2][];
    arrayOfByte1[0] = t("");
    arrayOfByte1[1] = t("");
    qz = arrayOfByte1;
    byte[][] arrayOfByte2 = new byte[2][];
    arrayOfByte2[0] = t("");
    arrayOfByte2[1] = t("");
    qA = arrayOfByte2;
    byte[][] arrayOfByte3 = new byte[1][];
    arrayOfByte3[0] = t("");
    qB = arrayOfByte3;
    byte[][] arrayOfByte4 = new byte[2][];
    arrayOfByte4[0] = t("");
    arrayOfByte4[1] = t("");
    qC = arrayOfByte4;
    byte[][] arrayOfByte5 = new byte[2][];
    arrayOfByte5[0] = t("");
    arrayOfByte5[1] = t("");
    qD = arrayOfByte5;
    byte[][][] arrayOfByte = new byte[5][][];
    arrayOfByte[0] = qz;
    arrayOfByte[1] = qA;
    arrayOfByte[2] = qB;
    arrayOfByte[3] = qC;
    arrayOfByte[4] = qD;
    qE = a(arrayOfByte);
    byte[][] arrayOfByte6 = new byte[4][];
    arrayOfByte6[0] = qz[0];
    arrayOfByte6[1] = qA[0];
    arrayOfByte6[2] = qC[0];
    arrayOfByte6[3] = qD[0];
    qF = arrayOfByte6;
    byte[][] arrayOfByte7 = new byte[1][];
    arrayOfByte7[0] = t("");
    qG = arrayOfByte7;
  }
  
  static boolean Z(int paramInt)
  {
    boolean bool = true;
    switch (aa(paramInt))
    {
    default: 
      bool = false;
    case 1: 
    case 0: 
      do
      {
        return bool;
      } while (!bl());
      return false;
    }
    return false;
  }
  
  public static String a(Context paramContext, int paramInt)
  {
    Resources localResources = paramContext.getResources();
    switch (paramInt)
    {
    default: 
      return localResources.getString(17039370);
    case 1: 
      return localResources.getString(R.string.common_google_play_services_install_button);
    case 3: 
      return localResources.getString(R.string.common_google_play_services_enable_button);
    }
    return localResources.getString(R.string.common_google_play_services_update_button);
  }
  
  public static String a(Context paramContext, int paramInt1, int paramInt2)
  {
    Resources localResources = paramContext.getResources();
    String str;
    switch (paramInt1)
    {
    case 4: 
    case 6: 
    case 8: 
    case 10: 
    case 11: 
    default: 
      str = localResources.getString(R.string.common_google_play_services_unknown_issue);
    case 1: 
    case 3: 
    case 2: 
      do
      {
        return str;
        if (a(paramContext.getResources())) {}
        for (str = localResources.getString(R.string.common_google_play_services_install_text_tablet); Z(paramInt2); str = localResources.getString(R.string.common_google_play_services_install_text_phone)) {
          return str + " (via Bazaar)";
        }
        return localResources.getString(R.string.common_google_play_services_enable_text);
        str = localResources.getString(R.string.common_google_play_services_update_text);
      } while (!Z(paramInt2));
      return str + " (via Bazaar)";
    case 9: 
      return localResources.getString(R.string.common_google_play_services_unsupported_text);
    case 7: 
      return localResources.getString(R.string.common_google_play_services_network_error_text);
    case 5: 
      return localResources.getString(R.string.common_google_play_services_invalid_account_text);
    }
    return localResources.getString(R.string.common_google_play_services_unsupported_date_text);
  }
  
  public static boolean a(PackageManager paramPackageManager)
  {
    synchronized (qL)
    {
      int i = qK;
      if (i == -1) {}
      try
      {
        PackageInfo localPackageInfo = paramPackageManager.getPackageInfo("com.google.android.gms", 64);
        byte[][] arrayOfByte = new byte[1][];
        arrayOfByte[0] = qE[1];
        if (a(localPackageInfo, arrayOfByte) != null) {}
        for (qK = 1; qK != 0; qK = 0) {
          return true;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        for (;;)
        {
          qK = 0;
        }
      }
    }
    return false;
  }
  
  public static boolean a(Resources paramResources)
  {
    if (paramResources == null) {}
    for (;;)
    {
      return false;
      if ((0xF & paramResources.getConfiguration().screenLayout) > 3) {}
      for (int i = 1; ((bn.cm()) && (i != 0)) || (b(paramResources)); i = 0) {
        return true;
      }
    }
  }
  
  private static byte[] a(PackageInfo paramPackageInfo, byte[]... paramVarArgs)
  {
    CertificateFactory localCertificateFactory;
    try
    {
      localCertificateFactory = CertificateFactory.getInstance("X509");
      if (paramPackageInfo.signatures.length != 1)
      {
        Log.w("GooglePlayServicesUtil", "Package has more than one signature.");
        return null;
      }
    }
    catch (CertificateException localCertificateException1)
    {
      Log.w("GooglePlayServicesUtil", "Could not get certificate instance.");
      return null;
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPackageInfo.signatures[0].toByteArray());
    byte[] arrayOfByte1;
    label151:
    for (;;)
    {
      try
      {
        X509Certificate localX509Certificate = (X509Certificate)localCertificateFactory.generateCertificate(localByteArrayInputStream);
        int i;
        byte[] arrayOfByte2;
        i++;
      }
      catch (CertificateException localCertificateException2)
      {
        try
        {
          localX509Certificate.checkValidity();
          arrayOfByte1 = paramPackageInfo.signatures[0].toByteArray();
          i = 0;
          if (i >= paramVarArgs.length) {
            break;
          }
          arrayOfByte2 = paramVarArgs[i];
          if (!Arrays.equals(arrayOfByte2, arrayOfByte1)) {
            break label151;
          }
          return arrayOfByte2;
        }
        catch (CertificateExpiredException localCertificateExpiredException)
        {
          Log.w("GooglePlayServicesUtil", "Certificate has expired.");
          return null;
        }
        catch (CertificateNotYetValidException localCertificateNotYetValidException)
        {
          Log.w("GooglePlayServicesUtil", "Certificate is not yet valid.");
          return null;
        }
        localCertificateException2 = localCertificateException2;
        Log.w("GooglePlayServicesUtil", "Could not generate certificate.");
        return null;
      }
    }
    if (Log.isLoggable("GooglePlayServicesUtil", 2)) {
      Log.v("GooglePlayServicesUtil", "Signature not valid.  Found: \n" + Base64.encodeToString(arrayOfByte1, 0));
    }
    return null;
  }
  
  private static byte[][] a(byte[][]... paramVarArgs)
  {
    int i = paramVarArgs.length;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      k += paramVarArgs[j].length;
      j++;
    }
    byte[][] arrayOfByte = new byte[k][];
    int m = paramVarArgs.length;
    int n = 0;
    int i2;
    for (int i1 = 0; n < m; i1 = i2)
    {
      byte[][] arrayOfByte1 = paramVarArgs[n];
      i2 = i1;
      int i3 = 0;
      while (i3 < arrayOfByte1.length)
      {
        int i4 = i2 + 1;
        arrayOfByte[i2] = arrayOfByte1[i3];
        i3++;
        i2 = i4;
      }
      n++;
    }
    return arrayOfByte;
  }
  
  private static int aa(int paramInt)
  {
    if (paramInt == -1) {
      paramInt = 2;
    }
    return paramInt;
  }
  
  private static boolean b(Resources paramResources)
  {
    Configuration localConfiguration = paramResources.getConfiguration();
    boolean bool1 = bn.cn();
    boolean bool2 = false;
    if (bool1)
    {
      int i = 0xF & localConfiguration.screenLayout;
      bool2 = false;
      if (i <= 3)
      {
        int j = localConfiguration.smallestScreenWidthDp;
        bool2 = false;
        if (j >= 600) {
          bool2 = true;
        }
      }
    }
    return bool2;
  }
  
  public static boolean bl()
  {
    if (qH) {
      return qI;
    }
    return "user".equals(Build.TYPE);
  }
  
  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2)
  {
    return getErrorDialog(paramInt1, paramActivity, paramInt2, null, -1);
  }
  
  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener)
  {
    return getErrorDialog(paramInt1, paramActivity, paramInt2, paramOnCancelListener, -1);
  }
  
  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener, int paramInt3)
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(paramActivity).setMessage(a(paramActivity, paramInt1, paramInt3));
    if (paramOnCancelListener != null) {
      localBuilder.setOnCancelListener(paramOnCancelListener);
    }
    aj localaj = new aj(paramActivity, getGooglePlayServicesAvailabilityRecoveryIntent(paramActivity, paramInt1, paramInt3), paramInt2);
    String str = a(paramActivity, paramInt1);
    if (str != null) {
      localBuilder.setPositiveButton(str, localaj);
    }
    switch (paramInt1)
    {
    default: 
      Log.e("GooglePlayServicesUtil", "Unexpected error code " + paramInt1);
      return localBuilder.create();
    case 0: 
      return null;
    case 4: 
    case 6: 
      return localBuilder.create();
    case 1: 
      return localBuilder.setTitle(R.string.common_google_play_services_install_title).create();
    case 3: 
      return localBuilder.setTitle(R.string.common_google_play_services_enable_title).create();
    case 2: 
      return localBuilder.setTitle(R.string.common_google_play_services_update_title).create();
    case 9: 
      Log.e("GooglePlayServicesUtil", "Google Play services is invalid. Cannot recover.");
      return localBuilder.setTitle(R.string.common_google_play_services_unsupported_title).create();
    case 7: 
      Log.e("GooglePlayServicesUtil", "Network error occurred. Please retry request later.");
      return localBuilder.setTitle(R.string.common_google_play_services_network_error_title).create();
    case 8: 
      Log.e("GooglePlayServicesUtil", "Internal error occurred. Please see logs for detailed information");
      return localBuilder.create();
    case 10: 
      Log.e("GooglePlayServicesUtil", "Developer error occurred. Please see logs for detailed information");
      return localBuilder.create();
    case 5: 
      Log.e("GooglePlayServicesUtil", "An invalid account was specified when connecting. Please provide a valid account.");
      return localBuilder.setTitle(R.string.common_google_play_services_invalid_account_title).create();
    case 11: 
      Log.e("GooglePlayServicesUtil", "The application is not licensed to the user.");
      return localBuilder.create();
    }
    Log.e("GooglePlayServicesUtil", "The date of the device is not valid.");
    return localBuilder.setTitle(R.string.common_google_play_services_unsupported_title).create();
  }
  
  public static PendingIntent getErrorPendingIntent(int paramInt1, Context paramContext, int paramInt2)
  {
    Intent localIntent = getGooglePlayServicesAvailabilityRecoveryIntent(paramContext, paramInt1, -1);
    if (localIntent == null) {
      return null;
    }
    return PendingIntent.getActivity(paramContext, paramInt2, localIntent, 268435456);
  }
  
  public static String getErrorString(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return "UNKNOWN_ERROR_CODE";
    case 0: 
      return "SUCCESS";
    case 1: 
      return "SERVICE_MISSING";
    case 2: 
      return "SERVICE_VERSION_UPDATE_REQUIRED";
    case 3: 
      return "SERVICE_DISABLED";
    case 4: 
      return "SIGN_IN_REQUIRED";
    case 5: 
      return "INVALID_ACCOUNT";
    case 6: 
      return "RESOLUTION_REQUIRED";
    case 7: 
      return "NETWORK_ERROR";
    case 8: 
      return "INTERNAL_ERROR";
    case 9: 
      return "SERVICE_INVALID";
    case 10: 
      return "DEVELOPER_ERROR";
    case 11: 
      return "LICENSE_CHECK_FAILED";
    }
    return "DATE_INVALID";
  }
  
  public static Intent getGooglePlayServicesAvailabilityRecoveryIntent(Context paramContext, int paramInt1, int paramInt2)
  {
    switch (paramInt1)
    {
    default: 
      return null;
    case 1: 
    case 2: 
      if (Z(paramInt2))
      {
        if (o(paramContext)) {
          return an.B("com.google.android.gms");
        }
        return an.A("com.google.android.apps.bazaar");
      }
      return an.A("com.google.android.gms");
    case 3: 
      return an.y("com.google.android.gms");
    }
    return an.bZ();
  }
  
  /* Error */
  public static String getOpenSourceSoftwareLicenseInfo(Context paramContext)
  {
    // Byte code:
    //   0: new 453	android/net/Uri$Builder
    //   3: dup
    //   4: invokespecial 454	android/net/Uri$Builder:<init>	()V
    //   7: ldc_w 456
    //   10: invokevirtual 460	android/net/Uri$Builder:scheme	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   13: ldc 11
    //   15: invokevirtual 463	android/net/Uri$Builder:authority	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   18: ldc_w 465
    //   21: invokevirtual 468	android/net/Uri$Builder:appendPath	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   24: ldc_w 470
    //   27: invokevirtual 468	android/net/Uri$Builder:appendPath	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   30: invokevirtual 474	android/net/Uri$Builder:build	()Landroid/net/Uri;
    //   33: astore_1
    //   34: aload_0
    //   35: invokevirtual 478	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   38: aload_1
    //   39: invokevirtual 484	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   42: astore 4
    //   44: new 486	java/util/Scanner
    //   47: dup
    //   48: aload 4
    //   50: invokespecial 489	java/util/Scanner:<init>	(Ljava/io/InputStream;)V
    //   53: ldc_w 491
    //   56: invokevirtual 495	java/util/Scanner:useDelimiter	(Ljava/lang/String;)Ljava/util/Scanner;
    //   59: invokevirtual 498	java/util/Scanner:next	()Ljava/lang/String;
    //   62: astore 7
    //   64: aload 7
    //   66: astore_3
    //   67: aload 4
    //   69: ifnull +43 -> 112
    //   72: aload 4
    //   74: invokevirtual 503	java/io/InputStream:close	()V
    //   77: aload_3
    //   78: areturn
    //   79: astore 6
    //   81: aload 4
    //   83: ifnull +31 -> 114
    //   86: aload 4
    //   88: invokevirtual 503	java/io/InputStream:close	()V
    //   91: goto +23 -> 114
    //   94: astore 5
    //   96: aload 4
    //   98: ifnull +8 -> 106
    //   101: aload 4
    //   103: invokevirtual 503	java/io/InputStream:close	()V
    //   106: aload 5
    //   108: athrow
    //   109: astore_2
    //   110: aconst_null
    //   111: astore_3
    //   112: aload_3
    //   113: areturn
    //   114: aconst_null
    //   115: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	116	0	paramContext	Context
    //   33	6	1	localUri	android.net.Uri
    //   109	1	2	localException	java.lang.Exception
    //   66	47	3	str1	String
    //   42	60	4	localInputStream	java.io.InputStream
    //   94	13	5	localObject	Object
    //   79	1	6	localNoSuchElementException	java.util.NoSuchElementException
    //   62	3	7	str2	String
    // Exception table:
    //   from	to	target	type
    //   44	64	79	java/util/NoSuchElementException
    //   44	64	94	finally
    //   34	44	109	java/lang/Exception
    //   72	77	109	java/lang/Exception
    //   86	91	109	java/lang/Exception
    //   101	106	109	java/lang/Exception
    //   106	109	109	java/lang/Exception
  }
  
  public static Context getRemoteContext(Context paramContext)
  {
    try
    {
      Context localContext = paramContext.createPackageContext("com.google.android.gms", 3);
      return localContext;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return null;
  }
  
  public static Resources getRemoteResource(Context paramContext)
  {
    try
    {
      Resources localResources = paramContext.getPackageManager().getResourcesForApplication("com.google.android.gms");
      return localResources;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return null;
  }
  
  public static boolean honorsDebugCertificates(PackageManager paramPackageManager)
  {
    return (a(paramPackageManager)) || (!bl());
  }
  
  public static int isGooglePlayServicesAvailable(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      paramContext.getResources().getString(R.string.common_google_play_services_unknown_issue);
      if (System.currentTimeMillis() < 1227312000288L) {
        return 12;
      }
    }
    catch (Throwable localThrowable)
    {
      for (;;)
      {
        Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
      }
      n(paramContext);
      PackageInfo localPackageInfo1;
      PackageInfo localPackageInfo2;
      try
      {
        localPackageInfo1 = localPackageManager.getPackageInfo("com.google.android.gms", 64);
        byte[][] arrayOfByte3;
        arrayOfByte4 = new byte[2][];
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException1)
      {
        try
        {
          localPackageInfo2 = localPackageManager.getPackageInfo(paramContext.getPackageName(), 64);
          if (bl()) {
            break label220;
          }
          arrayOfByte3 = new byte[2][];
          arrayOfByte3[0] = qz[1];
          arrayOfByte3[1] = qD[1];
          if (a(localPackageInfo1, arrayOfByte3) != null) {
            break label147;
          }
          Log.w("GooglePlayServicesUtil", "Google Play services signature (test key) invalid on Glass.");
          return 9;
        }
        catch (PackageManager.NameNotFoundException localNameNotFoundException2)
        {
          Log.w("GooglePlayServicesUtil", "Calling package info missing.");
          return 9;
        }
        localNameNotFoundException1 = localNameNotFoundException1;
        Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
        return 1;
      }
      label147:
      byte[][] arrayOfByte4;
      arrayOfByte4[0] = qz[1];
      arrayOfByte4[1] = qD[1];
      if (a(localPackageInfo2, arrayOfByte4) == null)
      {
        Log.w("GooglePlayServicesUtil", "Calling package " + localPackageInfo2.packageName + "signature (test key) invalid on Glass.");
        return 9;
        label220:
        byte[][] arrayOfByte1 = new byte[2][];
        arrayOfByte1[0] = qz[0];
        arrayOfByte1[1] = qD[0];
        if (a(localPackageInfo1, arrayOfByte1) == null)
        {
          Log.w("GooglePlayServicesUtil", "Google Play services signature invalid (release key) on Glass.");
          return 9;
        }
        byte[][] arrayOfByte2 = new byte[1][];
        arrayOfByte2[0] = qD[0];
        if (a(localPackageInfo2, arrayOfByte2) == null)
        {
          Log.w("GooglePlayServicesUtil", "Calling package " + localPackageInfo2.packageName + "signature (release key) invalid on Glass.");
          return 9;
        }
      }
      if (localPackageInfo1.versionCode < 4324000)
      {
        Log.w("GooglePlayServicesUtil", "Google Play services out of date.  Requires 4324000 but found " + localPackageInfo1.versionCode);
        return 2;
      }
      try
      {
        ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo("com.google.android.gms", 0);
        if (!localApplicationInfo.enabled) {
          return 3;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException3)
      {
        Log.wtf("GooglePlayServicesUtil", "Google Play services missing when getting application info.");
        localNameNotFoundException3.printStackTrace();
        return 1;
      }
    }
    return 0;
  }
  
  public static boolean isGoogleSignedPackage(PackageManager paramPackageManager, PackageInfo paramPackageInfo)
  {
    boolean bool1 = true;
    boolean bool2 = false;
    if (paramPackageInfo == null) {}
    do
    {
      return bool2;
      if (honorsDebugCertificates(paramPackageManager))
      {
        if (a(paramPackageInfo, qE) != null) {}
        for (;;)
        {
          return bool1;
          bool1 = false;
        }
      }
      byte[] arrayOfByte = a(paramPackageInfo, qF);
      bool2 = false;
      if (arrayOfByte != null) {
        bool2 = bool1;
      }
    } while ((bool2) || (a(paramPackageInfo, qE) == null));
    Log.w("GooglePlayServicesUtil", "Test-keys aren't accepted on this build.");
    return bool2;
  }
  
  public static boolean isPackageGoogleSigned(PackageManager paramPackageManager, String paramString)
  {
    try
    {
      PackageInfo localPackageInfo = paramPackageManager.getPackageInfo(paramString, 64);
      return isGoogleSignedPackage(paramPackageManager, localPackageInfo);
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      if (Log.isLoggable("GooglePlayServicesUtil", 3)) {
        Log.d("GooglePlayServicesUtil", "Package manager can't find package " + paramString + ", defaulting to false");
      }
    }
    return false;
  }
  
  public static boolean isUserRecoverableError(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return false;
    }
    return true;
  }
  
  public static void m(Context paramContext)
    throws GooglePlayServicesRepairableException, GooglePlayServicesNotAvailableException
  {
    int i = isGooglePlayServicesAvailable(paramContext);
    if (i != 0)
    {
      Intent localIntent = getGooglePlayServicesAvailabilityRecoveryIntent(paramContext, i, -1);
      Log.e("GooglePlayServicesUtil", "GooglePlayServices not available due to error " + i);
      if (localIntent == null) {
        throw new GooglePlayServicesNotAvailableException(i);
      }
      throw new GooglePlayServicesRepairableException(i, "Google Play Services not available", localIntent);
    }
  }
  
  private static void n(Context paramContext)
  {
    try
    {
      ApplicationInfo localApplicationInfo2 = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      localApplicationInfo1 = localApplicationInfo2;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;)
      {
        Bundle localBundle;
        Log.wtf("GooglePlayServicesUtil", "This should never happen.", localNameNotFoundException);
        ApplicationInfo localApplicationInfo1 = null;
      }
    }
    localBundle = localApplicationInfo1.metaData;
    if (localBundle != null)
    {
      int i = localBundle.getInt("com.google.android.gms.version");
      if (i == 4324000) {
        return;
      }
      throw new IllegalStateException("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected 4324000 but found " + i + ".  You must have the" + " following declaration within the <application> element: " + "    <meta-data android:name=\"" + "com.google.android.gms.version" + "\" android:value=\"@integer/google_play_services_version\" />");
    }
    throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
  }
  
  private static boolean o(Context paramContext)
  {
    boolean bool;
    if (qH) {
      bool = qJ;
    }
    for (;;)
    {
      return bool;
      try
      {
        byte[] arrayOfByte = a(paramContext.getPackageManager().getPackageInfo("com.google.android.apps.bazaar", 64), qG);
        bool = false;
        if (arrayOfByte != null) {
          return true;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    }
    return false;
  }
  
  public static boolean showErrorDialogFragment(int paramInt1, Activity paramActivity, int paramInt2)
  {
    return showErrorDialogFragment(paramInt1, paramActivity, paramInt2, null);
  }
  
  public static boolean showErrorDialogFragment(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener)
  {
    Dialog localDialog = getErrorDialog(paramInt1, paramActivity, paramInt2, paramOnCancelListener);
    if (localDialog == null) {
      return false;
    }
    try
    {
      bool = paramActivity instanceof FragmentActivity;
      if (bool)
      {
        android.support.v4.app.FragmentManager localFragmentManager1 = ((FragmentActivity)paramActivity).getSupportFragmentManager();
        b.a(localDialog, paramOnCancelListener).show(localFragmentManager1, "GooglePlayServicesErrorDialog");
      }
      for (;;)
      {
        return true;
        if (!bn.cm()) {
          break;
        }
        android.app.FragmentManager localFragmentManager = paramActivity.getFragmentManager();
        ErrorDialogFragment.newInstance(localDialog, paramOnCancelListener).show(localFragmentManager, "GooglePlayServicesErrorDialog");
      }
      throw new RuntimeException("This Activity does not support Fragments.");
    }
    catch (NoClassDefFoundError localNoClassDefFoundError)
    {
      for (;;)
      {
        boolean bool = false;
      }
    }
  }
  
  private static byte[] t(String paramString)
  {
    try
    {
      byte[] arrayOfByte = paramString.getBytes("ISO-8859-1");
      return arrayOfByte;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new AssertionError(localUnsupportedEncodingException);
    }
  }
  
  public static void verifyPackageIsGoogleSigned(PackageManager paramPackageManager, String paramString)
    throws SecurityException
  {
    if (!isPackageGoogleSigned(paramPackageManager, paramString)) {
      throw new SecurityException();
    }
  }
  
  public static abstract interface RedirectPolicy
  {
    public static final int DEFAULT = -1;
    public static final int FROM_BAZAAR_ALWAYS = 1;
    public static final int FROM_BAZAAR_ONLY_IF_NOT_USER_BUILD = 0;
    public static final int FROM_PLAY_STORE_ALWAYS = 2;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.GooglePlayServicesUtil
 * JD-Core Version:    0.7.0.1
 */