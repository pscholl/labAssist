package com.google.android.gms.common.people.data;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;

public class b
  implements Parcelable.Creator<AudienceMember>
{
  static void a(AudienceMember paramAudienceMember, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramAudienceMember.getType());
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1000, paramAudienceMember.getVersionCode());
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 2, paramAudienceMember.getCircleType());
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramAudienceMember.getCircleId(), false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 4, paramAudienceMember.getPeopleQualifiedId(), false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 5, paramAudienceMember.getDisplayName(), false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 6, paramAudienceMember.getAvatarUrl(), false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 7, paramAudienceMember.getMetadata(), false);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public AudienceMember ab(Parcel paramParcel)
  {
    int i = 0;
    Bundle localBundle = null;
    int j = a.Y(paramParcel);
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    int k = 0;
    int m = 0;
    while (paramParcel.dataPosition() < j)
    {
      int n = a.X(paramParcel);
      switch (a.al(n))
      {
      default: 
        a.b(paramParcel, n);
        break;
      case 1: 
        k = a.f(paramParcel, n);
        break;
      case 1000: 
        m = a.f(paramParcel, n);
        break;
      case 2: 
        i = a.f(paramParcel, n);
        break;
      case 3: 
        str4 = a.l(paramParcel, n);
        break;
      case 4: 
        str3 = a.l(paramParcel, n);
        break;
      case 5: 
        str2 = a.l(paramParcel, n);
        break;
      case 6: 
        str1 = a.l(paramParcel, n);
        break;
      case 7: 
        localBundle = a.n(paramParcel, n);
      }
    }
    if (paramParcel.dataPosition() != j) {
      throw new a.a("Overread allowed size end=" + j, paramParcel);
    }
    return new AudienceMember(m, k, i, str4, str3, str2, str1, localBundle);
  }
  
  public AudienceMember[] ao(int paramInt)
  {
    return new AudienceMember[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.people.data.b
 * JD-Core Version:    0.7.0.1
 */