package com.google.android.gms.common.server.response;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class FieldMappingDictionary
  implements SafeParcelable
{
  public static final c CREATOR = new c();
  private final int oj;
  private final HashMap<String, HashMap<String, FastJsonResponse.Field<?, ?>>> vi;
  private final ArrayList<Entry> vj;
  private final String vk;
  
  FieldMappingDictionary(int paramInt, ArrayList<Entry> paramArrayList, String paramString)
  {
    this.oj = paramInt;
    this.vj = null;
    this.vi = b(paramArrayList);
    this.vk = ((String)at.f(paramString));
    linkFields();
  }
  
  public FieldMappingDictionary(Class<? extends FastJsonResponse> paramClass)
  {
    this.oj = 1;
    this.vj = null;
    this.vi = new HashMap();
    this.vk = paramClass.getCanonicalName();
  }
  
  private static HashMap<String, HashMap<String, FastJsonResponse.Field<?, ?>>> b(ArrayList<Entry> paramArrayList)
  {
    HashMap localHashMap = new HashMap();
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
    {
      Entry localEntry = (Entry)paramArrayList.get(j);
      localHashMap.put(localEntry.className, localEntry.ch());
    }
    return localHashMap;
  }
  
  ArrayList<Entry> cg()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.vi.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localArrayList.add(new Entry(str, (HashMap)this.vi.get(str)));
    }
    return localArrayList;
  }
  
  public void copyInternalFieldMappings()
  {
    Iterator localIterator1 = this.vi.keySet().iterator();
    while (localIterator1.hasNext())
    {
      String str1 = (String)localIterator1.next();
      HashMap localHashMap1 = (HashMap)this.vi.get(str1);
      HashMap localHashMap2 = new HashMap();
      Iterator localIterator2 = localHashMap1.keySet().iterator();
      while (localIterator2.hasNext())
      {
        String str2 = (String)localIterator2.next();
        localHashMap2.put(str2, ((FastJsonResponse.Field)localHashMap1.get(str2)).copyForDictionary());
      }
      this.vi.put(str1, localHashMap2);
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public HashMap<String, FastJsonResponse.Field<?, ?>> getFieldMapping(Class<? extends FastJsonResponse> paramClass)
  {
    return (HashMap)this.vi.get(paramClass.getCanonicalName());
  }
  
  public HashMap<String, FastJsonResponse.Field<?, ?>> getFieldMapping(String paramString)
  {
    return (HashMap)this.vi.get(paramString);
  }
  
  public String getRootClassName()
  {
    return this.vk;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public boolean hasFieldMappingForClass(Class<? extends FastJsonResponse> paramClass)
  {
    return this.vi.containsKey(paramClass.getCanonicalName());
  }
  
  public void linkFields()
  {
    Iterator localIterator1 = this.vi.keySet().iterator();
    while (localIterator1.hasNext())
    {
      String str = (String)localIterator1.next();
      HashMap localHashMap = (HashMap)this.vi.get(str);
      Iterator localIterator2 = localHashMap.keySet().iterator();
      while (localIterator2.hasNext()) {
        ((FastJsonResponse.Field)localHashMap.get((String)localIterator2.next())).setFieldMappingDictionary(this);
      }
    }
  }
  
  public void put(Class<? extends FastJsonResponse> paramClass, HashMap<String, FastJsonResponse.Field<?, ?>> paramHashMap)
  {
    this.vi.put(paramClass.getCanonicalName(), paramHashMap);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator1 = this.vi.keySet().iterator();
    while (localIterator1.hasNext())
    {
      String str1 = (String)localIterator1.next();
      localStringBuilder.append(str1).append(":\n");
      HashMap localHashMap = (HashMap)this.vi.get(str1);
      Iterator localIterator2 = localHashMap.keySet().iterator();
      while (localIterator2.hasNext())
      {
        String str2 = (String)localIterator2.next();
        localStringBuilder.append("  ").append(str2).append(": ");
        localStringBuilder.append(localHashMap.get(str2));
      }
    }
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    c.a(this, paramParcel, paramInt);
  }
  
  public static class Entry
    implements SafeParcelable
  {
    public static final d CREATOR = new d();
    final String className;
    final int versionCode;
    final ArrayList<FieldMappingDictionary.FieldMapPair> vl;
    
    Entry(int paramInt, String paramString, ArrayList<FieldMappingDictionary.FieldMapPair> paramArrayList)
    {
      this.versionCode = paramInt;
      this.className = paramString;
      this.vl = paramArrayList;
    }
    
    Entry(String paramString, HashMap<String, FastJsonResponse.Field<?, ?>> paramHashMap)
    {
      this.versionCode = 1;
      this.className = paramString;
      this.vl = c(paramHashMap);
    }
    
    private static ArrayList<FieldMappingDictionary.FieldMapPair> c(HashMap<String, FastJsonResponse.Field<?, ?>> paramHashMap)
    {
      if (paramHashMap == null) {
        return null;
      }
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = paramHashMap.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localArrayList.add(new FieldMappingDictionary.FieldMapPair(str, (FastJsonResponse.Field)paramHashMap.get(str)));
      }
      return localArrayList;
    }
    
    HashMap<String, FastJsonResponse.Field<?, ?>> ch()
    {
      HashMap localHashMap = new HashMap();
      int i = this.vl.size();
      for (int j = 0; j < i; j++)
      {
        FieldMappingDictionary.FieldMapPair localFieldMapPair = (FieldMappingDictionary.FieldMapPair)this.vl.get(j);
        localHashMap.put(localFieldMapPair.key, localFieldMapPair.vm);
      }
      return localHashMap;
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      d.a(this, paramParcel, paramInt);
    }
  }
  
  public static class FieldMapPair
    implements SafeParcelable
  {
    public static final b CREATOR = new b();
    final String key;
    final int versionCode;
    final FastJsonResponse.Field<?, ?> vm;
    
    FieldMapPair(int paramInt, String paramString, FastJsonResponse.Field<?, ?> paramField)
    {
      this.versionCode = paramInt;
      this.key = paramString;
      this.vm = paramField;
    }
    
    FieldMapPair(String paramString, FastJsonResponse.Field<?, ?> paramField)
    {
      this.versionCode = 1;
      this.key = paramString;
      this.vm = paramField;
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      b.a(this, paramParcel, paramInt);
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.FieldMappingDictionary
 * JD-Core Version:    0.7.0.1
 */