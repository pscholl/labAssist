package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.IntentSender.SendIntentException;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.ar.a;

public final class Status
  implements Result, SafeParcelable
{
  public static final StatusCreator CREATOR = new StatusCreator();
  public static final Status rF = new Status(0, null, null);
  public static final Status rG = new Status(14, null, null);
  public static final Status rH = new Status(15, null, null);
  private final PendingIntent mPendingIntent;
  private final int oj;
  private final int qx;
  private final String rI;
  
  public Status(int paramInt)
  {
    this(1, paramInt, null, null);
  }
  
  Status(int paramInt1, int paramInt2, String paramString, PendingIntent paramPendingIntent)
  {
    this.oj = paramInt1;
    this.qx = paramInt2;
    this.rI = paramString;
    this.mPendingIntent = paramPendingIntent;
  }
  
  public Status(int paramInt, String paramString, PendingIntent paramPendingIntent)
  {
    this(1, paramInt, paramString, paramPendingIntent);
  }
  
  private String bk()
  {
    if (this.rI != null) {
      return this.rI;
    }
    return CommonStatusCodes.getStatusCodeString(this.qx);
  }
  
  String bC()
  {
    return this.rI;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Status)) {}
    Status localStatus;
    do
    {
      return false;
      localStatus = (Status)paramObject;
    } while ((this.oj != localStatus.oj) || (this.qx != localStatus.qx) || (!ar.equal(this.rI, localStatus.rI)) || (!ar.equal(this.mPendingIntent, localStatus.mPendingIntent)));
    return true;
  }
  
  PendingIntent getPendingIntent()
  {
    return this.mPendingIntent;
  }
  
  public PendingIntent getResolution()
  {
    return this.mPendingIntent;
  }
  
  public Status getStatus()
  {
    return this;
  }
  
  public int getStatusCode()
  {
    return this.qx;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public boolean hasResolution()
  {
    return this.mPendingIntent != null;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = Integer.valueOf(this.oj);
    arrayOfObject[1] = Integer.valueOf(this.qx);
    arrayOfObject[2] = this.rI;
    arrayOfObject[3] = this.mPendingIntent;
    return ar.hashCode(arrayOfObject);
  }
  
  public boolean isInterrupted()
  {
    return this.qx == 14;
  }
  
  public boolean isSuccess()
  {
    return this.qx <= 0;
  }
  
  public void startResolutionForResult(Activity paramActivity, int paramInt)
    throws IntentSender.SendIntentException
  {
    if (!hasResolution()) {
      return;
    }
    paramActivity.startIntentSenderForResult(this.mPendingIntent.getIntentSender(), paramInt, null, 0, 0, 0);
  }
  
  public String toString()
  {
    return ar.e(this).a("statusCode", bk()).a("resolution", this.mPendingIntent).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    StatusCreator.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Status
 * JD-Core Version:    0.7.0.1
 */