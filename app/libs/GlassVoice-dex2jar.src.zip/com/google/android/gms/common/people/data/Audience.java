package com.google.android.gms.common.people.data;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import java.util.Collections;
import java.util.List;

public final class Audience
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  public static final int DOMAIN_RESTRICTED_NOT_SET = 0;
  public static final int DOMAIN_RESTRICTED_RESTRICTED = 1;
  public static final int DOMAIN_RESTRICTED_UNRESTRICTED = 2;
  private final int oj;
  private final List<AudienceMember> uq;
  private final int ur;
  @Deprecated
  private final boolean us;
  private final boolean ut;
  
  Audience(int paramInt1, List<AudienceMember> paramList, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    if ((paramInt1 == i) && (paramList == null)) {
      paramList = Collections.emptyList();
    }
    this.oj = paramInt1;
    this.uq = Collections.unmodifiableList(paramList);
    this.ur = paramInt2;
    if (paramInt1 == i)
    {
      this.us = paramBoolean1;
      if (!paramBoolean1) {}
      for (;;)
      {
        this.ut = i;
        return;
        i = 0;
      }
    }
    this.ut = paramBoolean2;
    if (!paramBoolean2) {}
    for (;;)
    {
      this.us = i;
      return;
      i = 0;
    }
  }
  
  Audience(List<AudienceMember> paramList, int paramInt, boolean paramBoolean)
  {
    this.oj = 2;
    this.uq = paramList;
    this.ur = paramInt;
    this.ut = paramBoolean;
    if (!paramBoolean) {}
    for (boolean bool = true;; bool = false)
    {
      this.us = bool;
      return;
    }
  }
  
  @Deprecated
  boolean ca()
  {
    return this.us;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Audience)) {}
    Audience localAudience;
    do
    {
      return false;
      localAudience = (Audience)paramObject;
    } while ((this.oj != localAudience.oj) || (!ar.equal(this.uq, localAudience.uq)) || (this.ur != localAudience.ur) || (this.ut != localAudience.ut));
    return true;
  }
  
  public List<AudienceMember> getAudienceMemberList()
  {
    return this.uq;
  }
  
  public int getDomainRestricted()
  {
    return this.ur;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = Integer.valueOf(this.oj);
    arrayOfObject[1] = this.uq;
    arrayOfObject[2] = Integer.valueOf(this.ur);
    arrayOfObject[3] = Boolean.valueOf(this.ut);
    return ar.hashCode(arrayOfObject);
  }
  
  public boolean isReadOnly()
  {
    return this.ut;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.people.data.Audience
 * JD-Core Version:    0.7.0.1
 */