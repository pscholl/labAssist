package com.google.android.gms.common.audience.dialogs;

import android.content.Intent;
import com.google.android.gms.common.people.data.Audience;
import com.google.android.gms.common.people.data.AudienceMember;
import com.google.android.gms.internal.de;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AudienceSelectionIntentBuilder
  implements AclSelection.Builder, AclSelection.Results, CircleSelection.Results, CircleSelection.SelectBuilder, CircleSelection.UpdateBuilder, FaclSelection.Builder, FaclSelection.Results
{
  public static final int DOMAIN_RESTRICTED_NOT_VISIBLE = 0;
  public static final int DOMAIN_RESTRICTED_OFF = 2;
  public static final int DOMAIN_RESTRICTED_ON = 1;
  private final Intent mIntent;
  
  public AudienceSelectionIntentBuilder(Intent paramIntent)
  {
    this.mIntent = new Intent(paramIntent);
  }
  
  public AudienceSelectionIntentBuilder(String paramString)
  {
    this(new Intent(paramString).setPackage("com.google.android.gms"));
  }
  
  private static <T> ArrayList<T> a(List<T> paramList)
  {
    if ((paramList instanceof ArrayList)) {
      return (ArrayList)paramList;
    }
    return new ArrayList(paramList);
  }
  
  public static String getAccountName(Intent paramIntent)
  {
    return paramIntent.getStringExtra("com.google.android.gms.common.acl.EXTRA_ACCOUNT_NAME");
  }
  
  public static ArrayList<AudienceMember> getAddedAudienceDelta(Intent paramIntent)
  {
    return paramIntent.getParcelableArrayListExtra("com.google.android.gms.common.acl.EXTRA_ADDED_AUDIENCE");
  }
  
  public static boolean getAllowEmptySelection(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("ALLOW_EMPTY", paramBoolean);
  }
  
  public static String getCancelText(Intent paramIntent)
  {
    return paramIntent.getStringExtra("CANCEL_TEXT");
  }
  
  public static String getClientApplicationId(Intent paramIntent)
  {
    return paramIntent.getStringExtra("com.google.android.gms.common.acl.EXTRA_CLIENT_APPLICATION_ID");
  }
  
  public static String getDescription(Intent paramIntent)
  {
    return paramIntent.getStringExtra("DESCRIPTION_TEXT");
  }
  
  public static int getDomainRestricted(Intent paramIntent, int paramInt)
  {
    return paramIntent.getIntExtra("com.google.android.gms.common.acl.EXTRA_DOMAIN_RESTRICTED", paramInt);
  }
  
  public static String getEveryoneCheckboxText(Intent paramIntent)
  {
    return paramIntent.getStringExtra("EVERYONE_CHECKBOX_TEXT");
  }
  
  public static boolean getEveryoneChecked(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("EVERYONE_CHECKED", paramBoolean);
  }
  
  public static boolean getIncludeSuggestionsWithPeople(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("EXTRA_INCLUDE_SUGGESTIONS_WITH_PEOPLE", paramBoolean);
  }
  
  public static List<AudienceMember> getInitialAudienceMembers(Intent paramIntent)
  {
    if (paramIntent.hasExtra("com.google.android.gms.common.acl.EXTRA_INITIAL_AUDIENCE")) {
      return paramIntent.getParcelableArrayListExtra("com.google.android.gms.common.acl.EXTRA_INITIAL_AUDIENCE");
    }
    return Collections.emptyList();
  }
  
  public static ArrayList<AudienceMember> getKnownAudienceMembers(Intent paramIntent)
  {
    return paramIntent.getParcelableArrayListExtra("INITIAL_ACL");
  }
  
  public static boolean getLoadCircles(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("LOAD_CIRCLES", paramBoolean);
  }
  
  public static boolean getLoadPeople(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("LOAD_PEOPLE", paramBoolean);
  }
  
  public static boolean getLoadSuggested(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOULD_LOAD_SUGGESTED", paramBoolean);
  }
  
  public static boolean getLoadSystemGroups(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOULD_LOAD_GROUPS", paramBoolean);
  }
  
  public static int getMaxSuggestedDeviceContacts(Intent paramIntent, int paramInt)
  {
    return paramIntent.getIntExtra("EXTRA_MAX_SUGGESTED_DEVICE", paramInt);
  }
  
  public static int getMaxSuggestedImages(Intent paramIntent, int paramInt)
  {
    return paramIntent.getIntExtra("EXTRA_MAX_SUGGESTED_IMAGES", paramInt);
  }
  
  public static int getMaxSuggestedListItems(Intent paramIntent, int paramInt)
  {
    return paramIntent.getIntExtra("EXTRA_MAX_SUGGESTED_LIST_ITEMS", paramInt);
  }
  
  public static String getOkText(Intent paramIntent)
  {
    return paramIntent.getStringExtra("OK_TEXT");
  }
  
  public static String getPlusPageId(Intent paramIntent)
  {
    return paramIntent.getStringExtra("com.google.android.gms.common.acl.EXTRA_PLUS_PAGE_ID");
  }
  
  public static ArrayList<AudienceMember> getRemovedAudienceDelta(Intent paramIntent)
  {
    return paramIntent.getParcelableArrayListExtra("com.google.android.gms.common.acl.EXTRA_REMOVED_AUDIENCE");
  }
  
  public static boolean getSearchDeviceContacts(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("EXTRA_SEARCH_DEVICE", paramBoolean);
  }
  
  public static boolean getSearchEmail(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("EXTRA_SEARCH_EMAIL", paramBoolean);
  }
  
  public static ArrayList<AudienceMember> getSelectedAudienceMembers(Intent paramIntent)
  {
    ArrayList localArrayList1 = new ArrayList();
    List localList = getInitialAudienceMembers(paramIntent);
    if ((localList != null) && (!localList.isEmpty())) {
      localArrayList1.addAll(localList);
    }
    ArrayList localArrayList2 = getRemovedAudienceDelta(paramIntent);
    if (localArrayList2 != null) {
      localArrayList1.removeAll(localArrayList2);
    }
    ArrayList localArrayList3 = getAddedAudienceDelta(paramIntent);
    if (localArrayList3 != null) {
      localArrayList1.addAll(localArrayList3);
    }
    return localArrayList1;
  }
  
  public static boolean getShowCancel(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOW_CANCEL_VISIBLE", paramBoolean);
  }
  
  public static boolean getShowChips(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOW_CHIPS_VISIBLE", paramBoolean);
  }
  
  public static boolean getShowEveryoneCheckbox(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOW_EVERYONE_CHECKBOX", paramBoolean);
  }
  
  public static boolean getShowHiddenCirclesText(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOW_HIDDEN_CIRCLES_TEXT", paramBoolean);
  }
  
  public static String getTitle(Intent paramIntent)
  {
    return paramIntent.getStringExtra("com.google.android.gms.common.acl.EXTRA_TITLE_TEXT");
  }
  
  public static String getUpdatePersonId(Intent paramIntent)
  {
    return paramIntent.getStringExtra("com.google.android.gms.common.acl.EXTRA_UPDATE_PERSON_ID");
  }
  
  public static boolean shouldShowSectionTitles(Intent paramIntent, boolean paramBoolean)
  {
    return paramIntent.getBooleanExtra("SHOW_SECTION_TITLES", paramBoolean);
  }
  
  public Intent build()
  {
    return this.mIntent;
  }
  
  public ArrayList<AudienceMember> getAddedAudienceDelta()
  {
    return getAddedAudienceDelta(this.mIntent);
  }
  
  public ArrayList<AudienceMember> getAddedCirclesDelta()
  {
    return getAddedAudienceDelta();
  }
  
  public int getDomainRestricted()
  {
    return getDomainRestricted(this.mIntent, 0);
  }
  
  public boolean getEveryoneChecked()
  {
    return getEveryoneChecked(this.mIntent, false);
  }
  
  public List<AudienceMember> getInitialAudienceMembers()
  {
    return getInitialAudienceMembers(this.mIntent);
  }
  
  public List<AudienceMember> getInitialCircles()
  {
    return getInitialAudienceMembers();
  }
  
  public ArrayList<AudienceMember> getRemovedAudienceDelta()
  {
    return getRemovedAudienceDelta(this.mIntent);
  }
  
  public ArrayList<AudienceMember> getRemovedCirclesDelta()
  {
    return getRemovedAudienceDelta();
  }
  
  public ArrayList<AudienceMember> getSelectedAudienceMembers()
  {
    return getSelectedAudienceMembers(this.mIntent);
  }
  
  public ArrayList<AudienceMember> getSelectedCircles()
  {
    return getSelectedAudienceMembers();
  }
  
  public AudienceSelectionIntentBuilder setAccountName(String paramString)
  {
    this.mIntent.putExtra("com.google.android.gms.common.acl.EXTRA_ACCOUNT_NAME", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setAddedAudienceDelta(ArrayList<AudienceMember> paramArrayList)
  {
    this.mIntent.putParcelableArrayListExtra("com.google.android.gms.common.acl.EXTRA_ADDED_AUDIENCE", paramArrayList);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setAllowEmptySelection(boolean paramBoolean)
  {
    this.mIntent.putExtra("ALLOW_EMPTY", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setCancelText(String paramString)
  {
    this.mIntent.putExtra("CANCEL_TEXT", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setClientApplicationId(String paramString)
  {
    this.mIntent.putExtra("com.google.android.gms.common.acl.EXTRA_CLIENT_APPLICATION_ID", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setDescription(String paramString)
  {
    this.mIntent.putExtra("DESCRIPTION_TEXT", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setDomainRestricted(int paramInt)
  {
    this.mIntent.putExtra("com.google.android.gms.common.acl.EXTRA_DOMAIN_RESTRICTED", paramInt);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setEveryoneCheckboxText(String paramString)
  {
    this.mIntent.putExtra("EVERYONE_CHECKBOX_TEXT", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setEveryoneChecked(boolean paramBoolean)
  {
    this.mIntent.putExtra("EVERYONE_CHECKED", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setIncludeSuggestionsWithPeople(boolean paramBoolean)
  {
    this.mIntent.putExtra("EXTRA_INCLUDE_SUGGESTIONS_WITH_PEOPLE", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setInitialAcl(Audience paramAudience)
  {
    setInitialAudience(paramAudience);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setInitialAcl(List<AudienceMember> paramList)
  {
    setInitialAudience(paramList);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setInitialAudience(Audience paramAudience)
  {
    setInitialAudience(paramAudience.getAudienceMemberList());
    return this;
  }
  
  public AudienceSelectionIntentBuilder setInitialAudience(List<AudienceMember> paramList)
  {
    if (paramList == null) {
      paramList = Collections.EMPTY_LIST;
    }
    this.mIntent.putParcelableArrayListExtra("com.google.android.gms.common.acl.EXTRA_INITIAL_AUDIENCE", a(paramList));
    return this;
  }
  
  public AudienceSelectionIntentBuilder setInitialCircles(List<AudienceMember> paramList)
  {
    setInitialAudience(paramList);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setKnownAudienceMembers(List<AudienceMember> paramList)
  {
    this.mIntent.putParcelableArrayListExtra("INITIAL_ACL", a(paramList));
    return this;
  }
  
  public AudienceSelectionIntentBuilder setLoadCircles(boolean paramBoolean)
  {
    this.mIntent.putExtra("LOAD_CIRCLES", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setLoadPeople(boolean paramBoolean)
  {
    this.mIntent.putExtra("LOAD_PEOPLE", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setLoadSuggested(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOULD_LOAD_SUGGESTED", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setLoadSystemGroups(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOULD_LOAD_GROUPS", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setMaxSuggestedDeviceContacts(int paramInt)
  {
    this.mIntent.putExtra("EXTRA_MAX_SUGGESTED_DEVICE", paramInt);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setMaxSuggestedImages(int paramInt)
  {
    this.mIntent.putExtra("EXTRA_MAX_SUGGESTED_IMAGES", paramInt);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setMaxSuggestedListItems(int paramInt)
  {
    this.mIntent.putExtra("EXTRA_MAX_SUGGESTED_LIST_ITEMS", paramInt);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setOkText(String paramString)
  {
    this.mIntent.putExtra("OK_TEXT", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setPlusPageId(String paramString)
  {
    this.mIntent.putExtra("com.google.android.gms.common.acl.EXTRA_PLUS_PAGE_ID", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setRemovedAudienceDelta(ArrayList<AudienceMember> paramArrayList)
  {
    this.mIntent.putParcelableArrayListExtra("com.google.android.gms.common.acl.EXTRA_REMOVED_AUDIENCE", paramArrayList);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setSearchDeviceContacts(boolean paramBoolean)
  {
    this.mIntent.putExtra("EXTRA_SEARCH_DEVICE", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setSearchEmail(boolean paramBoolean)
  {
    this.mIntent.putExtra("EXTRA_SEARCH_EMAIL", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setShowCancel(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOW_CANCEL_VISIBLE", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setShowChips(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOW_CHIPS_VISIBLE", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setShowEveryoneCheckbox(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOW_EVERYONE_CHECKBOX", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setShowHiddenCirclesText(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOW_HIDDEN_CIRCLES_TEXT", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setShowSectionTitles(boolean paramBoolean)
  {
    this.mIntent.putExtra("SHOW_SECTION_TITLES", paramBoolean);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setTitleText(String paramString)
  {
    this.mIntent.putExtra("com.google.android.gms.common.acl.EXTRA_TITLE_TEXT", paramString);
    return this;
  }
  
  public AudienceSelectionIntentBuilder setUpdatePersonId(String paramString)
  {
    de.k(paramString, "People qualified ID");
    this.mIntent.putExtra("com.google.android.gms.common.acl.EXTRA_UPDATE_PERSON_ID", paramString);
    return this;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.audience.dialogs.AudienceSelectionIntentBuilder
 * JD-Core Version:    0.7.0.1
 */