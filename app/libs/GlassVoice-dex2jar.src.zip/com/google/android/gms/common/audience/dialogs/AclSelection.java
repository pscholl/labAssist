package com.google.android.gms.common.audience.dialogs;

import android.content.Intent;
import com.google.android.gms.common.people.data.Audience;
import com.google.android.gms.common.people.data.AudienceMember;
import java.util.ArrayList;
import java.util.List;

public final class AclSelection
{
  public static ArrayList<AudienceMember> getAddedAclDeltaFromResult(Intent paramIntent)
  {
    return AudienceSelectionIntentBuilder.getAddedAudienceDelta(paramIntent);
  }
  
  public static Builder getBuilder()
  {
    return new AudienceSelectionIntentBuilder("com.google.android.gms.common.acl.CHOOSE_ACL");
  }
  
  public static Results getResults(Intent paramIntent)
  {
    return new AudienceSelectionIntentBuilder(paramIntent);
  }
  
  public static ArrayList<AudienceMember> getSelectedAclsFromResult(Intent paramIntent)
  {
    return AudienceSelectionIntentBuilder.getSelectedAudienceMembers(paramIntent);
  }
  
  public static abstract interface Builder
  {
    public abstract Intent build();
    
    public abstract Builder setAccountName(String paramString);
    
    public abstract Builder setAllowEmptySelection(boolean paramBoolean);
    
    public abstract Builder setClientApplicationId(String paramString);
    
    public abstract Builder setDescription(String paramString);
    
    public abstract Builder setDomainRestricted(int paramInt);
    
    public abstract Builder setInitialAcl(Audience paramAudience);
    
    @Deprecated
    public abstract Builder setInitialAcl(List<AudienceMember> paramList);
    
    public abstract Builder setKnownAudienceMembers(List<AudienceMember> paramList);
    
    public abstract Builder setOkText(String paramString);
    
    public abstract Builder setPlusPageId(String paramString);
    
    public abstract Builder setShowCancel(boolean paramBoolean);
    
    public abstract Builder setTitleText(String paramString);
  }
  
  public static abstract interface DomainRestricted
  {
    public static final int NOT_VISIBLE = 0;
    public static final int OFF = 2;
    public static final int ON = 1;
  }
  
  public static abstract interface Results
  {
    public abstract ArrayList<AudienceMember> getAddedAudienceDelta();
    
    public abstract int getDomainRestricted();
    
    public abstract List<AudienceMember> getInitialAudienceMembers();
    
    public abstract ArrayList<AudienceMember> getRemovedAudienceDelta();
    
    public abstract ArrayList<AudienceMember> getSelectedAudienceMembers();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.audience.dialogs.AclSelection
 * JD-Core Version:    0.7.0.1
 */