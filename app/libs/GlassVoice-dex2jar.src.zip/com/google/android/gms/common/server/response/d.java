package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class d
  implements Parcelable.Creator<FieldMappingDictionary.Entry>
{
  static void a(FieldMappingDictionary.Entry paramEntry, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramEntry.versionCode);
    b.a(paramParcel, 2, paramEntry.className, false);
    b.b(paramParcel, 3, paramEntry.vl, false);
    b.C(paramParcel, i);
  }
  
  public FieldMappingDictionary.Entry aj(Parcel paramParcel)
  {
    ArrayList localArrayList = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
        break;
      case 3: 
        localArrayList = a.c(paramParcel, k, FieldMappingDictionary.FieldMapPair.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new FieldMappingDictionary.Entry(j, str, localArrayList);
  }
  
  public FieldMappingDictionary.Entry[] ax(int paramInt)
  {
    return new FieldMappingDictionary.Entry[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.d
 * JD-Core Version:    0.7.0.1
 */