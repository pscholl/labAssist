package com.google.android.gms.common.people.data;

import com.google.android.gms.internal.at;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public final class AudienceBuilder
{
  public static final Audience EMPTY_AUDIENCE = new AudienceBuilder().build();
  private List<AudienceMember> uq;
  private int ur;
  private boolean ut;
  
  public AudienceBuilder()
  {
    this.uq = Collections.emptyList();
    this.ur = 0;
    this.ut = false;
  }
  
  public AudienceBuilder(Audience paramAudience)
  {
    at.a(paramAudience, "Audience must not be null.");
    this.uq = paramAudience.getAudienceMemberList();
    this.ur = paramAudience.getDomainRestricted();
    this.ut = paramAudience.isReadOnly();
  }
  
  private int am(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      throw new IllegalArgumentException("Unknown domain restriction setting: " + paramInt);
    }
    return paramInt;
  }
  
  public Audience build()
  {
    return new Audience(this.uq, this.ur, this.ut);
  }
  
  public AudienceBuilder setAudienceMembers(Collection<AudienceMember> paramCollection)
  {
    this.uq = Collections.unmodifiableList(new ArrayList((Collection)at.a(paramCollection, "Audience members must not be null.")));
    return this;
  }
  
  public AudienceBuilder setDomainRestricted(int paramInt)
  {
    this.ur = am(paramInt);
    return this;
  }
  
  public AudienceBuilder setReadOnly(boolean paramBoolean)
  {
    this.ut = paramBoolean;
    return this;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.people.data.AudienceBuilder
 * JD-Core Version:    0.7.0.1
 */