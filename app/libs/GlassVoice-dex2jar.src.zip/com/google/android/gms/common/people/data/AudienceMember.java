package com.google.android.gms.common.people.data;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.de;
import java.util.Map;

public final class AudienceMember
  implements SafeParcelable
{
  public static final String AUDIENCE_GROUP_DOMAIN = "domain";
  public static final String AUDIENCE_GROUP_EXTENDED = "extendedCircles";
  public static final String AUDIENCE_GROUP_PUBLIC = "public";
  public static final String AUDIENCE_GROUP_YOUR_CIRCLES = "myCircles";
  public static final b CREATOR = new b();
  public static final int TYPE_CIRCLE = 1;
  public static final int TYPE_PERSON = 2;
  private final int oj;
  private final int sM;
  @Deprecated
  private final Bundle sk;
  private final int uu;
  private final String uv;
  private final String uw;
  private final String ux;
  private final String uy;
  
  AudienceMember(int paramInt1, int paramInt2, int paramInt3, String paramString1, String paramString2, String paramString3, String paramString4, Bundle paramBundle)
  {
    this.oj = paramInt1;
    this.sM = paramInt2;
    this.uu = paramInt3;
    this.uv = paramString1;
    this.uw = paramString2;
    this.ux = paramString3;
    this.uy = paramString4;
    if (paramBundle != null) {}
    for (;;)
    {
      this.sk = paramBundle;
      return;
      paramBundle = new Bundle();
    }
  }
  
  private AudienceMember(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    this(1, paramInt1, paramInt2, paramString1, paramString2, paramString3, paramString4, null);
  }
  
  public static AudienceMember forCircle(String paramString1, String paramString2)
  {
    return new AudienceMember(1, -1, paramString1, null, paramString2, null);
  }
  
  public static AudienceMember forGroup(String paramString1, String paramString2)
  {
    Integer localInteger1 = (Integer)de.Ch.get(paramString1);
    if (localInteger1 == null) {}
    for (Integer localInteger2 = (Integer)de.Ch.get(null);; localInteger2 = localInteger1) {
      return new AudienceMember(1, localInteger2.intValue(), paramString1, null, paramString2, null);
    }
  }
  
  public static AudienceMember forPersonWithEmail(String paramString1, String paramString2)
  {
    return forPersonWithPeopleQualifiedId(de.Y(paramString1), paramString2, null);
  }
  
  public static AudienceMember forPersonWithGaiaId(String paramString1, String paramString2, String paramString3)
  {
    at.b(paramString1, "Person ID must not be empty.");
    return forPersonWithPeopleQualifiedId(de.W(paramString1), paramString2, paramString3);
  }
  
  public static AudienceMember forPersonWithPeopleQualifiedId(String paramString1, String paramString2, String paramString3)
  {
    return new AudienceMember(2, 0, null, paramString1, paramString2, paramString3);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof AudienceMember)) {}
    AudienceMember localAudienceMember;
    do
    {
      return false;
      localAudienceMember = (AudienceMember)paramObject;
    } while ((this.oj != localAudienceMember.oj) || (this.sM != localAudienceMember.sM) || (this.uu != localAudienceMember.uu) || (!ar.equal(this.uv, localAudienceMember.uv)) || (!ar.equal(this.uw, localAudienceMember.uw)));
    return true;
  }
  
  public String getAvatarUrl()
  {
    return this.uy;
  }
  
  public String getCircleId()
  {
    return this.uv;
  }
  
  public int getCircleType()
  {
    return this.uu;
  }
  
  public String getDisplayName()
  {
    return this.ux;
  }
  
  @Deprecated
  public Bundle getMetadata()
  {
    return this.sk;
  }
  
  public String getPeopleQualifiedId()
  {
    return this.uw;
  }
  
  public int getType()
  {
    return this.sM;
  }
  
  public int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[5];
    arrayOfObject[0] = Integer.valueOf(this.oj);
    arrayOfObject[1] = Integer.valueOf(this.sM);
    arrayOfObject[2] = Integer.valueOf(this.uu);
    arrayOfObject[3] = this.uv;
    arrayOfObject[4] = this.uw;
    return ar.hashCode(arrayOfObject);
  }
  
  public boolean isPerson()
  {
    return this.sM == 2;
  }
  
  public boolean isPersonalCircle()
  {
    return (this.sM == 1) && (this.uu == -1);
  }
  
  public boolean isPublicSystemGroup()
  {
    return (this.sM == 1) && (this.uu == 1);
  }
  
  public boolean isSystemGroup()
  {
    return (this.sM == 1) && (this.uu != -1);
  }
  
  public String toString()
  {
    if (isPerson())
    {
      Object[] arrayOfObject3 = new Object[2];
      arrayOfObject3[0] = getPeopleQualifiedId();
      arrayOfObject3[1] = getDisplayName();
      return String.format("Person [%s] %s", arrayOfObject3);
    }
    if (isPersonalCircle())
    {
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = getCircleId();
      arrayOfObject2[1] = getDisplayName();
      return String.format("Circle [%s] %s", arrayOfObject2);
    }
    Object[] arrayOfObject1 = new Object[2];
    arrayOfObject1[0] = getCircleId();
    arrayOfObject1[1] = getDisplayName();
    return String.format("Group [%s] %s", arrayOfObject1);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.people.data.AudienceMember
 * JD-Core Version:    0.7.0.1
 */