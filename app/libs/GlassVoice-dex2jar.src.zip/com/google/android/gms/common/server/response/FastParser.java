package com.google.android.gms.common.server.response;

import android.util.Log;
import com.google.android.gms.internal.bh;
import com.google.android.gms.internal.bl;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;

public class FastParser<T extends FastJsonResponse>
{
  private static final char[] uT = { 117, 108, 108 };
  private static final char[] uU = { 114, 117, 101 };
  private static final char[] uV = { 114, 117, 101, 34 };
  private static final char[] uW = { 97, 108, 115, 101 };
  private static final char[] uX = { 97, 108, 115, 101, 34 };
  private static final char[] uY = { '\n' };
  private static final a<Integer> va = new a()
  {
    public Integer h(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return Integer.valueOf(FastParser.a(paramAnonymousFastParser, paramAnonymousBufferedReader));
    }
  };
  private static final a<Long> vb = new a()
  {
    public Long j(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return Long.valueOf(FastParser.b(paramAnonymousFastParser, paramAnonymousBufferedReader));
    }
  };
  private static final a<Float> vc = new a()
  {
    public Float k(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return Float.valueOf(FastParser.c(paramAnonymousFastParser, paramAnonymousBufferedReader));
    }
  };
  private static final a<Double> vd = new a()
  {
    public Double l(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return Double.valueOf(FastParser.d(paramAnonymousFastParser, paramAnonymousBufferedReader));
    }
  };
  private static final a<Boolean> ve = new a()
  {
    public Boolean m(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return Boolean.valueOf(FastParser.a(paramAnonymousFastParser, paramAnonymousBufferedReader, false));
    }
  };
  private static final a<String> vf = new a()
  {
    public String n(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return FastParser.e(paramAnonymousFastParser, paramAnonymousBufferedReader);
    }
  };
  private static final a<BigInteger> vg = new a()
  {
    public BigInteger o(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return FastParser.f(paramAnonymousFastParser, paramAnonymousBufferedReader);
    }
  };
  private static final a<BigDecimal> vh = new a()
  {
    public BigDecimal p(FastParser paramAnonymousFastParser, BufferedReader paramAnonymousBufferedReader)
      throws FastParser.ParseException, IOException
    {
      return FastParser.g(paramAnonymousFastParser, paramAnonymousBufferedReader);
    }
  };
  private final char[] uO = new char[1];
  private final char[] uP = new char[32];
  private final char[] uQ = new char[1024];
  private final StringBuilder uR = new StringBuilder(32);
  private final StringBuilder uS = new StringBuilder(1024);
  private final Stack<Integer> uZ = new Stack();
  
  private int a(BufferedReader paramBufferedReader, char[] paramArrayOfChar)
    throws FastParser.ParseException, IOException
  {
    int i = k(paramBufferedReader);
    if (i == 0) {
      throw new ParseException("Unexpected EOF");
    }
    if (i == 44) {
      throw new ParseException("Missing value");
    }
    if (i == 110)
    {
      b(paramBufferedReader, uT);
      return 0;
    }
    paramBufferedReader.mark(1024);
    int j;
    if (i == 34)
    {
      int k = 0;
      int m = 0;
      if ((m < paramArrayOfChar.length) && (paramBufferedReader.read(paramArrayOfChar, m, 1) != -1))
      {
        char c = paramArrayOfChar[m];
        if (Character.isISOControl(c)) {
          throw new ParseException("Unexpected control character while reading string");
        }
        if ((c == '"') && (k == 0))
        {
          paramBufferedReader.reset();
          paramBufferedReader.skip(m + 1);
          return m;
        }
        if (c == '\\') {
          if (k == 0) {
            k = 1;
          }
        }
        for (;;)
        {
          m++;
          break;
          k = 0;
          continue;
          k = 0;
        }
      }
      j = m;
    }
    while (j == paramArrayOfChar.length)
    {
      throw new ParseException("Absurdly long value");
      paramArrayOfChar[0] = i;
      for (j = 1; (j < paramArrayOfChar.length) && (paramBufferedReader.read(paramArrayOfChar, j, 1) != -1); j++) {
        if ((paramArrayOfChar[j] == '}') || (paramArrayOfChar[j] == ',') || (Character.isWhitespace(paramArrayOfChar[j])) || (paramArrayOfChar[j] == ']'))
        {
          paramBufferedReader.reset();
          paramBufferedReader.skip(j - 1);
          paramArrayOfChar[j] = '\000';
          return j;
        }
      }
    }
    throw new ParseException("Unexpected EOF");
  }
  
  private static int a(char[] paramArrayOfChar, int paramInt)
    throws FastParser.ParseException
  {
    int i;
    int j;
    int k;
    int m;
    int n;
    int i1;
    if (paramInt > 0)
    {
      if (paramArrayOfChar[0] == '-')
      {
        i = -2147483648;
        j = 1;
      }
      int i5;
      for (k = 1;; k = 0)
      {
        m = i / 10;
        if (j >= paramInt) {
          break label210;
        }
        n = j + 1;
        i5 = Character.digit(paramArrayOfChar[j], 10);
        if (i5 >= 0) {
          break;
        }
        throw new ParseException("Unexpected non-digit character");
        i = -2147483647;
        j = 0;
      }
      i1 = -i5;
    }
    for (;;)
    {
      if (n < paramInt)
      {
        int i2 = n + 1;
        int i3 = Character.digit(paramArrayOfChar[n], 10);
        if (i3 < 0) {
          throw new ParseException("Unexpected non-digit character");
        }
        if (i1 < m) {
          throw new ParseException("Number too large");
        }
        int i4 = i1 * 10;
        if (i4 < i + i3) {
          throw new ParseException("Number too large");
        }
        i1 = i4 - i3;
        n = i2;
        continue;
        throw new ParseException("No number to parse");
      }
      else
      {
        if (k != 0)
        {
          if (n > 1) {
            return i1;
          }
          throw new ParseException("No digits to parse");
        }
        return -i1;
        label210:
        n = j;
        i1 = 0;
      }
    }
  }
  
  private String a(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    String str = null;
    this.uZ.push(Integer.valueOf(2));
    char c = k(paramBufferedReader);
    switch (c)
    {
    default: 
      throw new ParseException("Unexpected token: " + c);
    case '}': 
      at(2);
    }
    do
    {
      return str;
      at(2);
      at(1);
      at(5);
      return null;
      this.uZ.push(Integer.valueOf(3));
      str = b(paramBufferedReader, this.uP, this.uR, null);
      at(3);
    } while (k(paramBufferedReader) == ':');
    throw new ParseException("Expected key/value separator");
  }
  
  private String a(BufferedReader paramBufferedReader, char[] paramArrayOfChar1, StringBuilder paramStringBuilder, char[] paramArrayOfChar2)
    throws FastParser.ParseException, IOException
  {
    switch (k(paramBufferedReader))
    {
    default: 
      throw new ParseException("Expected string");
    case '"': 
      return b(paramBufferedReader, paramArrayOfChar1, paramStringBuilder, paramArrayOfChar2);
    }
    b(paramBufferedReader, uT);
    return null;
  }
  
  private <T extends FastJsonResponse> ArrayList<T> a(BufferedReader paramBufferedReader, FastJsonResponse.Field<?, ?> paramField)
    throws FastParser.ParseException, IOException
  {
    ArrayList localArrayList = new ArrayList();
    char c1 = k(paramBufferedReader);
    switch (c1)
    {
    default: 
      throw new ParseException("Unexpected token: " + c1);
    case ']': 
      at(5);
      return localArrayList;
    case '{': 
      this.uZ.push(Integer.valueOf(1));
    }
    for (;;)
    {
      try
      {
        FastJsonResponse localFastJsonResponse = paramField.newConcreteTypeInstance();
        if (!c(paramBufferedReader, localFastJsonResponse)) {
          break;
        }
        localArrayList.add(localFastJsonResponse);
        char c2 = k(paramBufferedReader);
        switch (c2)
        {
        default: 
          throw new ParseException("Unexpected token: " + c2);
        }
      }
      catch (InstantiationException localInstantiationException)
      {
        throw new ParseException("Error instantiating inner object", localInstantiationException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new ParseException("Error instantiating inner object", localIllegalAccessException);
      }
      b(paramBufferedReader, uT);
      at(5);
      return null;
      if (k(paramBufferedReader) != '{') {
        throw new ParseException("Expected start of next object in array");
      }
      this.uZ.push(Integer.valueOf(1));
    }
    at(5);
    return localArrayList;
  }
  
  private <O> ArrayList<O> a(BufferedReader paramBufferedReader, a<O> parama)
    throws FastParser.ParseException, IOException
  {
    int i = k(paramBufferedReader);
    if (i == 110)
    {
      b(paramBufferedReader, uT);
      return null;
    }
    if (i != 91) {
      throw new ParseException("Expected start of array");
    }
    this.uZ.push(Integer.valueOf(5));
    ArrayList localArrayList = new ArrayList();
    for (;;)
    {
      paramBufferedReader.mark(1024);
      switch (k(paramBufferedReader))
      {
      case ',': 
      default: 
        paramBufferedReader.reset();
        localArrayList.add(parama.i(this, paramBufferedReader));
      }
    }
    at(5);
    return localArrayList;
    throw new ParseException("Unexpected EOF");
  }
  
  private void a(BufferedReader paramBufferedReader, T paramT)
    throws FastParser.ParseException, IOException
  {
    char c = k(paramBufferedReader);
    switch (c)
    {
    default: 
      throw new ParseException("Unexpected token: " + c);
    case '{': 
      this.uZ.push(Integer.valueOf(1));
      c(paramBufferedReader, paramT);
      return;
    case '[': 
      this.uZ.push(Integer.valueOf(5));
      b(paramBufferedReader, paramT);
      return;
    }
    throw new ParseException("No data to parse");
  }
  
  private boolean a(BufferedReader paramBufferedReader, boolean paramBoolean)
    throws FastParser.ParseException, IOException
  {
    char c = k(paramBufferedReader);
    switch (c)
    {
    default: 
      throw new ParseException("Unexpected token: " + c);
    case 'n': 
      b(paramBufferedReader, uT);
      return false;
    case 't': 
      if (paramBoolean) {}
      for (char[] arrayOfChar2 = uV;; arrayOfChar2 = uU)
      {
        b(paramBufferedReader, arrayOfChar2);
        return true;
      }
    case 'f': 
      if (paramBoolean) {}
      for (char[] arrayOfChar1 = uX;; arrayOfChar1 = uW)
      {
        b(paramBufferedReader, arrayOfChar1);
        return false;
      }
    }
    if (paramBoolean) {
      throw new ParseException("No boolean value found in string");
    }
    return a(paramBufferedReader, true);
  }
  
  private boolean a(char[] paramArrayOfChar, char paramChar)
  {
    if (paramArrayOfChar == null) {}
    for (;;)
    {
      return false;
      for (int i = 0; i < paramArrayOfChar.length; i++) {
        if (paramArrayOfChar[i] == paramChar) {
          return true;
        }
      }
    }
  }
  
  private void at(int paramInt)
    throws FastParser.ParseException
  {
    if (this.uZ.isEmpty()) {
      throw new ParseException("Expected state " + paramInt + " but had empty stack");
    }
    int i = ((Integer)this.uZ.pop()).intValue();
    if (i != paramInt) {
      throw new ParseException("Expected state " + paramInt + " but had " + i);
    }
  }
  
  private static long b(char[] paramArrayOfChar, int paramInt)
    throws FastParser.ParseException
  {
    long l1 = 0L;
    int j;
    int i;
    if (paramInt > 0)
    {
      long l2;
      if (paramArrayOfChar[0] == '-')
      {
        j = 1;
        l2 = -9223372036854775808L;
        i = 1;
      }
      long l3;
      int n;
      int i1;
      for (;;)
      {
        l3 = l2 / 10L;
        if (i >= paramInt) {
          break label98;
        }
        n = i + 1;
        i1 = Character.digit(paramArrayOfChar[i], 10);
        if (i1 >= 0) {
          break;
        }
        throw new ParseException("Unexpected non-digit character");
        l2 = -9223372036854775807L;
        i = 0;
        j = 0;
      }
      long l5 = -i1;
      i = n;
      l1 = l5;
      label98:
      while (i < paramInt)
      {
        int k = i + 1;
        int m = Character.digit(paramArrayOfChar[i], 10);
        if (m < 0) {
          throw new ParseException("Unexpected non-digit character");
        }
        if (l1 < l3) {
          throw new ParseException("Number too large");
        }
        long l4 = l1 * 10L;
        if (l4 < l2 + m) {
          throw new ParseException("Number too large");
        }
        l1 = l4 - m;
        i = k;
      }
    }
    throw new ParseException("No number to parse");
    if (j != 0)
    {
      if (i > 1) {
        return l1;
      }
      throw new ParseException("No digits to parse");
    }
    return -l1;
  }
  
  private String b(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    paramBufferedReader.mark(1024);
    int i3;
    int i4;
    switch (k(paramBufferedReader))
    {
    default: 
      paramBufferedReader.reset();
      a(paramBufferedReader, this.uQ);
      char c1 = k(paramBufferedReader);
      switch (c1)
      {
      default: 
        throw new ParseException("Unexpected token " + c1);
      }
    case '"': 
      if (paramBufferedReader.read(this.uO) == -1) {
        throw new ParseException("Unexpected EOF while parsing string");
      }
      i3 = this.uO[0];
      i4 = 0;
    }
    while ((i3 != 34) || (i4 != 0))
    {
      int i5;
      if (i3 == 92) {
        if (i4 == 0) {
          i5 = 1;
        }
      }
      while (paramBufferedReader.read(this.uO) == -1)
      {
        throw new ParseException("Unexpected EOF while parsing string");
        i5 = 0;
        continue;
        i5 = 0;
      }
      char c4 = this.uO[0];
      if (Character.isISOControl(c4))
      {
        throw new ParseException("Unexpected control character while reading string");
        this.uZ.push(Integer.valueOf(1));
        paramBufferedReader.mark(32);
        char c3 = k(paramBufferedReader);
        if (c3 == '}')
        {
          at(1);
          break;
        }
        if (c3 == '"')
        {
          paramBufferedReader.reset();
          a(paramBufferedReader);
          while (b(paramBufferedReader) != null) {}
          at(1);
          break;
        }
        throw new ParseException("Unexpected token " + c3);
        this.uZ.push(Integer.valueOf(5));
        paramBufferedReader.mark(32);
        if (k(paramBufferedReader) == ']')
        {
          at(5);
          break;
        }
        paramBufferedReader.reset();
        int i = 1;
        int j = 0;
        int k = 0;
        label405:
        char c2;
        int i2;
        if (i > 0)
        {
          c2 = k(paramBufferedReader);
          if (c2 == 0) {
            throw new ParseException("Unexpected EOF while parsing array");
          }
          if (Character.isISOControl(c2)) {
            throw new ParseException("Unexpected control character while reading array");
          }
          if ((c2 != '"') || (k != 0)) {
            break label610;
          }
          if (j == 0) {
            i2 = 1;
          }
        }
        label471:
        label610:
        for (int m = i2;; m = j)
        {
          if ((c2 == '[') && (m == 0)) {}
          for (int n = i + 1;; n = i)
          {
            if ((c2 == ']') && (m == 0)) {}
            for (i = n - 1;; i = n)
            {
              if ((c2 == '\\') && (m != 0))
              {
                if (k == 0) {}
                for (int i1 = 1;; i1 = 0)
                {
                  k = i1;
                  j = m;
                  break;
                  i2 = 0;
                  break label471;
                }
              }
              j = m;
              k = 0;
              break label405;
              at(5);
              break;
              throw new ParseException("Missing value");
              at(2);
              return a(paramBufferedReader);
              at(2);
              return null;
            }
          }
        }
      }
      i4 = i5;
      i3 = c4;
    }
  }
  
  private String b(BufferedReader paramBufferedReader, char[] paramArrayOfChar1, StringBuilder paramStringBuilder, char[] paramArrayOfChar2)
    throws FastParser.ParseException, IOException
  {
    paramStringBuilder.setLength(0);
    paramBufferedReader.mark(paramArrayOfChar1.length);
    int i = 0;
    for (;;)
    {
      int j = paramBufferedReader.read(paramArrayOfChar1);
      if (j == -1) {
        break;
      }
      int k = 0;
      if (k < j)
      {
        char c = paramArrayOfChar1[k];
        if ((Character.isISOControl(c)) && (!a(paramArrayOfChar2, c))) {
          throw new ParseException("Unexpected control character while reading string");
        }
        if ((c == '"') && (i == 0))
        {
          paramStringBuilder.append(paramArrayOfChar1, 0, k);
          paramBufferedReader.reset();
          paramBufferedReader.skip(k + 1);
          return bl.G(paramStringBuilder.toString());
        }
        if (c == '\\') {
          if (i == 0) {
            i = 1;
          }
        }
        for (;;)
        {
          k++;
          break;
          i = 0;
          continue;
          i = 0;
        }
      }
      paramStringBuilder.append(paramArrayOfChar1, 0, j);
      paramBufferedReader.mark(paramArrayOfChar1.length);
    }
    throw new ParseException("Unexpected EOF while parsing string");
  }
  
  private void b(BufferedReader paramBufferedReader, FastJsonResponse paramFastJsonResponse)
    throws FastParser.ParseException, IOException
  {
    HashMap localHashMap = paramFastJsonResponse.getFieldMappings();
    if (localHashMap.size() != 1) {
      throw new ParseException("Object array response class must have a single Field");
    }
    FastJsonResponse.Field localField = (FastJsonResponse.Field)((Map.Entry)localHashMap.entrySet().iterator().next()).getValue();
    ArrayList localArrayList = a(paramBufferedReader, localField);
    paramFastJsonResponse.addConcreteTypeArrayInternal(localField, localField.getOutputFieldName(), localArrayList);
  }
  
  private void b(BufferedReader paramBufferedReader, char[] paramArrayOfChar)
    throws FastParser.ParseException, IOException
  {
    int i = 0;
    while (i < paramArrayOfChar.length)
    {
      int j = paramBufferedReader.read(this.uP, 0, paramArrayOfChar.length - i);
      if (j == -1) {
        throw new ParseException("Unexpected EOF");
      }
      for (int k = 0; k < j; k++) {
        if (paramArrayOfChar[(k + i)] != this.uP[k]) {
          throw new ParseException("Unexpected character");
        }
      }
      i += j;
    }
  }
  
  private String c(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    return a(paramBufferedReader, this.uP, this.uR, null);
  }
  
  private boolean c(BufferedReader paramBufferedReader, FastJsonResponse paramFastJsonResponse)
    throws FastParser.ParseException, IOException
  {
    HashMap localHashMap = paramFastJsonResponse.getFieldMappings();
    String str = a(paramBufferedReader);
    if (str == null)
    {
      at(1);
      return false;
      str = null;
    }
    while (str != null)
    {
      FastJsonResponse.Field localField = (FastJsonResponse.Field)localHashMap.get(str);
      if (localField == null)
      {
        str = b(paramBufferedReader);
      }
      else
      {
        this.uZ.push(Integer.valueOf(4));
        switch (localField.getTypeIn())
        {
        default: 
          throw new ParseException("Invalid field type " + localField.getTypeIn());
        case 0: 
          if (localField.isTypeInArray()) {
            paramFastJsonResponse.setIntegers(localField, a(paramBufferedReader, va));
          }
          break;
        }
        for (;;)
        {
          at(4);
          at(2);
          char c = k(paramBufferedReader);
          switch (c)
          {
          case '}': 
          default: 
            throw new ParseException("Expected end of object or field separator, but found: " + c);
            paramFastJsonResponse.setInteger(localField, e(paramBufferedReader));
            continue;
            if (localField.isTypeInArray())
            {
              paramFastJsonResponse.setBigIntegers(localField, a(paramBufferedReader, vg));
            }
            else
            {
              paramFastJsonResponse.setBigInteger(localField, g(paramBufferedReader));
              continue;
              if (localField.isTypeInArray())
              {
                paramFastJsonResponse.setLongs(localField, a(paramBufferedReader, vb));
              }
              else
              {
                paramFastJsonResponse.setLong(localField, f(paramBufferedReader));
                continue;
                if (localField.isTypeInArray())
                {
                  paramFastJsonResponse.setFloats(localField, a(paramBufferedReader, vc));
                }
                else
                {
                  paramFastJsonResponse.setFloat(localField, h(paramBufferedReader));
                  continue;
                  if (localField.isTypeInArray())
                  {
                    paramFastJsonResponse.setDoubles(localField, a(paramBufferedReader, vd));
                  }
                  else
                  {
                    paramFastJsonResponse.setDouble(localField, i(paramBufferedReader));
                    continue;
                    if (localField.isTypeInArray())
                    {
                      paramFastJsonResponse.setBigDecimals(localField, a(paramBufferedReader, vh));
                    }
                    else
                    {
                      paramFastJsonResponse.setBigDecimal(localField, j(paramBufferedReader));
                      continue;
                      if (localField.isTypeInArray())
                      {
                        paramFastJsonResponse.setBooleans(localField, a(paramBufferedReader, ve));
                      }
                      else
                      {
                        paramFastJsonResponse.setBoolean(localField, a(paramBufferedReader, false));
                        continue;
                        if (localField.isTypeInArray())
                        {
                          paramFastJsonResponse.setStrings(localField, a(paramBufferedReader, vf));
                        }
                        else
                        {
                          paramFastJsonResponse.setString(localField, c(paramBufferedReader));
                          continue;
                          paramFastJsonResponse.setDecodedBytes(localField, bh.E(a(paramBufferedReader, this.uQ, this.uS, uY)));
                          continue;
                          paramFastJsonResponse.setDecodedBytes(localField, bh.F(a(paramBufferedReader, this.uQ, this.uS, uY)));
                          continue;
                          paramFastJsonResponse.setStringMap(localField, d(paramBufferedReader));
                          continue;
                          if (localField.isTypeInArray())
                          {
                            int j = k(paramBufferedReader);
                            if (j == 110)
                            {
                              b(paramBufferedReader, uT);
                              paramFastJsonResponse.addConcreteTypeArrayInternal(localField, localField.getOutputFieldName(), null);
                            }
                            else
                            {
                              this.uZ.push(Integer.valueOf(5));
                              if (j != 91) {
                                throw new ParseException("Expected array start");
                              }
                              paramFastJsonResponse.addConcreteTypeArrayInternal(localField, localField.getOutputFieldName(), a(paramBufferedReader, localField));
                            }
                          }
                          else
                          {
                            int i = k(paramBufferedReader);
                            if (i == 110)
                            {
                              b(paramBufferedReader, uT);
                              paramFastJsonResponse.addConcreteTypeInternal(localField, localField.getOutputFieldName(), null);
                            }
                            else
                            {
                              this.uZ.push(Integer.valueOf(1));
                              if (i != 123) {
                                throw new ParseException("Expected start of object");
                              }
                              try
                              {
                                FastJsonResponse localFastJsonResponse = localField.newConcreteTypeInstance();
                                c(paramBufferedReader, localFastJsonResponse);
                                paramFastJsonResponse.addConcreteTypeInternal(localField, localField.getOutputFieldName(), localFastJsonResponse);
                              }
                              catch (InstantiationException localInstantiationException)
                              {
                                throw new ParseException("Error instantiating inner object", localInstantiationException);
                              }
                              catch (IllegalAccessException localIllegalAccessException)
                              {
                                throw new ParseException("Error instantiating inner object", localIllegalAccessException);
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            break;
          }
        }
        str = a(paramBufferedReader);
      }
    }
    at(1);
    return true;
  }
  
  private HashMap<String, String> d(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = k(paramBufferedReader);
    if (i == 110)
    {
      b(paramBufferedReader, uT);
      return null;
    }
    if (i != 123) {
      throw new ParseException("Expected start of a map object");
    }
    this.uZ.push(Integer.valueOf(1));
    HashMap localHashMap = new HashMap();
    char c;
    do
    {
      for (;;)
      {
        switch (k(paramBufferedReader))
        {
        }
      }
      throw new ParseException("Unexpected EOF");
      String str = b(paramBufferedReader, this.uP, this.uR, null);
      if (k(paramBufferedReader) != ':') {
        throw new ParseException("No map value found for key " + str);
      }
      if (k(paramBufferedReader) != '"') {
        throw new ParseException("Expected String value for key " + str);
      }
      localHashMap.put(str, b(paramBufferedReader, this.uP, this.uR, null));
      c = k(paramBufferedReader);
    } while (c == ',');
    if (c == '}')
    {
      at(1);
      return localHashMap;
    }
    throw new ParseException("Unexpected character while parsing string map: " + c);
    at(1);
    return localHashMap;
  }
  
  private int e(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = a(paramBufferedReader, this.uQ);
    if (i == 0) {
      return 0;
    }
    return a(this.uQ, i);
  }
  
  private long f(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = a(paramBufferedReader, this.uQ);
    if (i == 0) {
      return 0L;
    }
    return b(this.uQ, i);
  }
  
  private BigInteger g(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = a(paramBufferedReader, this.uQ);
    if (i == 0) {
      return null;
    }
    return new BigInteger(new String(this.uQ, 0, i));
  }
  
  private float h(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = a(paramBufferedReader, this.uQ);
    if (i == 0) {
      return 0.0F;
    }
    return Float.parseFloat(new String(this.uQ, 0, i));
  }
  
  private double i(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = a(paramBufferedReader, this.uQ);
    if (i == 0) {
      return 0.0D;
    }
    return Double.parseDouble(new String(this.uQ, 0, i));
  }
  
  private BigDecimal j(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    int i = a(paramBufferedReader, this.uQ);
    if (i == 0) {
      return null;
    }
    return new BigDecimal(new String(this.uQ, 0, i));
  }
  
  private char k(BufferedReader paramBufferedReader)
    throws FastParser.ParseException, IOException
  {
    if (paramBufferedReader.read(this.uO) == -1) {
      return '\000';
    }
    while (Character.isWhitespace(this.uO[0])) {
      if (paramBufferedReader.read(this.uO) == -1) {
        return '\000';
      }
    }
    return this.uO[0];
  }
  
  public void parse(InputStream paramInputStream, T paramT)
    throws FastParser.ParseException
  {
    localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream), 1024);
    try
    {
      this.uZ.push(Integer.valueOf(0));
      a(localBufferedReader, paramT);
      at(0);
      try
      {
        localBufferedReader.close();
        return;
      }
      catch (IOException localIOException3)
      {
        Log.w("FastParser", "Failed to close reader while parsing.");
        return;
      }
      try
      {
        localBufferedReader.close();
        throw localObject;
      }
      catch (IOException localIOException1)
      {
        for (;;)
        {
          Log.w("FastParser", "Failed to close reader while parsing.");
        }
      }
    }
    catch (IOException localIOException2)
    {
      localIOException2 = localIOException2;
      throw new ParseException(localIOException2);
    }
    finally {}
  }
  
  public void parse(String paramString, T paramT)
    throws FastParser.ParseException
  {
    localByteArrayInputStream = new ByteArrayInputStream(paramString.getBytes());
    try
    {
      parse(localByteArrayInputStream, paramT);
      try
      {
        localByteArrayInputStream.close();
        return;
      }
      catch (IOException localIOException2)
      {
        Log.w("FastParser", "Failed to close the input stream while parsing.");
        return;
      }
      try
      {
        localByteArrayInputStream.close();
        throw localObject;
      }
      catch (IOException localIOException1)
      {
        for (;;)
        {
          Log.w("FastParser", "Failed to close the input stream while parsing.");
        }
      }
    }
    finally {}
  }
  
  public static class ParseException
    extends Exception
  {
    public ParseException(String paramString)
    {
      super();
    }
    
    public ParseException(String paramString, Throwable paramThrowable)
    {
      super(paramThrowable);
    }
    
    public ParseException(Throwable paramThrowable)
    {
      super();
    }
  }
  
  private static abstract interface a<O>
  {
    public abstract O i(FastParser paramFastParser, BufferedReader paramBufferedReader)
      throws FastParser.ParseException, IOException;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.FastParser
 * JD-Core Version:    0.7.0.1
 */