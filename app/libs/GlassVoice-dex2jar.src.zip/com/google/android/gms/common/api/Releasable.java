package com.google.android.gms.common.api;

public abstract interface Releasable
{
  public abstract void release();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Releasable
 * JD-Core Version:    0.7.0.1
 */