package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.internal.ai;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Api
{
  private final b<?> qP;
  private final ArrayList<Scope> qQ;
  
  public Api(b<?> paramb, Scope... paramVarArgs)
  {
    this.qP = paramb;
    this.qQ = new ArrayList(Arrays.asList(paramVarArgs));
  }
  
  public b<?> bm()
  {
    return this.qP;
  }
  
  public List<Scope> bn()
  {
    return this.qQ;
  }
  
  public static abstract interface a
  {
    public abstract void connect();
    
    public abstract void disconnect();
    
    public abstract Looper getLooper();
    
    public abstract boolean isConnected();
  }
  
  public static abstract interface b<T extends Api.a>
  {
    public abstract T a(Context paramContext, Looper paramLooper, ai paramai, GoogleApiClient.ApiOptions paramApiOptions, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener);
    
    public abstract int getPriority();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Api
 * JD-Core Version:    0.7.0.1
 */