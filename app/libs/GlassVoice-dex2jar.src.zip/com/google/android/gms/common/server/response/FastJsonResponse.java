package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.bb;
import com.google.android.gms.internal.bh;
import com.google.android.gms.internal.bk;
import com.google.android.gms.internal.bl;
import com.google.android.gms.internal.bm;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;

public abstract class FastJsonResponse
{
  protected static final String QUOTE = "\"";
  private int uI;
  private byte[] uJ;
  private boolean uK;
  
  private <I, O> void a(Field<I, O> paramField, I paramI)
  {
    String str = paramField.getOutputFieldName();
    Object localObject = paramField.convert(paramI);
    switch (paramField.getTypeOut())
    {
    case 3: 
    default: 
      throw new IllegalStateException("Unsupported type for conversion: " + paramField.getTypeOut());
    case 0: 
      if (c(str, localObject)) {
        setIntegerInternal(paramField, str, ((Integer)localObject).intValue());
      }
      break;
    }
    do
    {
      do
      {
        do
        {
          do
          {
            return;
            setBigIntegerInternal(paramField, str, (BigInteger)localObject);
            return;
          } while (!c(str, localObject));
          setLongInternal(paramField, str, ((Long)localObject).longValue());
          return;
        } while (!c(str, localObject));
        setDoubleInternal(paramField, str, ((Double)localObject).doubleValue());
        return;
        setBigDecimalInternal(paramField, str, (BigDecimal)localObject);
        return;
      } while (!c(str, localObject));
      setBooleanInternal(paramField, str, ((Boolean)localObject).booleanValue());
      return;
      setStringInternal(paramField, str, (String)localObject);
      return;
    } while (!c(str, localObject));
    setDecodedBytesInternal(paramField, str, (byte[])localObject);
  }
  
  private void a(StringBuilder paramStringBuilder, Field paramField, Object paramObject)
  {
    if (paramField.getTypeIn() == 11)
    {
      paramStringBuilder.append(((FastJsonResponse)paramField.getConcreteType().cast(paramObject)).toString());
      return;
    }
    if (paramField.getTypeIn() == 7)
    {
      paramStringBuilder.append("\"");
      paramStringBuilder.append(bl.H((String)paramObject));
      paramStringBuilder.append("\"");
      return;
    }
    paramStringBuilder.append(paramObject);
  }
  
  private void a(StringBuilder paramStringBuilder, Field paramField, ArrayList<Object> paramArrayList)
  {
    paramStringBuilder.append("[");
    int i = 0;
    int j = paramArrayList.size();
    while (i < j)
    {
      if (i > 0) {
        paramStringBuilder.append(",");
      }
      Object localObject = paramArrayList.get(i);
      if (localObject != null) {
        a(paramStringBuilder, paramField, localObject);
      }
      i++;
    }
    paramStringBuilder.append("]");
  }
  
  private <O> boolean c(String paramString, O paramO)
  {
    if (paramO == null)
    {
      if (Log.isLoggable("FastJsonResponse", 6)) {
        Log.e("FastJsonResponse", "Output field (" + paramString + ") has a null value," + " but expected a primitive");
      }
      return false;
    }
    return true;
  }
  
  private static InputStream d(byte[] paramArrayOfByte)
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    if (bk.g(paramArrayOfByte)) {
      try
      {
        GZIPInputStream localGZIPInputStream = new GZIPInputStream(localByteArrayInputStream);
        return localGZIPInputStream;
      }
      catch (IOException localIOException) {}
    }
    return localByteArrayInputStream;
  }
  
  public <T extends FastJsonResponse> void addConcreteType(String paramString, T paramT)
  {
    throw new UnsupportedOperationException("Concrete type not supported");
  }
  
  public <T extends FastJsonResponse> void addConcreteTypeArray(String paramString, ArrayList<T> paramArrayList)
  {
    throw new UnsupportedOperationException("Concrete type array not supported");
  }
  
  public <T extends FastJsonResponse> void addConcreteTypeArrayInternal(Field<?, ?> paramField, String paramString, ArrayList<T> paramArrayList)
  {
    addConcreteTypeArray(paramString, paramArrayList);
  }
  
  public <T extends FastJsonResponse> void addConcreteTypeInternal(Field<?, ?> paramField, String paramString, T paramT)
  {
    addConcreteType(paramString, paramT);
  }
  
  public HashMap<String, Object> getConcreteTypeArrays()
  {
    return null;
  }
  
  public HashMap<String, Object> getConcreteTypes()
  {
    return null;
  }
  
  public abstract HashMap<String, Field<?, ?>> getFieldMappings();
  
  protected Object getFieldValue(Field paramField)
  {
    boolean bool = true;
    String str1 = paramField.getOutputFieldName();
    if (paramField.getConcreteType() != null)
    {
      if (getValueObject(paramField.getOutputFieldName()) == null)
      {
        at.a(bool, "Concrete field shouldn't be value object: " + paramField.getOutputFieldName());
        if (!paramField.isTypeOutArray()) {
          break label83;
        }
      }
      label83:
      for (HashMap localHashMap = getConcreteTypeArrays();; localHashMap = getConcreteTypes())
      {
        if (localHashMap == null) {
          break label92;
        }
        return localHashMap.get(str1);
        bool = false;
        break;
      }
      try
      {
        label92:
        String str2 = "get" + Character.toUpperCase(str1.charAt(0)) + str1.substring(1);
        Object localObject = getClass().getMethod(str2, new Class[0]).invoke(this, new Object[0]);
        return localObject;
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localException);
      }
    }
    return getValueObject(paramField.getOutputFieldName());
  }
  
  protected <O, I> I getOriginalValue(Field<I, O> paramField, Object paramObject)
  {
    if (Field.a(paramField) != null) {
      paramObject = paramField.convertBack(paramObject);
    }
    return paramObject;
  }
  
  /* Error */
  public byte[] getResponseBody()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 296	com/google/android/gms/common/server/response/FastJsonResponse:uK	Z
    //   4: invokestatic 300	com/google/android/gms/internal/at:f	(Z)V
    //   7: new 196	java/util/zip/GZIPInputStream
    //   10: dup
    //   11: new 185	java/io/ByteArrayInputStream
    //   14: dup
    //   15: aload_0
    //   16: getfield 302	com/google/android/gms/common/server/response/FastJsonResponse:uJ	[B
    //   19: invokespecial 188	java/io/ByteArrayInputStream:<init>	([B)V
    //   22: invokespecial 199	java/util/zip/GZIPInputStream:<init>	(Ljava/io/InputStream;)V
    //   25: astore_1
    //   26: sipush 4096
    //   29: newarray byte
    //   31: astore 7
    //   33: new 304	java/io/ByteArrayOutputStream
    //   36: dup
    //   37: invokespecial 305	java/io/ByteArrayOutputStream:<init>	()V
    //   40: astore 8
    //   42: aload_1
    //   43: aload 7
    //   45: iconst_0
    //   46: aload 7
    //   48: arraylength
    //   49: invokevirtual 311	java/io/InputStream:read	([BII)I
    //   52: istore 9
    //   54: iload 9
    //   56: iconst_m1
    //   57: if_icmpeq +35 -> 92
    //   60: aload 8
    //   62: aload 7
    //   64: iconst_0
    //   65: iload 9
    //   67: invokevirtual 315	java/io/ByteArrayOutputStream:write	([BII)V
    //   70: goto -28 -> 42
    //   73: astore 4
    //   75: aload_0
    //   76: getfield 302	com/google/android/gms/common/server/response/FastJsonResponse:uJ	[B
    //   79: astore 5
    //   81: aload_1
    //   82: ifnull +7 -> 89
    //   85: aload_1
    //   86: invokevirtual 318	java/io/InputStream:close	()V
    //   89: aload 5
    //   91: areturn
    //   92: aload 8
    //   94: invokevirtual 321	java/io/ByteArrayOutputStream:flush	()V
    //   97: aload 8
    //   99: invokevirtual 324	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   102: astore 10
    //   104: aload 10
    //   106: astore 5
    //   108: aload_1
    //   109: ifnull -20 -> 89
    //   112: aload_1
    //   113: invokevirtual 318	java/io/InputStream:close	()V
    //   116: aload 5
    //   118: areturn
    //   119: astore 11
    //   121: aload 5
    //   123: areturn
    //   124: astore 13
    //   126: aconst_null
    //   127: astore_1
    //   128: aload 13
    //   130: astore_2
    //   131: aload_1
    //   132: ifnull +7 -> 139
    //   135: aload_1
    //   136: invokevirtual 318	java/io/InputStream:close	()V
    //   139: aload_2
    //   140: athrow
    //   141: astore 6
    //   143: aload 5
    //   145: areturn
    //   146: astore_3
    //   147: goto -8 -> 139
    //   150: astore_2
    //   151: goto -20 -> 131
    //   154: astore 12
    //   156: aconst_null
    //   157: astore_1
    //   158: goto -83 -> 75
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	161	0	this	FastJsonResponse
    //   25	133	1	localGZIPInputStream	GZIPInputStream
    //   130	10	2	localObject1	Object
    //   150	1	2	localObject2	Object
    //   146	1	3	localIOException1	IOException
    //   73	1	4	localIOException2	IOException
    //   79	65	5	localObject3	Object
    //   141	1	6	localIOException3	IOException
    //   31	32	7	arrayOfByte1	byte[]
    //   40	58	8	localByteArrayOutputStream	java.io.ByteArrayOutputStream
    //   52	14	9	i	int
    //   102	3	10	arrayOfByte2	byte[]
    //   119	1	11	localIOException4	IOException
    //   154	1	12	localIOException5	IOException
    //   124	5	13	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   26	42	73	java/io/IOException
    //   42	54	73	java/io/IOException
    //   60	70	73	java/io/IOException
    //   92	104	73	java/io/IOException
    //   112	116	119	java/io/IOException
    //   7	26	124	finally
    //   85	89	141	java/io/IOException
    //   135	139	146	java/io/IOException
    //   26	42	150	finally
    //   42	54	150	finally
    //   60	70	150	finally
    //   75	81	150	finally
    //   92	104	150	finally
    //   7	26	154	java/io/IOException
  }
  
  public int getResponseCode()
  {
    at.f(this.uK);
    return this.uI;
  }
  
  protected abstract Object getValueObject(String paramString);
  
  protected boolean isConcreteTypeArrayFieldSet(String paramString)
  {
    throw new UnsupportedOperationException("Concrete type arrays not supported");
  }
  
  protected boolean isConcreteTypeFieldSet(String paramString)
  {
    throw new UnsupportedOperationException("Concrete types not supported");
  }
  
  protected boolean isFieldSet(Field paramField)
  {
    if (paramField.getTypeOut() == 11)
    {
      if (paramField.isTypeOutArray()) {
        return isConcreteTypeArrayFieldSet(paramField.getOutputFieldName());
      }
      return isConcreteTypeFieldSet(paramField.getOutputFieldName());
    }
    return isPrimitiveFieldSet(paramField.getOutputFieldName());
  }
  
  protected abstract boolean isPrimitiveFieldSet(String paramString);
  
  /* Error */
  public <T extends FastJsonResponse> void parseNetworkResponse(int paramInt, byte[] paramArrayOfByte)
    throws FastParser.ParseException
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield 327	com/google/android/gms/common/server/response/FastJsonResponse:uI	I
    //   5: aload_0
    //   6: aload_2
    //   7: putfield 302	com/google/android/gms/common/server/response/FastJsonResponse:uJ	[B
    //   10: aload_0
    //   11: iconst_1
    //   12: putfield 296	com/google/android/gms/common/server/response/FastJsonResponse:uK	Z
    //   15: aload_2
    //   16: invokestatic 349	com/google/android/gms/common/server/response/FastJsonResponse:d	([B)Ljava/io/InputStream;
    //   19: astore_3
    //   20: new 351	com/google/android/gms/common/server/response/FastParser
    //   23: dup
    //   24: invokespecial 352	com/google/android/gms/common/server/response/FastParser:<init>	()V
    //   27: aload_3
    //   28: aload_0
    //   29: invokevirtual 356	com/google/android/gms/common/server/response/FastParser:parse	(Ljava/io/InputStream;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V
    //   32: aload_3
    //   33: invokevirtual 318	java/io/InputStream:close	()V
    //   36: return
    //   37: astore 4
    //   39: aload_3
    //   40: invokevirtual 318	java/io/InputStream:close	()V
    //   43: aload 4
    //   45: athrow
    //   46: astore 6
    //   48: return
    //   49: astore 5
    //   51: goto -8 -> 43
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	54	0	this	FastJsonResponse
    //   0	54	1	paramInt	int
    //   0	54	2	paramArrayOfByte	byte[]
    //   19	21	3	localInputStream	InputStream
    //   37	7	4	localObject	Object
    //   49	1	5	localIOException1	IOException
    //   46	1	6	localIOException2	IOException
    // Exception table:
    //   from	to	target	type
    //   20	32	37	finally
    //   32	36	46	java/io/IOException
    //   39	43	49	java/io/IOException
  }
  
  public final <O> void setBigDecimal(Field<BigDecimal, O> paramField, BigDecimal paramBigDecimal)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramBigDecimal);
      return;
    }
    setBigDecimalInternal(paramField, paramField.getOutputFieldName(), paramBigDecimal);
  }
  
  protected void setBigDecimal(String paramString, BigDecimal paramBigDecimal)
  {
    throw new UnsupportedOperationException("BigDecimal not supported");
  }
  
  protected void setBigDecimalInternal(Field<?, ?> paramField, String paramString, BigDecimal paramBigDecimal)
  {
    setBigDecimal(paramString, paramBigDecimal);
  }
  
  public final <O> void setBigDecimals(Field<ArrayList<BigDecimal>, O> paramField, ArrayList<BigDecimal> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setBigDecimalsInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setBigDecimals(String paramString, ArrayList<BigDecimal> paramArrayList)
  {
    throw new UnsupportedOperationException("BigDecimal list not supported");
  }
  
  protected void setBigDecimalsInternal(Field<?, ?> paramField, String paramString, ArrayList<BigDecimal> paramArrayList)
  {
    setBigDecimals(paramString, paramArrayList);
  }
  
  public final <O> void setBigInteger(Field<BigInteger, O> paramField, BigInteger paramBigInteger)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramBigInteger);
      return;
    }
    setBigIntegerInternal(paramField, paramField.getOutputFieldName(), paramBigInteger);
  }
  
  protected void setBigInteger(String paramString, BigInteger paramBigInteger)
  {
    throw new UnsupportedOperationException("BigInteger not supported");
  }
  
  protected void setBigIntegerInternal(Field<?, ?> paramField, String paramString, BigInteger paramBigInteger)
  {
    setBigInteger(paramString, paramBigInteger);
  }
  
  public final <O> void setBigIntegers(Field<ArrayList<BigInteger>, O> paramField, ArrayList<BigInteger> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setBigIntegersInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setBigIntegers(String paramString, ArrayList<BigInteger> paramArrayList)
  {
    throw new UnsupportedOperationException("BigInteger list not supported");
  }
  
  protected void setBigIntegersInternal(Field<?, ?> paramField, String paramString, ArrayList<BigInteger> paramArrayList)
  {
    setBigIntegers(paramString, paramArrayList);
  }
  
  public final <O> void setBoolean(Field<Boolean, O> paramField, boolean paramBoolean)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, Boolean.valueOf(paramBoolean));
      return;
    }
    setBooleanInternal(paramField, paramField.getOutputFieldName(), paramBoolean);
  }
  
  protected void setBoolean(String paramString, boolean paramBoolean)
  {
    throw new UnsupportedOperationException("Boolean not supported");
  }
  
  protected void setBooleanInternal(Field<?, ?> paramField, String paramString, boolean paramBoolean)
  {
    setBoolean(paramString, paramBoolean);
  }
  
  public final <O> void setBooleans(Field<ArrayList<Boolean>, O> paramField, ArrayList<Boolean> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setBooleansInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setBooleans(String paramString, ArrayList<Boolean> paramArrayList)
  {
    throw new UnsupportedOperationException("Boolean list not supported");
  }
  
  protected void setBooleansInternal(Field<?, ?> paramField, String paramString, ArrayList<Boolean> paramArrayList)
  {
    setBooleans(paramString, paramArrayList);
  }
  
  public final <O> void setDecodedBytes(Field<byte[], O> paramField, byte[] paramArrayOfByte)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayOfByte);
      return;
    }
    setDecodedBytesInternal(paramField, paramField.getOutputFieldName(), paramArrayOfByte);
  }
  
  protected void setDecodedBytes(String paramString, byte[] paramArrayOfByte)
  {
    throw new UnsupportedOperationException("byte[] not supported");
  }
  
  protected void setDecodedBytesInternal(Field<?, ?> paramField, String paramString, byte[] paramArrayOfByte)
  {
    setDecodedBytes(paramString, paramArrayOfByte);
  }
  
  public final <O> void setDouble(Field<Double, O> paramField, double paramDouble)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, Double.valueOf(paramDouble));
      return;
    }
    setDoubleInternal(paramField, paramField.getOutputFieldName(), paramDouble);
  }
  
  protected void setDouble(String paramString, double paramDouble)
  {
    throw new UnsupportedOperationException("Double not supported");
  }
  
  protected void setDoubleInternal(Field<?, ?> paramField, String paramString, double paramDouble)
  {
    setDouble(paramString, paramDouble);
  }
  
  public final <O> void setDoubles(Field<ArrayList<Double>, O> paramField, ArrayList<Double> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setDoublesInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setDoubles(String paramString, ArrayList<Double> paramArrayList)
  {
    throw new UnsupportedOperationException("Double list not supported");
  }
  
  protected void setDoublesInternal(Field<?, ?> paramField, String paramString, ArrayList<Double> paramArrayList)
  {
    setDoubles(paramString, paramArrayList);
  }
  
  public final <O> void setFloat(Field<Float, O> paramField, float paramFloat)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, Float.valueOf(paramFloat));
      return;
    }
    setFloatInternal(paramField, paramField.getOutputFieldName(), paramFloat);
  }
  
  protected void setFloat(String paramString, float paramFloat)
  {
    throw new UnsupportedOperationException("Float not supported");
  }
  
  protected void setFloatInternal(Field<?, ?> paramField, String paramString, float paramFloat)
  {
    setFloat(paramString, paramFloat);
  }
  
  public final <O> void setFloats(Field<ArrayList<Float>, O> paramField, ArrayList<Float> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setFloatsInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setFloats(String paramString, ArrayList<Float> paramArrayList)
  {
    throw new UnsupportedOperationException("Float list not supported");
  }
  
  protected void setFloatsInternal(Field<?, ?> paramField, String paramString, ArrayList<Float> paramArrayList)
  {
    setFloats(paramString, paramArrayList);
  }
  
  public final <O> void setInteger(Field<Integer, O> paramField, int paramInt)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, Integer.valueOf(paramInt));
      return;
    }
    setIntegerInternal(paramField, paramField.getOutputFieldName(), paramInt);
  }
  
  protected void setInteger(String paramString, int paramInt)
  {
    throw new UnsupportedOperationException("Integer not supported");
  }
  
  protected void setIntegerInternal(Field<?, ?> paramField, String paramString, int paramInt)
  {
    setInteger(paramString, paramInt);
  }
  
  public final <O> void setIntegers(Field<ArrayList<Integer>, O> paramField, ArrayList<Integer> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setIntegersInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setIntegers(String paramString, ArrayList<Integer> paramArrayList)
  {
    throw new UnsupportedOperationException("Integer list not supported");
  }
  
  protected void setIntegersInternal(Field<?, ?> paramField, String paramString, ArrayList<Integer> paramArrayList)
  {
    setIntegers(paramString, paramArrayList);
  }
  
  public final <O> void setLong(Field<Long, O> paramField, long paramLong)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, Long.valueOf(paramLong));
      return;
    }
    setLongInternal(paramField, paramField.getOutputFieldName(), paramLong);
  }
  
  protected void setLong(String paramString, long paramLong)
  {
    throw new UnsupportedOperationException("Long not supported");
  }
  
  protected void setLongInternal(Field<?, ?> paramField, String paramString, long paramLong)
  {
    setLong(paramString, paramLong);
  }
  
  public final <O> void setLongs(Field<ArrayList<Long>, O> paramField, ArrayList<Long> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setLongsInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setLongs(String paramString, ArrayList<Long> paramArrayList)
  {
    throw new UnsupportedOperationException("Long list not supported");
  }
  
  protected void setLongsInternal(Field<?, ?> paramField, String paramString, ArrayList<Long> paramArrayList)
  {
    setLongs(paramString, paramArrayList);
  }
  
  public final <O> void setString(Field<String, O> paramField, String paramString)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramString);
      return;
    }
    setStringInternal(paramField, paramField.getOutputFieldName(), paramString);
  }
  
  protected void setString(String paramString1, String paramString2)
  {
    throw new UnsupportedOperationException("String not supported");
  }
  
  protected void setStringInternal(Field<?, ?> paramField, String paramString1, String paramString2)
  {
    setString(paramString1, paramString2);
  }
  
  public final <O> void setStringMap(Field<Map<String, String>, O> paramField, Map<String, String> paramMap)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramMap);
      return;
    }
    setStringMapInternal(paramField, paramField.getOutputFieldName(), paramMap);
  }
  
  protected void setStringMap(String paramString, Map<String, String> paramMap)
  {
    throw new UnsupportedOperationException("String map not supported");
  }
  
  protected void setStringMapInternal(Field<?, ?> paramField, String paramString, Map<String, String> paramMap)
  {
    setStringMap(paramString, paramMap);
  }
  
  public final <O> void setStrings(Field<ArrayList<String>, O> paramField, ArrayList<String> paramArrayList)
  {
    if (Field.a(paramField) != null)
    {
      a(paramField, paramArrayList);
      return;
    }
    setStringsInternal(paramField, paramField.getOutputFieldName(), paramArrayList);
  }
  
  protected void setStrings(String paramString, ArrayList<String> paramArrayList)
  {
    throw new UnsupportedOperationException("String list not supported");
  }
  
  protected void setStringsInternal(Field<?, ?> paramField, String paramString, ArrayList<String> paramArrayList)
  {
    setStrings(paramString, paramArrayList);
  }
  
  public String toString()
  {
    HashMap localHashMap = getFieldMappings();
    StringBuilder localStringBuilder = new StringBuilder(100);
    Iterator localIterator = localHashMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Field localField = (Field)localHashMap.get(str);
      if (isFieldSet(localField))
      {
        Object localObject = getOriginalValue(localField, getFieldValue(localField));
        if (localStringBuilder.length() == 0) {
          localStringBuilder.append("{");
        }
        for (;;)
        {
          localStringBuilder.append("\"").append(str).append("\":");
          if (localObject != null) {
            break label138;
          }
          localStringBuilder.append("null");
          break;
          localStringBuilder.append(",");
        }
        label138:
        switch (localField.getTypeOut())
        {
        default: 
          if (localField.isTypeInArray()) {
            a(localStringBuilder, localField, (ArrayList)localObject);
          }
          break;
        case 8: 
          localStringBuilder.append("\"").append(bh.e((byte[])localObject)).append("\"");
          break;
        case 9: 
          localStringBuilder.append("\"").append(bh.f((byte[])localObject)).append("\"");
          break;
        case 10: 
          bm.a(localStringBuilder, (HashMap)localObject);
          continue;
          a(localStringBuilder, localField, localObject);
        }
      }
    }
    if (localStringBuilder.length() > 0) {
      localStringBuilder.append("}");
    }
    for (;;)
    {
      return localStringBuilder.toString();
      localStringBuilder.append("{}");
    }
  }
  
  public static class Field<I, O>
    implements SafeParcelable
  {
    public static final a CREATOR = new a();
    protected final Class<? extends FastJsonResponse> mConcreteType;
    protected final String mConcreteTypeName;
    protected final String mOutputFieldName;
    protected final int mSafeParcelableFieldId;
    protected final int mTypeIn;
    protected final boolean mTypeInArray;
    protected final int mTypeOut;
    protected final boolean mTypeOutArray;
    private final int oj;
    private FieldMappingDictionary uL;
    private FastJsonResponse.FieldConverter<I, O> uM;
    
    Field(int paramInt1, int paramInt2, boolean paramBoolean1, int paramInt3, boolean paramBoolean2, String paramString1, int paramInt4, String paramString2, bb parambb)
    {
      this.oj = paramInt1;
      this.mTypeIn = paramInt2;
      this.mTypeInArray = paramBoolean1;
      this.mTypeOut = paramInt3;
      this.mTypeOutArray = paramBoolean2;
      this.mOutputFieldName = paramString1;
      this.mSafeParcelableFieldId = paramInt4;
      if (paramString2 == null) {
        this.mConcreteType = null;
      }
      for (this.mConcreteTypeName = null; parambb == null; this.mConcreteTypeName = paramString2)
      {
        this.uM = null;
        return;
        this.mConcreteType = e.class;
      }
      this.uM = parambb.cc();
    }
    
    protected Field(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, String paramString, int paramInt3, Class<? extends FastJsonResponse> paramClass, FastJsonResponse.FieldConverter<I, O> paramFieldConverter)
    {
      this.oj = 1;
      this.mTypeIn = paramInt1;
      this.mTypeInArray = paramBoolean1;
      this.mTypeOut = paramInt2;
      this.mTypeOutArray = paramBoolean2;
      this.mOutputFieldName = paramString;
      this.mSafeParcelableFieldId = paramInt3;
      this.mConcreteType = paramClass;
      if (paramClass == null) {}
      for (this.mConcreteTypeName = null;; this.mConcreteTypeName = paramClass.getCanonicalName())
      {
        this.uM = paramFieldConverter;
        return;
      }
    }
    
    public static Field<byte[], byte[]> forBase64(String paramString)
    {
      return new Field(8, false, 8, false, paramString, -1, null, null);
    }
    
    public static Field<byte[], byte[]> forBase64(String paramString, int paramInt)
    {
      return new Field(8, false, 8, false, paramString, paramInt, null, null);
    }
    
    public static Field<byte[], byte[]> forBase64UrlSafe(String paramString)
    {
      return new Field(9, false, 9, false, paramString, -1, null, null);
    }
    
    public static Field<byte[], byte[]> forBase64UrlSafe(String paramString, int paramInt)
    {
      return new Field(9, false, 9, false, paramString, paramInt, null, null);
    }
    
    public static Field<BigDecimal, BigDecimal> forBigDecimal(String paramString)
    {
      return new Field(5, false, 5, false, paramString, -1, null, null);
    }
    
    public static Field<BigDecimal, BigDecimal> forBigDecimal(String paramString, int paramInt)
    {
      return new Field(5, false, 5, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<BigDecimal>, ArrayList<BigDecimal>> forBigDecimals(String paramString)
    {
      return new Field(5, true, 5, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<BigDecimal>, ArrayList<BigDecimal>> forBigDecimals(String paramString, int paramInt)
    {
      return new Field(5, true, 5, true, paramString, paramInt, null, null);
    }
    
    public static Field<BigInteger, BigInteger> forBigInteger(String paramString)
    {
      return new Field(1, false, 1, false, paramString, -1, null, null);
    }
    
    public static Field<BigInteger, BigInteger> forBigInteger(String paramString, int paramInt)
    {
      return new Field(1, false, 1, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<BigInteger>, ArrayList<BigInteger>> forBigIntegers(String paramString)
    {
      return new Field(0, true, 1, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<BigInteger>, ArrayList<BigInteger>> forBigIntegers(String paramString, int paramInt)
    {
      return new Field(0, true, 1, true, paramString, paramInt, null, null);
    }
    
    public static Field<Boolean, Boolean> forBoolean(String paramString)
    {
      return new Field(6, false, 6, false, paramString, -1, null, null);
    }
    
    public static Field<Boolean, Boolean> forBoolean(String paramString, int paramInt)
    {
      return new Field(6, false, 6, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<Boolean>, ArrayList<Boolean>> forBooleans(String paramString)
    {
      return new Field(6, true, 6, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<Boolean>, ArrayList<Boolean>> forBooleans(String paramString, int paramInt)
    {
      return new Field(6, true, 6, true, paramString, paramInt, null, null);
    }
    
    public static <T extends FastJsonResponse> Field<T, T> forConcreteType(String paramString, int paramInt, Class<T> paramClass)
    {
      return new Field(11, false, 11, false, paramString, paramInt, paramClass, null);
    }
    
    public static <T extends FastJsonResponse> Field<T, T> forConcreteType(String paramString, Class<T> paramClass)
    {
      return new Field(11, false, 11, false, paramString, -1, paramClass, null);
    }
    
    public static <T extends FastJsonResponse> Field<ArrayList<T>, ArrayList<T>> forConcreteTypeArray(String paramString, int paramInt, Class<T> paramClass)
    {
      return new Field(11, true, 11, true, paramString, paramInt, paramClass, null);
    }
    
    public static <T extends FastJsonResponse> Field<ArrayList<T>, ArrayList<T>> forConcreteTypeArray(String paramString, Class<T> paramClass)
    {
      return new Field(11, true, 11, true, paramString, -1, paramClass, null);
    }
    
    public static Field<Double, Double> forDouble(String paramString)
    {
      return new Field(4, false, 4, false, paramString, -1, null, null);
    }
    
    public static Field<Double, Double> forDouble(String paramString, int paramInt)
    {
      return new Field(4, false, 4, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<Double>, ArrayList<Double>> forDoubles(String paramString)
    {
      return new Field(4, true, 4, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<Double>, ArrayList<Double>> forDoubles(String paramString, int paramInt)
    {
      return new Field(4, true, 4, true, paramString, paramInt, null, null);
    }
    
    public static Field<Float, Float> forFloat(String paramString)
    {
      return new Field(3, false, 3, false, paramString, -1, null, null);
    }
    
    public static Field<Float, Float> forFloat(String paramString, int paramInt)
    {
      return new Field(3, false, 3, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<Float>, ArrayList<Float>> forFloats(String paramString)
    {
      return new Field(3, true, 3, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<Float>, ArrayList<Float>> forFloats(String paramString, int paramInt)
    {
      return new Field(3, true, 3, true, paramString, paramInt, null, null);
    }
    
    public static Field<Integer, Integer> forInteger(String paramString)
    {
      return new Field(0, false, 0, false, paramString, -1, null, null);
    }
    
    public static Field<Integer, Integer> forInteger(String paramString, int paramInt)
    {
      return new Field(0, false, 0, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<Integer>, ArrayList<Integer>> forIntegers(String paramString)
    {
      return new Field(0, true, 0, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<Integer>, ArrayList<Integer>> forIntegers(String paramString, int paramInt)
    {
      return new Field(0, true, 0, true, paramString, paramInt, null, null);
    }
    
    public static Field<Long, Long> forLong(String paramString)
    {
      return new Field(2, false, 2, false, paramString, -1, null, null);
    }
    
    public static Field<Long, Long> forLong(String paramString, int paramInt)
    {
      return new Field(2, false, 2, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<Long>, ArrayList<Long>> forLongs(String paramString)
    {
      return new Field(2, true, 2, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<Long>, ArrayList<Long>> forLongs(String paramString, int paramInt)
    {
      return new Field(2, true, 2, true, paramString, paramInt, null, null);
    }
    
    public static Field<String, String> forString(String paramString)
    {
      return new Field(7, false, 7, false, paramString, -1, null, null);
    }
    
    public static Field<String, String> forString(String paramString, int paramInt)
    {
      return new Field(7, false, 7, false, paramString, paramInt, null, null);
    }
    
    public static Field<HashMap<String, String>, HashMap<String, String>> forStringMap(String paramString)
    {
      return new Field(10, false, 10, false, paramString, -1, null, null);
    }
    
    public static Field<HashMap<String, String>, HashMap<String, String>> forStringMap(String paramString, int paramInt)
    {
      return new Field(10, false, 10, false, paramString, paramInt, null, null);
    }
    
    public static Field<ArrayList<String>, ArrayList<String>> forStrings(String paramString)
    {
      return new Field(7, true, 7, true, paramString, -1, null, null);
    }
    
    public static Field<ArrayList<String>, ArrayList<String>> forStrings(String paramString, int paramInt)
    {
      return new Field(7, true, 7, true, paramString, paramInt, null, null);
    }
    
    public static Field withConverter(String paramString, int paramInt, FastJsonResponse.FieldConverter<?, ?> paramFieldConverter, boolean paramBoolean)
    {
      return new Field(paramFieldConverter.getTypeIn(), paramBoolean, paramFieldConverter.getTypeOut(), false, paramString, paramInt, null, paramFieldConverter);
    }
    
    public static <T extends FastJsonResponse.FieldConverter> Field withConverter(String paramString, int paramInt, Class<T> paramClass, boolean paramBoolean)
    {
      try
      {
        Field localField = withConverter(paramString, paramInt, (FastJsonResponse.FieldConverter)paramClass.newInstance(), paramBoolean);
        return localField;
      }
      catch (InstantiationException localInstantiationException)
      {
        throw new RuntimeException(localInstantiationException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new RuntimeException(localIllegalAccessException);
      }
    }
    
    public static Field withConverter(String paramString, FastJsonResponse.FieldConverter<?, ?> paramFieldConverter, boolean paramBoolean)
    {
      return withConverter(paramString, -1, paramFieldConverter, paramBoolean);
    }
    
    public static <T extends FastJsonResponse.FieldConverter> Field withConverter(String paramString, Class<T> paramClass, boolean paramBoolean)
    {
      return withConverter(paramString, -1, paramClass, paramBoolean);
    }
    
    String ce()
    {
      if (this.mConcreteTypeName == null) {
        return null;
      }
      return this.mConcreteTypeName;
    }
    
    bb cf()
    {
      if (this.uM == null) {
        return null;
      }
      return bb.a(this.uM);
    }
    
    public O convert(I paramI)
    {
      return this.uM.convert(paramI);
    }
    
    public I convertBack(O paramO)
    {
      return this.uM.convertBack(paramO);
    }
    
    public Field<I, O> copyForDictionary()
    {
      return new Field(this.oj, this.mTypeIn, this.mTypeInArray, this.mTypeOut, this.mTypeOutArray, this.mOutputFieldName, this.mSafeParcelableFieldId, this.mConcreteTypeName, cf());
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public Class<? extends FastJsonResponse> getConcreteType()
    {
      return this.mConcreteType;
    }
    
    public HashMap<String, Field<?, ?>> getConcreteTypeFieldMappingFromDictionary()
    {
      at.f(this.mConcreteTypeName);
      at.f(this.uL);
      return this.uL.getFieldMapping(this.mConcreteTypeName);
    }
    
    public String getOutputFieldName()
    {
      return this.mOutputFieldName;
    }
    
    public int getSafeParcelableFieldId()
    {
      return this.mSafeParcelableFieldId;
    }
    
    public int getTypeIn()
    {
      return this.mTypeIn;
    }
    
    public int getTypeOut()
    {
      return this.mTypeOut;
    }
    
    public int getVersionCode()
    {
      return this.oj;
    }
    
    public boolean hasConverter()
    {
      return this.uM != null;
    }
    
    public boolean isTypeInArray()
    {
      return this.mTypeInArray;
    }
    
    public boolean isTypeOutArray()
    {
      return this.mTypeOutArray;
    }
    
    public boolean isValidSafeParcelableFieldId()
    {
      return this.mSafeParcelableFieldId != -1;
    }
    
    public FastJsonResponse newConcreteTypeInstance()
      throws InstantiationException, IllegalAccessException
    {
      if (this.mConcreteType == e.class)
      {
        at.a(this.uL, "The field mapping dictionary must be set if the concrete type is a SafeParcelResponse object.");
        return new e(this.uL, this.mConcreteTypeName);
      }
      return (FastJsonResponse)this.mConcreteType.newInstance();
    }
    
    public void setFieldMappingDictionary(FieldMappingDictionary paramFieldMappingDictionary)
    {
      this.uL = paramFieldMappingDictionary;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      localStringBuilder1.append("Field\n");
      localStringBuilder1.append("            versionCode=").append(this.oj).append('\n');
      localStringBuilder1.append("                 typeIn=").append(this.mTypeIn).append('\n');
      localStringBuilder1.append("            typeInArray=").append(this.mTypeInArray).append('\n');
      localStringBuilder1.append("                typeOut=").append(this.mTypeOut).append('\n');
      localStringBuilder1.append("           typeOutArray=").append(this.mTypeOutArray).append('\n');
      localStringBuilder1.append("        outputFieldName=").append(this.mOutputFieldName).append('\n');
      localStringBuilder1.append("      safeParcelFieldId=").append(this.mSafeParcelableFieldId).append('\n');
      localStringBuilder1.append("       concreteTypeName=").append(ce()).append('\n');
      if (getConcreteType() != null) {
        localStringBuilder1.append("     concreteType.class=").append(getConcreteType().getCanonicalName()).append('\n');
      }
      StringBuilder localStringBuilder2 = localStringBuilder1.append("          converterName=");
      if (this.uM == null) {}
      for (String str = "null";; str = this.uM.getClass().getCanonicalName())
      {
        localStringBuilder2.append(str).append('\n');
        return localStringBuilder1.toString();
      }
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      a.a(this, paramParcel, paramInt);
    }
  }
  
  public static abstract interface FieldConverter<I, O>
  {
    public abstract O convert(I paramI);
    
    public abstract I convertBack(O paramO);
    
    public abstract int getTypeIn();
    
    public abstract int getTypeOut();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.FastJsonResponse
 * JD-Core Version:    0.7.0.1
 */