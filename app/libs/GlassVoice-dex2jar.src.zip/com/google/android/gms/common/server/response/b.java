package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;

public class b
  implements Parcelable.Creator<FieldMappingDictionary.FieldMapPair>
{
  static void a(FieldMappingDictionary.FieldMapPair paramFieldMapPair, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramFieldMapPair.versionCode);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, paramFieldMapPair.key, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramFieldMapPair.vm, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public FieldMappingDictionary.FieldMapPair ah(Parcel paramParcel)
  {
    FastJsonResponse.Field localField = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
        break;
      case 3: 
        localField = (FastJsonResponse.Field)a.a(paramParcel, k, FastJsonResponse.Field.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new FieldMappingDictionary.FieldMapPair(j, str, localField);
  }
  
  public FieldMappingDictionary.FieldMapPair[] av(int paramInt)
  {
    return new FieldMappingDictionary.FieldMapPair[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.b
 * JD-Core Version:    0.7.0.1
 */