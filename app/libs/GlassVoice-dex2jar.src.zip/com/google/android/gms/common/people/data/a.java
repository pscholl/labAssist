package com.google.android.gms.common.people.data;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class a
  implements Parcelable.Creator<Audience>
{
  static void a(Audience paramAudience, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.b(paramParcel, 1, paramAudience.getAudienceMemberList(), false);
    b.c(paramParcel, 1000, paramAudience.getVersionCode());
    b.c(paramParcel, 2, paramAudience.getDomainRestricted());
    b.a(paramParcel, 3, paramAudience.ca());
    b.a(paramParcel, 4, paramAudience.isReadOnly());
    b.C(paramParcel, i);
  }
  
  public Audience aa(Parcel paramParcel)
  {
    boolean bool1 = false;
    int i = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    ArrayList localArrayList = null;
    boolean bool2 = false;
    int j = 0;
    int k = 0;
    while (paramParcel.dataPosition() < i)
    {
      int m = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.al(m))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, m);
        break;
      case 1: 
        localArrayList = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, m, AudienceMember.CREATOR);
        break;
      case 1000: 
        k = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, m);
        break;
      case 2: 
        j = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, m);
        break;
      case 3: 
        bool2 = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, m);
        break;
      case 4: 
        bool1 = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, m);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new Audience(k, localArrayList, j, bool2, bool1);
  }
  
  public Audience[] an(int paramInt)
  {
    return new Audience[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.people.data.a
 * JD-Core Version:    0.7.0.1
 */