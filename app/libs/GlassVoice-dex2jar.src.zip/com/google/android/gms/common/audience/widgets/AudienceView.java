package com.google.android.gms.common.audience.widgets;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.people.data.Audience;
import com.google.android.gms.common.people.data.AudienceMember;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.internal.ab;
import com.google.android.gms.internal.ab.a;
import com.google.android.gms.internal.ac;
import com.google.android.gms.internal.ac.a;
import com.google.android.gms.internal.ad;
import com.google.android.gms.internal.at;
import com.google.android.gms.people.PeopleClient;
import com.google.android.gms.people.PeopleClient.OnImageLoadedListener;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public final class AudienceView
  extends FrameLayout
{
  public static final int EDIT_MODE_CLICK_TO_EDIT = 3;
  public static final int EDIT_MODE_CLICK_TO_REMOVE = 2;
  public static final int EDIT_MODE_READ_ONLY = 1;
  protected static final String PACKAGE_IMPLEMENTATION_CLASS_NAME = "com.google.android.gms.plus.audience.widgets.AudienceViewImpl$DynamiteHost";
  private static Context rJ;
  private final Context rK;
  private final ab rL;
  private EditAudienceCallback rM;
  private RemoveAudienceMemberCallback rN;
  
  public AudienceView(Context paramContext)
  {
    this(paramContext, null, 0);
  }
  
  public AudienceView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AudienceView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    Pair localPair = q(paramContext);
    this.rL = ((ab)localPair.first);
    this.rK = ((Context)localPair.second);
  }
  
  private void a(int paramInt, EditAudienceCallback paramEditAudienceCallback, RemoveAudienceMemberCallback paramRemoveAudienceMemberCallback)
  {
    this.rM = paramEditAudienceCallback;
    this.rN = paramRemoveAudienceMemberCallback;
    try
    {
      this.rL.ac(paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  private static Pair<ab, Context> q(Context paramContext)
  {
    if (rJ == null) {
      rJ = GooglePlayServicesUtil.getRemoteContext(paramContext);
    }
    ClassLoader localClassLoader;
    if (rJ != null) {
      localClassLoader = rJ.getClassLoader();
    }
    try
    {
      Pair localPair = new Pair(ab.a.l((IBinder)localClassLoader.loadClass("com.google.android.gms.plus.audience.widgets.AudienceViewImpl$DynamiteHost").newInstance()), rJ);
      return localPair;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      if ((localIllegalAccessException != null) && (Log.isLoggable("AudienceView", 3))) {
        Log.d("AudienceView", "Can't load com.google.android.gms.plus.audience.widgets.AudienceViewImpl$DynamiteHost", localIllegalAccessException);
      }
      return new Pair(new a(null), paramContext);
    }
    catch (InstantiationException localInstantiationException)
    {
      break label55;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      label55:
      break label55;
    }
  }
  
  public void initialize(final ImageLoadCallback paramImageLoadCallback)
  {
    try
    {
      this.rL.a(c.g(getContext()), c.g(this.rK), new ac.a()
      {
        public void a(final ad paramAnonymousad, String paramAnonymousString, int paramAnonymousInt1, int paramAnonymousInt2)
        {
          paramImageLoadCallback.loadImage(new AudienceView.ImageLoadedCallback()
          {
            public void imageLoaded(ConnectionResult paramAnonymous2ConnectionResult, ParcelFileDescriptor paramAnonymous2ParcelFileDescriptor)
            {
              try
              {
                paramAnonymousad.a(paramAnonymous2ConnectionResult.getErrorCode(), paramAnonymous2ParcelFileDescriptor);
                return;
              }
              catch (RemoteException localRemoteException)
              {
                localRemoteException.printStackTrace();
              }
            }
          }, paramAnonymousString, paramAnonymousInt1, paramAnonymousInt2);
        }
        
        public void editAudience()
        {
          AudienceView.b(AudienceView.this).editAudience();
        }
        
        public void removeAudienceMember(AudienceMember paramAnonymousAudienceMember)
        {
          AudienceView.a(AudienceView.this).removeAudienceMember(paramAnonymousAudienceMember);
        }
      });
      addView((View)c.d(this.rL.getView()));
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    Bundle localBundle = (Bundle)paramParcelable;
    super.onRestoreInstanceState(localBundle.getParcelable("parent"));
    try
    {
      this.rL.onRestoreInstanceState(localBundle.getBundle("impl"));
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  protected Parcelable onSaveInstanceState()
  {
    Bundle localBundle = new Bundle();
    localBundle.putParcelable("parent", super.onSaveInstanceState());
    try
    {
      localBundle.putBundle("impl", this.rL.onSaveInstanceState());
      return localBundle;
    }
    catch (RemoteException localRemoteException) {}
    return localBundle;
  }
  
  public void setAudience(Audience paramAudience)
  {
    try
    {
      this.rL.setAudience(paramAudience);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setModeClickToEdit(EditAudienceCallback paramEditAudienceCallback)
  {
    a(3, (EditAudienceCallback)at.f(paramEditAudienceCallback), null);
  }
  
  public void setModeClickToRemove(RemoveAudienceMemberCallback paramRemoveAudienceMemberCallback)
  {
    a(2, null, (RemoveAudienceMemberCallback)at.f(paramRemoveAudienceMemberCallback));
  }
  
  public void setModeReadonly()
  {
    a(1, null, null);
  }
  
  public void setShowEmptyText(boolean paramBoolean)
  {
    try
    {
      this.rL.setShowEmptyText(paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static abstract interface EditAudienceCallback
  {
    public abstract void editAudience();
  }
  
  public static abstract interface ImageLoadCallback
  {
    public abstract void loadImage(AudienceView.ImageLoadedCallback paramImageLoadedCallback, String paramString, int paramInt1, int paramInt2);
  }
  
  public static abstract interface ImageLoadedCallback
  {
    public abstract void imageLoaded(ConnectionResult paramConnectionResult, ParcelFileDescriptor paramParcelFileDescriptor);
  }
  
  public static class PeopleClientImageLoader
    implements AudienceView.ImageLoadCallback
  {
    private PeopleClient rU;
    private final GooglePlayServicesClient.ConnectionCallbacks rV = new GooglePlayServicesClient.ConnectionCallbacks()
    {
      public void onConnected(Bundle paramAnonymousBundle)
      {
        while (!AudienceView.PeopleClientImageLoader.a(AudienceView.PeopleClientImageLoader.this).isEmpty())
        {
          AudienceView.PeopleClientImageLoader.a locala = (AudienceView.PeopleClientImageLoader.a)AudienceView.PeopleClientImageLoader.a(AudienceView.PeopleClientImageLoader.this).remove();
          AudienceView.PeopleClientImageLoader.b(AudienceView.PeopleClientImageLoader.this).loadAvatarByUrl(AudienceView.PeopleClientImageLoader.a.a(locala), AudienceView.PeopleClientImageLoader.a.b(locala), AudienceView.PeopleClientImageLoader.a.c(locala), AudienceView.PeopleClientImageLoader.a.d(locala));
        }
      }
      
      public void onDisconnected() {}
    };
    private final Queue<a> rW = new LinkedList();
    
    public PeopleClientImageLoader(PeopleClient paramPeopleClient)
    {
      this.rU = paramPeopleClient;
      paramPeopleClient.registerConnectionCallbacks(this.rV);
    }
    
    public void loadImage(final AudienceView.ImageLoadedCallback paramImageLoadedCallback, String paramString, int paramInt1, int paramInt2)
    {
      PeopleClient.OnImageLoadedListener local2 = new PeopleClient.OnImageLoadedListener()
      {
        public void onImageLoaded(ConnectionResult paramAnonymousConnectionResult, ParcelFileDescriptor paramAnonymousParcelFileDescriptor)
        {
          paramImageLoadedCallback.imageLoaded(paramAnonymousConnectionResult, paramAnonymousParcelFileDescriptor);
        }
      };
      if ((this.rU != null) && (this.rU.isConnected()))
      {
        this.rU.loadAvatarByUrl(local2, paramString, paramInt1, paramInt2);
        return;
      }
      this.rW.add(new a(local2, paramString, paramInt2, paramInt2));
    }
    
    private static class a
    {
      private final PeopleClient.OnImageLoadedListener rZ;
      private final int sa;
      private final int sb;
      private final String url;
      
      public a(PeopleClient.OnImageLoadedListener paramOnImageLoadedListener, String paramString, int paramInt1, int paramInt2)
      {
        this.rZ = paramOnImageLoadedListener;
        this.url = paramString;
        this.sa = paramInt1;
        this.sb = paramInt2;
      }
    }
  }
  
  public static abstract interface RemoveAudienceMemberCallback
  {
    public abstract void removeAudienceMember(AudienceMember paramAudienceMember);
  }
  
  private static class a
    extends ab.a
  {
    private Audience rS;
    private TextView rT;
    
    public void a(b paramb1, b paramb2, ac paramac)
    {
      this.rT = new TextView((Context)c.d(paramb1));
    }
    
    public void ac(int paramInt) {}
    
    public b getView()
    {
      return c.g(this.rT);
    }
    
    public void onRestoreInstanceState(Bundle paramBundle)
    {
      setAudience((Audience)paramBundle.getParcelable("audience"));
    }
    
    public Bundle onSaveInstanceState()
    {
      Bundle localBundle = new Bundle();
      localBundle.putParcelable("audience", this.rS);
      return localBundle;
    }
    
    public void setAudience(Audience paramAudience)
    {
      this.rS = paramAudience;
      if (this.rS == null)
      {
        this.rT.setText("");
        return;
      }
      Iterator localIterator = paramAudience.getAudienceMemberList().iterator();
      String str1 = null;
      if (localIterator.hasNext())
      {
        AudienceMember localAudienceMember = (AudienceMember)localIterator.next();
        StringBuilder localStringBuilder = new StringBuilder();
        if (str1 == null) {}
        for (String str2 = "";; str2 = str1 + ", ")
        {
          str1 = str2 + localAudienceMember.getDisplayName();
          break;
        }
      }
      this.rT.setText(str1);
    }
    
    public void setShowEmptyText(boolean paramBoolean) {}
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.audience.widgets.AudienceView
 * JD-Core Version:    0.7.0.1
 */