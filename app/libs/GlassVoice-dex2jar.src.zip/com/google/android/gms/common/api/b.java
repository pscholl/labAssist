package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.internal.ai;
import com.google.android.gms.internal.al;
import com.google.android.gms.internal.al.b;
import com.google.android.gms.internal.at;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

final class b
  implements GoogleApiClient
{
  final GoogleApiClient.ConnectionCallbacks rA = new GoogleApiClient.ConnectionCallbacks()
  {
    public void onConnected(Bundle paramAnonymousBundle)
    {
      b.a(b.this).lock();
      try
      {
        if (b.b(b.this) == 1)
        {
          if (paramAnonymousBundle != null) {
            b.c(b.this).putAll(paramAnonymousBundle);
          }
          b.d(b.this);
        }
        return;
      }
      finally
      {
        b.a(b.this).unlock();
      }
    }
    
    public void onConnectionSuspended(int paramAnonymousInt)
    {
      b.a(b.this).lock();
      for (;;)
      {
        try
        {
          b.a(b.this, paramAnonymousInt);
          switch (paramAnonymousInt)
          {
          default: 
            return;
          }
        }
        finally
        {
          b.a(b.this).unlock();
        }
        b.this.connect();
        continue;
        boolean bool = b.e(b.this);
        if (bool)
        {
          b.a(b.this).unlock();
          return;
        }
        b.b(b.this, 2);
        b.this.rv.sendMessageDelayed(b.this.rv.obtainMessage(1), b.f(b.this));
      }
    }
  };
  private final al.b rB = new al.b()
  {
    public Bundle bA()
    {
      return null;
    }
    
    public boolean bz()
    {
      return b.g(b.this);
    }
    
    public boolean isConnected()
    {
      return b.this.isConnected();
    }
  };
  private final a rb = new a()
  {
    public void b(b.c paramAnonymousc)
    {
      b.a(b.this).lock();
      try
      {
        b.this.rz.remove(paramAnonymousc);
        return;
      }
      finally
      {
        b.a(b.this).unlock();
      }
    }
  };
  private final Lock rk = new ReentrantLock();
  private final Condition rl = this.rk.newCondition();
  private final al rm = new al(paramContext, paramLooper, this.rB);
  final Queue<c<?>> rn = new LinkedList();
  private ConnectionResult ro;
  private int rp;
  private int rq = 4;
  private int rr = 0;
  private boolean rs = false;
  private int rt;
  private long ru = 5000L;
  final Handler rv;
  private final Bundle rw = new Bundle();
  private final Map<Api.b<?>, Api.a> rx = new HashMap();
  private boolean ry;
  final Set<c> rz = new HashSet();
  
  public b(Context paramContext, Looper paramLooper, ai paramai, Map<Api, GoogleApiClient.ApiOptions> paramMap, Set<GoogleApiClient.ConnectionCallbacks> paramSet, Set<GoogleApiClient.OnConnectionFailedListener> paramSet1)
  {
    this.rv = new b(paramLooper);
    Iterator localIterator1 = paramSet.iterator();
    while (localIterator1.hasNext())
    {
      GoogleApiClient.ConnectionCallbacks localConnectionCallbacks = (GoogleApiClient.ConnectionCallbacks)localIterator1.next();
      this.rm.registerConnectionCallbacks(localConnectionCallbacks);
    }
    Iterator localIterator2 = paramSet1.iterator();
    while (localIterator2.hasNext())
    {
      GoogleApiClient.OnConnectionFailedListener localOnConnectionFailedListener = (GoogleApiClient.OnConnectionFailedListener)localIterator2.next();
      this.rm.registerConnectionFailedListener(localOnConnectionFailedListener);
    }
    Iterator localIterator3 = paramMap.keySet().iterator();
    while (localIterator3.hasNext())
    {
      Api localApi = (Api)localIterator3.next();
      final Api.b localb = localApi.bm();
      GoogleApiClient.ApiOptions localApiOptions = (GoogleApiClient.ApiOptions)paramMap.get(localApi);
      this.rx.put(localb, localb.a(paramContext, paramLooper, paramai, localApiOptions, this.rA, new GoogleApiClient.OnConnectionFailedListener()
      {
        public void onConnectionFailed(ConnectionResult paramAnonymousConnectionResult)
        {
          b.a(b.this).lock();
          try
          {
            if ((b.h(b.this) == null) || (localb.getPriority() < b.i(b.this)))
            {
              b.a(b.this, paramAnonymousConnectionResult);
              b.c(b.this, localb.getPriority());
            }
            b.d(b.this);
            return;
          }
          finally
          {
            b.a(b.this).unlock();
          }
        }
      }));
    }
  }
  
  /* Error */
  private <A extends Api.a> void a(c<A> paramc)
    throws DeadObjectException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   4: invokeinterface 193 1 0
    //   9: aload_0
    //   10: invokevirtual 196	com/google/android/gms/common/api/b:isConnected	()Z
    //   13: ldc 198
    //   15: invokestatic 203	com/google/android/gms/internal/at:a	(ZLjava/lang/Object;)V
    //   18: aload_1
    //   19: invokeinterface 206 1 0
    //   24: ifnull +65 -> 89
    //   27: iconst_1
    //   28: istore_3
    //   29: iload_3
    //   30: ldc 208
    //   32: invokestatic 203	com/google/android/gms/internal/at:a	(ZLjava/lang/Object;)V
    //   35: aload_1
    //   36: instanceof 210
    //   39: ifeq +24 -> 63
    //   42: aload_0
    //   43: getfield 91	com/google/android/gms/common/api/b:rz	Ljava/util/Set;
    //   46: aload_1
    //   47: invokeinterface 214 2 0
    //   52: pop
    //   53: aload_1
    //   54: aload_0
    //   55: getfield 98	com/google/android/gms/common/api/b:rb	Lcom/google/android/gms/common/api/b$a;
    //   58: invokeinterface 217 2 0
    //   63: aload_1
    //   64: aload_0
    //   65: aload_1
    //   66: invokeinterface 206 1 0
    //   71: invokevirtual 220	com/google/android/gms/common/api/b:a	(Lcom/google/android/gms/common/api/Api$b;)Lcom/google/android/gms/common/api/Api$a;
    //   74: invokeinterface 223 2 0
    //   79: aload_0
    //   80: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   83: invokeinterface 226 1 0
    //   88: return
    //   89: iconst_0
    //   90: istore_3
    //   91: goto -62 -> 29
    //   94: astore_2
    //   95: aload_0
    //   96: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   99: invokeinterface 226 1 0
    //   104: aload_2
    //   105: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	106	0	this	b
    //   0	106	1	paramc	c<A>
    //   94	11	2	localObject	Object
    //   28	63	3	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   9	27	94	finally
    //   29	63	94	finally
    //   63	79	94	finally
  }
  
  private void ab(int paramInt)
  {
    this.rk.lock();
    try
    {
      if (this.rq == 3) {
        break label317;
      }
      if (paramInt != -1) {
        break label134;
      }
      if (isConnecting())
      {
        Iterator localIterator3 = this.rn.iterator();
        while (localIterator3.hasNext()) {
          if (((c)localIterator3.next()).bo() != 1) {
            localIterator3.remove();
          }
        }
      }
      this.rn.clear();
    }
    finally
    {
      this.rk.unlock();
    }
    if ((this.ro == null) && (!this.rn.isEmpty()))
    {
      this.rs = true;
      this.rk.unlock();
      return;
    }
    label134:
    boolean bool1 = isConnecting();
    boolean bool2 = isConnected();
    this.rq = 3;
    if (bool1)
    {
      if (paramInt == -1) {
        this.ro = null;
      }
      this.rl.signalAll();
    }
    Iterator localIterator1 = this.rz.iterator();
    while (localIterator1.hasNext()) {
      ((c)localIterator1.next()).br();
    }
    this.rz.clear();
    this.ry = false;
    Iterator localIterator2 = this.rx.values().iterator();
    while (localIterator2.hasNext())
    {
      Api.a locala = (Api.a)localIterator2.next();
      if (locala.isConnected()) {
        locala.disconnect();
      }
    }
    this.ry = true;
    this.rq = 4;
    if (bool2)
    {
      if (paramInt != -1) {
        this.rm.aj(paramInt);
      }
      this.ry = false;
    }
    label317:
    this.rk.unlock();
  }
  
  private void bv()
  {
    this.rk.lock();
    for (;;)
    {
      try
      {
        this.rt = (-1 + this.rt);
        if (this.rt == 0)
        {
          if (this.ro == null) {
            break label128;
          }
          this.rs = false;
          ab(3);
          if (bx()) {
            this.rr = (-1 + this.rr);
          }
          if (bx())
          {
            this.rv.sendMessageDelayed(this.rv.obtainMessage(1), this.ru);
            this.ry = false;
          }
        }
        else
        {
          return;
        }
        this.rm.a(this.ro);
        continue;
        this.rq = 2;
      }
      finally
      {
        this.rk.unlock();
      }
      label128:
      by();
      this.rl.signalAll();
      bw();
      if (!this.rs) {
        break;
      }
      this.rs = false;
      ab(-1);
    }
    if (this.rw.isEmpty()) {}
    for (Bundle localBundle = null;; localBundle = this.rw)
    {
      this.rm.a(localBundle);
      break;
    }
  }
  
  private void bw()
  {
    at.a(isConnected(), "GoogleApiClient is not connected yet.");
    this.rk.lock();
    try
    {
      for (;;)
      {
        boolean bool = this.rn.isEmpty();
        if (bool) {
          break;
        }
        try
        {
          a((c)this.rn.remove());
        }
        catch (DeadObjectException localDeadObjectException)
        {
          Log.w("GoogleApiClientImpl", "Service died while flushing queue", localDeadObjectException);
        }
      }
    }
    finally
    {
      this.rk.unlock();
    }
  }
  
  /* Error */
  private boolean bx()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   4: invokeinterface 193 1 0
    //   9: aload_0
    //   10: getfield 70	com/google/android/gms/common/api/b:rr	I
    //   13: istore_2
    //   14: iload_2
    //   15: ifeq +16 -> 31
    //   18: iconst_1
    //   19: istore_3
    //   20: aload_0
    //   21: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   24: invokeinterface 226 1 0
    //   29: iload_3
    //   30: ireturn
    //   31: iconst_0
    //   32: istore_3
    //   33: goto -13 -> 20
    //   36: astore_1
    //   37: aload_0
    //   38: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   41: invokeinterface 226 1 0
    //   46: aload_1
    //   47: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	48	0	this	b
    //   36	11	1	localObject	Object
    //   13	2	2	i	int
    //   19	14	3	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   9	14	36	finally
  }
  
  private void by()
  {
    this.rk.lock();
    try
    {
      this.rr = 0;
      this.rv.removeMessages(1);
      return;
    }
    finally
    {
      this.rk.unlock();
    }
  }
  
  public <C extends Api.a> C a(Api.b<C> paramb)
  {
    Api.a locala = (Api.a)this.rx.get(paramb);
    at.a(locala, "Appropriate Api was not requested.");
    return locala;
  }
  
  /* Error */
  public <A extends Api.a, T extends a.a<? extends Result, A>> T a(T paramT)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   4: invokeinterface 193 1 0
    //   9: aload_0
    //   10: invokevirtual 196	com/google/android/gms/common/api/b:isConnected	()Z
    //   13: ifeq +20 -> 33
    //   16: aload_0
    //   17: aload_1
    //   18: invokevirtual 348	com/google/android/gms/common/api/b:b	(Lcom/google/android/gms/common/api/a$a;)Lcom/google/android/gms/common/api/a$a;
    //   21: pop
    //   22: aload_0
    //   23: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   26: invokeinterface 226 1 0
    //   31: aload_1
    //   32: areturn
    //   33: aload_0
    //   34: getfield 66	com/google/android/gms/common/api/b:rn	Ljava/util/Queue;
    //   37: aload_1
    //   38: invokeinterface 349 2 0
    //   43: pop
    //   44: goto -22 -> 22
    //   47: astore_2
    //   48: aload_0
    //   49: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   52: invokeinterface 226 1 0
    //   57: aload_2
    //   58: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	59	0	this	b
    //   0	59	1	paramT	T
    //   47	11	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   9	22	47	finally
    //   33	44	47	finally
  }
  
  public <A extends Api.a, T extends a.a<? extends Result, A>> T b(T paramT)
  {
    at.a(isConnected(), "GoogleApiClient is not connected yet.");
    bw();
    try
    {
      a(paramT);
      return paramT;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      ab(1);
    }
    return paramT;
  }
  
  public ConnectionResult blockingConnect(long paramLong, TimeUnit paramTimeUnit)
  {
    boolean bool1;
    if (Looper.myLooper() != Looper.getMainLooper()) {
      bool1 = true;
    }
    for (;;)
    {
      at.a(bool1, "blockingConnect must not be called on the UI thread");
      this.rk.lock();
      try
      {
        connect();
        long l = paramTimeUnit.toNanos(paramLong);
        for (;;)
        {
          boolean bool2 = isConnecting();
          if (!bool2) {
            break;
          }
          try
          {
            l = this.rl.awaitNanos(l);
            if (l <= 0L)
            {
              ConnectionResult localConnectionResult5 = new ConnectionResult(14, null);
              return localConnectionResult5;
            }
          }
          catch (InterruptedException localInterruptedException)
          {
            Thread.currentThread().interrupt();
            ConnectionResult localConnectionResult4 = new ConnectionResult(15, null);
            return localConnectionResult4;
          }
        }
        bool1 = false;
        continue;
        if (isConnected())
        {
          ConnectionResult localConnectionResult3 = ConnectionResult.qw;
          return localConnectionResult3;
        }
        if (this.ro != null)
        {
          ConnectionResult localConnectionResult2 = this.ro;
          return localConnectionResult2;
        }
        ConnectionResult localConnectionResult1 = new ConnectionResult(13, null);
        return localConnectionResult1;
      }
      finally
      {
        this.rk.unlock();
      }
    }
  }
  
  public void connect()
  {
    this.rk.lock();
    try
    {
      this.rs = false;
      if (!isConnected())
      {
        boolean bool = isConnecting();
        if (!bool) {}
      }
      else
      {
        return;
      }
      this.ry = true;
      this.ro = null;
      this.rq = 1;
      this.rw.clear();
      this.rt = this.rx.size();
      Iterator localIterator = this.rx.values().iterator();
      while (localIterator.hasNext()) {
        ((Api.a)localIterator.next()).connect();
      }
    }
    finally
    {
      this.rk.unlock();
    }
  }
  
  public void disconnect()
  {
    by();
    ab(-1);
  }
  
  /* Error */
  public boolean isConnected()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   4: invokeinterface 193 1 0
    //   9: aload_0
    //   10: getfield 68	com/google/android/gms/common/api/b:rq	I
    //   13: istore_2
    //   14: iload_2
    //   15: iconst_2
    //   16: if_icmpne +16 -> 32
    //   19: iconst_1
    //   20: istore_3
    //   21: aload_0
    //   22: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   25: invokeinterface 226 1 0
    //   30: iload_3
    //   31: ireturn
    //   32: iconst_0
    //   33: istore_3
    //   34: goto -13 -> 21
    //   37: astore_1
    //   38: aload_0
    //   39: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   42: invokeinterface 226 1 0
    //   47: aload_1
    //   48: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	b
    //   37	11	1	localObject	Object
    //   13	4	2	i	int
    //   20	14	3	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   9	14	37	finally
  }
  
  /* Error */
  public boolean isConnecting()
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   6: invokeinterface 193 1 0
    //   11: aload_0
    //   12: getfield 68	com/google/android/gms/common/api/b:rq	I
    //   15: istore_3
    //   16: iload_3
    //   17: iload_1
    //   18: if_icmpne +14 -> 32
    //   21: aload_0
    //   22: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   25: invokeinterface 226 1 0
    //   30: iload_1
    //   31: ireturn
    //   32: iconst_0
    //   33: istore_1
    //   34: goto -13 -> 21
    //   37: astore_2
    //   38: aload_0
    //   39: getfield 53	com/google/android/gms/common/api/b:rk	Ljava/util/concurrent/locks/Lock;
    //   42: invokeinterface 226 1 0
    //   47: aload_2
    //   48: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	b
    //   1	33	1	i	int
    //   37	11	2	localObject	Object
    //   15	4	3	j	int
    // Exception table:
    //   from	to	target	type
    //   11	16	37	finally
  }
  
  public boolean isConnectionCallbacksRegistered(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    return this.rm.isConnectionCallbacksRegistered(paramConnectionCallbacks);
  }
  
  public boolean isConnectionFailedListenerRegistered(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    return this.rm.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  public void reconnect()
  {
    disconnect();
    connect();
  }
  
  public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.rm.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.rm.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void unregisterConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.rm.unregisterConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void unregisterConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.rm.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  static abstract interface a
  {
    public abstract void b(b.c paramc);
  }
  
  class b
    extends Handler
  {
    b(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      if (paramMessage.what == 1)
      {
        b.a(b.this).lock();
        try
        {
          if ((!b.this.isConnected()) && (!b.this.isConnecting())) {
            b.this.connect();
          }
          return;
        }
        finally
        {
          b.a(b.this).unlock();
        }
      }
      Log.wtf("GoogleApiClientImpl", "Don't know how to handle this message.");
    }
  }
  
  static abstract interface c<A extends Api.a>
  {
    public abstract void a(A paramA)
      throws DeadObjectException;
    
    public abstract void a(b.a parama);
    
    public abstract Api.b<A> bm();
    
    public abstract int bo();
    
    public abstract void br();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.b
 * JD-Core Version:    0.7.0.1
 */