package com.google.android.gms.common;

import android.content.Intent;

public class GooglePlayServicesRepairableException
  extends UserRecoverableException
{
  private final int oo;
  
  GooglePlayServicesRepairableException(int paramInt, String paramString, Intent paramIntent)
  {
    super(paramString, paramIntent);
    this.oo = paramInt;
  }
  
  public int getConnectionStatusCode()
  {
    return this.oo;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.GooglePlayServicesRepairableException
 * JD-Core Version:    0.7.0.1
 */