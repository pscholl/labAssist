package com.google.android.gms.common.people.data;

import android.content.Intent;
import com.google.android.gms.common.audience.dialogs.AudienceSelectionIntentBuilder;
import com.google.android.gms.internal.at;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;

public final class Audiences
{
  public static Audience addMember(Audience paramAudience, AudienceMember paramAudienceMember)
  {
    at.a(paramAudience, "Audience must not be null.");
    at.a(paramAudienceMember, "Audience member must not be null.");
    LinkedHashSet localLinkedHashSet = new LinkedHashSet(paramAudience.getAudienceMemberList());
    localLinkedHashSet.add(paramAudienceMember);
    return new AudienceBuilder(paramAudience).setAudienceMembers(localLinkedHashSet).build();
  }
  
  public static Audience addMemberList(Audience paramAudience, Collection<AudienceMember> paramCollection)
  {
    LinkedHashSet localLinkedHashSet = new LinkedHashSet(paramAudience.getAudienceMemberList());
    localLinkedHashSet.addAll(paramCollection);
    return new AudienceBuilder(paramAudience).setAudienceMembers(localLinkedHashSet).build();
  }
  
  public static Audience fromAudienceSelectionIntent(Intent paramIntent, Audience paramAudience)
  {
    if (paramAudience == null) {
      paramAudience = new AudienceBuilder().build();
    }
    ArrayList localArrayList = AudienceSelectionIntentBuilder.getSelectedAudienceMembers(paramIntent);
    return new AudienceBuilder(paramAudience).setAudienceMembers(localArrayList).build();
  }
  
  public static boolean hasMember(Audience paramAudience, AudienceMember paramAudienceMember)
  {
    at.a(paramAudience, "Audience must not be null.");
    at.a(paramAudienceMember, "Audience member must not be null.");
    return paramAudience.getAudienceMemberList().contains(paramAudienceMember);
  }
  
  public static boolean isEmpty(Audience paramAudience)
  {
    at.a(paramAudience, "Audience must not be null.");
    return (!paramAudience.isReadOnly()) && (paramAudience.getAudienceMemberList().isEmpty());
  }
  
  public static Audience removeMember(Audience paramAudience, AudienceMember paramAudienceMember)
  {
    at.a(paramAudience, "Audience must not be null.");
    at.a(paramAudienceMember, "Audience member must not be null.");
    LinkedHashSet localLinkedHashSet = new LinkedHashSet(paramAudience.getAudienceMemberList());
    localLinkedHashSet.remove(paramAudienceMember);
    return new AudienceBuilder(paramAudience).setAudienceMembers(localLinkedHashSet).build();
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.people.data.Audiences
 * JD-Core Version:    0.7.0.1
 */