package com.google.android.gms.common;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import com.google.android.gms.dynamic.e.a;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.aw;
import com.google.android.gms.internal.ax;

public final class SignInButton
  extends FrameLayout
  implements View.OnClickListener
{
  public static final int COLOR_DARK = 0;
  public static final int COLOR_LIGHT = 1;
  public static final int SIZE_ICON_ONLY = 2;
  public static final int SIZE_STANDARD = 0;
  public static final int SIZE_WIDE = 1;
  private int mSize;
  private int qM;
  private View qN;
  private View.OnClickListener qO = null;
  
  public SignInButton(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public SignInButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public SignInButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setStyle(0, 0);
  }
  
  private static Button b(Context paramContext, int paramInt1, int paramInt2)
  {
    ax localax = new ax(paramContext);
    localax.a(paramContext.getResources(), paramInt1, paramInt2);
    return localax;
  }
  
  private void p(Context paramContext)
  {
    if (this.qN != null) {
      removeView(this.qN);
    }
    try
    {
      this.qN = aw.c(paramContext, this.mSize, this.qM);
      addView(this.qN);
      this.qN.setEnabled(isEnabled());
      this.qN.setOnClickListener(this);
      return;
    }
    catch (e.a locala)
    {
      for (;;)
      {
        Log.w("SignInButton", "Sign in button not found, using placeholder instead");
        this.qN = b(paramContext, this.mSize, this.qM);
      }
    }
  }
  
  public void onClick(View paramView)
  {
    if ((this.qO != null) && (paramView == this.qN)) {
      this.qO.onClick(this);
    }
  }
  
  public void setColorScheme(int paramInt)
  {
    setStyle(this.mSize, paramInt);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    this.qN.setEnabled(paramBoolean);
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener)
  {
    this.qO = paramOnClickListener;
    if (this.qN != null) {
      this.qN.setOnClickListener(this);
    }
  }
  
  public void setSize(int paramInt)
  {
    setStyle(paramInt, this.qM);
  }
  
  public void setStyle(int paramInt1, int paramInt2)
  {
    boolean bool1 = true;
    boolean bool2;
    if ((paramInt1 >= 0) && (paramInt1 < 3))
    {
      bool2 = bool1;
      at.a(bool2, "Unknown button size " + paramInt1);
      if ((paramInt2 < 0) || (paramInt2 >= 2)) {
        break label95;
      }
    }
    for (;;)
    {
      at.a(bool1, "Unknown color scheme " + paramInt2);
      this.mSize = paramInt1;
      this.qM = paramInt2;
      p(getContext());
      return;
      bool2 = false;
      break;
      label95:
      bool1 = false;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.SignInButton
 * JD-Core Version:    0.7.0.1
 */