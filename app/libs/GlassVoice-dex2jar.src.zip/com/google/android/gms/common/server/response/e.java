package com.google.android.gms.common.server.response;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.bg;
import com.google.android.gms.internal.bh;
import com.google.android.gms.internal.bl;
import com.google.android.gms.internal.bm;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class e
  extends FastJsonResponse
  implements SafeParcelable
{
  public static final f CREATOR = new f();
  private final String mClassName;
  private final int oj;
  private final FieldMappingDictionary uL;
  private final Parcel vn;
  private final int vo;
  private int vp;
  private int vq;
  
  e(int paramInt, Parcel paramParcel, FieldMappingDictionary paramFieldMappingDictionary)
  {
    this.oj = paramInt;
    this.vn = ((Parcel)at.f(paramParcel));
    this.vo = 2;
    this.uL = paramFieldMappingDictionary;
    if (this.uL == null) {}
    for (this.mClassName = null;; this.mClassName = this.uL.getRootClassName())
    {
      this.vp = 2;
      return;
    }
  }
  
  public e(FieldMappingDictionary paramFieldMappingDictionary, String paramString)
  {
    this.oj = 1;
    this.vn = Parcel.obtain();
    this.vo = 0;
    this.uL = ((FieldMappingDictionary)at.f(paramFieldMappingDictionary));
    this.mClassName = ((String)at.f(paramString));
    this.vp = 0;
  }
  
  private void a(StringBuilder paramStringBuilder, int paramInt, Object paramObject)
  {
    switch (paramInt)
    {
    default: 
      throw new IllegalArgumentException("Unknown type = " + paramInt);
    case 0: 
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
      paramStringBuilder.append(paramObject);
      return;
    case 7: 
      paramStringBuilder.append("\"").append(bl.H(paramObject.toString())).append("\"");
      return;
    case 8: 
      paramStringBuilder.append("\"").append(bh.e((byte[])paramObject)).append("\"");
      return;
    case 9: 
      paramStringBuilder.append("\"").append(bh.f((byte[])paramObject));
      paramStringBuilder.append("\"");
      return;
    case 10: 
      bm.a(paramStringBuilder, (HashMap)paramObject);
      return;
    }
    throw new IllegalArgumentException("Method does not accept concrete type.");
  }
  
  private void a(StringBuilder paramStringBuilder, FastJsonResponse.Field<?, ?> paramField, Parcel paramParcel, int paramInt)
  {
    switch (paramField.getTypeOut())
    {
    default: 
      throw new IllegalArgumentException("Unknown field out type = " + paramField.getTypeOut());
    case 0: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, Integer.valueOf(a.f(paramParcel, paramInt))));
      return;
    case 1: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, a.h(paramParcel, paramInt)));
      return;
    case 2: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, Long.valueOf(a.g(paramParcel, paramInt))));
      return;
    case 3: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, Float.valueOf(a.i(paramParcel, paramInt))));
      return;
    case 4: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, Double.valueOf(a.j(paramParcel, paramInt))));
      return;
    case 5: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, a.k(paramParcel, paramInt)));
      return;
    case 6: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, Boolean.valueOf(a.c(paramParcel, paramInt))));
      return;
    case 7: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, a.l(paramParcel, paramInt)));
      return;
    case 8: 
    case 9: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, a.o(paramParcel, paramInt)));
      return;
    case 10: 
      b(paramStringBuilder, paramField, getOriginalValue(paramField, b(a.n(paramParcel, paramInt))));
      return;
    }
    throw new IllegalArgumentException("Method does not accept concrete type.");
  }
  
  private void a(StringBuilder paramStringBuilder, String paramString, FastJsonResponse.Field<?, ?> paramField, Parcel paramParcel, int paramInt)
  {
    paramStringBuilder.append("\"").append(paramString).append("\":");
    if (paramField.hasConverter())
    {
      a(paramStringBuilder, paramField, paramParcel, paramInt);
      return;
    }
    b(paramStringBuilder, paramField, paramParcel, paramInt);
  }
  
  private void a(StringBuilder paramStringBuilder, HashMap<String, FastJsonResponse.Field<?, ?>> paramHashMap, Parcel paramParcel)
  {
    HashMap localHashMap = d(paramHashMap);
    paramStringBuilder.append('{');
    int i = a.Y(paramParcel);
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      Map.Entry localEntry = (Map.Entry)localHashMap.get(Integer.valueOf(a.al(k)));
      if (localEntry != null)
      {
        if (j != 0) {
          paramStringBuilder.append(",");
        }
        a(paramStringBuilder, (String)localEntry.getKey(), (FastJsonResponse.Field)localEntry.getValue(), paramParcel, k);
        j = 1;
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    paramStringBuilder.append('}');
  }
  
  public static HashMap<String, String> b(Bundle paramBundle)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = paramBundle.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localHashMap.put(str, paramBundle.getString(str));
    }
    return localHashMap;
  }
  
  private void b(FastJsonResponse.Field<?, ?> paramField)
  {
    if (!paramField.isValidSafeParcelableFieldId()) {
      throw new IllegalStateException("Field does not have a valid safe parcelable field id.");
    }
    if (this.vn == null) {
      throw new IllegalStateException("Internal Parcel object is null.");
    }
    switch (this.vp)
    {
    default: 
      throw new IllegalStateException("Unknown parse state in SafeParcelResponse.");
    case 0: 
      this.vq = b.Z(this.vn);
      this.vp = 1;
    case 1: 
      return;
    }
    throw new IllegalStateException("Attempted to parse JSON with a SafeParcelResponse object that is already filled with data.");
  }
  
  private void b(StringBuilder paramStringBuilder, FastJsonResponse.Field<?, ?> paramField, Parcel paramParcel, int paramInt)
  {
    if (paramField.isTypeOutArray())
    {
      paramStringBuilder.append("[");
      switch (paramField.getTypeOut())
      {
      default: 
        throw new IllegalStateException("Unknown field type out.");
      case 0: 
        bg.a(paramStringBuilder, a.q(paramParcel, paramInt));
      }
      for (;;)
      {
        paramStringBuilder.append("]");
        return;
        bg.a(paramStringBuilder, a.s(paramParcel, paramInt));
        continue;
        bg.a(paramStringBuilder, a.r(paramParcel, paramInt));
        continue;
        bg.a(paramStringBuilder, a.t(paramParcel, paramInt));
        continue;
        bg.a(paramStringBuilder, a.u(paramParcel, paramInt));
        continue;
        bg.a(paramStringBuilder, a.v(paramParcel, paramInt));
        continue;
        bg.a(paramStringBuilder, a.p(paramParcel, paramInt));
        continue;
        bg.a(paramStringBuilder, a.w(paramParcel, paramInt));
        continue;
        throw new UnsupportedOperationException("List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported");
        Parcel[] arrayOfParcel = a.z(paramParcel, paramInt);
        int j = arrayOfParcel.length;
        for (int k = 0; k < j; k++)
        {
          if (k > 0) {
            paramStringBuilder.append(",");
          }
          arrayOfParcel[k].setDataPosition(0);
          a(paramStringBuilder, paramField.getConcreteTypeFieldMappingFromDictionary(), arrayOfParcel[k]);
        }
      }
    }
    switch (paramField.getTypeOut())
    {
    default: 
      throw new IllegalStateException("Unknown field type out");
    case 0: 
      paramStringBuilder.append(a.f(paramParcel, paramInt));
      return;
    case 1: 
      paramStringBuilder.append(a.h(paramParcel, paramInt));
      return;
    case 2: 
      paramStringBuilder.append(a.g(paramParcel, paramInt));
      return;
    case 3: 
      paramStringBuilder.append(a.i(paramParcel, paramInt));
      return;
    case 4: 
      paramStringBuilder.append(a.j(paramParcel, paramInt));
      return;
    case 5: 
      paramStringBuilder.append(a.k(paramParcel, paramInt));
      return;
    case 6: 
      paramStringBuilder.append(a.c(paramParcel, paramInt));
      return;
    case 7: 
      String str2 = a.l(paramParcel, paramInt);
      paramStringBuilder.append("\"").append(bl.H(str2)).append("\"");
      return;
    case 8: 
      byte[] arrayOfByte2 = a.o(paramParcel, paramInt);
      paramStringBuilder.append("\"").append(bh.e(arrayOfByte2)).append("\"");
      return;
    case 9: 
      byte[] arrayOfByte1 = a.o(paramParcel, paramInt);
      paramStringBuilder.append("\"").append(bh.f(arrayOfByte1));
      paramStringBuilder.append("\"");
      return;
    case 10: 
      Bundle localBundle = a.n(paramParcel, paramInt);
      Set localSet = localBundle.keySet();
      localSet.size();
      paramStringBuilder.append("{");
      Iterator localIterator = localSet.iterator();
      for (int i = 1; localIterator.hasNext(); i = 0)
      {
        String str1 = (String)localIterator.next();
        if (i == 0) {
          paramStringBuilder.append(",");
        }
        paramStringBuilder.append("\"").append(str1).append("\"");
        paramStringBuilder.append(":");
        paramStringBuilder.append("\"").append(bl.H(localBundle.getString(str1))).append("\"");
      }
      paramStringBuilder.append("}");
      return;
    }
    Parcel localParcel = a.y(paramParcel, paramInt);
    localParcel.setDataPosition(0);
    a(paramStringBuilder, paramField.getConcreteTypeFieldMappingFromDictionary(), localParcel);
  }
  
  private void b(StringBuilder paramStringBuilder, FastJsonResponse.Field<?, ?> paramField, Object paramObject)
  {
    if (paramField.isTypeInArray())
    {
      b(paramStringBuilder, paramField, (ArrayList)paramObject);
      return;
    }
    a(paramStringBuilder, paramField.getTypeIn(), paramObject);
  }
  
  private void b(StringBuilder paramStringBuilder, FastJsonResponse.Field<?, ?> paramField, ArrayList<?> paramArrayList)
  {
    paramStringBuilder.append("[");
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
    {
      if (j != 0) {
        paramStringBuilder.append(",");
      }
      a(paramStringBuilder, paramField.getTypeIn(), paramArrayList.get(j));
    }
    paramStringBuilder.append("]");
  }
  
  private static HashMap<Integer, Map.Entry<String, FastJsonResponse.Field<?, ?>>> d(HashMap<String, FastJsonResponse.Field<?, ?>> paramHashMap)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = paramHashMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localHashMap.put(Integer.valueOf(((FastJsonResponse.Field)localEntry.getValue()).getSafeParcelableFieldId()), localEntry);
    }
    return localHashMap;
  }
  
  public <T extends FastJsonResponse> void addConcreteTypeArrayInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<T> paramArrayList)
  {
    b(paramField);
    ArrayList localArrayList = new ArrayList();
    paramArrayList.size();
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext()) {
      localArrayList.add(((e)localIterator.next()).ci());
    }
    b.c(this.vn, paramField.getSafeParcelableFieldId(), localArrayList, true);
  }
  
  public <T extends FastJsonResponse> void addConcreteTypeInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, T paramT)
  {
    b(paramField);
    Parcel localParcel = ((e)paramT).ci();
    b.a(this.vn, paramField.getSafeParcelableFieldId(), localParcel, true);
  }
  
  public Parcel ci()
  {
    switch (this.vp)
    {
    }
    for (;;)
    {
      return this.vn;
      this.vq = b.Z(this.vn);
      b.C(this.vn, this.vq);
      this.vp = 2;
      continue;
      b.C(this.vn, this.vq);
      this.vp = 2;
    }
  }
  
  FieldMappingDictionary cj()
  {
    switch (this.vo)
    {
    default: 
      throw new IllegalStateException("Invalid creation type: " + this.vo);
    case 0: 
      return null;
    case 1: 
      return this.uL;
    }
    return this.uL;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public HashMap<String, FastJsonResponse.Field<?, ?>> getFieldMappings()
  {
    if (this.uL == null) {
      return null;
    }
    return this.uL.getFieldMapping(this.mClassName);
  }
  
  protected Object getValueObject(String paramString)
  {
    throw new UnsupportedOperationException("Converting to JSON does not require this method.");
  }
  
  public int getVersionCode()
  {
    return this.oj;
  }
  
  protected boolean isPrimitiveFieldSet(String paramString)
  {
    throw new UnsupportedOperationException("Converting to JSON does not require this method.");
  }
  
  protected void setBigDecimalInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, BigDecimal paramBigDecimal)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramBigDecimal, true);
  }
  
  protected void setBigDecimalsInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<BigDecimal> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    BigDecimal[] arrayOfBigDecimal = new BigDecimal[i];
    for (int j = 0; j < i; j++) {
      arrayOfBigDecimal[j] = ((BigDecimal)paramArrayList.get(j));
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfBigDecimal, true);
  }
  
  protected void setBigIntegerInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, BigInteger paramBigInteger)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramBigInteger, true);
  }
  
  protected void setBigIntegersInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<BigInteger> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    BigInteger[] arrayOfBigInteger = new BigInteger[i];
    for (int j = 0; j < i; j++) {
      arrayOfBigInteger[j] = ((BigInteger)paramArrayList.get(j));
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfBigInteger, true);
  }
  
  protected void setBooleanInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, boolean paramBoolean)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramBoolean);
  }
  
  protected void setBooleansInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<Boolean> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    boolean[] arrayOfBoolean = new boolean[i];
    for (int j = 0; j < i; j++) {
      arrayOfBoolean[j] = ((Boolean)paramArrayList.get(j)).booleanValue();
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfBoolean, true);
  }
  
  protected void setDecodedBytesInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, byte[] paramArrayOfByte)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramArrayOfByte, true);
  }
  
  protected void setDoubleInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, double paramDouble)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramDouble);
  }
  
  protected void setDoublesInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<Double> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    double[] arrayOfDouble = new double[i];
    for (int j = 0; j < i; j++) {
      arrayOfDouble[j] = ((Double)paramArrayList.get(j)).doubleValue();
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfDouble, true);
  }
  
  protected void setFloatInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, float paramFloat)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramFloat);
  }
  
  protected void setFloatsInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<Float> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    float[] arrayOfFloat = new float[i];
    for (int j = 0; j < i; j++) {
      arrayOfFloat[j] = ((Float)paramArrayList.get(j)).floatValue();
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfFloat, true);
  }
  
  protected void setIntegerInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, int paramInt)
  {
    b(paramField);
    b.c(this.vn, paramField.getSafeParcelableFieldId(), paramInt);
  }
  
  protected void setIntegersInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<Integer> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    int[] arrayOfInt = new int[i];
    for (int j = 0; j < i; j++) {
      arrayOfInt[j] = ((Integer)paramArrayList.get(j)).intValue();
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfInt, true);
  }
  
  protected void setLongInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, long paramLong)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramLong);
  }
  
  protected void setLongsInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<Long> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    long[] arrayOfLong = new long[i];
    for (int j = 0; j < i; j++) {
      arrayOfLong[j] = ((Long)paramArrayList.get(j)).longValue();
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfLong, true);
  }
  
  protected void setStringInternal(FastJsonResponse.Field<?, ?> paramField, String paramString1, String paramString2)
  {
    b(paramField);
    b.a(this.vn, paramField.getSafeParcelableFieldId(), paramString2, true);
  }
  
  protected void setStringMapInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, Map<String, String> paramMap)
  {
    b(paramField);
    Bundle localBundle = new Bundle();
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localBundle.putString(str, (String)paramMap.get(str));
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), localBundle, true);
  }
  
  protected void setStringsInternal(FastJsonResponse.Field<?, ?> paramField, String paramString, ArrayList<String> paramArrayList)
  {
    b(paramField);
    int i = paramArrayList.size();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++) {
      arrayOfString[j] = ((String)paramArrayList.get(j));
    }
    b.a(this.vn, paramField.getSafeParcelableFieldId(), arrayOfString, true);
  }
  
  public String toString()
  {
    at.a(this.uL, "Cannot convert to JSON on client side.");
    Parcel localParcel = ci();
    localParcel.setDataPosition(0);
    StringBuilder localStringBuilder = new StringBuilder(100);
    a(localStringBuilder, this.uL.getFieldMapping(this.mClassName), localParcel);
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    f.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.e
 * JD-Core Version:    0.7.0.1
 */