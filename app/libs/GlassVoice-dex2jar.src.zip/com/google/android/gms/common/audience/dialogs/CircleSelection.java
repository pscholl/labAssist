package com.google.android.gms.common.audience.dialogs;

import android.content.Intent;
import com.google.android.gms.common.people.data.AudienceMember;
import java.util.ArrayList;
import java.util.List;

public final class CircleSelection
{
  public static final String ACTION_CHOOSE_CIRCLES = "com.google.android.gms.common.acl.CHOOSE_CIRCLES";
  
  public static ArrayList<AudienceMember> getAddedCirclesDeltaFromResult(Intent paramIntent)
  {
    return AudienceSelectionIntentBuilder.getAddedAudienceDelta(paramIntent);
  }
  
  public static SelectBuilder getChooseCirclesBuilder()
  {
    return new AudienceSelectionIntentBuilder("com.google.android.gms.common.acl.CHOOSE_CIRCLES");
  }
  
  public static ArrayList<AudienceMember> getRemovedCirclesDeltaFromResult(Intent paramIntent)
  {
    return AudienceSelectionIntentBuilder.getRemovedAudienceDelta(paramIntent);
  }
  
  public static Results getResults(Intent paramIntent)
  {
    return new AudienceSelectionIntentBuilder(paramIntent);
  }
  
  public static ArrayList<AudienceMember> getSelectedCirclesFromResult(Intent paramIntent)
  {
    return AudienceSelectionIntentBuilder.getSelectedAudienceMembers(paramIntent);
  }
  
  public static UpdateBuilder getUpdateCirclesBuilder()
  {
    return new AudienceSelectionIntentBuilder("com.google.android.gms.common.acl.UPDATE_CIRCLES");
  }
  
  public static abstract interface Results
  {
    public abstract ArrayList<AudienceMember> getAddedCirclesDelta();
    
    public abstract List<AudienceMember> getInitialCircles();
    
    public abstract ArrayList<AudienceMember> getRemovedCirclesDelta();
    
    public abstract ArrayList<AudienceMember> getSelectedCircles();
  }
  
  public static abstract interface SelectBuilder
  {
    public abstract Intent build();
    
    public abstract SelectBuilder setAccountName(String paramString);
    
    public abstract SelectBuilder setClientApplicationId(String paramString);
    
    public abstract SelectBuilder setInitialCircles(List<AudienceMember> paramList);
    
    public abstract SelectBuilder setPlusPageId(String paramString);
    
    public abstract SelectBuilder setTitleText(String paramString);
  }
  
  public static abstract interface UpdateBuilder
  {
    public abstract Intent build();
    
    public abstract UpdateBuilder setAccountName(String paramString);
    
    public abstract CircleSelection.SelectBuilder setClientApplicationId(String paramString);
    
    public abstract UpdateBuilder setInitialCircles(List<AudienceMember> paramList);
    
    public abstract UpdateBuilder setPlusPageId(String paramString);
    
    public abstract UpdateBuilder setTitleText(String paramString);
    
    public abstract UpdateBuilder setUpdatePersonId(String paramString);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.audience.dialogs.CircleSelection
 * JD-Core Version:    0.7.0.1
 */