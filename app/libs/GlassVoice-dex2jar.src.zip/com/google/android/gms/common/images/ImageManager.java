package com.google.android.gms.common.images;

import android.app.ActivityManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import android.util.Log;
import android.widget.ImageView;
import com.google.android.gms.internal.ah;
import com.google.android.gms.internal.ay;
import com.google.android.gms.internal.bn;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageManager
{
  private static final Object sv = new Object();
  private static HashSet<Uri> sw = new HashSet();
  private static ImageManager sx;
  private static ImageManager sy;
  private final Context mContext;
  private final Handler mHandler;
  private final b sA;
  private final Map<a, ImageReceiver> sB;
  private final Map<Uri, ImageReceiver> sC;
  private final ExecutorService sz;
  
  private ImageManager(Context paramContext, boolean paramBoolean)
  {
    this.mContext = paramContext.getApplicationContext();
    this.mHandler = new Handler(Looper.getMainLooper());
    this.sz = Executors.newFixedThreadPool(4);
    if (paramBoolean)
    {
      this.sA = new b(this.mContext);
      if (bn.co()) {
        bG();
      }
    }
    for (;;)
    {
      this.sB = new HashMap();
      this.sC = new HashMap();
      return;
      this.sA = null;
    }
  }
  
  private Bitmap a(a.a parama)
  {
    if (this.sA == null) {
      return null;
    }
    return (Bitmap)this.sA.get(parama);
  }
  
  public static ImageManager a(Context paramContext, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (sy == null) {
        sy = new ImageManager(paramContext, true);
      }
      return sy;
    }
    if (sx == null) {
      sx = new ImageManager(paramContext, false);
    }
    return sx;
  }
  
  private boolean b(a parama)
  {
    ah.u("ImageManager.cleanupHashMaps() must be called in the main thread");
    if (parama.sM == 1) {
      return true;
    }
    ImageReceiver localImageReceiver = (ImageReceiver)this.sB.get(parama);
    if (localImageReceiver == null) {
      return true;
    }
    if (localImageReceiver.sE) {
      return false;
    }
    this.sB.remove(parama);
    localImageReceiver.d(parama);
    return true;
  }
  
  private void bG()
  {
    this.mContext.registerComponentCallbacks(new e(this.sA));
  }
  
  public static ImageManager create(Context paramContext)
  {
    return a(paramContext, false);
  }
  
  public void a(a parama)
  {
    ah.u("ImageManager.loadImage() must be called in the main thread");
    boolean bool = b(parama);
    d locald = new d(parama);
    if (bool)
    {
      locald.run();
      return;
    }
    this.mHandler.post(locald);
  }
  
  public void loadImage(ImageView paramImageView, int paramInt)
  {
    a locala = new a(paramInt);
    locala.a(paramImageView);
    a(locala);
  }
  
  public void loadImage(ImageView paramImageView, Uri paramUri)
  {
    a locala = new a(paramUri);
    locala.a(paramImageView);
    a(locala);
  }
  
  public void loadImage(ImageView paramImageView, Uri paramUri, int paramInt)
  {
    a locala = new a(paramUri);
    locala.ag(paramInt);
    locala.a(paramImageView);
    a(locala);
  }
  
  public void loadImage(OnImageLoadedListener paramOnImageLoadedListener, Uri paramUri)
  {
    a locala = new a(paramUri);
    locala.a(paramOnImageLoadedListener);
    a(locala);
  }
  
  public void loadImage(OnImageLoadedListener paramOnImageLoadedListener, Uri paramUri, int paramInt)
  {
    a locala = new a(paramUri);
    locala.ag(paramInt);
    locala.a(paramOnImageLoadedListener);
    a(locala);
  }
  
  private final class ImageReceiver
    extends ResultReceiver
  {
    private final Uri mUri;
    private final ArrayList<a> sD;
    boolean sE = false;
    
    ImageReceiver(Uri paramUri)
    {
      super();
      this.mUri = paramUri;
      this.sD = new ArrayList();
    }
    
    public void bJ()
    {
      Intent localIntent = new Intent("com.google.android.gms.common.images.LOAD_IMAGE");
      localIntent.putExtra("com.google.android.gms.extras.uri", this.mUri);
      localIntent.putExtra("com.google.android.gms.extras.resultReceiver", this);
      localIntent.putExtra("com.google.android.gms.extras.priority", 3);
      ImageManager.a(ImageManager.this).sendBroadcast(localIntent);
    }
    
    public void c(a parama)
    {
      if (!this.sE) {}
      for (boolean bool = true;; bool = false)
      {
        ah.a(bool, "Cannot add an ImageRequest when mHandlingRequests is true");
        ah.u("ImageReceiver.addImageRequest() must be called in the main thread");
        this.sD.add(parama);
        return;
      }
    }
    
    public void d(a parama)
    {
      if (!this.sE) {}
      for (boolean bool = true;; bool = false)
      {
        ah.a(bool, "Cannot remove an ImageRequest when mHandlingRequests is true");
        ah.u("ImageReceiver.removeImageRequest() must be called in the main thread");
        this.sD.remove(parama);
        return;
      }
    }
    
    public void onReceiveResult(int paramInt, Bundle paramBundle)
    {
      ParcelFileDescriptor localParcelFileDescriptor = (ParcelFileDescriptor)paramBundle.getParcelable("com.google.android.gms.extra.fileDescriptor");
      ImageManager.d(ImageManager.this).execute(new ImageManager.c(ImageManager.this, this.mUri, localParcelFileDescriptor));
    }
  }
  
  public static abstract interface OnImageLoadedListener
  {
    public abstract void onImageLoaded(Uri paramUri, Drawable paramDrawable, boolean paramBoolean);
  }
  
  private static final class a
  {
    static int a(ActivityManager paramActivityManager)
    {
      return paramActivityManager.getLargeMemoryClass();
    }
  }
  
  private static final class b
    extends ay<a.a, Bitmap>
  {
    public b(Context paramContext)
    {
      super();
    }
    
    private static int r(Context paramContext)
    {
      ActivityManager localActivityManager = (ActivityManager)paramContext.getSystemService("activity");
      int i;
      if ((0x100000 & paramContext.getApplicationInfo().flags) != 0)
      {
        i = 1;
        if ((i == 0) || (!bn.cm())) {
          break label55;
        }
      }
      label55:
      for (int j = ImageManager.a.a(localActivityManager);; j = localActivityManager.getMemoryClass())
      {
        return (int)(0.33F * (j * 1048576));
        i = 0;
        break;
      }
    }
    
    protected int a(a.a parama, Bitmap paramBitmap)
    {
      return paramBitmap.getHeight() * paramBitmap.getRowBytes();
    }
    
    protected void a(boolean paramBoolean, a.a parama, Bitmap paramBitmap1, Bitmap paramBitmap2)
    {
      super.entryRemoved(paramBoolean, parama, paramBitmap1, paramBitmap2);
    }
  }
  
  private final class c
    implements Runnable
  {
    private final Uri mUri;
    private final ParcelFileDescriptor sG;
    
    public c(Uri paramUri, ParcelFileDescriptor paramParcelFileDescriptor)
    {
      this.mUri = paramUri;
      this.sG = paramParcelFileDescriptor;
    }
    
    public void run()
    {
      ah.x("LoadBitmapFromDiskRunnable can't be executed in the main thread");
      ParcelFileDescriptor localParcelFileDescriptor = this.sG;
      Object localObject = null;
      boolean bool = false;
      if (localParcelFileDescriptor != null) {}
      try
      {
        Bitmap localBitmap = BitmapFactory.decodeFileDescriptor(this.sG.getFileDescriptor());
        localObject = localBitmap;
        CountDownLatch localCountDownLatch;
        return;
      }
      catch (OutOfMemoryError localOutOfMemoryError)
      {
        try
        {
          for (;;)
          {
            this.sG.close();
            localCountDownLatch = new CountDownLatch(1);
            ImageManager.e(ImageManager.this).post(new ImageManager.f(ImageManager.this, this.mUri, localObject, bool, localCountDownLatch));
            try
            {
              localCountDownLatch.await();
              return;
            }
            catch (InterruptedException localInterruptedException)
            {
              Log.w("ImageManager", "Latch interrupted while posting " + this.mUri);
            }
            localOutOfMemoryError = localOutOfMemoryError;
            Log.e("ImageManager", "OOM while loading bitmap for uri: " + this.mUri, localOutOfMemoryError);
            bool = true;
            localObject = null;
          }
        }
        catch (IOException localIOException)
        {
          for (;;)
          {
            Log.e("ImageManager", "closed failed", localIOException);
          }
        }
      }
    }
  }
  
  private final class d
    implements Runnable
  {
    private final a sH;
    
    public d(a parama)
    {
      this.sH = parama;
    }
    
    public void run()
    {
      ah.u("LoadImageRunnable must be executed on the main thread");
      ImageManager.a(ImageManager.this, this.sH);
      a.a locala = this.sH.sJ;
      if (locala.uri == null)
      {
        this.sH.b(ImageManager.a(ImageManager.this), true);
        return;
      }
      Bitmap localBitmap = ImageManager.a(ImageManager.this, locala);
      if (localBitmap != null)
      {
        this.sH.a(ImageManager.a(ImageManager.this), localBitmap, true);
        return;
      }
      this.sH.s(ImageManager.a(ImageManager.this));
      ImageManager.ImageReceiver localImageReceiver = (ImageManager.ImageReceiver)ImageManager.b(ImageManager.this).get(locala.uri);
      if (localImageReceiver == null)
      {
        localImageReceiver = new ImageManager.ImageReceiver(ImageManager.this, locala.uri);
        ImageManager.b(ImageManager.this).put(locala.uri, localImageReceiver);
      }
      localImageReceiver.c(this.sH);
      if (this.sH.sM != 1) {
        ImageManager.c(ImageManager.this).put(this.sH, localImageReceiver);
      }
      synchronized (ImageManager.bH())
      {
        if (!ImageManager.bI().contains(locala.uri))
        {
          ImageManager.bI().add(locala.uri);
          localImageReceiver.bJ();
        }
        return;
      }
    }
  }
  
  private static final class e
    implements ComponentCallbacks2
  {
    private final ImageManager.b sA;
    
    public e(ImageManager.b paramb)
    {
      this.sA = paramb;
    }
    
    public void onConfigurationChanged(Configuration paramConfiguration) {}
    
    public void onLowMemory()
    {
      this.sA.evictAll();
    }
    
    public void onTrimMemory(int paramInt)
    {
      if (paramInt >= 60) {
        this.sA.evictAll();
      }
      while (paramInt < 20) {
        return;
      }
      this.sA.trimToSize(this.sA.size() / 2);
    }
  }
  
  private final class f
    implements Runnable
  {
    private final Bitmap mBitmap;
    private final Uri mUri;
    private final CountDownLatch qU;
    private boolean sI;
    
    public f(Uri paramUri, Bitmap paramBitmap, boolean paramBoolean, CountDownLatch paramCountDownLatch)
    {
      this.mUri = paramUri;
      this.mBitmap = paramBitmap;
      this.sI = paramBoolean;
      this.qU = paramCountDownLatch;
    }
    
    private void a(ImageManager.ImageReceiver paramImageReceiver, boolean paramBoolean)
    {
      paramImageReceiver.sE = true;
      ArrayList localArrayList = ImageManager.ImageReceiver.a(paramImageReceiver);
      int i = localArrayList.size();
      int j = 0;
      if (j < i)
      {
        a locala = (a)localArrayList.get(j);
        if (paramBoolean) {
          locala.a(ImageManager.a(ImageManager.this), this.mBitmap, false);
        }
        for (;;)
        {
          if (locala.sM != 1) {
            ImageManager.c(ImageManager.this).remove(locala);
          }
          j++;
          break;
          locala.b(ImageManager.a(ImageManager.this), false);
        }
      }
      paramImageReceiver.sE = false;
    }
    
    public void run()
    {
      ah.u("OnBitmapLoadedRunnable must be executed in the main thread");
      boolean bool;
      if (this.mBitmap != null) {
        bool = true;
      }
      while (ImageManager.f(ImageManager.this) != null) {
        if (this.sI)
        {
          ImageManager.f(ImageManager.this).evictAll();
          System.gc();
          this.sI = false;
          ImageManager.e(ImageManager.this).post(this);
          return;
          bool = false;
        }
        else if (bool)
        {
          ImageManager.f(ImageManager.this).put(new a.a(this.mUri), this.mBitmap);
        }
      }
      ImageManager.ImageReceiver localImageReceiver = (ImageManager.ImageReceiver)ImageManager.b(ImageManager.this).remove(this.mUri);
      if (localImageReceiver != null) {
        a(localImageReceiver, bool);
      }
      this.qU.countDown();
      synchronized (ImageManager.bH())
      {
        ImageManager.bI().remove(this.mUri);
        return;
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.images.ImageManager
 * JD-Core Version:    0.7.0.1
 */