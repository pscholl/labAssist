package com.google.android.gms.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import com.google.android.gms.internal.at;

public class b
  extends DialogFragment
{
  private Dialog mDialog = null;
  private DialogInterface.OnCancelListener qy = null;
  
  public static b a(Dialog paramDialog, DialogInterface.OnCancelListener paramOnCancelListener)
  {
    b localb = new b();
    Dialog localDialog = (Dialog)at.a(paramDialog, "Cannot display null dialog");
    localDialog.setOnCancelListener(null);
    localDialog.setOnDismissListener(null);
    localb.mDialog = localDialog;
    if (paramOnCancelListener != null) {
      localb.qy = paramOnCancelListener;
    }
    return localb;
  }
  
  public void onCancel(DialogInterface paramDialogInterface)
  {
    if (this.qy != null) {
      this.qy.onCancel(paramDialogInterface);
    }
  }
  
  public Dialog onCreateDialog(Bundle paramBundle)
  {
    return this.mDialog;
  }
  
  public void show(FragmentManager paramFragmentManager, String paramString)
  {
    super.show(paramFragmentManager, paramString);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.b
 * JD-Core Version:    0.7.0.1
 */