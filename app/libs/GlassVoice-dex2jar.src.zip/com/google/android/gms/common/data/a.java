package com.google.android.gms.common.data;

import com.google.android.gms.internal.at;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class a<T>
  implements Iterator<T>
{
  private final DataBuffer<T> mDataBuffer;
  private int sc;
  
  public a(DataBuffer<T> paramDataBuffer)
  {
    this.mDataBuffer = ((DataBuffer)at.f(paramDataBuffer));
    this.sc = -1;
  }
  
  public boolean hasNext()
  {
    return this.sc < -1 + this.mDataBuffer.getCount();
  }
  
  public T next()
  {
    if (!hasNext()) {
      throw new NoSuchElementException("Cannot advance the iterator beyond " + this.sc);
    }
    DataBuffer localDataBuffer = this.mDataBuffer;
    int i = 1 + this.sc;
    this.sc = i;
    return localDataBuffer.get(i);
  }
  
  public void remove()
  {
    throw new UnsupportedOperationException("Cannot remove elements from a DataBufferIterator");
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.a
 * JD-Core Version:    0.7.0.1
 */