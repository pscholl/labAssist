package com.google.android.gms.common.api;

public final class Scope
{
  private final String rE;
  
  public Scope(String paramString)
  {
    this.rE = paramString;
  }
  
  public String bB()
  {
    return this.rE;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Scope
 * JD-Core Version:    0.7.0.1
 */