package com.google.android.gms.common.data;

import android.os.Bundle;
import java.util.Iterator;

public abstract class DataBuffer<T>
  implements Iterable<T>
{
  protected final d mDataHolder;
  
  protected DataBuffer(d paramd)
  {
    this.mDataHolder = paramd;
    if (this.mDataHolder != null) {
      this.mDataHolder.b(this);
    }
  }
  
  public void close()
  {
    if (this.mDataHolder != null) {
      this.mDataHolder.close();
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public abstract T get(int paramInt);
  
  public int getCount()
  {
    if (this.mDataHolder == null) {
      return 0;
    }
    return this.mDataHolder.getCount();
  }
  
  public Bundle getMetadata()
  {
    return this.mDataHolder.getMetadata();
  }
  
  public boolean isClosed()
  {
    if (this.mDataHolder == null) {
      return true;
    }
    return this.mDataHolder.isClosed();
  }
  
  public Iterator<T> iterator()
  {
    return new a(this);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.DataBuffer
 * JD-Core Version:    0.7.0.1
 */