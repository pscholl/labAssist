package com.google.android.gms.common.data;

import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.at;

public abstract class b
{
  protected final d mDataHolder;
  protected final int sd;
  private final int se;
  
  public b(d paramd, int paramInt)
  {
    this.mDataHolder = ((d)at.f(paramd));
    if ((paramInt >= 0) && (paramInt < paramd.getCount())) {}
    for (boolean bool = true;; bool = false)
    {
      at.f(bool);
      this.sd = paramInt;
      this.se = paramd.ad(this.sd);
      return;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool1 = paramObject instanceof b;
    boolean bool2 = false;
    if (bool1)
    {
      b localb = (b)paramObject;
      boolean bool3 = ar.equal(Integer.valueOf(localb.sd), Integer.valueOf(this.sd));
      bool2 = false;
      if (bool3)
      {
        boolean bool4 = ar.equal(Integer.valueOf(localb.se), Integer.valueOf(this.se));
        bool2 = false;
        if (bool4)
        {
          d locald1 = localb.mDataHolder;
          d locald2 = this.mDataHolder;
          bool2 = false;
          if (locald1 == locald2) {
            bool2 = true;
          }
        }
      }
    }
    return bool2;
  }
  
  protected boolean getBoolean(String paramString)
  {
    return this.mDataHolder.d(paramString, this.sd, this.se);
  }
  
  protected int getInteger(String paramString)
  {
    return this.mDataHolder.b(paramString, this.sd, this.se);
  }
  
  protected long getLong(String paramString)
  {
    return this.mDataHolder.a(paramString, this.sd, this.se);
  }
  
  protected String getString(String paramString)
  {
    return this.mDataHolder.c(paramString, this.sd, this.se);
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = Integer.valueOf(this.sd);
    arrayOfObject[1] = Integer.valueOf(this.se);
    arrayOfObject[2] = this.mDataHolder;
    return ar.hashCode(arrayOfObject);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.b
 * JD-Core Version:    0.7.0.1
 */