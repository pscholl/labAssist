package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class c
  implements Parcelable.Creator<FieldMappingDictionary>
{
  static void a(FieldMappingDictionary paramFieldMappingDictionary, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramFieldMappingDictionary.getVersionCode());
    b.b(paramParcel, 2, paramFieldMappingDictionary.cg(), false);
    b.a(paramParcel, 3, paramFieldMappingDictionary.getRootClassName(), false);
    b.C(paramParcel, i);
  }
  
  public FieldMappingDictionary ai(Parcel paramParcel)
  {
    String str = null;
    int i = a.Y(paramParcel);
    int j = 0;
    ArrayList localArrayList = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localArrayList = a.c(paramParcel, k, FieldMappingDictionary.Entry.CREATOR);
        break;
      case 3: 
        str = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new FieldMappingDictionary(j, localArrayList, str);
  }
  
  public FieldMappingDictionary[] aw(int paramInt)
  {
    return new FieldMappingDictionary[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.c
 * JD-Core Version:    0.7.0.1
 */