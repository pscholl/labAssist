package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.bb;

public class a
  implements Parcelable.Creator<FastJsonResponse.Field>
{
  static void a(FastJsonResponse.Field paramField, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramField.getVersionCode());
    b.c(paramParcel, 2, paramField.getTypeIn());
    b.a(paramParcel, 3, paramField.isTypeInArray());
    b.c(paramParcel, 4, paramField.getTypeOut());
    b.a(paramParcel, 5, paramField.isTypeOutArray());
    b.a(paramParcel, 6, paramField.getOutputFieldName(), false);
    b.c(paramParcel, 7, paramField.getSafeParcelableFieldId());
    b.a(paramParcel, 8, paramField.ce(), false);
    b.a(paramParcel, 9, paramField.cf(), paramInt, false);
    b.C(paramParcel, i);
  }
  
  public FastJsonResponse.Field ag(Parcel paramParcel)
  {
    bb localbb = null;
    int i = 0;
    int j = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    String str1 = null;
    String str2 = null;
    boolean bool1 = false;
    int k = 0;
    boolean bool2 = false;
    int m = 0;
    int n = 0;
    while (paramParcel.dataPosition() < j)
    {
      int i1 = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.al(i1))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, i1);
        break;
      case 1: 
        n = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, i1);
        break;
      case 2: 
        m = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, i1);
        break;
      case 3: 
        bool2 = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, i1);
        break;
      case 4: 
        k = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, i1);
        break;
      case 5: 
        bool1 = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, i1);
        break;
      case 6: 
        str2 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, i1);
        break;
      case 7: 
        i = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, i1);
        break;
      case 8: 
        str1 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, i1);
        break;
      case 9: 
        localbb = (bb)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, i1, bb.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != j) {
      throw new a.a("Overread allowed size end=" + j, paramParcel);
    }
    return new FastJsonResponse.Field(n, m, bool2, k, bool1, str2, i, str1, localbb);
  }
  
  public FastJsonResponse.Field[] au(int paramInt)
  {
    return new FastJsonResponse.Field[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.server.response.a
 * JD-Core Version:    0.7.0.1
 */