package com.google.android.gms.common.data;

import android.content.ContentValues;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class c<T extends SafeParcelable>
  extends DataBuffer<T>
{
  public static final String DATA_FIELD = "data";
  private static final String[] sf = { "data" };
  private final Parcelable.Creator<T> sg;
  
  public c(d paramd, Parcelable.Creator<T> paramCreator)
  {
    super(paramd);
    this.sg = paramCreator;
  }
  
  public static <T extends SafeParcelable> void addValue(d.a parama, T paramT)
  {
    Parcel localParcel = Parcel.obtain();
    paramT.writeToParcel(localParcel, 0);
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("data", localParcel.marshall());
    parama.a(localContentValues);
    localParcel.recycle();
  }
  
  public static d.a buildDataHolder()
  {
    return d.b(sf);
  }
  
  public T get(int paramInt)
  {
    byte[] arrayOfByte = this.mDataHolder.e("data", paramInt, 0);
    Parcel localParcel = Parcel.obtain();
    localParcel.unmarshall(arrayOfByte, 0, arrayOfByte.length);
    localParcel.setDataPosition(0);
    SafeParcelable localSafeParcelable = (SafeParcelable)this.sg.createFromParcel(localParcel);
    localParcel.recycle();
    return localSafeParcelable;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.c
 * JD-Core Version:    0.7.0.1
 */