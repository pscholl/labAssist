package com.google.android.gms.auth;

import android.app.PendingIntent;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class RecoveryDecision
  implements SafeParcelable
{
  public static final b CREATOR = new b();
  public boolean isRecoveryInfoNeeded;
  public boolean isRecoveryInterstitialAllowed;
  final int oj;
  public PendingIntent recoveryIntent;
  public PendingIntent recoveryIntentWithoutIntro;
  public boolean showRecoveryInterstitial;
  
  public RecoveryDecision()
  {
    this.oj = 1;
  }
  
  RecoveryDecision(int paramInt, PendingIntent paramPendingIntent1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, PendingIntent paramPendingIntent2)
  {
    this.oj = paramInt;
    this.recoveryIntent = paramPendingIntent1;
    this.showRecoveryInterstitial = paramBoolean1;
    this.isRecoveryInfoNeeded = paramBoolean2;
    this.isRecoveryInterstitialAllowed = paramBoolean3;
    this.recoveryIntentWithoutIntro = paramPendingIntent2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public int getVersionCode()
  {
    return this.oj;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.RecoveryDecision
 * JD-Core Version:    0.7.0.1
 */