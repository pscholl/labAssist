package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class s
  implements Parcelable.Creator<GplusInfoRequest>
{
  static void a(GplusInfoRequest paramGplusInfoRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramGplusInfoRequest.version);
    b.a(paramParcel, 2, paramGplusInfoRequest.accountName, false);
    b.a(paramParcel, 3, paramGplusInfoRequest.os, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public GplusInfoRequest[] D(int paramInt)
  {
    return new GplusInfoRequest[paramInt];
  }
  
  public GplusInfoRequest y(Parcel paramParcel)
  {
    CaptchaSolution localCaptchaSolution = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
        break;
      case 3: 
        localCaptchaSolution = (CaptchaSolution)a.a(paramParcel, k, CaptchaSolution.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new GplusInfoRequest(j, str, localCaptchaSolution);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.s
 * JD-Core Version:    0.7.0.1
 */