package com.google.android.gms.auth.firstparty.shared;

import android.graphics.Bitmap;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class CaptchaChallenge
  implements SafeParcelable
{
  public static final c CREATOR = new c();
  String oP;
  String ot;
  Bitmap qe;
  final int version;
  
  CaptchaChallenge(int paramInt, String paramString1, String paramString2, Bitmap paramBitmap)
  {
    this.version = paramInt;
    this.ot = paramString1;
    this.oP = paramString2;
    this.qe = paramBitmap;
  }
  
  public CaptchaChallenge(Status paramStatus)
  {
    this(paramStatus, null, null);
  }
  
  public CaptchaChallenge(Status paramStatus, String paramString, Bitmap paramBitmap)
  {
    this.version = 1;
    this.ot = ((Status)at.f(paramStatus)).getWire();
    this.oP = paramString;
    this.qe = paramBitmap;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public Bitmap getCaptcha()
  {
    return this.qe;
  }
  
  public String getCaptchaToken()
  {
    return this.oP;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.ot);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.CaptchaChallenge
 * JD-Core Version:    0.7.0.1
 */