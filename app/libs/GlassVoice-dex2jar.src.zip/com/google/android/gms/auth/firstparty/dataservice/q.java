package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class q
  implements Parcelable.Creator<GoogleAccountData>
{
  static void a(GoogleAccountData paramGoogleAccountData, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramGoogleAccountData.version);
    b.a(paramParcel, 2, paramGoogleAccountData.accountName, false);
    b.a(paramParcel, 3, paramGoogleAccountData.oQ);
    b.a(paramParcel, 4, paramGoogleAccountData.services, false);
    b.C(paramParcel, i);
  }
  
  public GoogleAccountData[] B(int paramInt)
  {
    return new GoogleAccountData[paramInt];
  }
  
  public GoogleAccountData w(Parcel paramParcel)
  {
    ArrayList localArrayList = null;
    boolean bool = false;
    int i = a.Y(paramParcel);
    String str = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
        break;
      case 3: 
        bool = a.c(paramParcel, k);
        break;
      case 4: 
        localArrayList = a.x(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new GoogleAccountData(j, str, bool, localArrayList);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.q
 * JD-Core Version:    0.7.0.1
 */