package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class PACLConfig
  implements SafeParcelable
{
  public static final g CREATOR = new g();
  String qm;
  String qn;
  final int version;
  
  PACLConfig(int paramInt, String paramString1, String paramString2)
  {
    this.version = paramInt;
    this.qm = paramString1;
    this.qn = paramString2;
  }
  
  public PACLConfig(String paramString1, String paramString2)
  {
    this.version = 1;
    this.qm = paramString1;
    this.qn = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getPacl()
  {
    return this.qn;
  }
  
  public String getVisibleActions()
  {
    return this.qm;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    g.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.PACLConfig
 * JD-Core Version:    0.7.0.1
 */