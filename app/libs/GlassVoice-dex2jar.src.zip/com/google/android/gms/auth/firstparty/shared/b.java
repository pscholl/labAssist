package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;

public class b
  implements Parcelable.Creator<AppDescription>
{
  static void a(AppDescription paramAppDescription, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramAppDescription.version);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 2, paramAppDescription.qa);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramAppDescription.qb, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 4, paramAppDescription.qc, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 5, paramAppDescription.qd, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 6, paramAppDescription.oL);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public AppDescription M(Parcel paramParcel)
  {
    String str1 = null;
    boolean bool = false;
    int i = a.Y(paramParcel);
    String str2 = null;
    String str3 = null;
    int j = 0;
    int k = 0;
    while (paramParcel.dataPosition() < i)
    {
      int m = a.X(paramParcel);
      switch (a.al(m))
      {
      default: 
        a.b(paramParcel, m);
        break;
      case 1: 
        k = a.f(paramParcel, m);
        break;
      case 2: 
        j = a.f(paramParcel, m);
        break;
      case 3: 
        str3 = a.l(paramParcel, m);
        break;
      case 4: 
        str2 = a.l(paramParcel, m);
        break;
      case 5: 
        str1 = a.l(paramParcel, m);
        break;
      case 6: 
        bool = a.c(paramParcel, m);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AppDescription(k, j, str3, str2, str1, bool);
  }
  
  public AppDescription[] R(int paramInt)
  {
    return new AppDescription[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.b
 * JD-Core Version:    0.7.0.1
 */