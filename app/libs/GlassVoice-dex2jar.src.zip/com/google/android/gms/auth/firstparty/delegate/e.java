package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class e
  implements Parcelable.Creator<UpdateCredentialsWorkflowRequest>
{
  static void a(UpdateCredentialsWorkflowRequest paramUpdateCredentialsWorkflowRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramUpdateCredentialsWorkflowRequest.version);
    b.a(paramParcel, 2, paramUpdateCredentialsWorkflowRequest.accountName, false);
    b.a(paramParcel, 3, paramUpdateCredentialsWorkflowRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 4, paramUpdateCredentialsWorkflowRequest.pj, false);
    b.C(paramParcel, i);
  }
  
  public UpdateCredentialsWorkflowRequest K(Parcel paramParcel)
  {
    Object localObject1 = null;
    int i = a.Y(paramParcel);
    int j = 0;
    Object localObject2 = new Bundle();
    Object localObject3 = null;
    if (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      Object localObject4;
      Object localObject5;
      Object localObject6;
      int m;
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        localObject4 = localObject2;
        localObject5 = localObject1;
        localObject6 = localObject3;
        m = j;
      }
      for (;;)
      {
        j = m;
        localObject3 = localObject6;
        localObject1 = localObject5;
        localObject2 = localObject4;
        break;
        int n = a.f(paramParcel, k);
        Object localObject9 = localObject2;
        localObject5 = localObject1;
        localObject6 = localObject3;
        m = n;
        localObject4 = localObject9;
        continue;
        String str = a.l(paramParcel, k);
        m = j;
        Object localObject8 = localObject1;
        localObject6 = str;
        localObject4 = localObject2;
        localObject5 = localObject8;
        continue;
        AppDescription localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
        localObject6 = localObject3;
        m = j;
        Object localObject7 = localObject2;
        localObject5 = localAppDescription;
        localObject4 = localObject7;
        continue;
        localObject4 = a.n(paramParcel, k);
        localObject5 = localObject1;
        localObject6 = localObject3;
        m = j;
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new UpdateCredentialsWorkflowRequest(j, localObject3, localObject1, (Bundle)localObject2);
  }
  
  public UpdateCredentialsWorkflowRequest[] P(int paramInt)
  {
    return new UpdateCredentialsWorkflowRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.e
 * JD-Core Version:    0.7.0.1
 */