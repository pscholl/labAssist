package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class o
  implements Parcelable.Creator<ClearTokenResponse>
{
  static void a(ClearTokenResponse paramClearTokenResponse, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramClearTokenResponse.version);
    b.a(paramParcel, 2, paramClearTokenResponse.ot, false);
    b.C(paramParcel, i);
  }
  
  public ClearTokenResponse u(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    String str = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new ClearTokenResponse(j, str);
  }
  
  public ClearTokenResponse[] z(int paramInt)
  {
    return new ClearTokenResponse[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.o
 * JD-Core Version:    0.7.0.1
 */