package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountRecoveryGuidanceRequest
  implements SafeParcelable
{
  public static final f CREATOR = new f();
  public final String accountName;
  final int version;
  
  AccountRecoveryGuidanceRequest(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.accountName = paramString;
  }
  
  public AccountRecoveryGuidanceRequest(String paramString)
  {
    this(0, paramString);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    f.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRecoveryGuidanceRequest
 * JD-Core Version:    0.7.0.1
 */