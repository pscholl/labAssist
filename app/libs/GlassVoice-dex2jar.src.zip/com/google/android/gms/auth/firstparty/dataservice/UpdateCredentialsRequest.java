package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AccountCredentials;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class UpdateCredentialsRequest
  implements SafeParcelable
{
  public static final z CREATOR = new z();
  AccountCredentials oM;
  CaptchaSolution os;
  final int version;
  
  public UpdateCredentialsRequest()
  {
    this.version = 1;
  }
  
  UpdateCredentialsRequest(int paramInt, AccountCredentials paramAccountCredentials, CaptchaSolution paramCaptchaSolution)
  {
    this.version = paramInt;
    this.oM = paramAccountCredentials;
    this.os = paramCaptchaSolution;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public AccountCredentials getAccountCredentials()
  {
    return this.oM;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public UpdateCredentialsRequest setAccountCredentials(AccountCredentials paramAccountCredentials)
  {
    this.oM = paramAccountCredentials;
    return this;
  }
  
  public UpdateCredentialsRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    z.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.UpdateCredentialsRequest
 * JD-Core Version:    0.7.0.1
 */