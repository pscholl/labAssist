package com.google.android.gms.auth.firstparty.shared;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

public abstract class BlockingServiceClient
{
  private final String TAG = "BlockingServiceClient";
  private final Context mContext;
  
  protected BlockingServiceClient(Context paramContext)
  {
    this.mContext = paramContext.getApplicationContext();
  }
  
  /* Error */
  protected <R> R exec(Call<R> paramCall)
  {
    // Byte code:
    //   0: ldc 33
    //   2: invokestatic 39	com/google/android/gms/internal/at:x	(Ljava/lang/String;)V
    //   5: aload_0
    //   6: invokevirtual 43	com/google/android/gms/auth/firstparty/shared/BlockingServiceClient:getServiceIntent	()Landroid/content/Intent;
    //   9: astore_2
    //   10: aload_0
    //   11: getfield 25	com/google/android/gms/auth/firstparty/shared/BlockingServiceClient:mContext	Landroid/content/Context;
    //   14: invokevirtual 47	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   17: astore_3
    //   18: aload_3
    //   19: aload_2
    //   20: iconst_0
    //   21: invokevirtual 53	android/content/pm/PackageManager:resolveService	(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   24: astore 4
    //   26: aload 4
    //   28: ifnull +11 -> 39
    //   31: aload 4
    //   33: getfield 59	android/content/pm/ResolveInfo:serviceInfo	Landroid/content/pm/ServiceInfo;
    //   36: ifnonnull +33 -> 69
    //   39: new 61	java/lang/IllegalStateException
    //   42: dup
    //   43: new 63	java/lang/StringBuilder
    //   46: dup
    //   47: invokespecial 64	java/lang/StringBuilder:<init>	()V
    //   50: ldc 66
    //   52: invokevirtual 70	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: aload_2
    //   56: invokevirtual 76	android/content/Intent:toString	()Ljava/lang/String;
    //   59: invokevirtual 70	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: invokevirtual 77	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   65: invokespecial 79	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   68: athrow
    //   69: aload 4
    //   71: getfield 59	android/content/pm/ResolveInfo:serviceInfo	Landroid/content/pm/ServiceInfo;
    //   74: astore 5
    //   76: aload_3
    //   77: aload 5
    //   79: getfield 84	android/content/pm/ServiceInfo:packageName	Ljava/lang/String;
    //   82: invokestatic 90	com/google/android/gms/common/GooglePlayServicesUtil:isPackageGoogleSigned	(Landroid/content/pm/PackageManager;Ljava/lang/String;)Z
    //   85: ifne +25 -> 110
    //   88: new 92	java/lang/SecurityException
    //   91: dup
    //   92: ldc 94
    //   94: invokespecial 95	java/lang/SecurityException:<init>	(Ljava/lang/String;)V
    //   97: astore 6
    //   99: ldc 15
    //   101: aload 6
    //   103: invokestatic 101	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   106: pop
    //   107: aload 6
    //   109: athrow
    //   110: aload_2
    //   111: aload 5
    //   113: getfield 84	android/content/pm/ServiceInfo:packageName	Ljava/lang/String;
    //   116: invokevirtual 105	android/content/Intent:setPackage	(Ljava/lang/String;)Landroid/content/Intent;
    //   119: pop
    //   120: new 107	com/google/android/gms/common/a
    //   123: dup
    //   124: invokespecial 108	com/google/android/gms/common/a:<init>	()V
    //   127: astore 9
    //   129: aload_0
    //   130: getfield 25	com/google/android/gms/auth/firstparty/shared/BlockingServiceClient:mContext	Landroid/content/Context;
    //   133: aload_2
    //   134: aload 9
    //   136: iconst_1
    //   137: invokevirtual 112	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   140: ifeq +82 -> 222
    //   143: aload_1
    //   144: aload 9
    //   146: invokevirtual 116	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   149: invokeinterface 121 2 0
    //   154: astore 15
    //   156: aload_0
    //   157: getfield 25	com/google/android/gms/auth/firstparty/shared/BlockingServiceClient:mContext	Landroid/content/Context;
    //   160: aload 9
    //   162: invokevirtual 125	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   165: aload 15
    //   167: areturn
    //   168: astore 13
    //   170: ldc 15
    //   172: aload 13
    //   174: invokestatic 101	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   177: pop
    //   178: new 127	java/lang/RuntimeException
    //   181: dup
    //   182: aload 13
    //   184: invokespecial 130	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   187: athrow
    //   188: astore 12
    //   190: aload_0
    //   191: getfield 25	com/google/android/gms/auth/firstparty/shared/BlockingServiceClient:mContext	Landroid/content/Context;
    //   194: aload 9
    //   196: invokevirtual 125	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   199: aload 12
    //   201: athrow
    //   202: astore 10
    //   204: ldc 15
    //   206: aload 10
    //   208: invokestatic 101	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   211: pop
    //   212: new 127	java/lang/RuntimeException
    //   215: dup
    //   216: aload 10
    //   218: invokespecial 130	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   221: athrow
    //   222: aconst_null
    //   223: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	224	0	this	BlockingServiceClient
    //   0	224	1	paramCall	Call<R>
    //   9	125	2	localIntent	Intent
    //   17	60	3	localPackageManager	android.content.pm.PackageManager
    //   24	46	4	localResolveInfo	android.content.pm.ResolveInfo
    //   74	38	5	localServiceInfo	android.content.pm.ServiceInfo
    //   97	11	6	localSecurityException	java.lang.SecurityException
    //   127	68	9	locala	com.google.android.gms.common.a
    //   202	15	10	localRemoteException	RemoteException
    //   188	12	12	localObject1	Object
    //   168	15	13	localInterruptedException	java.lang.InterruptedException
    //   154	12	15	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   143	156	168	java/lang/InterruptedException
    //   143	156	188	finally
    //   170	188	188	finally
    //   204	222	188	finally
    //   143	156	202	android/os/RemoteException
  }
  
  protected abstract Intent getServiceIntent();
  
  protected static abstract interface Call<R>
  {
    public abstract R exec(IBinder paramIBinder)
      throws RemoteException;
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.BlockingServiceClient
 * JD-Core Version:    0.7.0.1
 */