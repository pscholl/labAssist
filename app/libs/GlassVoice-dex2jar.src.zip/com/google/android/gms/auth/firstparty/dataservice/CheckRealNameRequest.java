package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class CheckRealNameRequest
  implements SafeParcelable
{
  public static final l CREATOR = new l();
  AppDescription callingAppDescription;
  String oN;
  String oO;
  final int version;
  
  public CheckRealNameRequest()
  {
    this.version = 1;
  }
  
  CheckRealNameRequest(int paramInt, AppDescription paramAppDescription, String paramString1, String paramString2)
  {
    this.version = paramInt;
    this.callingAppDescription = paramAppDescription;
    this.oN = paramString1;
    this.oO = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public String getFirstName()
  {
    return this.oN;
  }
  
  public String getLastName()
  {
    return this.oO;
  }
  
  public CheckRealNameRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public CheckRealNameRequest setFirstName(String paramString)
  {
    this.oN = paramString;
    return this;
  }
  
  public CheckRealNameRequest setLastName(String paramString)
  {
    this.oO = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    l.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.CheckRealNameRequest
 * JD-Core Version:    0.7.0.1
 */