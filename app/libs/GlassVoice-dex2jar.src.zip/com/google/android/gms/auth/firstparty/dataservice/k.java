package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AccountCredentials;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class k
  implements Parcelable.Creator<AccountSignInRequest>
{
  static void a(AccountSignInRequest paramAccountSignInRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountSignInRequest.version);
    b.a(paramParcel, 2, paramAccountSignInRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 3, paramAccountSignInRequest.oK);
    b.a(paramParcel, 4, paramAccountSignInRequest.oL);
    b.a(paramParcel, 5, paramAccountSignInRequest.os, paramInt, false);
    b.a(paramParcel, 6, paramAccountSignInRequest.oM, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public AccountSignInRequest q(Parcel paramParcel)
  {
    AccountCredentials localAccountCredentials = null;
    boolean bool1 = false;
    int i = a.Y(paramParcel);
    CaptchaSolution localCaptchaSolution = null;
    boolean bool2 = false;
    AppDescription localAppDescription = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
        break;
      case 3: 
        bool2 = a.c(paramParcel, k);
        break;
      case 4: 
        bool1 = a.c(paramParcel, k);
        break;
      case 5: 
        localCaptchaSolution = (CaptchaSolution)a.a(paramParcel, k, CaptchaSolution.CREATOR);
        break;
      case 6: 
        localAccountCredentials = (AccountCredentials)a.a(paramParcel, k, AccountCredentials.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountSignInRequest(j, localAppDescription, bool2, bool1, localCaptchaSolution, localAccountCredentials);
  }
  
  public AccountSignInRequest[] v(int paramInt)
  {
    return new AccountSignInRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.k
 * JD-Core Version:    0.7.0.1
 */