package com.google.android.gms.auth;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class c
  implements Parcelable.Creator<RecoveryReadResponse>
{
  static void a(RecoveryReadResponse paramRecoveryReadResponse, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramRecoveryReadResponse.oj);
    b.a(paramParcel, 2, paramRecoveryReadResponse.mSecondaryEmail, false);
    b.a(paramParcel, 3, paramRecoveryReadResponse.mPhoneNumber, false);
    b.a(paramParcel, 4, paramRecoveryReadResponse.mPhoneCountryCode, false);
    b.b(paramParcel, 5, paramRecoveryReadResponse.mCountryList, false);
    b.a(paramParcel, 6, paramRecoveryReadResponse.mError, false);
    b.a(paramParcel, 7, paramRecoveryReadResponse.mAction, false);
    b.a(paramParcel, 8, paramRecoveryReadResponse.mAllowedOptions, false);
    b.C(paramParcel, i);
  }
  
  public RecoveryReadResponse d(Parcel paramParcel)
  {
    String str1 = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str2 = null;
    String str3 = null;
    ArrayList localArrayList = null;
    String str4 = null;
    String str5 = null;
    String str6 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str6 = a.l(paramParcel, k);
        break;
      case 3: 
        str5 = a.l(paramParcel, k);
        break;
      case 4: 
        str4 = a.l(paramParcel, k);
        break;
      case 5: 
        localArrayList = a.c(paramParcel, k, Country.CREATOR);
        break;
      case 6: 
        str3 = a.l(paramParcel, k);
        break;
      case 7: 
        str2 = a.l(paramParcel, k);
        break;
      case 8: 
        str1 = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new RecoveryReadResponse(j, str6, str5, str4, localArrayList, str3, str2, str1);
  }
  
  public RecoveryReadResponse[] i(int paramInt)
  {
    return new RecoveryReadResponse[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.c
 * JD-Core Version:    0.7.0.1
 */