package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class ab
  implements Parcelable.Creator<WebSetupConfigRequest>
{
  static void a(WebSetupConfigRequest paramWebSetupConfigRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramWebSetupConfigRequest.version);
    b.a(paramParcel, 2, paramWebSetupConfigRequest.callingAppDescription, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public WebSetupConfigRequest G(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    AppDescription localAppDescription = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new WebSetupConfigRequest(j, localAppDescription);
  }
  
  public WebSetupConfigRequest[] L(int paramInt)
  {
    return new WebSetupConfigRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.ab
 * JD-Core Version:    0.7.0.1
 */