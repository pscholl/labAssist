package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.Country;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class c
  implements Parcelable.Creator<AccountRecoveryData>
{
  static void a(AccountRecoveryData paramAccountRecoveryData, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountRecoveryData.version);
    b.a(paramParcel, 2, paramAccountRecoveryData.guidance, paramInt, false);
    b.a(paramParcel, 3, paramAccountRecoveryData.action, false);
    b.a(paramParcel, 4, paramAccountRecoveryData.allowedRecoveryOption, false);
    b.a(paramParcel, 5, paramAccountRecoveryData.accountName, false);
    b.a(paramParcel, 6, paramAccountRecoveryData.secondaryEmail, false);
    b.a(paramParcel, 7, paramAccountRecoveryData.phoneNumber, false);
    b.b(paramParcel, 8, paramAccountRecoveryData.countries, false);
    b.a(paramParcel, 9, paramAccountRecoveryData.defaultCountryCode, false);
    b.a(paramParcel, 10, paramAccountRecoveryData.error, false);
    b.C(paramParcel, i);
  }
  
  public AccountRecoveryData i(Parcel paramParcel)
  {
    String str1 = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str2 = null;
    ArrayList localArrayList = null;
    String str3 = null;
    String str4 = null;
    String str5 = null;
    String str6 = null;
    String str7 = null;
    AccountRecoveryGuidance localAccountRecoveryGuidance = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localAccountRecoveryGuidance = (AccountRecoveryGuidance)a.a(paramParcel, k, AccountRecoveryGuidance.CREATOR);
        break;
      case 3: 
        str7 = a.l(paramParcel, k);
        break;
      case 4: 
        str6 = a.l(paramParcel, k);
        break;
      case 5: 
        str5 = a.l(paramParcel, k);
        break;
      case 6: 
        str4 = a.l(paramParcel, k);
        break;
      case 7: 
        str3 = a.l(paramParcel, k);
        break;
      case 8: 
        localArrayList = a.c(paramParcel, k, Country.CREATOR);
        break;
      case 9: 
        str2 = a.l(paramParcel, k);
        break;
      case 10: 
        str1 = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountRecoveryData(j, localAccountRecoveryGuidance, str7, str6, str5, str4, str3, localArrayList, str2, str1);
  }
  
  public AccountRecoveryData[] n(int paramInt)
  {
    return new AccountRecoveryData[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.c
 * JD-Core Version:    0.7.0.1
 */