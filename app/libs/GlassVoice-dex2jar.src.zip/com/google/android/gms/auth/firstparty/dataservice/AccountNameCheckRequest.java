package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountNameCheckRequest
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  AppDescription callingAppDescription;
  String op;
  String oq;
  String or;
  CaptchaSolution os;
  final int version;
  
  public AccountNameCheckRequest()
  {
    this.version = 1;
  }
  
  AccountNameCheckRequest(int paramInt, String paramString1, String paramString2, String paramString3, AppDescription paramAppDescription, CaptchaSolution paramCaptchaSolution)
  {
    this.version = paramInt;
    this.op = paramString1;
    this.oq = paramString2;
    this.or = paramString3;
    this.callingAppDescription = paramAppDescription;
    this.os = paramCaptchaSolution;
  }
  
  public AccountNameCheckRequest(String paramString)
  {
    this.version = 1;
    this.op = paramString;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountNameToCheck()
  {
    return this.op;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public String getFirstName()
  {
    return this.oq;
  }
  
  public String getLastName()
  {
    return this.or;
  }
  
  public AccountNameCheckRequest setAccountNameToCheck(String paramString)
  {
    this.op = paramString;
    return this;
  }
  
  public AccountNameCheckRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public AccountNameCheckRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  public AccountNameCheckRequest setFirstName(String paramString)
  {
    this.oq = paramString;
    return this;
  }
  
  public AccountNameCheckRequest setLastName(String paramString)
  {
    this.or = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountNameCheckRequest
 * JD-Core Version:    0.7.0.1
 */