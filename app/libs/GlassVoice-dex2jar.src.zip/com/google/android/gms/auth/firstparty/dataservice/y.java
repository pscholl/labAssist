package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.CaptchaChallenge;
import com.google.android.gms.auth.firstparty.shared.ScopeDetail;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class y
  implements Parcelable.Creator<TokenResponse>
{
  static void a(TokenResponse paramTokenResponse, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramTokenResponse.version);
    b.a(paramParcel, 2, paramTokenResponse.accountName, false);
    b.a(paramParcel, 3, paramTokenResponse.ot, false);
    b.a(paramParcel, 4, paramTokenResponse.oP, false);
    b.a(paramParcel, 5, paramTokenResponse.pF, false);
    b.a(paramParcel, 6, paramTokenResponse.ov, false);
    b.a(paramParcel, 7, paramTokenResponse.pG, false);
    b.a(paramParcel, 8, paramTokenResponse.oN, false);
    b.a(paramParcel, 9, paramTokenResponse.oO, false);
    b.a(paramParcel, 10, paramTokenResponse.pH);
    b.a(paramParcel, 11, paramTokenResponse.pI);
    b.a(paramParcel, 12, paramTokenResponse.pJ);
    b.a(paramParcel, 13, paramTokenResponse.pK);
    b.a(paramParcel, 14, paramTokenResponse.ow, paramInt, false);
    b.b(paramParcel, 15, paramTokenResponse.pL, false);
    b.a(paramParcel, 17, paramTokenResponse.pp, false);
    b.a(paramParcel, 16, paramTokenResponse.pu, false);
    b.a(paramParcel, 18, paramTokenResponse.pM);
    b.C(paramParcel, i);
  }
  
  public TokenResponse D(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    String str5 = null;
    String str6 = null;
    String str7 = null;
    String str8 = null;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    CaptchaChallenge localCaptchaChallenge = null;
    ArrayList localArrayList = new ArrayList();
    String str9 = null;
    String str10 = null;
    boolean bool5 = false;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str1 = a.l(paramParcel, k);
        break;
      case 3: 
        str2 = a.l(paramParcel, k);
        break;
      case 4: 
        str3 = a.l(paramParcel, k);
        break;
      case 5: 
        str4 = a.l(paramParcel, k);
        break;
      case 6: 
        str5 = a.l(paramParcel, k);
        break;
      case 7: 
        str6 = a.l(paramParcel, k);
        break;
      case 8: 
        str7 = a.l(paramParcel, k);
        break;
      case 9: 
        str8 = a.l(paramParcel, k);
        break;
      case 10: 
        bool1 = a.c(paramParcel, k);
        break;
      case 11: 
        bool2 = a.c(paramParcel, k);
        break;
      case 12: 
        bool3 = a.c(paramParcel, k);
        break;
      case 13: 
        bool4 = a.c(paramParcel, k);
        break;
      case 14: 
        localCaptchaChallenge = (CaptchaChallenge)a.a(paramParcel, k, CaptchaChallenge.CREATOR);
        break;
      case 15: 
        localArrayList = a.c(paramParcel, k, ScopeDetail.CREATOR);
        break;
      case 17: 
        str10 = a.l(paramParcel, k);
        break;
      case 16: 
        str9 = a.l(paramParcel, k);
        break;
      case 18: 
        bool5 = a.c(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new TokenResponse(j, str1, str2, str3, str4, str5, str6, str7, str8, bool1, bool2, bool3, bool4, localCaptchaChallenge, localArrayList, str9, str10, bool5);
  }
  
  public TokenResponse[] I(int paramInt)
  {
    return new TokenResponse[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.y
 * JD-Core Version:    0.7.0.1
 */