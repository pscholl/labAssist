package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class FACLData
  implements SafeParcelable
{
  public static final f CREATOR = new f();
  FACLConfig qi;
  String qj;
  boolean qk;
  String ql;
  final int version;
  
  FACLData(int paramInt, FACLConfig paramFACLConfig, String paramString1, boolean paramBoolean, String paramString2)
  {
    this.version = paramInt;
    this.qi = paramFACLConfig;
    this.qj = paramString1;
    this.qk = paramBoolean;
    this.ql = paramString2;
  }
  
  public FACLData(FACLConfig paramFACLConfig, String paramString1, String paramString2, boolean paramBoolean)
  {
    this.version = 1;
    this.qi = paramFACLConfig;
    this.qj = paramString1;
    this.ql = paramString2;
    this.qk = paramBoolean;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getActivityText()
  {
    return this.qj;
  }
  
  public FACLConfig getFaclConfig()
  {
    return this.qi;
  }
  
  public String getSpeedbumpText()
  {
    return this.ql;
  }
  
  public boolean isSpeedbumpNeeded()
  {
    return this.qk;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    f.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.FACLData
 * JD-Core Version:    0.7.0.1
 */