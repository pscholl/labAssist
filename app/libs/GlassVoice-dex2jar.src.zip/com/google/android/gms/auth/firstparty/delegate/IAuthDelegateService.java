package com.google.android.gms.auth.firstparty.delegate;

import android.app.PendingIntent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IAuthDelegateService
  extends IInterface
{
  public abstract PendingIntent getConfirmCredentialsWorkflowIntent(ConfirmCredentialsWorkflowRequest paramConfirmCredentialsWorkflowRequest)
    throws RemoteException;
  
  public abstract PendingIntent getSetupAccountWorkflowIntent(SetupAccountWorkflowRequest paramSetupAccountWorkflowRequest)
    throws RemoteException;
  
  public abstract PendingIntent getTokenRetrievalWorkflowIntent(TokenWorkflowRequest paramTokenWorkflowRequest)
    throws RemoteException;
  
  public abstract PendingIntent getUpdateCredentialsWorkflowIntent(UpdateCredentialsWorkflowRequest paramUpdateCredentialsWorkflowRequest)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IAuthDelegateService
  {
    public Stub()
    {
      attachInterface(this, "com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
    }
    
    public static IAuthDelegateService asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
      if ((localIInterface != null) && ((localIInterface instanceof IAuthDelegateService))) {
        return (IAuthDelegateService)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
        return true;
      case 1: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
        int m = paramParcel1.readInt();
        SetupAccountWorkflowRequest localSetupAccountWorkflowRequest = null;
        if (m != 0) {
          localSetupAccountWorkflowRequest = SetupAccountWorkflowRequest.CREATOR.I(paramParcel1);
        }
        PendingIntent localPendingIntent4 = getSetupAccountWorkflowIntent(localSetupAccountWorkflowRequest);
        paramParcel2.writeNoException();
        if (localPendingIntent4 != null)
        {
          paramParcel2.writeInt(1);
          localPendingIntent4.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 2: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
        int k = paramParcel1.readInt();
        TokenWorkflowRequest localTokenWorkflowRequest = null;
        if (k != 0) {
          localTokenWorkflowRequest = TokenWorkflowRequest.CREATOR.J(paramParcel1);
        }
        PendingIntent localPendingIntent3 = getTokenRetrievalWorkflowIntent(localTokenWorkflowRequest);
        paramParcel2.writeNoException();
        if (localPendingIntent3 != null)
        {
          paramParcel2.writeInt(1);
          localPendingIntent3.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 3: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
        int j = paramParcel1.readInt();
        UpdateCredentialsWorkflowRequest localUpdateCredentialsWorkflowRequest = null;
        if (j != 0) {
          localUpdateCredentialsWorkflowRequest = UpdateCredentialsWorkflowRequest.CREATOR.K(paramParcel1);
        }
        PendingIntent localPendingIntent2 = getUpdateCredentialsWorkflowIntent(localUpdateCredentialsWorkflowRequest);
        paramParcel2.writeNoException();
        if (localPendingIntent2 != null)
        {
          paramParcel2.writeInt(1);
          localPendingIntent2.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      }
      paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
      int i = paramParcel1.readInt();
      ConfirmCredentialsWorkflowRequest localConfirmCredentialsWorkflowRequest = null;
      if (i != 0) {
        localConfirmCredentialsWorkflowRequest = ConfirmCredentialsWorkflowRequest.CREATOR.H(paramParcel1);
      }
      PendingIntent localPendingIntent1 = getConfirmCredentialsWorkflowIntent(localConfirmCredentialsWorkflowRequest);
      paramParcel2.writeNoException();
      if (localPendingIntent1 != null)
      {
        paramParcel2.writeInt(1);
        localPendingIntent1.writeToParcel(paramParcel2, 1);
      }
      for (;;)
      {
        return true;
        paramParcel2.writeInt(0);
      }
    }
    
    private static class Proxy
      implements IAuthDelegateService
    {
      private IBinder jR;
      
      Proxy(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public PendingIntent getConfirmCredentialsWorkflowIntent(ConfirmCredentialsWorkflowRequest paramConfirmCredentialsWorkflowRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
            if (paramConfirmCredentialsWorkflowRequest != null)
            {
              localParcel1.writeInt(1);
              paramConfirmCredentialsWorkflowRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(4, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(localParcel2);
                return localPendingIntent;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PendingIntent localPendingIntent = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService";
      }
      
      public PendingIntent getSetupAccountWorkflowIntent(SetupAccountWorkflowRequest paramSetupAccountWorkflowRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
            if (paramSetupAccountWorkflowRequest != null)
            {
              localParcel1.writeInt(1);
              paramSetupAccountWorkflowRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(1, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(localParcel2);
                return localPendingIntent;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PendingIntent localPendingIntent = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public PendingIntent getTokenRetrievalWorkflowIntent(TokenWorkflowRequest paramTokenWorkflowRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
            if (paramTokenWorkflowRequest != null)
            {
              localParcel1.writeInt(1);
              paramTokenWorkflowRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(2, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(localParcel2);
                return localPendingIntent;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PendingIntent localPendingIntent = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public PendingIntent getUpdateCredentialsWorkflowIntent(UpdateCredentialsWorkflowRequest paramUpdateCredentialsWorkflowRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService");
            if (paramUpdateCredentialsWorkflowRequest != null)
            {
              localParcel1.writeInt(1);
              paramUpdateCredentialsWorkflowRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(3, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(localParcel2);
                return localPendingIntent;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PendingIntent localPendingIntent = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.IAuthDelegateService
 * JD-Core Version:    0.7.0.1
 */