package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class v
  implements Parcelable.Creator<PasswordCheckRequest>
{
  static void a(PasswordCheckRequest paramPasswordCheckRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramPasswordCheckRequest.version);
    b.a(paramParcel, 2, paramPasswordCheckRequest.accountName, false);
    b.a(paramParcel, 3, paramPasswordCheckRequest.pw, false);
    b.a(paramParcel, 4, paramPasswordCheckRequest.oq, false);
    b.a(paramParcel, 5, paramPasswordCheckRequest.or, false);
    b.a(paramParcel, 6, paramPasswordCheckRequest.px, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public PasswordCheckRequest A(Parcel paramParcel)
  {
    AppDescription localAppDescription = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str4 = a.l(paramParcel, k);
        break;
      case 3: 
        str3 = a.l(paramParcel, k);
        break;
      case 4: 
        str2 = a.l(paramParcel, k);
        break;
      case 5: 
        str1 = a.l(paramParcel, k);
        break;
      case 6: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new PasswordCheckRequest(j, str4, str3, str2, str1, localAppDescription);
  }
  
  public PasswordCheckRequest[] F(int paramInt)
  {
    return new PasswordCheckRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.v
 * JD-Core Version:    0.7.0.1
 */