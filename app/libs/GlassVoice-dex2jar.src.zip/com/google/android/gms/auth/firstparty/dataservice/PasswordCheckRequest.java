package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class PasswordCheckRequest
  implements SafeParcelable
{
  public static final v CREATOR = new v();
  String accountName;
  String oq;
  String or;
  String pw;
  AppDescription px;
  final int version;
  
  PasswordCheckRequest(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, AppDescription paramAppDescription)
  {
    this.version = paramInt;
    this.accountName = paramString1;
    this.pw = paramString2;
    this.oq = paramString3;
    this.or = paramString4;
    this.px = paramAppDescription;
  }
  
  public PasswordCheckRequest(String paramString1, String paramString2)
  {
    this.version = 1;
    this.accountName = paramString1;
    this.pw = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.px;
  }
  
  public String getFirstName()
  {
    return this.oq;
  }
  
  public String getLastName()
  {
    return this.or;
  }
  
  public String getPassword()
  {
    return this.pw;
  }
  
  public PasswordCheckRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.px = paramAppDescription;
    return this;
  }
  
  public PasswordCheckRequest setFirstName(String paramString)
  {
    this.oq = paramString;
    return this;
  }
  
  public PasswordCheckRequest setLastName(String paramString)
  {
    this.or = paramString;
    return this;
  }
  
  public PasswordCheckRequest setPassword(String paramString)
  {
    this.pw = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    v.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.PasswordCheckRequest
 * JD-Core Version:    0.7.0.1
 */