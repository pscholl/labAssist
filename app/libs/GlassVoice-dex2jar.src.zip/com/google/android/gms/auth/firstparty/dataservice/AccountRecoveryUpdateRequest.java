package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.RecoveryResponse;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountRecoveryUpdateRequest
  implements RecoveryResponse, SafeParcelable
{
  public static final g CREATOR = new g();
  public final String accountName;
  public final AppDescription callingAppDescription;
  public final boolean isBroadUse;
  public final String phoneCountryCode;
  public final String phoneNumber;
  public final String secondaryEmail;
  final int version;
  
  AccountRecoveryUpdateRequest(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean, AppDescription paramAppDescription)
  {
    this.version = paramInt;
    this.accountName = paramString1;
    this.secondaryEmail = paramString2;
    this.phoneNumber = paramString3;
    this.phoneCountryCode = paramString4;
    this.isBroadUse = paramBoolean;
    this.callingAppDescription = paramAppDescription;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    g.a(this, paramParcel, paramInt);
  }
  
  public static class Builder
  {
    private String oA;
    private String oB;
    private String oC;
    private String oH;
    private boolean oI;
    private AppDescription oJ;
    
    public AccountRecoveryUpdateRequest build()
    {
      return new AccountRecoveryUpdateRequest(0, this.oA, this.oB, this.oC, this.oH, this.oI, this.oJ);
    }
    
    public Builder setAccountName(String paramString)
    {
      this.oA = paramString;
      return this;
    }
    
    public Builder setBroadUse(boolean paramBoolean)
    {
      this.oI = paramBoolean;
      return this;
    }
    
    public Builder setCallingAppDescription(AppDescription paramAppDescription)
    {
      this.oJ = paramAppDescription;
      return this;
    }
    
    public Builder setPhoneCountryCode(String paramString)
    {
      this.oH = paramString;
      return this;
    }
    
    public Builder setPhoneNumber(String paramString)
    {
      this.oC = paramString;
      return this;
    }
    
    public Builder setSecondaryEmail(String paramString)
    {
      this.oB = paramString;
      return this;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRecoveryUpdateRequest
 * JD-Core Version:    0.7.0.1
 */