package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class a
  implements Parcelable.Creator<ConfirmCredentialsWorkflowRequest>
{
  static void a(ConfirmCredentialsWorkflowRequest paramConfirmCredentialsWorkflowRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramConfirmCredentialsWorkflowRequest.version);
    b.a(paramParcel, 2, paramConfirmCredentialsWorkflowRequest.accountName, false);
    b.a(paramParcel, 3, paramConfirmCredentialsWorkflowRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 4, paramConfirmCredentialsWorkflowRequest.pj, false);
    b.C(paramParcel, i);
  }
  
  public ConfirmCredentialsWorkflowRequest H(Parcel paramParcel)
  {
    Object localObject1 = null;
    int i = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    int j = 0;
    Object localObject2 = new Bundle();
    Object localObject3 = null;
    if (paramParcel.dataPosition() < i)
    {
      int k = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      Object localObject4;
      Object localObject5;
      Object localObject6;
      int m;
      switch (com.google.android.gms.common.internal.safeparcel.a.al(k))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, k);
        localObject4 = localObject2;
        localObject5 = localObject1;
        localObject6 = localObject3;
        m = j;
      }
      for (;;)
      {
        j = m;
        localObject3 = localObject6;
        localObject1 = localObject5;
        localObject2 = localObject4;
        break;
        int n = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, k);
        Object localObject9 = localObject2;
        localObject5 = localObject1;
        localObject6 = localObject3;
        m = n;
        localObject4 = localObject9;
        continue;
        String str = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        m = j;
        Object localObject8 = localObject1;
        localObject6 = str;
        localObject4 = localObject2;
        localObject5 = localObject8;
        continue;
        AppDescription localAppDescription = (AppDescription)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, k, AppDescription.CREATOR);
        localObject6 = localObject3;
        m = j;
        Object localObject7 = localObject2;
        localObject5 = localAppDescription;
        localObject4 = localObject7;
        continue;
        localObject4 = com.google.android.gms.common.internal.safeparcel.a.n(paramParcel, k);
        localObject5 = localObject1;
        localObject6 = localObject3;
        m = j;
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new ConfirmCredentialsWorkflowRequest(j, localObject3, localObject1, (Bundle)localObject2);
  }
  
  public ConfirmCredentialsWorkflowRequest[] M(int paramInt)
  {
    return new ConfirmCredentialsWorkflowRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.a
 * JD-Core Version:    0.7.0.1
 */