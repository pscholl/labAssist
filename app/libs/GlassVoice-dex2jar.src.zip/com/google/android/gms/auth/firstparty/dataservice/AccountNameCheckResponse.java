package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.CaptchaChallenge;
import com.google.android.gms.auth.firstparty.shared.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AccountNameCheckResponse
  implements SafeParcelable
{
  public static final b CREATOR = new b();
  String ot;
  List<String> ou;
  String ov;
  CaptchaChallenge ow;
  final int version;
  
  AccountNameCheckResponse(int paramInt, String paramString1, List<String> paramList, String paramString2, CaptchaChallenge paramCaptchaChallenge)
  {
    this.version = paramInt;
    this.ot = paramString1;
    this.ou = paramList;
    this.ov = paramString2;
    this.ow = paramCaptchaChallenge;
  }
  
  public AccountNameCheckResponse(Status paramStatus)
  {
    this(paramStatus, Collections.EMPTY_LIST);
  }
  
  public AccountNameCheckResponse(Status paramStatus, String paramString, CaptchaChallenge paramCaptchaChallenge, List<String> paramList)
  {
    this.version = 1;
    this.ot = ((Status)at.f(paramStatus)).getWire();
    this.ov = paramString;
    this.ow = paramCaptchaChallenge;
    this.ou = Collections.unmodifiableList(new ArrayList(paramList));
  }
  
  public AccountNameCheckResponse(Status paramStatus, String paramString, List<String> paramList)
  {
    this(paramStatus, paramString, null, paramList);
  }
  
  public AccountNameCheckResponse(Status paramStatus, List<String> paramList)
  {
    this(paramStatus, null, paramList);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public List<String> getAccountNameSuggestions()
  {
    return this.ou;
  }
  
  public CaptchaChallenge getCaptchaChallenge()
  {
    return this.ow;
  }
  
  public String getDetail()
  {
    return this.ov;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.ot);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountNameCheckResponse
 * JD-Core Version:    0.7.0.1
 */