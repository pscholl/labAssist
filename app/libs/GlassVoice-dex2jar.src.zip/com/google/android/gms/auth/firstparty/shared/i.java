package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class i
  implements Parcelable.Creator<ScopeDetail>
{
  static void a(ScopeDetail paramScopeDetail, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramScopeDetail.version);
    b.a(paramParcel, 2, paramScopeDetail.description, false);
    b.a(paramParcel, 3, paramScopeDetail.ov, false);
    b.a(paramParcel, 4, paramScopeDetail.qp, false);
    b.a(paramParcel, 5, paramScopeDetail.qq, false);
    b.a(paramParcel, 6, paramScopeDetail.pA, false);
    b.a(paramParcel, 7, paramScopeDetail.qr, false);
    b.a(paramParcel, 8, paramScopeDetail.friendPickerData, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public ScopeDetail T(Parcel paramParcel)
  {
    FACLData localFACLData = null;
    int i = a.Y(paramParcel);
    int j = 0;
    ArrayList localArrayList = new ArrayList();
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    String str5 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str5 = a.l(paramParcel, k);
        break;
      case 3: 
        str4 = a.l(paramParcel, k);
        break;
      case 4: 
        str3 = a.l(paramParcel, k);
        break;
      case 5: 
        str2 = a.l(paramParcel, k);
        break;
      case 6: 
        str1 = a.l(paramParcel, k);
        break;
      case 7: 
        localArrayList = a.x(paramParcel, k);
        break;
      case 8: 
        localFACLData = (FACLData)a.a(paramParcel, k, FACLData.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new ScopeDetail(j, str5, str4, str3, str2, str1, localArrayList, localFACLData);
  }
  
  public ScopeDetail[] Y(int paramInt)
  {
    return new ScopeDetail[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.i
 * JD-Core Version:    0.7.0.1
 */