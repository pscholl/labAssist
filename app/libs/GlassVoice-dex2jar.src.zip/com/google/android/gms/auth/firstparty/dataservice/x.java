package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.auth.firstparty.shared.FACLConfig;
import com.google.android.gms.auth.firstparty.shared.PACLConfig;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class x
  implements Parcelable.Creator<TokenRequest>
{
  static void a(TokenRequest paramTokenRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramTokenRequest.version);
    b.a(paramParcel, 2, paramTokenRequest.pA, false);
    b.a(paramParcel, 3, paramTokenRequest.accountName, false);
    b.a(paramParcel, 4, paramTokenRequest.pj, false);
    b.a(paramParcel, 5, paramTokenRequest.pB, paramInt, false);
    b.a(paramParcel, 6, paramTokenRequest.pC, paramInt, false);
    b.a(paramParcel, 7, paramTokenRequest.po);
    b.a(paramParcel, 8, paramTokenRequest.oK);
    b.a(paramParcel, 9, paramTokenRequest.pD, false);
    b.a(paramParcel, 10, paramTokenRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 11, paramTokenRequest.os, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public TokenRequest C(Parcel paramParcel)
  {
    boolean bool1 = false;
    CaptchaSolution localCaptchaSolution = null;
    int i = a.Y(paramParcel);
    Bundle localBundle = new Bundle();
    String str1 = "com.google.android.gms.auth.firstparty.shared.Consent.UNKNOWN.toString()";
    AppDescription localAppDescription = null;
    boolean bool2 = false;
    PACLConfig localPACLConfig = null;
    FACLConfig localFACLConfig = null;
    String str2 = null;
    String str3 = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str3 = a.l(paramParcel, k);
        break;
      case 3: 
        str2 = a.l(paramParcel, k);
        break;
      case 4: 
        localBundle = a.n(paramParcel, k);
        break;
      case 5: 
        localFACLConfig = (FACLConfig)a.a(paramParcel, k, FACLConfig.CREATOR);
        break;
      case 6: 
        localPACLConfig = (PACLConfig)a.a(paramParcel, k, PACLConfig.CREATOR);
        break;
      case 7: 
        bool2 = a.c(paramParcel, k);
        break;
      case 8: 
        bool1 = a.c(paramParcel, k);
        break;
      case 9: 
        str1 = a.l(paramParcel, k);
        break;
      case 10: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
        break;
      case 11: 
        localCaptchaSolution = (CaptchaSolution)a.a(paramParcel, k, CaptchaSolution.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new TokenRequest(j, str3, str2, localBundle, localFACLConfig, localPACLConfig, bool2, bool1, str1, localAppDescription, localCaptchaSolution);
  }
  
  public TokenRequest[] H(int paramInt)
  {
    return new TokenRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.x
 * JD-Core Version:    0.7.0.1
 */