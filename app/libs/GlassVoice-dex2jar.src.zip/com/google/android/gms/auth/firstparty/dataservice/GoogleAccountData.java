package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GoogleAccountData
  implements SafeParcelable
{
  public static final q CREATOR = new q();
  String accountName;
  boolean oQ;
  public List<String> services;
  final int version;
  
  GoogleAccountData(int paramInt, String paramString, boolean paramBoolean, List<String> paramList)
  {
    this.version = paramInt;
    this.accountName = paramString;
    this.oQ = paramBoolean;
    this.services = paramList;
  }
  
  public GoogleAccountData(String paramString, boolean paramBoolean, List<String> paramList)
  {
    this.version = 1;
    this.accountName = paramString;
    this.oQ = paramBoolean;
    if (paramList == null) {}
    for (List localList = Collections.EMPTY_LIST;; localList = Collections.unmodifiableList(new ArrayList(paramList)))
    {
      this.services = localList;
      return;
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public List<String> getServices()
  {
    return this.services;
  }
  
  public boolean isBrowserFlowRequired()
  {
    return this.oQ;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    q.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.GoogleAccountData
 * JD-Core Version:    0.7.0.1
 */