package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class CheckRealNameResponse
  implements SafeParcelable
{
  public static final m CREATOR = new m();
  String ot;
  final int version;
  
  CheckRealNameResponse(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.ot = paramString;
  }
  
  public CheckRealNameResponse(Status paramStatus)
  {
    this.version = 1;
    this.ot = ((Status)at.f(paramStatus)).getWire();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.ot);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    m.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.CheckRealNameResponse
 * JD-Core Version:    0.7.0.1
 */