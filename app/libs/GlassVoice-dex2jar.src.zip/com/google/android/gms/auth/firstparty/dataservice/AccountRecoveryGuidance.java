package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class AccountRecoveryGuidance
  implements SafeParcelable
{
  public static final e CREATOR = new e();
  public final String accountName;
  public final boolean isRecoveryInfoNeeded;
  public final boolean isRecoveryInterstitialSuggested;
  public final boolean isRecoveryUpdateAllowed;
  final int version;
  
  AccountRecoveryGuidance(int paramInt, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    this.version = paramInt;
    this.accountName = paramString;
    this.isRecoveryInfoNeeded = paramBoolean1;
    this.isRecoveryInterstitialSuggested = paramBoolean2;
    this.isRecoveryUpdateAllowed = paramBoolean3;
  }
  
  public AccountRecoveryGuidance(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    this(0, at.C(paramString), paramBoolean1, paramBoolean2, paramBoolean3);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    e.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRecoveryGuidance
 * JD-Core Version:    0.7.0.1
 */