package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class WebSetupConfigRequest
  implements SafeParcelable
{
  public static final ab CREATOR = new ab();
  public final AppDescription callingAppDescription;
  final int version;
  
  WebSetupConfigRequest(int paramInt, AppDescription paramAppDescription)
  {
    this.version = paramInt;
    this.callingAppDescription = ((AppDescription)at.f(paramAppDescription));
  }
  
  public WebSetupConfigRequest(AppDescription paramAppDescription)
  {
    this(1, paramAppDescription);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    ab.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.WebSetupConfigRequest
 * JD-Core Version:    0.7.0.1
 */