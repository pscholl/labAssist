package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class l
  implements Parcelable.Creator<CheckRealNameRequest>
{
  static void a(CheckRealNameRequest paramCheckRealNameRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramCheckRealNameRequest.version);
    b.a(paramParcel, 2, paramCheckRealNameRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 3, paramCheckRealNameRequest.oN, false);
    b.a(paramParcel, 4, paramCheckRealNameRequest.oO, false);
    b.C(paramParcel, i);
  }
  
  public CheckRealNameRequest r(Parcel paramParcel)
  {
    Object localObject1 = null;
    int i = a.Y(paramParcel);
    int j = 0;
    Object localObject2 = null;
    Object localObject3 = null;
    if (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      Object localObject4;
      Object localObject5;
      Object localObject6;
      int m;
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        localObject4 = localObject1;
        localObject5 = localObject2;
        localObject6 = localObject3;
        m = j;
      }
      for (;;)
      {
        j = m;
        localObject3 = localObject6;
        localObject2 = localObject5;
        localObject1 = localObject4;
        break;
        int n = a.f(paramParcel, k);
        Object localObject9 = localObject1;
        localObject5 = localObject2;
        localObject6 = localObject3;
        m = n;
        localObject4 = localObject9;
        continue;
        AppDescription localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
        m = j;
        Object localObject8 = localObject2;
        localObject6 = localAppDescription;
        localObject4 = localObject1;
        localObject5 = localObject8;
        continue;
        String str = a.l(paramParcel, k);
        localObject6 = localObject3;
        m = j;
        Object localObject7 = localObject1;
        localObject5 = str;
        localObject4 = localObject7;
        continue;
        localObject4 = a.l(paramParcel, k);
        localObject5 = localObject2;
        localObject6 = localObject3;
        m = j;
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new CheckRealNameRequest(j, localObject3, localObject2, localObject1);
  }
  
  public CheckRealNameRequest[] w(int paramInt)
  {
    return new CheckRealNameRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.l
 * JD-Core Version:    0.7.0.1
 */