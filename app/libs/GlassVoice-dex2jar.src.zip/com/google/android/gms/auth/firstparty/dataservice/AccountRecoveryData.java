package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.Country;
import com.google.android.gms.auth.RecoveryResponse;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AccountRecoveryData
  implements RecoveryResponse, SafeParcelable
{
  public static final int ACTION_NONE = 3;
  public static final int ACTION_REQUEST_RECOVERY_INFO = 1;
  public static final int ACTION_VERIFY_RECOVERY_INFO = 2;
  public static final c CREATOR = new c();
  public static final int DETAIL_EMAIL_AND_PHONE = 1003;
  public static final int DETAIL_EMAIL_ONLY = 1001;
  public static final int DETAIL_PHONE_ONLY = 1002;
  public final String accountName;
  public final String action;
  public final String allowedRecoveryOption;
  public final List<Country> countries;
  public final String defaultCountryCode;
  public final String error;
  public final AccountRecoveryGuidance guidance;
  public final String phoneNumber;
  public final String secondaryEmail;
  public final int version;
  
  AccountRecoveryData(int paramInt, AccountRecoveryGuidance paramAccountRecoveryGuidance, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, List<Country> paramList, String paramString6, String paramString7)
  {
    this.version = paramInt;
    this.guidance = paramAccountRecoveryGuidance;
    this.action = paramString1;
    this.allowedRecoveryOption = paramString2;
    this.accountName = paramString3;
    this.secondaryEmail = paramString4;
    this.phoneNumber = paramString5;
    if (paramList == null) {}
    for (List localList = Collections.EMPTY_LIST;; localList = Collections.unmodifiableList(paramList))
    {
      this.countries = localList;
      this.defaultCountryCode = paramString6;
      this.error = paramString7;
      return;
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    c.a(this, paramParcel, paramInt);
  }
  
  public static class Builder
  {
    private String oA;
    private String oB;
    private String oC;
    private List<Country> oD;
    private String oE;
    private String oF;
    private AccountRecoveryGuidance ox;
    private String oy;
    private String oz;
    
    public AccountRecoveryData build()
    {
      return new AccountRecoveryData(0, this.ox, this.oy, this.oz, this.oA, this.oB, this.oC, this.oD, this.oE, this.oF);
    }
    
    public Builder setAccountName(String paramString)
    {
      this.oA = paramString;
      return this;
    }
    
    public Builder setAccountRecoveryGuidance(AccountRecoveryGuidance paramAccountRecoveryGuidance)
    {
      this.ox = paramAccountRecoveryGuidance;
      return this;
    }
    
    public Builder setAction(String paramString)
    {
      this.oy = paramString;
      return this;
    }
    
    public Builder setAllowedRecoveryOption(String paramString)
    {
      this.oz = paramString;
      return this;
    }
    
    public Builder setCountryList(List<Country> paramList)
    {
      this.oD = Collections.unmodifiableList(new ArrayList(paramList));
      return this;
    }
    
    public Builder setDefaultCountryCode(String paramString)
    {
      this.oE = paramString;
      return this;
    }
    
    public Builder setError(String paramString)
    {
      this.oF = paramString;
      return this;
    }
    
    public Builder setPhoneNumber(String paramString)
    {
      this.oC = paramString;
      return this;
    }
    
    public Builder setSecondaryEmail(String paramString)
    {
      this.oB = paramString;
      return this;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRecoveryData
 * JD-Core Version:    0.7.0.1
 */