package com.google.android.gms.auth;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class Country
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  public String mCode;
  public String mName;
  final int oj;
  
  public Country()
  {
    this.oj = 1;
  }
  
  Country(int paramInt, String paramString1, String paramString2)
  {
    this.oj = paramInt;
    this.mName = paramString1;
    this.mCode = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public int getVersionCode()
  {
    return this.oj;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.Country
 * JD-Core Version:    0.7.0.1
 */