package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class AppDescription
  implements SafeParcelable
{
  public static final b CREATOR = new b();
  protected static final String TAG = "GLSSession";
  private static final String oG = "[" + AppDescription.class.getSimpleName() + "]";
  boolean oL;
  private final String pZ = "[" + getClass().getSimpleName() + "] %s - %s: %s";
  int qa;
  String qb;
  String qc;
  String qd;
  final int version;
  
  AppDescription(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    this.version = paramInt1;
    this.qb = at.b(paramString1, oG + " sessionId cannot be null or empty!");
    this.qc = at.b(paramString2, oG + " sessionSig cannot be null or empty!");
    this.qd = at.b(paramString3, oG + " callingPkg cannot be null or empty!");
    if (paramInt2 != 0) {}
    for (boolean bool = true;; bool = false)
    {
      at.b(bool, "Invalid callingUid! Cannot be 0!");
      this.qa = paramInt2;
      this.oL = paramBoolean;
      return;
    }
  }
  
  public AppDescription(String paramString1, int paramInt, String paramString2, String paramString3)
  {
    this(1, paramInt, paramString2, paramString3, paramString1, false);
    if (Log.isLoggable("GLSSession", 2)) {
      Log.v("GLSSession", "New " + getClass().getSimpleName() + " (" + "sessiondId: " + this.qb + ", " + "sessiondSig: " + this.qc + ", " + "callingPkg: " + this.qd + ", " + "callingUid: " + this.qa + ", ");
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  @Deprecated
  public String getCallingPackage()
  {
    return this.qd;
  }
  
  @Deprecated
  public int getCallingUid()
  {
    return this.qa;
  }
  
  public String getPackageName()
  {
    return this.qd;
  }
  
  public String getSessionId()
  {
    return this.qb;
  }
  
  public String getSessionSignature()
  {
    return this.qc;
  }
  
  public int getUid()
  {
    return this.qa;
  }
  
  public boolean isSetupWizardInProgress()
  {
    return this.oL;
  }
  
  protected void log(String paramString, int paramInt)
  {
    if (Log.isLoggable("GLSSession", 2))
    {
      String str = this.pZ;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = this.qb;
      arrayOfObject[1] = paramString;
      arrayOfObject[2] = Integer.valueOf(paramInt);
      Log.v("GLSSession", String.format(str, arrayOfObject));
    }
  }
  
  protected void log(String paramString1, String paramString2)
  {
    String str1;
    if (Log.isLoggable("GLSSession", 2))
    {
      if (paramString2 != null) {
        break label60;
      }
      str1 = "<NULL>";
    }
    for (;;)
    {
      String str2 = this.pZ;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = this.qb;
      arrayOfObject[1] = paramString1;
      arrayOfObject[2] = str1;
      Log.v("GLSSession", String.format(str2, arrayOfObject));
      return;
      label60:
      if (paramString2.isEmpty()) {
        str1 = "<EMPTY>";
      } else {
        str1 = "<MEANINFGUL>";
      }
    }
  }
  
  protected void log(String paramString, boolean paramBoolean)
  {
    if (Log.isLoggable("GLSSession", 2))
    {
      String str = this.pZ;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = this.qb;
      arrayOfObject[1] = paramString;
      arrayOfObject[2] = Boolean.valueOf(paramBoolean);
      Log.v("GLSSession", String.format(str, arrayOfObject));
    }
  }
  
  public AppDescription setSetupWizardInProgress(boolean paramBoolean)
  {
    this.oL = paramBoolean;
    return this;
  }
  
  public String toString()
  {
    return getClass().getSimpleName() + "<" + this.qd + ", " + this.qa + ">";
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.AppDescription
 * JD-Core Version:    0.7.0.1
 */