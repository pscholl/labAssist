package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class CaptchaSolution
  implements SafeParcelable
{
  public static final d CREATOR = new d();
  String oP;
  String qf;
  final int version;
  
  CaptchaSolution(int paramInt, String paramString1, String paramString2)
  {
    this.version = paramInt;
    this.oP = paramString1;
    this.qf = paramString2;
  }
  
  public CaptchaSolution(String paramString1, String paramString2)
  {
    this.version = 1;
    this.oP = paramString1;
    this.qf = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAnswer()
  {
    return this.qf;
  }
  
  public String getToken()
  {
    return this.oP;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    d.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.CaptchaSolution
 * JD-Core Version:    0.7.0.1
 */