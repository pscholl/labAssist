package com.google.android.gms.auth;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class RecoveryWriteResponse
  implements SafeParcelable
{
  public static final e CREATOR = new e();
  public String mErrorCode;
  final int oj;
  
  public RecoveryWriteResponse()
  {
    this.oj = 1;
  }
  
  RecoveryWriteResponse(int paramInt, String paramString)
  {
    this.oj = paramInt;
    this.mErrorCode = paramString;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public int getVersionCode()
  {
    return this.oj;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    e.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.RecoveryWriteResponse
 * JD-Core Version:    0.7.0.1
 */