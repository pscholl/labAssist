package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.FACLConfig;
import com.google.android.gms.auth.firstparty.shared.PACLConfig;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class d
  implements Parcelable.Creator<TokenWorkflowRequest>
{
  static void a(TokenWorkflowRequest paramTokenWorkflowRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramTokenWorkflowRequest.version);
    b.a(paramParcel, 2, paramTokenWorkflowRequest.pA, false);
    b.a(paramParcel, 3, paramTokenWorkflowRequest.accountName, false);
    b.a(paramParcel, 4, paramTokenWorkflowRequest.pj, false);
    b.a(paramParcel, 5, paramTokenWorkflowRequest.pB, paramInt, false);
    b.a(paramParcel, 6, paramTokenWorkflowRequest.pC, paramInt, false);
    b.a(paramParcel, 7, paramTokenWorkflowRequest.pS);
    b.a(paramParcel, 8, paramTokenWorkflowRequest.callingAppDescription, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public TokenWorkflowRequest J(Parcel paramParcel)
  {
    boolean bool = false;
    AppDescription localAppDescription = null;
    int i = a.Y(paramParcel);
    Bundle localBundle = new Bundle();
    PACLConfig localPACLConfig = null;
    FACLConfig localFACLConfig = null;
    String str1 = null;
    String str2 = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str2 = a.l(paramParcel, k);
        break;
      case 3: 
        str1 = a.l(paramParcel, k);
        break;
      case 4: 
        localBundle = a.n(paramParcel, k);
        break;
      case 5: 
        localFACLConfig = (FACLConfig)a.a(paramParcel, k, FACLConfig.CREATOR);
        break;
      case 6: 
        localPACLConfig = (PACLConfig)a.a(paramParcel, k, PACLConfig.CREATOR);
        break;
      case 7: 
        bool = a.c(paramParcel, k);
        break;
      case 8: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new TokenWorkflowRequest(j, str2, str1, localBundle, localFACLConfig, localPACLConfig, bool, localAppDescription);
  }
  
  public TokenWorkflowRequest[] O(int paramInt)
  {
    return new TokenWorkflowRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.d
 * JD-Core Version:    0.7.0.1
 */