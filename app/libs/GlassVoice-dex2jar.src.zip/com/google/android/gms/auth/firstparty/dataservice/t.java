package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class t
  implements Parcelable.Creator<GplusInfoResponse>
{
  static void a(GplusInfoResponse paramGplusInfoResponse, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramGplusInfoResponse.version);
    b.a(paramParcel, 2, paramGplusInfoResponse.pq);
    b.a(paramParcel, 3, paramGplusInfoResponse.oN, false);
    b.a(paramParcel, 4, paramGplusInfoResponse.oO, false);
    b.a(paramParcel, 5, paramGplusInfoResponse.pr, false);
    b.a(paramParcel, 6, paramGplusInfoResponse.ps);
    b.a(paramParcel, 7, paramGplusInfoResponse.pt);
    b.a(paramParcel, 8, paramGplusInfoResponse.pu, false);
    b.a(paramParcel, 9, paramGplusInfoResponse.pp, false);
    b.a(paramParcel, 10, paramGplusInfoResponse.pv, false);
    b.C(paramParcel, i);
  }
  
  public GplusInfoResponse[] E(int paramInt)
  {
    return new GplusInfoResponse[paramInt];
  }
  
  public GplusInfoResponse z(Parcel paramParcel)
  {
    boolean bool1 = false;
    String str1 = null;
    int i = a.Y(paramParcel);
    String str2 = null;
    String str3 = null;
    boolean bool2 = false;
    String str4 = null;
    String str5 = null;
    String str6 = null;
    boolean bool3 = false;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        bool3 = a.c(paramParcel, k);
        break;
      case 3: 
        str6 = a.l(paramParcel, k);
        break;
      case 4: 
        str5 = a.l(paramParcel, k);
        break;
      case 5: 
        str4 = a.l(paramParcel, k);
        break;
      case 6: 
        bool2 = a.c(paramParcel, k);
        break;
      case 7: 
        bool1 = a.c(paramParcel, k);
        break;
      case 8: 
        str3 = a.l(paramParcel, k);
        break;
      case 9: 
        str2 = a.l(paramParcel, k);
        break;
      case 10: 
        str1 = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new GplusInfoResponse(j, bool3, str6, str5, str4, bool2, bool1, str3, str2, str1);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.t
 * JD-Core Version:    0.7.0.1
 */