package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class FACLConfig
  implements SafeParcelable
{
  public static final e CREATOR = new e();
  private static final String oG = "[" + FACLConfig.class.getSimpleName() + "]";
  boolean qg;
  String qh;
  final int version;
  
  FACLConfig(int paramInt, boolean paramBoolean, String paramString)
  {
    this.version = paramInt;
    this.qg = paramBoolean;
    this.qh = paramString;
  }
  
  public FACLConfig(boolean paramBoolean, String paramString)
  {
    this.version = 1;
    this.qg = paramBoolean;
    if (paramBoolean)
    {
      this.qh = "";
      return;
    }
    this.qh = paramString;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getVisibleSocialGraph()
  {
    return this.qh;
  }
  
  public boolean isAllSocialGraphVisible()
  {
    return this.qg;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    e.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.FACLConfig
 * JD-Core Version:    0.7.0.1
 */