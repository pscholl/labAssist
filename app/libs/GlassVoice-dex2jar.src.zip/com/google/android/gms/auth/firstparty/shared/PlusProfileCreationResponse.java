package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class PlusProfileCreationResponse
  implements SafeParcelable
{
  public static final h CREATOR = new h();
  String qo;
  final int version;
  
  PlusProfileCreationResponse(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.qo = paramString;
  }
  
  public PlusProfileCreationResponse(Status paramStatus)
  {
    this.version = 1;
    this.qo = ((Status)at.f(paramStatus)).getWire();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.qo);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    h.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.PlusProfileCreationResponse
 * JD-Core Version:    0.7.0.1
 */