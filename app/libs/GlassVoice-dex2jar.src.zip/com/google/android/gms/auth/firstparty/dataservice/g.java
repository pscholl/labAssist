package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class g
  implements Parcelable.Creator<AccountRecoveryUpdateRequest>
{
  static void a(AccountRecoveryUpdateRequest paramAccountRecoveryUpdateRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountRecoveryUpdateRequest.version);
    b.a(paramParcel, 2, paramAccountRecoveryUpdateRequest.accountName, false);
    b.a(paramParcel, 3, paramAccountRecoveryUpdateRequest.secondaryEmail, false);
    b.a(paramParcel, 4, paramAccountRecoveryUpdateRequest.phoneNumber, false);
    b.a(paramParcel, 5, paramAccountRecoveryUpdateRequest.phoneCountryCode, false);
    b.a(paramParcel, 6, paramAccountRecoveryUpdateRequest.isBroadUse);
    b.a(paramParcel, 7, paramAccountRecoveryUpdateRequest.callingAppDescription, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public AccountRecoveryUpdateRequest m(Parcel paramParcel)
  {
    boolean bool = false;
    AppDescription localAppDescription = null;
    int i = a.Y(paramParcel);
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str4 = a.l(paramParcel, k);
        break;
      case 3: 
        str3 = a.l(paramParcel, k);
        break;
      case 4: 
        str2 = a.l(paramParcel, k);
        break;
      case 5: 
        str1 = a.l(paramParcel, k);
        break;
      case 6: 
        bool = a.c(paramParcel, k);
        break;
      case 7: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountRecoveryUpdateRequest(j, str4, str3, str2, str1, bool, localAppDescription);
  }
  
  public AccountRecoveryUpdateRequest[] r(int paramInt)
  {
    return new AccountRecoveryUpdateRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.g
 * JD-Core Version:    0.7.0.1
 */