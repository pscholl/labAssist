package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.RecoveryResponse;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountRecoveryUpdateResult
  implements RecoveryResponse, SafeParcelable
{
  public static final h CREATOR = new h();
  public final String error;
  final int version;
  
  AccountRecoveryUpdateResult(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.error = paramString;
  }
  
  public AccountRecoveryUpdateResult(String paramString)
  {
    this(0, paramString);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    h.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRecoveryUpdateResult
 * JD-Core Version:    0.7.0.1
 */