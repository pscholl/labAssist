package com.google.android.gms.auth.firstparty.delegate;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.auth.firstparty.shared.BlockingServiceClient;
import com.google.android.gms.auth.firstparty.shared.BlockingServiceClient.Call;

public class AccountSetupWorkflowServiceClient
  extends BlockingServiceClient
{
  public AccountSetupWorkflowServiceClient(Context paramContext)
  {
    super(paramContext);
  }
  
  public PendingIntent getAccountSetupWorkflowIntent(final SetupAccountWorkflowRequest paramSetupAccountWorkflowRequest)
  {
    (PendingIntent)exec(new BlockingServiceClient.Call()
    {
      public PendingIntent j(IBinder paramAnonymousIBinder)
        throws RemoteException
      {
        return b.a.k(paramAnonymousIBinder).getAccountSetupWorkflowIntent(paramSetupAccountWorkflowRequest);
      }
    });
  }
  
  protected Intent getServiceIntent()
  {
    return new Intent().setAction("com.google.android.gms.auth.setup.workflow.SETUP_WORKFLOW").addCategory("android.intent.category.DEFAULT");
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.AccountSetupWorkflowServiceClient
 * JD-Core Version:    0.7.0.1
 */