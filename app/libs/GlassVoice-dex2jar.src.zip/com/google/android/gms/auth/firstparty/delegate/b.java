package com.google.android.gms.auth.firstparty.delegate;

import android.app.PendingIntent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface b
  extends IInterface
{
  public abstract PendingIntent getAccountSetupWorkflowIntent(SetupAccountWorkflowRequest paramSetupAccountWorkflowRequest)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements b
  {
    public static b k(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.auth.firstparty.delegate.IAccountSetupWorkflowService");
      if ((localIInterface != null) && ((localIInterface instanceof b))) {
        return (b)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.auth.firstparty.delegate.IAccountSetupWorkflowService");
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.delegate.IAccountSetupWorkflowService");
      SetupAccountWorkflowRequest localSetupAccountWorkflowRequest;
      if (paramParcel1.readInt() != 0)
      {
        localSetupAccountWorkflowRequest = SetupAccountWorkflowRequest.CREATOR.I(paramParcel1);
        PendingIntent localPendingIntent = getAccountSetupWorkflowIntent(localSetupAccountWorkflowRequest);
        paramParcel2.writeNoException();
        if (localPendingIntent == null) {
          break label105;
        }
        paramParcel2.writeInt(1);
        localPendingIntent.writeToParcel(paramParcel2, 1);
      }
      for (;;)
      {
        return true;
        localSetupAccountWorkflowRequest = null;
        break;
        label105:
        paramParcel2.writeInt(0);
      }
    }
    
    private static class a
      implements b
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public PendingIntent getAccountSetupWorkflowIntent(SetupAccountWorkflowRequest paramSetupAccountWorkflowRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.delegate.IAccountSetupWorkflowService");
            if (paramSetupAccountWorkflowRequest != null)
            {
              localParcel1.writeInt(1);
              paramSetupAccountWorkflowRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(1, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(localParcel2);
                return localPendingIntent;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PendingIntent localPendingIntent = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.b
 * JD-Core Version:    0.7.0.1
 */