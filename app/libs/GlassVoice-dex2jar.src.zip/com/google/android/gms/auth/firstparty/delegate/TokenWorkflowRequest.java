package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.FACLConfig;
import com.google.android.gms.auth.firstparty.shared.PACLConfig;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class TokenWorkflowRequest
  implements SafeParcelable
{
  public static final d CREATOR = new d();
  volatile String accountName;
  volatile AppDescription callingAppDescription;
  volatile String pA;
  volatile FACLConfig pB;
  volatile PACLConfig pC;
  volatile boolean pS;
  volatile Bundle pj;
  final int version;
  
  public TokenWorkflowRequest()
  {
    this.version = 1;
    this.pj = new Bundle();
  }
  
  TokenWorkflowRequest(int paramInt, String paramString1, String paramString2, Bundle paramBundle, FACLConfig paramFACLConfig, PACLConfig paramPACLConfig, boolean paramBoolean, AppDescription paramAppDescription)
  {
    this.version = paramInt;
    this.pA = paramString1;
    this.accountName = paramString2;
    this.pj = paramBundle;
    this.pB = paramFACLConfig;
    this.pC = paramPACLConfig;
    this.pS = paramBoolean;
    this.callingAppDescription = paramAppDescription;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public FACLConfig getFaclData()
  {
    return this.pB;
  }
  
  public Bundle getOptions()
  {
    return new Bundle(this.pj);
  }
  
  public PACLConfig getPaclData()
  {
    return this.pC;
  }
  
  public String getService()
  {
    return this.pA;
  }
  
  public boolean isSuppressingProgressUx()
  {
    return this.pS;
  }
  
  public TokenWorkflowRequest setAccountName(String paramString)
  {
    this.accountName = paramString;
    return this;
  }
  
  public TokenWorkflowRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public TokenWorkflowRequest setFaclData(FACLConfig paramFACLConfig)
  {
    this.pB = paramFACLConfig;
    return this;
  }
  
  public TokenWorkflowRequest setOptions(Bundle paramBundle)
  {
    this.pj.clear();
    this.pj.putAll(paramBundle);
    return this;
  }
  
  public TokenWorkflowRequest setPaclData(PACLConfig paramPACLConfig)
  {
    this.pC = paramPACLConfig;
    return this;
  }
  
  public TokenWorkflowRequest setService(String paramString)
  {
    this.pA = paramString;
    return this;
  }
  
  public TokenWorkflowRequest setSuppressingProgressUx(boolean paramBoolean)
  {
    this.pS = paramBoolean;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    d.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.TokenWorkflowRequest
 * JD-Core Version:    0.7.0.1
 */