package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AccountCredentials;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class GoogleAccountSetupRequest
  implements SafeParcelable
{
  public static final r CREATOR = new r();
  AppDescription callingAppDescription;
  boolean oK;
  boolean oL;
  AccountCredentials oM;
  String oN;
  String oO;
  CaptchaSolution os;
  String phoneCountryCode;
  String phoneNumber;
  Bundle pj;
  boolean pk;
  boolean pl;
  boolean pm;
  String pn;
  boolean po;
  String pp;
  String secondaryEmail;
  final int version;
  
  public GoogleAccountSetupRequest()
  {
    this.version = 1;
    this.pj = new Bundle();
  }
  
  GoogleAccountSetupRequest(int paramInt, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, String paramString5, AppDescription paramAppDescription, AccountCredentials paramAccountCredentials, CaptchaSolution paramCaptchaSolution, String paramString6, String paramString7)
  {
    this.version = paramInt;
    this.pj = paramBundle;
    this.pk = paramBoolean1;
    this.pl = paramBoolean2;
    this.pm = paramBoolean3;
    this.oN = paramString1;
    this.oO = paramString2;
    this.secondaryEmail = paramString3;
    this.pn = paramString4;
    this.oK = paramBoolean4;
    this.po = paramBoolean5;
    this.oL = paramBoolean6;
    this.pp = paramString5;
    this.callingAppDescription = paramAppDescription;
    this.oM = paramAccountCredentials;
    this.os = paramCaptchaSolution;
    this.phoneNumber = paramString6;
    this.phoneCountryCode = paramString7;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public AccountCredentials getAccountCredentials()
  {
    return this.oM;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public String getFirstName()
  {
    return this.oN;
  }
  
  public String getGender()
  {
    return this.pn;
  }
  
  public String getLastName()
  {
    return this.oO;
  }
  
  public Bundle getOptions()
  {
    return new Bundle(this.pj);
  }
  
  public String getPhoneCountryCode()
  {
    return this.phoneCountryCode;
  }
  
  public String getPhoneNumber()
  {
    return this.phoneNumber;
  }
  
  public String getRopRevision()
  {
    return this.pp;
  }
  
  public String getSecondaryEmail()
  {
    return this.secondaryEmail;
  }
  
  public boolean isAddingAccount()
  {
    return this.po;
  }
  
  public boolean isAgreedToMobileTos()
  {
    return this.pm;
  }
  
  public boolean isAgreedToPersonalizedContent()
  {
    return this.pl;
  }
  
  public boolean isAgreedToWebHistory()
  {
    return this.pk;
  }
  
  public boolean isCreatingAccount()
  {
    return this.oK;
  }
  
  public boolean isSetupWizardInProgress()
  {
    return this.oL;
  }
  
  public GoogleAccountSetupRequest setAccountCredentials(AccountCredentials paramAccountCredentials)
  {
    this.oM = paramAccountCredentials;
    return this;
  }
  
  public GoogleAccountSetupRequest setAddingAccount(boolean paramBoolean)
  {
    this.po = paramBoolean;
    return this;
  }
  
  public GoogleAccountSetupRequest setAgreedToMobileTos(boolean paramBoolean)
  {
    this.pm = paramBoolean;
    return this;
  }
  
  public GoogleAccountSetupRequest setAgreedToPersonalizedContent(boolean paramBoolean)
  {
    this.pl = paramBoolean;
    return this;
  }
  
  public GoogleAccountSetupRequest setAgreedToWebHistory(boolean paramBoolean)
  {
    this.pk = paramBoolean;
    return this;
  }
  
  public GoogleAccountSetupRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public GoogleAccountSetupRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  public GoogleAccountSetupRequest setCreatingAccount(boolean paramBoolean)
  {
    this.oK = paramBoolean;
    return this;
  }
  
  public GoogleAccountSetupRequest setFirstName(String paramString)
  {
    this.oN = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setGender(String paramString)
  {
    this.pn = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setLastName(String paramString)
  {
    this.oO = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setOptions(Bundle paramBundle)
  {
    this.pj.clear();
    this.pj.putAll(paramBundle);
    return this;
  }
  
  public GoogleAccountSetupRequest setPhoneCountryCode(String paramString)
  {
    this.phoneCountryCode = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setPhoneNumber(String paramString)
  {
    this.phoneNumber = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setRopRevision(String paramString)
  {
    this.pp = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setSecondaryEmail(String paramString)
  {
    this.secondaryEmail = paramString;
    return this;
  }
  
  public GoogleAccountSetupRequest setSetupWizardInProgress(boolean paramBoolean)
  {
    this.oL = paramBoolean;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    r.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.GoogleAccountSetupRequest
 * JD-Core Version:    0.7.0.1
 */