package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class PasswordCheckResponse
  implements SafeParcelable
{
  public static final w CREATOR = new w();
  String ov;
  String py;
  String pz;
  final int version;
  
  PasswordCheckResponse(int paramInt, String paramString1, String paramString2, String paramString3)
  {
    this.version = paramInt;
    this.py = paramString1;
    this.pz = paramString2;
    this.ov = paramString3;
  }
  
  public PasswordCheckResponse(Status paramStatus)
  {
    this(paramStatus, null, null);
  }
  
  public PasswordCheckResponse(Status paramStatus, String paramString1, String paramString2)
  {
    this.version = 1;
    this.py = ((Status)at.f(paramStatus)).getWire();
    this.pz = paramString1;
    this.ov = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getDetail()
  {
    return this.ov;
  }
  
  public String getPasswordStrength()
  {
    return this.pz;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.py);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    w.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.PasswordCheckResponse
 * JD-Core Version:    0.7.0.1
 */