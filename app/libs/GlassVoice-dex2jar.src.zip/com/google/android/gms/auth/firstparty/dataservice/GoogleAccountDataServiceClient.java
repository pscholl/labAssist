package com.google.android.gms.auth.firstparty.dataservice;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.at;
import java.util.Iterator;
import java.util.List;

public class GoogleAccountDataServiceClient
{
  public static final String TAG = "GoogleAccountDataServiceClient";
  private static final String oG = "[" + GoogleAccountDataServiceClient.class.getSimpleName() + "]";
  private final Context mContext;
  
  public GoogleAccountDataServiceClient(Context paramContext)
  {
    this.mContext = ((Context)at.f(paramContext));
  }
  
  /* Error */
  private <R> R a(a<R> parama)
  {
    // Byte code:
    //   0: invokestatic 59	com/google/android/gms/auth/firstparty/dataservice/GoogleAccountDataServiceClient:bi	()Landroid/content/Intent;
    //   3: astore_2
    //   4: aload_0
    //   5: aload_2
    //   6: invokespecial 63	com/google/android/gms/auth/firstparty/dataservice/GoogleAccountDataServiceClient:b	(Landroid/content/Intent;)V
    //   9: new 65	com/google/android/gms/common/a
    //   12: dup
    //   13: invokespecial 66	com/google/android/gms/common/a:<init>	()V
    //   16: astore_3
    //   17: aload_0
    //   18: getfield 49	com/google/android/gms/auth/firstparty/dataservice/GoogleAccountDataServiceClient:mContext	Landroid/content/Context;
    //   21: aload_2
    //   22: aload_3
    //   23: iconst_1
    //   24: invokevirtual 70	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   27: ifeq +82 -> 109
    //   30: aload_1
    //   31: aload_3
    //   32: invokevirtual 74	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   35: invokestatic 80	com/google/android/gms/auth/firstparty/dataservice/u$a:i	(Landroid/os/IBinder;)Lcom/google/android/gms/auth/firstparty/dataservice/u;
    //   38: invokeinterface 85 2 0
    //   43: astore 9
    //   45: aload_0
    //   46: getfield 49	com/google/android/gms/auth/firstparty/dataservice/GoogleAccountDataServiceClient:mContext	Landroid/content/Context;
    //   49: aload_3
    //   50: invokevirtual 89	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   53: aload 9
    //   55: areturn
    //   56: astore 7
    //   58: ldc 8
    //   60: aload 7
    //   62: invokestatic 95	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   65: pop
    //   66: new 97	java/lang/RuntimeException
    //   69: dup
    //   70: aload 7
    //   72: invokespecial 100	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   75: athrow
    //   76: astore 6
    //   78: aload_0
    //   79: getfield 49	com/google/android/gms/auth/firstparty/dataservice/GoogleAccountDataServiceClient:mContext	Landroid/content/Context;
    //   82: aload_3
    //   83: invokevirtual 89	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   86: aload 6
    //   88: athrow
    //   89: astore 4
    //   91: ldc 8
    //   93: aload 4
    //   95: invokestatic 95	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   98: pop
    //   99: new 97	java/lang/RuntimeException
    //   102: dup
    //   103: aload 4
    //   105: invokespecial 100	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   108: athrow
    //   109: aconst_null
    //   110: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	111	0	this	GoogleAccountDataServiceClient
    //   0	111	1	parama	a<R>
    //   3	19	2	localIntent	Intent
    //   16	67	3	locala	com.google.android.gms.common.a
    //   89	15	4	localRemoteException	RemoteException
    //   76	11	6	localObject1	Object
    //   56	15	7	localInterruptedException	java.lang.InterruptedException
    //   43	11	9	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   30	45	56	java/lang/InterruptedException
    //   30	45	76	finally
    //   58	76	76	finally
    //   91	109	76	finally
    //   30	45	89	android/os/RemoteException
  }
  
  private void b(Intent paramIntent)
  {
    PackageManager localPackageManager = this.mContext.getPackageManager();
    Iterator localIterator = this.mContext.getPackageManager().queryIntentServices(paramIntent, 0).iterator();
    while (localIterator.hasNext())
    {
      String str = ((ResolveInfo)localIterator.next()).serviceInfo.packageName;
      if (!GooglePlayServicesUtil.isPackageGoogleSigned(localPackageManager, str)) {
        throw new SecurityException("GoogleAccountDataService appears to have been spoofed by: " + str);
      }
    }
  }
  
  private static Intent bi()
  {
    return new Intent().setPackage("com.google.android.gms").setAction("com.google.android.gms.auth.DATA_PROXY").addCategory("android.intent.category.DEFAULT");
  }
  
  public AccountNameCheckResponse checkAccountName(final AccountNameCheckRequest paramAccountNameCheckRequest)
  {
    (AccountNameCheckResponse)a(new a()
    {
      public AccountNameCheckResponse j(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.checkAccountName(paramAccountNameCheckRequest);
      }
    });
  }
  
  public PasswordCheckResponse checkPassword(final PasswordCheckRequest paramPasswordCheckRequest)
  {
    (PasswordCheckResponse)a(new a()
    {
      public PasswordCheckResponse l(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.checkPassword(paramPasswordCheckRequest);
      }
    });
  }
  
  public CheckRealNameResponse checkRealName(final CheckRealNameRequest paramCheckRealNameRequest)
  {
    (CheckRealNameResponse)a(new a()
    {
      public CheckRealNameResponse m(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.checkRealName(paramCheckRealNameRequest);
      }
    });
  }
  
  public ClearTokenResponse clearToken(final ClearTokenRequest paramClearTokenRequest)
  {
    at.a("ClearTokenRequest cannot be null!", paramClearTokenRequest);
    (ClearTokenResponse)a(new a()
    {
      public ClearTokenResponse o(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.clearToken(paramClearTokenRequest);
      }
    });
  }
  
  public TokenResponse confirmCredentials(final ConfirmCredentialsRequest paramConfirmCredentialsRequest)
  {
    (TokenResponse)a(new a()
    {
      public TokenResponse c(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.confirmCredentials(paramConfirmCredentialsRequest);
      }
    });
  }
  
  public TokenResponse createAccount(final GoogleAccountSetupRequest paramGoogleAccountSetupRequest)
  {
    (TokenResponse)a(new a()
    {
      public TokenResponse c(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.createAccount(paramGoogleAccountSetupRequest);
      }
    });
  }
  
  public TokenResponse createPlusProfile(final GoogleAccountSetupRequest paramGoogleAccountSetupRequest)
  {
    (TokenResponse)a(new a()
    {
      public TokenResponse c(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.createPlusProfile(paramGoogleAccountSetupRequest);
      }
    });
  }
  
  public GoogleAccountData getAccountData(final String paramString)
  {
    (GoogleAccountData)a(new a()
    {
      public GoogleAccountData a(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getAccountData(paramString);
      }
    });
  }
  
  public Bundle getAccountExportData(final String paramString)
  {
    (Bundle)a(new a()
    {
      public Bundle h(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getAccountExportData(paramString);
      }
    });
  }
  
  public AccountRecoveryData getAccountRecoveryCountryInfo()
  {
    (AccountRecoveryData)a(new a()
    {
      public AccountRecoveryData e(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getAccountRecoveryCountryInfo();
      }
    });
  }
  
  public AccountRecoveryData getAccountRecoveryData(final AccountRecoveryDataRequest paramAccountRecoveryDataRequest)
  {
    (AccountRecoveryData)a(new a()
    {
      public AccountRecoveryData e(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getAccountRecoveryData(paramAccountRecoveryDataRequest);
      }
    });
  }
  
  public AccountRecoveryGuidance getAccountRecoveryGuidance(final AccountRecoveryGuidanceRequest paramAccountRecoveryGuidanceRequest)
  {
    (AccountRecoveryGuidance)a(new a()
    {
      public AccountRecoveryGuidance f(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getAccountRecoveryGuidance(paramAccountRecoveryGuidanceRequest);
      }
    });
  }
  
  public GplusInfoResponse getGplusInfo(final GplusInfoRequest paramGplusInfoRequest)
  {
    (GplusInfoResponse)a(new a()
    {
      public GplusInfoResponse n(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getGplusInfo(paramGplusInfoRequest);
      }
    });
  }
  
  public TokenResponse getToken(final TokenRequest paramTokenRequest)
  {
    at.a("TokenRequest cannot be null!", paramTokenRequest);
    (TokenResponse)a(new a()
    {
      public TokenResponse c(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getToken(paramTokenRequest);
      }
    });
  }
  
  public WebSetupConfig getWebSetupConfig(final WebSetupConfigRequest paramWebSetupConfigRequest)
  {
    at.a(paramWebSetupConfigRequest, oG + " WebSetupConfigRequest cannot be null.");
    (WebSetupConfig)a(new a()
    {
      public WebSetupConfig k(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.getWebSetupConfig(paramWebSetupConfigRequest);
      }
    });
  }
  
  public boolean installAccountFromExportData(final String paramString, final Bundle paramBundle)
  {
    ((Boolean)a(new a()
    {
      public Boolean i(u paramAnonymousu)
        throws RemoteException
      {
        return Boolean.valueOf(paramAnonymousu.installAccountFromExportData(paramString, paramBundle));
      }
    })).booleanValue();
  }
  
  public AccountRemovalResponse removeAccount(final AccountRemovalRequest paramAccountRemovalRequest)
  {
    (AccountRemovalResponse)a(new a()
    {
      public AccountRemovalResponse d(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.removeAccount(paramAccountRemovalRequest);
      }
    });
  }
  
  public TokenResponse signIn(final AccountSignInRequest paramAccountSignInRequest)
  {
    (TokenResponse)a(new a()
    {
      public TokenResponse c(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.signIn(paramAccountSignInRequest);
      }
    });
  }
  
  public AccountRecoveryUpdateResult updateAccountRecoveryData(final AccountRecoveryUpdateRequest paramAccountRecoveryUpdateRequest)
  {
    (AccountRecoveryUpdateResult)a(new a()
    {
      public AccountRecoveryUpdateResult g(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.updateAccountRecoveryData(paramAccountRecoveryUpdateRequest);
      }
    });
  }
  
  public TokenResponse updateCredentials(final UpdateCredentialsRequest paramUpdateCredentialsRequest)
  {
    (TokenResponse)a(new a()
    {
      public TokenResponse c(u paramAnonymousu)
        throws RemoteException
      {
        return paramAnonymousu.updateCredentials(paramUpdateCredentialsRequest);
      }
    });
  }
  
  private static abstract interface a<R>
  {
    public abstract R b(u paramu)
      throws RemoteException;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.GoogleAccountDataServiceClient
 * JD-Core Version:    0.7.0.1
 */