package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ConfirmCredentialsWorkflowRequest
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  String accountName;
  AppDescription callingAppDescription;
  Bundle pj;
  final int version;
  
  public ConfirmCredentialsWorkflowRequest()
  {
    this.version = 1;
    this.pj = new Bundle();
  }
  
  ConfirmCredentialsWorkflowRequest(int paramInt, String paramString, AppDescription paramAppDescription, Bundle paramBundle)
  {
    this.version = paramInt;
    this.accountName = paramString;
    this.callingAppDescription = paramAppDescription;
    this.pj = paramBundle;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public Bundle getOptions()
  {
    return new Bundle(this.pj);
  }
  
  public ConfirmCredentialsWorkflowRequest setAccountName(String paramString)
  {
    this.accountName = paramString;
    return this;
  }
  
  public ConfirmCredentialsWorkflowRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public ConfirmCredentialsWorkflowRequest setOptions(Bundle paramBundle)
  {
    this.pj.clear();
    this.pj.putAll(paramBundle);
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.ConfirmCredentialsWorkflowRequest
 * JD-Core Version:    0.7.0.1
 */