package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.auth.firstparty.shared.FACLConfig;
import com.google.android.gms.auth.firstparty.shared.PACLConfig;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class TokenRequest
  implements SafeParcelable
{
  public static final x CREATOR = new x();
  String accountName;
  AppDescription callingAppDescription;
  volatile boolean oK;
  CaptchaSolution os;
  String pA;
  volatile FACLConfig pB;
  volatile PACLConfig pC;
  String pD = Consent.UNKNOWN.toString();
  Bundle pj = new Bundle();
  volatile boolean po;
  final int version;
  
  public TokenRequest()
  {
    this.version = 1;
  }
  
  TokenRequest(int paramInt, String paramString1, String paramString2, Bundle paramBundle, FACLConfig paramFACLConfig, PACLConfig paramPACLConfig, boolean paramBoolean1, boolean paramBoolean2, String paramString3, AppDescription paramAppDescription, CaptchaSolution paramCaptchaSolution)
  {
    this.version = paramInt;
    this.pA = paramString1;
    this.accountName = paramString2;
    this.pj = paramBundle;
    this.pB = paramFACLConfig;
    this.pC = paramPACLConfig;
    this.po = paramBoolean1;
    this.oK = paramBoolean2;
    this.pD = paramString3;
    this.callingAppDescription = paramAppDescription;
    this.os = paramCaptchaSolution;
  }
  
  public TokenRequest(String paramString1, String paramString2)
  {
    this.version = 1;
    this.accountName = paramString1;
    this.pA = paramString2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public Consent getConsent()
  {
    return Consent.valueOf(this.pD);
  }
  
  public FACLConfig getFaclData()
  {
    return this.pB;
  }
  
  public Bundle getOptions()
  {
    return new Bundle(this.pj);
  }
  
  public PACLConfig getPaclData()
  {
    return this.pC;
  }
  
  public String getService()
  {
    return this.pA;
  }
  
  public boolean isAddingAccount()
  {
    return this.po;
  }
  
  public boolean isCreatingAccount()
  {
    return this.oK;
  }
  
  public TokenRequest setAccountName(String paramString)
  {
    this.accountName = paramString;
    return this;
  }
  
  public TokenRequest setAddingAccount(boolean paramBoolean)
  {
    this.po = paramBoolean;
    return this;
  }
  
  public TokenRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public TokenRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  public TokenRequest setConsent(Consent paramConsent)
  {
    this.pD = ((Consent)at.a(paramConsent, " Consent cannot be null")).toString();
    return this;
  }
  
  public TokenRequest setCreatingAccount(boolean paramBoolean)
  {
    this.oK = paramBoolean;
    return this;
  }
  
  public TokenRequest setFaclData(FACLConfig paramFACLConfig)
  {
    this.pB = paramFACLConfig;
    return this;
  }
  
  public TokenRequest setOptions(Bundle paramBundle)
  {
    this.pj.clear();
    if (paramBundle != null) {
      this.pj.putAll(paramBundle);
    }
    return this;
  }
  
  public TokenRequest setPaclData(PACLConfig paramPACLConfig)
  {
    this.pC = paramPACLConfig;
    return this;
  }
  
  public TokenRequest setService(String paramString)
  {
    this.pA = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    x.a(this, paramParcel, paramInt);
  }
  
  public static enum Consent
  {
    static
    {
      GRANTED = new Consent("GRANTED", 1);
      REJECTED = new Consent("REJECTED", 2);
      Consent[] arrayOfConsent = new Consent[3];
      arrayOfConsent[0] = UNKNOWN;
      arrayOfConsent[1] = GRANTED;
      arrayOfConsent[2] = REJECTED;
      pE = arrayOfConsent;
    }
    
    private Consent() {}
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.TokenRequest
 * JD-Core Version:    0.7.0.1
 */