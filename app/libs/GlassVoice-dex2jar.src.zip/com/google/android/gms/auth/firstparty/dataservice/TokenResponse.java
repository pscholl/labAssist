package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.CaptchaChallenge;
import com.google.android.gms.auth.firstparty.shared.ScopeDetail;
import com.google.android.gms.auth.firstparty.shared.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TokenResponse
  implements SafeParcelable
{
  public static final y CREATOR = new y();
  String accountName;
  String oN;
  String oO;
  String oP;
  String ot;
  String ov;
  CaptchaChallenge ow;
  String pF;
  String pG;
  boolean pH;
  boolean pI;
  boolean pJ;
  boolean pK;
  List<ScopeDetail> pL;
  boolean pM;
  String pp;
  String pu;
  final int version;
  
  public TokenResponse()
  {
    this.version = 1;
    this.pL = new ArrayList();
  }
  
  TokenResponse(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, CaptchaChallenge paramCaptchaChallenge, List<ScopeDetail> paramList, String paramString9, String paramString10, boolean paramBoolean5)
  {
    this.version = paramInt;
    this.accountName = paramString1;
    this.ot = paramString2;
    this.oP = paramString3;
    this.pF = paramString4;
    this.ov = paramString5;
    this.pG = paramString6;
    this.oN = paramString7;
    this.oO = paramString8;
    this.pH = paramBoolean1;
    this.pI = paramBoolean2;
    this.pJ = paramBoolean3;
    this.pK = paramBoolean4;
    this.ow = paramCaptchaChallenge;
    this.pL = paramList;
    this.pu = paramString9;
    this.pp = paramString10;
    this.pM = paramBoolean5;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public CaptchaChallenge getCaptchaChallenge()
  {
    return this.ow;
  }
  
  public String getDetail()
  {
    return this.ov;
  }
  
  public String getFirstName()
  {
    return this.oN;
  }
  
  public String getLastName()
  {
    return this.oO;
  }
  
  public String getPicasaUser()
  {
    return this.pG;
  }
  
  public String getRopRevision()
  {
    return this.pp;
  }
  
  public String getRopText()
  {
    return this.pu;
  }
  
  public List<ScopeDetail> getScopeData()
  {
    return Collections.unmodifiableList(this.pL);
  }
  
  public String getSignInUrl()
  {
    return this.pF;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.ot);
  }
  
  public String getToken()
  {
    return this.oP;
  }
  
  public boolean isBrowserSignInSuggested()
  {
    return this.pK;
  }
  
  public boolean isEsMobileServiceEnabled()
  {
    return this.pJ;
  }
  
  public boolean isGPlusServiceAllowed()
  {
    return this.pH;
  }
  
  public boolean isGPlusServiceEnabled()
  {
    return this.pI;
  }
  
  public boolean isTokenCached()
  {
    return this.pM;
  }
  
  public TokenResponse setAccountName(String paramString)
  {
    this.accountName = paramString;
    return this;
  }
  
  public TokenResponse setBrowserSignInSuggested(boolean paramBoolean)
  {
    this.pK = paramBoolean;
    return this;
  }
  
  public TokenResponse setCaptchaChallenge(CaptchaChallenge paramCaptchaChallenge)
  {
    this.ow = paramCaptchaChallenge;
    return this;
  }
  
  public TokenResponse setDetail(String paramString)
  {
    this.ov = paramString;
    return this;
  }
  
  public TokenResponse setEsMobileServiceEnabled(boolean paramBoolean)
  {
    this.pJ = paramBoolean;
    return this;
  }
  
  public TokenResponse setFirstName(String paramString)
  {
    this.oN = paramString;
    return this;
  }
  
  public TokenResponse setGPlusServiceAllowed(boolean paramBoolean)
  {
    this.pH = paramBoolean;
    return this;
  }
  
  public TokenResponse setGPlusServiceEnabled(boolean paramBoolean)
  {
    this.pI = paramBoolean;
    return this;
  }
  
  public TokenResponse setIsTokenCached(boolean paramBoolean)
  {
    this.pM = paramBoolean;
    return this;
  }
  
  public TokenResponse setLastName(String paramString)
  {
    this.oO = paramString;
    return this;
  }
  
  public TokenResponse setPicasaUser(String paramString)
  {
    this.pG = paramString;
    return this;
  }
  
  public TokenResponse setRopRevision(String paramString)
  {
    this.pp = paramString;
    return this;
  }
  
  public TokenResponse setRopText(String paramString)
  {
    this.pu = paramString;
    return this;
  }
  
  public TokenResponse setScopeData(List<ScopeDetail> paramList)
  {
    this.pL.clear();
    this.pL.addAll(paramList);
    return this;
  }
  
  public TokenResponse setSignInUrl(String paramString)
  {
    this.pF = paramString;
    return this;
  }
  
  public TokenResponse setStatus(Status paramStatus)
  {
    this.ot = ((Status)at.f(paramStatus)).getWire();
    return this;
  }
  
  public TokenResponse setToken(String paramString)
  {
    this.oP = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    y.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.TokenResponse
 * JD-Core Version:    0.7.0.1
 */