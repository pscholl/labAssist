package com.google.android.gms.auth.firstparty.shared;

public enum Status
{
  public static String EXTRA_KEY_STATUS = "Error";
  public static String JSON_KEY_STATUS = "status";
  private final String qs;
  
  static
  {
    BAD_AUTHENTICATION = new Status("BAD_AUTHENTICATION", 1, "BadAuthentication");
    NEEDS_2F = new Status("NEEDS_2F", 2, "InvalidSecondFactor");
    NOT_VERIFIED = new Status("NOT_VERIFIED", 3, "NotVerified");
    TERMS_NOT_AGREED = new Status("TERMS_NOT_AGREED", 4, "TermsNotAgreed");
    UNKNOWN = new Status("UNKNOWN", 5, "Unknown");
    UNKNOWN_ERROR = new Status("UNKNOWN_ERROR", 6, "UNKNOWN_ERR");
    ACCOUNT_DELETED = new Status("ACCOUNT_DELETED", 7, "AccountDeleted");
    ACCOUNT_DISABLED = new Status("ACCOUNT_DISABLED", 8, "AccountDisabled");
    SERVICE_DISABLED = new Status("SERVICE_DISABLED", 9, "ServiceDisabled");
    SERVICE_UNAVAILABLE = new Status("SERVICE_UNAVAILABLE", 10, "ServiceUnavailable");
    CAPTCHA = new Status("CAPTCHA", 11, "CaptchaRequired");
    NETWORK_ERROR = new Status("NETWORK_ERROR", 12, "NetworkError");
    USER_CANCEL = new Status("USER_CANCEL", 13, "UserCancel");
    PERMISSION_DENIED = new Status("PERMISSION_DENIED", 14, "PermissionDenied");
    DEVICE_MANAGEMENT_REQUIRED = new Status("DEVICE_MANAGEMENT_REQUIRED", 15, "DeviceManagementRequiredOrSyncDisabled");
    CLIENT_LOGIN_DISABLED = new Status("CLIENT_LOGIN_DISABLED", 16, "ClientLoginDisabled");
    NEED_PERMISSION = new Status("NEED_PERMISSION", 17, "NeedPermission");
    BAD_PASSWORD = new Status("BAD_PASSWORD", 18, "WeakPassword");
    ALREADY_HAS_GMAIL = new Status("ALREADY_HAS_GMAIL", 19, "ALREADY_HAS_GMAIL");
    BAD_REQUEST = new Status("BAD_REQUEST", 20, "BadRequest");
    BAD_USERNAME = new Status("BAD_USERNAME", 21, "BadUsername");
    LOGIN_FAIL = new Status("LOGIN_FAIL", 22, "LoginFail");
    NOT_LOGGED_IN = new Status("NOT_LOGGED_IN", 23, "NotLoggedIn");
    NO_GMAIL = new Status("NO_GMAIL", 24, "NoGmail");
    REQUEST_DENIED = new Status("REQUEST_DENIED", 25, "RequestDenied");
    SERVER_ERROR = new Status("SERVER_ERROR", 26, "ServerError");
    USERNAME_UNAVAILABLE = new Status("USERNAME_UNAVAILABLE", 27, "UsernameUnavailable");
    DELETED_GMAIL = new Status("DELETED_GMAIL", 28, "DeletedGmail");
    SOCKET_TIMEOUT = new Status("SOCKET_TIMEOUT", 29, "SocketTimeout");
    EXISTING_USERNAME = new Status("EXISTING_USERNAME", 30, "ExistingUsername");
    NEEDS_BROWSER = new Status("NEEDS_BROWSER", 31, "NeedsBrowser");
    GPLUS_OTHER = new Status("GPLUS_OTHER", 32, "GPlusOther");
    GPLUS_NICKNAME = new Status("GPLUS_NICKNAME", 33, "GPlusNickname");
    GPLUS_INVALID_CHAR = new Status("GPLUS_INVALID_CHAR", 34, "GPlusInvalidChar");
    GPLUS_INTERSTITIAL = new Status("GPLUS_INTERSTITIAL", 35, "GPlusInterstitial");
    GPLUS_PROFILE_ERROR = new Status("GPLUS_PROFILE_ERROR", 36, "ProfileUpgradeError");
    INVALID_SCOPE = new Status("INVALID_SCOPE", 37, "INVALID_SCOPE");
    Status[] arrayOfStatus = new Status[38];
    arrayOfStatus[0] = SUCCESS;
    arrayOfStatus[1] = BAD_AUTHENTICATION;
    arrayOfStatus[2] = NEEDS_2F;
    arrayOfStatus[3] = NOT_VERIFIED;
    arrayOfStatus[4] = TERMS_NOT_AGREED;
    arrayOfStatus[5] = UNKNOWN;
    arrayOfStatus[6] = UNKNOWN_ERROR;
    arrayOfStatus[7] = ACCOUNT_DELETED;
    arrayOfStatus[8] = ACCOUNT_DISABLED;
    arrayOfStatus[9] = SERVICE_DISABLED;
    arrayOfStatus[10] = SERVICE_UNAVAILABLE;
    arrayOfStatus[11] = CAPTCHA;
    arrayOfStatus[12] = NETWORK_ERROR;
    arrayOfStatus[13] = USER_CANCEL;
    arrayOfStatus[14] = PERMISSION_DENIED;
    arrayOfStatus[15] = DEVICE_MANAGEMENT_REQUIRED;
    arrayOfStatus[16] = CLIENT_LOGIN_DISABLED;
    arrayOfStatus[17] = NEED_PERMISSION;
    arrayOfStatus[18] = BAD_PASSWORD;
    arrayOfStatus[19] = ALREADY_HAS_GMAIL;
    arrayOfStatus[20] = BAD_REQUEST;
    arrayOfStatus[21] = BAD_USERNAME;
    arrayOfStatus[22] = LOGIN_FAIL;
    arrayOfStatus[23] = NOT_LOGGED_IN;
    arrayOfStatus[24] = NO_GMAIL;
    arrayOfStatus[25] = REQUEST_DENIED;
    arrayOfStatus[26] = SERVER_ERROR;
    arrayOfStatus[27] = USERNAME_UNAVAILABLE;
    arrayOfStatus[28] = DELETED_GMAIL;
    arrayOfStatus[29] = SOCKET_TIMEOUT;
    arrayOfStatus[30] = EXISTING_USERNAME;
    arrayOfStatus[31] = NEEDS_BROWSER;
    arrayOfStatus[32] = GPLUS_OTHER;
    arrayOfStatus[33] = GPLUS_NICKNAME;
    arrayOfStatus[34] = GPLUS_INVALID_CHAR;
    arrayOfStatus[35] = GPLUS_INTERSTITIAL;
    arrayOfStatus[36] = GPLUS_PROFILE_ERROR;
    arrayOfStatus[37] = INVALID_SCOPE;
    qt = arrayOfStatus;
  }
  
  private Status(String paramString)
  {
    this.qs = paramString;
  }
  
  public static final Status fromWireCode(String paramString)
  {
    Object localObject1 = null;
    Status[] arrayOfStatus = values();
    int i = arrayOfStatus.length;
    int j = 0;
    Object localObject2;
    if (j < i)
    {
      localObject2 = arrayOfStatus[j];
      if (!((Status)localObject2).qs.equals(paramString)) {
        break label47;
      }
    }
    for (;;)
    {
      j++;
      localObject1 = localObject2;
      break;
      return localObject1;
      label47:
      localObject2 = localObject1;
    }
  }
  
  public boolean equals(String paramString)
  {
    return this.qs.equals(paramString);
  }
  
  public String getWire()
  {
    return this.qs;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.Status
 * JD-Core Version:    0.7.0.1
 */