package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class WebSetupConfig
  implements SafeParcelable
{
  public static final aa CREATOR = new aa();
  public final String url;
  final int version;
  
  WebSetupConfig(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.url = paramString;
  }
  
  public WebSetupConfig(String paramString)
  {
    this(1, paramString);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    aa.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.WebSetupConfig
 * JD-Core Version:    0.7.0.1
 */