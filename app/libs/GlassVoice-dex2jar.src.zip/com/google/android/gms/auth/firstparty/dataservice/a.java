package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class a
  implements Parcelable.Creator<AccountNameCheckRequest>
{
  static void a(AccountNameCheckRequest paramAccountNameCheckRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountNameCheckRequest.version);
    b.a(paramParcel, 2, paramAccountNameCheckRequest.op, false);
    b.a(paramParcel, 3, paramAccountNameCheckRequest.oq, false);
    b.a(paramParcel, 4, paramAccountNameCheckRequest.or, false);
    b.a(paramParcel, 5, paramAccountNameCheckRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 6, paramAccountNameCheckRequest.os, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public AccountNameCheckRequest g(Parcel paramParcel)
  {
    CaptchaSolution localCaptchaSolution = null;
    int i = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    int j = 0;
    AppDescription localAppDescription = null;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.al(k))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, k);
        break;
      case 1: 
        j = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, k);
        break;
      case 2: 
        str3 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 3: 
        str2 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 4: 
        str1 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 5: 
        localAppDescription = (AppDescription)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, k, AppDescription.CREATOR);
        break;
      case 6: 
        localCaptchaSolution = (CaptchaSolution)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, k, CaptchaSolution.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountNameCheckRequest(j, str3, str2, str1, localAppDescription, localCaptchaSolution);
  }
  
  public AccountNameCheckRequest[] l(int paramInt)
  {
    return new AccountNameCheckRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.a
 * JD-Core Version:    0.7.0.1
 */