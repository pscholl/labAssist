package com.google.android.gms.auth;

public class UserRecoverableNotifiedException
  extends GoogleAuthException
{
  public UserRecoverableNotifiedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.UserRecoverableNotifiedException
 * JD-Core Version:    0.7.0.1
 */