package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScopeDetail
  implements SafeParcelable
{
  public static final i CREATOR = new i();
  String description;
  public FACLData friendPickerData;
  String ov;
  String pA;
  String qp;
  String qq;
  List<String> qr;
  final int version;
  
  ScopeDetail(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, List<String> paramList, FACLData paramFACLData)
  {
    this.version = paramInt;
    this.description = paramString1;
    this.ov = paramString2;
    this.qp = paramString3;
    this.qq = paramString4;
    this.pA = paramString5;
    this.qr = paramList;
    this.friendPickerData = paramFACLData;
  }
  
  public ScopeDetail(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, FACLData paramFACLData, List<String> paramList)
  {
    this.version = 1;
    this.pA = paramString1;
    this.description = paramString2;
    this.ov = paramString3;
    this.qp = paramString4;
    this.qq = paramString5;
    this.friendPickerData = paramFACLData;
    this.qr = new ArrayList();
    this.qr.addAll(paramList);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public String getDetail()
  {
    return this.ov;
  }
  
  public FACLData getFriendPickerData()
  {
    return this.friendPickerData;
  }
  
  public String getIconBase64()
  {
    return this.qp;
  }
  
  public String getPaclPickerBase64()
  {
    return this.qq;
  }
  
  public String getService()
  {
    return this.pA;
  }
  
  public List<String> getUnmodifiableWarnings()
  {
    return Collections.unmodifiableList(this.qr);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    i.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.ScopeDetail
 * JD-Core Version:    0.7.0.1
 */