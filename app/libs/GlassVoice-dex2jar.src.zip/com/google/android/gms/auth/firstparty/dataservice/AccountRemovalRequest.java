package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountRemovalRequest
  implements SafeParcelable
{
  public static final i CREATOR = new i();
  String accountName;
  final int version;
  
  public AccountRemovalRequest()
  {
    this.version = 1;
  }
  
  AccountRemovalRequest(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.accountName = paramString;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public AccountRemovalRequest setAccountName(String paramString)
  {
    this.accountName = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    i.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRemovalRequest
 * JD-Core Version:    0.7.0.1
 */