package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class a
  implements Parcelable.Creator<AccountCredentials>
{
  static void a(AccountCredentials paramAccountCredentials, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountCredentials.version);
    b.a(paramParcel, 2, paramAccountCredentials.pT);
    b.a(paramParcel, 3, paramAccountCredentials.pU, false);
    b.a(paramParcel, 4, paramAccountCredentials.pV, false);
    b.a(paramParcel, 5, paramAccountCredentials.pW, false);
    b.a(paramParcel, 6, paramAccountCredentials.pX, false);
    b.a(paramParcel, 7, paramAccountCredentials.pY, false);
    b.C(paramParcel, i);
  }
  
  public AccountCredentials L(Parcel paramParcel)
  {
    boolean bool = false;
    String str1 = null;
    int i = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    String str2 = null;
    String str3 = null;
    String str4 = null;
    String str5 = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.al(k))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, k);
        break;
      case 1: 
        j = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, k);
        break;
      case 2: 
        bool = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, k);
        break;
      case 3: 
        str5 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 4: 
        str4 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 5: 
        str3 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 6: 
        str2 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 7: 
        str1 = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountCredentials(j, bool, str5, str4, str3, str2, str1);
  }
  
  public AccountCredentials[] Q(int paramInt)
  {
    return new AccountCredentials[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.a
 * JD-Core Version:    0.7.0.1
 */