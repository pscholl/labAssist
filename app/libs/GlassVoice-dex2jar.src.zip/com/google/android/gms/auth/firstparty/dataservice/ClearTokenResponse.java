package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class ClearTokenResponse
  implements SafeParcelable
{
  public static final o CREATOR = new o();
  final String ot;
  final int version;
  
  ClearTokenResponse(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.ot = paramString;
  }
  
  public ClearTokenResponse(Status paramStatus)
  {
    this.version = 1;
    this.ot = ((Status)at.f(paramStatus)).getWire();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public Status getStatus()
  {
    return Status.fromWireCode(this.ot);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    o.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.ClearTokenResponse
 * JD-Core Version:    0.7.0.1
 */