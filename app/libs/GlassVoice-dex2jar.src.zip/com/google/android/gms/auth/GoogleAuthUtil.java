package com.google.android.gms.auth;

import android.accounts.AccountManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.R.string;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import java.io.IOException;
import java.net.URISyntaxException;

public final class GoogleAuthUtil
{
  public static final String GOOGLE_ACCOUNT_TYPE = "com.google";
  public static final String KEY_ANDROID_PACKAGE_NAME;
  public static final String KEY_CALLER_UID;
  public static final String KEY_CLIENT_PACKAGE_NAME = "clientPackageName";
  public static final String KEY_HANDLE_NOTIFICATION = "handle_notification";
  public static final String KEY_REQUEST_ACTIONS = "request_visible_actions";
  @Deprecated
  public static final String KEY_REQUEST_VISIBLE_ACTIVITIES = "request_visible_actions";
  public static final String KEY_SUPPRESS_PROGRESS_SCREEN = "suppressProgressScreen";
  public static final String OEM_ONLY_KEY_TARGET_ANDROID_ID = "oauth2_target_device_id";
  public static final String OEM_ONLY_KEY_VERIFIER = "oauth2_authcode_verifier";
  public static final String OEM_ONLY_SCOPE_ACCOUNT_BOOTSTRAP = "_account_setup";
  public static final String STATUS_CAPTCHA_REQUIRED = "CaptchaRequired";
  public static final String STATUS_DEVICE_MANAGEMENT = "DeviceManagementRequiredOrSyncDisabled";
  public static final String STATUS_INTERRUPTED = "Interrupted";
  public static final String STATUS_NEEDS_PERMISSION = "NeedPermission";
  public static final String STATUS_NEED_APP = "AppDownloadRequired";
  public static final String STATUS_NETWORK_ERROR = "NetworkError";
  public static final String STATUS_USER_CANCEL = "UserCancel";
  private static final ComponentName ok;
  private static final ComponentName ol;
  private static final Intent om;
  private static final Intent on;
  
  static
  {
    String str1;
    if (Build.VERSION.SDK_INT >= 11)
    {
      str1 = "callerUid";
      KEY_CALLER_UID = str1;
      if (Build.VERSION.SDK_INT < 14) {
        break label107;
      }
    }
    label107:
    for (String str2 = "androidPackageName";; str2 = "androidPackageName")
    {
      KEY_ANDROID_PACKAGE_NAME = str2;
      ok = new ComponentName("com.google.android.gms", "com.google.android.gms.auth.GetToken");
      ol = new ComponentName("com.google.android.gms", "com.google.android.gms.recovery.RecoveryService");
      om = new Intent().setPackage("com.google.android.gms").setComponent(ok);
      on = new Intent().setPackage("com.google.android.gms").setComponent(ol);
      return;
      str1 = "callerUid";
      break;
    }
  }
  
  private static String a(Context paramContext, String paramString1, String paramString2, Bundle paramBundle)
    throws IOException, UserRecoverableNotifiedException, GoogleAuthException
  {
    if (paramBundle == null) {
      paramBundle = new Bundle();
    }
    try
    {
      String str3 = getToken(paramContext, paramString1, paramString2, paramBundle);
      return str3;
    }
    catch (GooglePlayServicesAvailabilityException localGooglePlayServicesAvailabilityException)
    {
      PendingIntent localPendingIntent = GooglePlayServicesUtil.getErrorPendingIntent(localGooglePlayServicesAvailabilityException.getConnectionStatusCode(), paramContext, 0);
      Resources localResources = paramContext.getResources();
      Notification localNotification = new Notification(17301642, localResources.getString(R.string.auth_client_play_services_err_notification_msg), System.currentTimeMillis());
      localNotification.flags = (0x10 | localNotification.flags);
      String str1 = paramContext.getApplicationInfo().name;
      PackageManager localPackageManager;
      if (TextUtils.isEmpty(str1))
      {
        str1 = paramContext.getPackageName();
        localPackageManager = paramContext.getApplicationContext().getPackageManager();
      }
      try
      {
        ApplicationInfo localApplicationInfo2 = localPackageManager.getApplicationInfo(paramContext.getPackageName(), 0);
        localApplicationInfo1 = localApplicationInfo2;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        for (;;)
        {
          String str2;
          ApplicationInfo localApplicationInfo1 = null;
          continue;
          int i = R.string.auth_client_needs_installation_title;
          continue;
          i = R.string.auth_client_needs_update_title;
          continue;
          i = R.string.auth_client_needs_enabling_title;
        }
      }
      if (localApplicationInfo1 != null) {
        str1 = localPackageManager.getApplicationLabel(localApplicationInfo1).toString();
      }
      str2 = localResources.getString(R.string.auth_client_requested_by_msg, new Object[] { str1 });
      switch (localGooglePlayServicesAvailabilityException.getConnectionStatusCode())
      {
      default: 
        i = R.string.auth_client_using_bad_version_title;
        localNotification.setLatestEventInfo(paramContext, localResources.getString(i), str2, localPendingIntent);
        ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, localNotification);
        throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
      }
    }
    catch (UserRecoverableAuthException localUserRecoverableAuthException)
    {
      throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
    }
  }
  
  private static void a(Intent paramIntent)
  {
    if (paramIntent == null) {
      throw new IllegalArgumentException("Callack cannot be null.");
    }
    String str = paramIntent.toUri(1);
    try
    {
      Intent.parseUri(str, 1);
      return;
    }
    catch (URISyntaxException localURISyntaxException)
    {
      throw new IllegalArgumentException("Parameter callback contains invalid data. It must be serializable using toUri() and parseUri().");
    }
  }
  
  /* Error */
  public static void clearToken(Context paramContext, String paramString)
    throws GooglePlayServicesAvailabilityException, GoogleAuthException, IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 194	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   4: astore_2
    //   5: ldc_w 275
    //   8: invokestatic 280	com/google/android/gms/internal/at:x	(Ljava/lang/String;)V
    //   11: aload_2
    //   12: invokestatic 284	com/google/android/gms/auth/GoogleAuthUtil:m	(Landroid/content/Context;)V
    //   15: new 125	android/os/Bundle
    //   18: dup
    //   19: invokespecial 126	android/os/Bundle:<init>	()V
    //   22: astore_3
    //   23: aload_0
    //   24: invokevirtual 175	android/content/Context:getApplicationInfo	()Landroid/content/pm/ApplicationInfo;
    //   27: getfield 287	android/content/pm/ApplicationInfo:packageName	Ljava/lang/String;
    //   30: astore 4
    //   32: aload_3
    //   33: ldc 13
    //   35: aload 4
    //   37: invokevirtual 290	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   40: aload_3
    //   41: getstatic 76	com/google/android/gms/auth/GoogleAuthUtil:KEY_ANDROID_PACKAGE_NAME	Ljava/lang/String;
    //   44: invokevirtual 294	android/os/Bundle:containsKey	(Ljava/lang/String;)Z
    //   47: ifne +12 -> 59
    //   50: aload_3
    //   51: getstatic 76	com/google/android/gms/auth/GoogleAuthUtil:KEY_ANDROID_PACKAGE_NAME	Ljava/lang/String;
    //   54: aload 4
    //   56: invokevirtual 290	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   59: new 296	com/google/android/gms/common/a
    //   62: dup
    //   63: invokespecial 297	com/google/android/gms/common/a:<init>	()V
    //   66: astore 5
    //   68: aload_2
    //   69: getstatic 106	com/google/android/gms/auth/GoogleAuthUtil:om	Landroid/content/Intent;
    //   72: aload 5
    //   74: iconst_1
    //   75: invokevirtual 301	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   78: ifeq +106 -> 184
    //   81: aload 5
    //   83: invokevirtual 305	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   86: invokestatic 310	com/google/android/gms/internal/s$a:a	(Landroid/os/IBinder;)Lcom/google/android/gms/internal/s;
    //   89: aload_1
    //   90: aload_3
    //   91: invokeinterface 315 3 0
    //   96: astore 10
    //   98: aload 10
    //   100: getstatic 320	com/google/android/gms/auth/firstparty/shared/Status:EXTRA_KEY_STATUS	Ljava/lang/String;
    //   103: invokevirtual 323	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   106: astore 11
    //   108: aload 10
    //   110: ldc_w 325
    //   113: invokevirtual 328	android/os/Bundle:getBoolean	(Ljava/lang/String;)Z
    //   116: ifne +49 -> 165
    //   119: new 117	com/google/android/gms/auth/GoogleAuthException
    //   122: dup
    //   123: aload 11
    //   125: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   128: athrow
    //   129: astore 8
    //   131: ldc_w 331
    //   134: ldc_w 333
    //   137: aload 8
    //   139: invokestatic 339	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   142: pop
    //   143: new 113	java/io/IOException
    //   146: dup
    //   147: ldc_w 341
    //   150: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   153: athrow
    //   154: astore 7
    //   156: aload_2
    //   157: aload 5
    //   159: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   162: aload 7
    //   164: athrow
    //   165: aload_2
    //   166: aload 5
    //   168: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   171: return
    //   172: astore 6
    //   174: new 117	com/google/android/gms/auth/GoogleAuthException
    //   177: dup
    //   178: ldc 42
    //   180: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   183: athrow
    //   184: new 113	java/io/IOException
    //   187: dup
    //   188: ldc_w 348
    //   191: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   194: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	195	0	paramContext	Context
    //   0	195	1	paramString	String
    //   4	162	2	localContext	Context
    //   22	69	3	localBundle1	Bundle
    //   30	25	4	str1	String
    //   66	101	5	locala	com.google.android.gms.common.a
    //   172	1	6	localInterruptedException	java.lang.InterruptedException
    //   154	9	7	localObject	Object
    //   129	9	8	localRemoteException	android.os.RemoteException
    //   96	13	10	localBundle2	Bundle
    //   106	18	11	str2	String
    // Exception table:
    //   from	to	target	type
    //   81	129	129	android/os/RemoteException
    //   81	129	154	finally
    //   131	154	154	finally
    //   174	184	154	finally
    //   81	129	172	java/lang/InterruptedException
  }
  
  /* Error */
  public static RecoveryReadResponse fetchCurrentRecoveryData(Context paramContext, String paramString)
    throws IOException, UserRecoverableAuthException, GoogleAuthException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 194	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   4: astore_2
    //   5: ldc_w 275
    //   8: invokestatic 280	com/google/android/gms/internal/at:x	(Ljava/lang/String;)V
    //   11: aload_2
    //   12: invokestatic 284	com/google/android/gms/auth/GoogleAuthUtil:m	(Landroid/content/Context;)V
    //   15: new 296	com/google/android/gms/common/a
    //   18: dup
    //   19: invokespecial 297	com/google/android/gms/common/a:<init>	()V
    //   22: astore_3
    //   23: aload_0
    //   24: getstatic 108	com/google/android/gms/auth/GoogleAuthUtil:on	Landroid/content/Intent;
    //   27: aload_3
    //   28: iconst_1
    //   29: invokevirtual 301	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   32: ifeq +77 -> 109
    //   35: aload_3
    //   36: invokevirtual 305	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   39: invokestatic 356	com/google/android/gms/internal/t$a:b	(Landroid/os/IBinder;)Lcom/google/android/gms/internal/t;
    //   42: aload_1
    //   43: aload_0
    //   44: invokevirtual 190	android/content/Context:getPackageName	()Ljava/lang/String;
    //   47: invokeinterface 361 3 0
    //   52: astore 8
    //   54: aload_0
    //   55: aload_3
    //   56: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   59: aload 8
    //   61: areturn
    //   62: astore 6
    //   64: ldc_w 331
    //   67: ldc_w 333
    //   70: aload 6
    //   72: invokestatic 339	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   75: pop
    //   76: new 113	java/io/IOException
    //   79: dup
    //   80: ldc_w 341
    //   83: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   86: athrow
    //   87: astore 5
    //   89: aload_0
    //   90: aload_3
    //   91: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   94: aload 5
    //   96: athrow
    //   97: astore 4
    //   99: new 117	com/google/android/gms/auth/GoogleAuthException
    //   102: dup
    //   103: ldc 42
    //   105: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   108: athrow
    //   109: new 113	java/io/IOException
    //   112: dup
    //   113: new 363	java/lang/StringBuilder
    //   116: dup
    //   117: invokespecial 364	java/lang/StringBuilder:<init>	()V
    //   120: ldc_w 366
    //   123: invokevirtual 370	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: getstatic 108	com/google/android/gms/auth/GoogleAuthUtil:on	Landroid/content/Intent;
    //   129: invokevirtual 374	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   132: invokevirtual 377	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   135: invokevirtual 378	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   138: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   141: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	142	0	paramContext	Context
    //   0	142	1	paramString	String
    //   4	8	2	localContext	Context
    //   22	69	3	locala	com.google.android.gms.common.a
    //   97	1	4	localInterruptedException	java.lang.InterruptedException
    //   87	8	5	localObject	Object
    //   62	9	6	localRemoteException	android.os.RemoteException
    //   52	8	8	localRecoveryReadResponse	RecoveryReadResponse
    // Exception table:
    //   from	to	target	type
    //   35	54	62	android/os/RemoteException
    //   35	54	87	finally
    //   64	87	87	finally
    //   99	109	87	finally
    //   35	54	97	java/lang/InterruptedException
  }
  
  /* Error */
  public static RecoveryDecision getRecoveryDetails(Context paramContext, String paramString1, String paramString2, boolean paramBoolean)
    throws IOException, UserRecoverableAuthException, GoogleAuthException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 194	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   4: astore 4
    //   6: ldc_w 275
    //   9: invokestatic 280	com/google/android/gms/internal/at:x	(Ljava/lang/String;)V
    //   12: aload 4
    //   14: invokestatic 284	com/google/android/gms/auth/GoogleAuthUtil:m	(Landroid/content/Context;)V
    //   17: new 125	android/os/Bundle
    //   20: dup
    //   21: invokespecial 126	android/os/Bundle:<init>	()V
    //   24: astore 5
    //   26: aload 5
    //   28: getstatic 76	com/google/android/gms/auth/GoogleAuthUtil:KEY_ANDROID_PACKAGE_NAME	Ljava/lang/String;
    //   31: aload_0
    //   32: invokevirtual 190	android/content/Context:getPackageName	()Ljava/lang/String;
    //   35: invokevirtual 290	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   38: new 296	com/google/android/gms/common/a
    //   41: dup
    //   42: invokespecial 297	com/google/android/gms/common/a:<init>	()V
    //   45: astore 6
    //   47: aload_0
    //   48: getstatic 108	com/google/android/gms/auth/GoogleAuthUtil:on	Landroid/content/Intent;
    //   51: aload 6
    //   53: iconst_1
    //   54: invokevirtual 301	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   57: ifeq +80 -> 137
    //   60: aload 6
    //   62: invokevirtual 305	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   65: invokestatic 356	com/google/android/gms/internal/t$a:b	(Landroid/os/IBinder;)Lcom/google/android/gms/internal/t;
    //   68: aload_1
    //   69: aload_2
    //   70: iload_3
    //   71: aload 5
    //   73: invokeinterface 383 5 0
    //   78: astore 11
    //   80: aload_0
    //   81: aload 6
    //   83: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   86: aload 11
    //   88: areturn
    //   89: astore 9
    //   91: ldc_w 331
    //   94: ldc_w 333
    //   97: aload 9
    //   99: invokestatic 339	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   102: pop
    //   103: new 113	java/io/IOException
    //   106: dup
    //   107: ldc_w 341
    //   110: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   113: athrow
    //   114: astore 8
    //   116: aload_0
    //   117: aload 6
    //   119: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   122: aload 8
    //   124: athrow
    //   125: astore 7
    //   127: new 117	com/google/android/gms/auth/GoogleAuthException
    //   130: dup
    //   131: ldc 42
    //   133: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   136: athrow
    //   137: new 113	java/io/IOException
    //   140: dup
    //   141: new 363	java/lang/StringBuilder
    //   144: dup
    //   145: invokespecial 364	java/lang/StringBuilder:<init>	()V
    //   148: ldc_w 366
    //   151: invokevirtual 370	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: getstatic 108	com/google/android/gms/auth/GoogleAuthUtil:on	Landroid/content/Intent;
    //   157: invokevirtual 374	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   160: invokevirtual 377	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   163: invokevirtual 378	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   166: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   169: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	170	0	paramContext	Context
    //   0	170	1	paramString1	String
    //   0	170	2	paramString2	String
    //   0	170	3	paramBoolean	boolean
    //   4	9	4	localContext	Context
    //   24	48	5	localBundle	Bundle
    //   45	73	6	locala	com.google.android.gms.common.a
    //   125	1	7	localInterruptedException	java.lang.InterruptedException
    //   114	9	8	localObject	Object
    //   89	9	9	localRemoteException	android.os.RemoteException
    //   78	9	11	localRecoveryDecision	RecoveryDecision
    // Exception table:
    //   from	to	target	type
    //   60	80	89	android/os/RemoteException
    //   60	80	114	finally
    //   91	114	114	finally
    //   127	137	114	finally
    //   60	80	125	java/lang/InterruptedException
  }
  
  public static PendingIntent getRecoveryIfSuggested(Context paramContext, String paramString1, String paramString2, boolean paramBoolean)
    throws IOException, UserRecoverableAuthException, GoogleAuthException
  {
    RecoveryDecision localRecoveryDecision = getRecoveryDetails(paramContext, paramString1, paramString2, paramBoolean);
    if ((localRecoveryDecision.showRecoveryInterstitial) && (localRecoveryDecision.isRecoveryInterstitialAllowed)) {
      return localRecoveryDecision.recoveryIntent;
    }
    return null;
  }
  
  public static String getToken(Context paramContext, String paramString1, String paramString2)
    throws IOException, UserRecoverableAuthException, GoogleAuthException
  {
    return getToken(paramContext, paramString1, paramString2, new Bundle());
  }
  
  /* Error */
  public static String getToken(Context paramContext, String paramString1, String paramString2, Bundle paramBundle)
    throws IOException, UserRecoverableAuthException, GoogleAuthException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 194	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   4: astore 4
    //   6: ldc_w 275
    //   9: invokestatic 280	com/google/android/gms/internal/at:x	(Ljava/lang/String;)V
    //   12: aload 4
    //   14: invokestatic 284	com/google/android/gms/auth/GoogleAuthUtil:m	(Landroid/content/Context;)V
    //   17: aload_3
    //   18: ifnonnull +125 -> 143
    //   21: new 125	android/os/Bundle
    //   24: dup
    //   25: invokespecial 126	android/os/Bundle:<init>	()V
    //   28: astore 5
    //   30: aload_0
    //   31: invokevirtual 175	android/content/Context:getApplicationInfo	()Landroid/content/pm/ApplicationInfo;
    //   34: getfield 287	android/content/pm/ApplicationInfo:packageName	Ljava/lang/String;
    //   37: astore 6
    //   39: aload 5
    //   41: ldc 13
    //   43: aload 6
    //   45: invokevirtual 290	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   48: aload 5
    //   50: getstatic 76	com/google/android/gms/auth/GoogleAuthUtil:KEY_ANDROID_PACKAGE_NAME	Ljava/lang/String;
    //   53: invokevirtual 294	android/os/Bundle:containsKey	(Ljava/lang/String;)Z
    //   56: ifne +13 -> 69
    //   59: aload 5
    //   61: getstatic 76	com/google/android/gms/auth/GoogleAuthUtil:KEY_ANDROID_PACKAGE_NAME	Ljava/lang/String;
    //   64: aload 6
    //   66: invokevirtual 290	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   69: new 296	com/google/android/gms/common/a
    //   72: dup
    //   73: invokespecial 297	com/google/android/gms/common/a:<init>	()V
    //   76: astore 7
    //   78: aload 4
    //   80: getstatic 106	com/google/android/gms/auth/GoogleAuthUtil:om	Landroid/content/Intent;
    //   83: aload 7
    //   85: iconst_1
    //   86: invokevirtual 301	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   89: ifeq +187 -> 276
    //   92: aload 7
    //   94: invokevirtual 305	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   97: invokestatic 310	com/google/android/gms/internal/s$a:a	(Landroid/os/IBinder;)Lcom/google/android/gms/internal/s;
    //   100: aload_1
    //   101: aload_2
    //   102: aload 5
    //   104: invokeinterface 404 4 0
    //   109: astore 12
    //   111: aload 12
    //   113: ldc_w 406
    //   116: invokevirtual 323	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   119: astore 13
    //   121: aload 13
    //   123: invokestatic 186	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   126: istore 14
    //   128: iload 14
    //   130: ifne +26 -> 156
    //   133: aload 4
    //   135: aload 7
    //   137: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   140: aload 13
    //   142: areturn
    //   143: new 125	android/os/Bundle
    //   146: dup
    //   147: aload_3
    //   148: invokespecial 409	android/os/Bundle:<init>	(Landroid/os/Bundle;)V
    //   151: astore 5
    //   153: goto -123 -> 30
    //   156: aload 12
    //   158: ldc_w 411
    //   161: invokevirtual 323	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   164: astore 15
    //   166: aload 12
    //   168: ldc_w 413
    //   171: invokevirtual 417	android/os/Bundle:getParcelable	(Ljava/lang/String;)Landroid/os/Parcelable;
    //   174: checkcast 94	android/content/Intent
    //   177: astore 16
    //   179: aload 15
    //   181: invokestatic 420	com/google/android/gms/auth/GoogleAuthUtil:s	(Ljava/lang/String;)Z
    //   184: ifeq +52 -> 236
    //   187: new 121	com/google/android/gms/auth/UserRecoverableAuthException
    //   190: dup
    //   191: aload 15
    //   193: aload 16
    //   195: invokespecial 423	com/google/android/gms/auth/UserRecoverableAuthException:<init>	(Ljava/lang/String;Landroid/content/Intent;)V
    //   198: athrow
    //   199: astore 10
    //   201: ldc_w 331
    //   204: ldc_w 333
    //   207: aload 10
    //   209: invokestatic 339	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   212: pop
    //   213: new 113	java/io/IOException
    //   216: dup
    //   217: ldc_w 341
    //   220: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   223: athrow
    //   224: astore 9
    //   226: aload 4
    //   228: aload 7
    //   230: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   233: aload 9
    //   235: athrow
    //   236: aload 15
    //   238: invokestatic 426	com/google/android/gms/auth/GoogleAuthUtil:r	(Ljava/lang/String;)Z
    //   241: ifeq +25 -> 266
    //   244: new 113	java/io/IOException
    //   247: dup
    //   248: aload 15
    //   250: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   253: athrow
    //   254: astore 8
    //   256: new 117	com/google/android/gms/auth/GoogleAuthException
    //   259: dup
    //   260: ldc 42
    //   262: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   265: athrow
    //   266: new 117	com/google/android/gms/auth/GoogleAuthException
    //   269: dup
    //   270: aload 15
    //   272: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   275: athrow
    //   276: new 113	java/io/IOException
    //   279: dup
    //   280: ldc_w 348
    //   283: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   286: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	287	0	paramContext	Context
    //   0	287	1	paramString1	String
    //   0	287	2	paramString2	String
    //   0	287	3	paramBundle	Bundle
    //   4	223	4	localContext	Context
    //   28	124	5	localBundle1	Bundle
    //   37	28	6	str1	String
    //   76	153	7	locala	com.google.android.gms.common.a
    //   254	1	8	localInterruptedException	java.lang.InterruptedException
    //   224	10	9	localObject	Object
    //   199	9	10	localRemoteException	android.os.RemoteException
    //   109	58	12	localBundle2	Bundle
    //   119	22	13	str2	String
    //   126	3	14	bool	boolean
    //   164	107	15	str3	String
    //   177	17	16	localIntent	Intent
    // Exception table:
    //   from	to	target	type
    //   92	128	199	android/os/RemoteException
    //   156	199	199	android/os/RemoteException
    //   236	254	199	android/os/RemoteException
    //   266	276	199	android/os/RemoteException
    //   92	128	224	finally
    //   156	199	224	finally
    //   201	224	224	finally
    //   236	254	224	finally
    //   256	266	224	finally
    //   266	276	224	finally
    //   92	128	254	java/lang/InterruptedException
    //   156	199	254	java/lang/InterruptedException
    //   236	254	254	java/lang/InterruptedException
    //   266	276	254	java/lang/InterruptedException
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle)
    throws IOException, UserRecoverableNotifiedException, GoogleAuthException
  {
    if (paramBundle == null) {
      paramBundle = new Bundle();
    }
    paramBundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, paramBundle);
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle, Intent paramIntent)
    throws IOException, UserRecoverableNotifiedException, GoogleAuthException
  {
    a(paramIntent);
    if (paramBundle == null) {
      paramBundle = new Bundle();
    }
    paramBundle.putParcelable("callback_intent", paramIntent);
    paramBundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, paramBundle);
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle1, String paramString3, Bundle paramBundle2)
    throws IOException, UserRecoverableNotifiedException, GoogleAuthException
  {
    if (TextUtils.isEmpty(paramString3)) {
      throw new IllegalArgumentException("Authority cannot be empty or null.");
    }
    if (paramBundle1 == null) {
      paramBundle1 = new Bundle();
    }
    if (paramBundle2 == null) {
      paramBundle2 = new Bundle();
    }
    ContentResolver.validateSyncExtrasBundle(paramBundle2);
    paramBundle1.putString("authority", paramString3);
    paramBundle1.putBundle("sync_extras", paramBundle2);
    paramBundle1.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, paramBundle1);
  }
  
  @Deprecated
  public static void invalidateToken(Context paramContext, String paramString)
  {
    AccountManager.get(paramContext).invalidateAuthToken("com.google", paramString);
  }
  
  private static void m(Context paramContext)
    throws GooglePlayServicesAvailabilityException, GoogleAuthException
  {
    try
    {
      GooglePlayServicesUtil.m(paramContext);
      return;
    }
    catch (GooglePlayServicesRepairableException localGooglePlayServicesRepairableException)
    {
      throw new GooglePlayServicesAvailabilityException(localGooglePlayServicesRepairableException.getConnectionStatusCode(), localGooglePlayServicesRepairableException.getMessage(), localGooglePlayServicesRepairableException.getIntent());
    }
    catch (GooglePlayServicesNotAvailableException localGooglePlayServicesNotAvailableException)
    {
      throw new GoogleAuthException(localGooglePlayServicesNotAvailableException.getMessage());
    }
  }
  
  private static boolean r(String paramString)
  {
    return ("NetworkError".equals(paramString)) || ("ServiceUnavailable".equals(paramString)) || ("Timeout".equals(paramString));
  }
  
  private static boolean s(String paramString)
  {
    return ("BadAuthentication".equals(paramString)) || ("CaptchaRequired".equals(paramString)) || ("DeviceManagementRequiredOrSyncDisabled".equals(paramString)) || ("NeedPermission".equals(paramString)) || ("NeedsBrowser".equals(paramString)) || ("UserCancel".equals(paramString)) || ("AppDownloadRequired".equals(paramString));
  }
  
  /* Error */
  public static RecoveryWriteResponse updateRecoveryData(Context paramContext, RecoveryWriteRequest paramRecoveryWriteRequest)
    throws IOException, UserRecoverableAuthException, GoogleAuthException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 194	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   4: astore_2
    //   5: ldc_w 275
    //   8: invokestatic 280	com/google/android/gms/internal/at:x	(Ljava/lang/String;)V
    //   11: aload_2
    //   12: invokestatic 284	com/google/android/gms/auth/GoogleAuthUtil:m	(Landroid/content/Context;)V
    //   15: new 296	com/google/android/gms/common/a
    //   18: dup
    //   19: invokespecial 297	com/google/android/gms/common/a:<init>	()V
    //   22: astore_3
    //   23: aload_0
    //   24: getstatic 108	com/google/android/gms/auth/GoogleAuthUtil:on	Landroid/content/Intent;
    //   27: aload_3
    //   28: iconst_1
    //   29: invokevirtual 301	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   32: ifeq +77 -> 109
    //   35: aload_3
    //   36: invokevirtual 305	com/google/android/gms/common/a:bj	()Landroid/os/IBinder;
    //   39: invokestatic 356	com/google/android/gms/internal/t$a:b	(Landroid/os/IBinder;)Lcom/google/android/gms/internal/t;
    //   42: aload_1
    //   43: aload_0
    //   44: invokevirtual 190	android/content/Context:getPackageName	()Ljava/lang/String;
    //   47: invokeinterface 504 3 0
    //   52: astore 8
    //   54: aload_0
    //   55: aload_3
    //   56: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   59: aload 8
    //   61: areturn
    //   62: astore 6
    //   64: ldc_w 331
    //   67: ldc_w 333
    //   70: aload 6
    //   72: invokestatic 339	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   75: pop
    //   76: new 113	java/io/IOException
    //   79: dup
    //   80: ldc_w 341
    //   83: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   86: athrow
    //   87: astore 5
    //   89: aload_0
    //   90: aload_3
    //   91: invokevirtual 346	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   94: aload 5
    //   96: athrow
    //   97: astore 4
    //   99: new 117	com/google/android/gms/auth/GoogleAuthException
    //   102: dup
    //   103: ldc 42
    //   105: invokespecial 329	com/google/android/gms/auth/GoogleAuthException:<init>	(Ljava/lang/String;)V
    //   108: athrow
    //   109: new 113	java/io/IOException
    //   112: dup
    //   113: new 363	java/lang/StringBuilder
    //   116: dup
    //   117: invokespecial 364	java/lang/StringBuilder:<init>	()V
    //   120: ldc_w 366
    //   123: invokevirtual 370	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: getstatic 108	com/google/android/gms/auth/GoogleAuthUtil:on	Landroid/content/Intent;
    //   129: invokevirtual 374	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   132: invokevirtual 377	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   135: invokevirtual 378	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   138: invokespecial 342	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   141: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	142	0	paramContext	Context
    //   0	142	1	paramRecoveryWriteRequest	RecoveryWriteRequest
    //   4	8	2	localContext	Context
    //   22	69	3	locala	com.google.android.gms.common.a
    //   97	1	4	localInterruptedException	java.lang.InterruptedException
    //   87	8	5	localObject	Object
    //   62	9	6	localRemoteException	android.os.RemoteException
    //   52	8	8	localRecoveryWriteResponse	RecoveryWriteResponse
    // Exception table:
    //   from	to	target	type
    //   35	54	62	android/os/RemoteException
    //   35	54	87	finally
    //   64	87	87	finally
    //   99	109	87	finally
    //   35	54	97	java/lang/InterruptedException
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.GoogleAuthUtil
 * JD-Core Version:    0.7.0.1
 */