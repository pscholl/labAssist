package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class GplusInfoRequest
  implements SafeParcelable
{
  public static final s CREATOR = new s();
  String accountName;
  CaptchaSolution os;
  final int version;
  
  public GplusInfoRequest()
  {
    this.version = 1;
  }
  
  GplusInfoRequest(int paramInt, String paramString, CaptchaSolution paramCaptchaSolution)
  {
    this.version = paramInt;
    this.accountName = paramString;
    this.os = paramCaptchaSolution;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public GplusInfoRequest setAccountName(String paramString)
  {
    this.accountName = paramString;
    return this;
  }
  
  public GplusInfoRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    s.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.GplusInfoRequest
 * JD-Core Version:    0.7.0.1
 */