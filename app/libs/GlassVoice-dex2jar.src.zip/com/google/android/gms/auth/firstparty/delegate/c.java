package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class c
  implements Parcelable.Creator<SetupAccountWorkflowRequest>
{
  static void a(SetupAccountWorkflowRequest paramSetupAccountWorkflowRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramSetupAccountWorkflowRequest.version);
    b.a(paramParcel, 2, paramSetupAccountWorkflowRequest.pP);
    b.a(paramParcel, 3, paramSetupAccountWorkflowRequest.pQ);
    b.a(paramParcel, 4, paramSetupAccountWorkflowRequest.pR, false);
    b.a(paramParcel, 5, paramSetupAccountWorkflowRequest.pj, false);
    b.a(paramParcel, 6, paramSetupAccountWorkflowRequest.callingAppDescription, paramInt, false);
    b.C(paramParcel, i);
  }
  
  public SetupAccountWorkflowRequest I(Parcel paramParcel)
  {
    AppDescription localAppDescription = null;
    boolean bool1 = false;
    int i = a.Y(paramParcel);
    Bundle localBundle = new Bundle();
    ArrayList localArrayList = null;
    boolean bool2 = false;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        bool2 = a.c(paramParcel, k);
        break;
      case 3: 
        bool1 = a.c(paramParcel, k);
        break;
      case 4: 
        localArrayList = a.x(paramParcel, k);
        break;
      case 5: 
        localBundle = a.n(paramParcel, k);
        break;
      case 6: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new SetupAccountWorkflowRequest(j, bool2, bool1, localArrayList, localBundle, localAppDescription);
  }
  
  public SetupAccountWorkflowRequest[] N(int paramInt)
  {
    return new SetupAccountWorkflowRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.c
 * JD-Core Version:    0.7.0.1
 */