package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class f
  implements Parcelable.Creator<FACLData>
{
  static void a(FACLData paramFACLData, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramFACLData.version);
    b.a(paramParcel, 2, paramFACLData.qi, paramInt, false);
    b.a(paramParcel, 3, paramFACLData.qj, false);
    b.a(paramParcel, 4, paramFACLData.qk);
    b.a(paramParcel, 5, paramFACLData.ql, false);
    b.C(paramParcel, i);
  }
  
  public FACLData Q(Parcel paramParcel)
  {
    boolean bool = false;
    String str1 = null;
    int i = a.Y(paramParcel);
    String str2 = null;
    FACLConfig localFACLConfig = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localFACLConfig = (FACLConfig)a.a(paramParcel, k, FACLConfig.CREATOR);
        break;
      case 3: 
        str2 = a.l(paramParcel, k);
        break;
      case 4: 
        bool = a.c(paramParcel, k);
        break;
      case 5: 
        str1 = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new FACLData(j, localFACLConfig, str2, bool, str1);
  }
  
  public FACLData[] V(int paramInt)
  {
    return new FACLData[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.f
 * JD-Core Version:    0.7.0.1
 */