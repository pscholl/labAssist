package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface u
  extends IInterface
{
  public abstract AccountNameCheckResponse checkAccountName(AccountNameCheckRequest paramAccountNameCheckRequest)
    throws RemoteException;
  
  public abstract PasswordCheckResponse checkPassword(PasswordCheckRequest paramPasswordCheckRequest)
    throws RemoteException;
  
  public abstract CheckRealNameResponse checkRealName(CheckRealNameRequest paramCheckRealNameRequest)
    throws RemoteException;
  
  public abstract ClearTokenResponse clearToken(ClearTokenRequest paramClearTokenRequest)
    throws RemoteException;
  
  public abstract TokenResponse confirmCredentials(ConfirmCredentialsRequest paramConfirmCredentialsRequest)
    throws RemoteException;
  
  public abstract TokenResponse createAccount(GoogleAccountSetupRequest paramGoogleAccountSetupRequest)
    throws RemoteException;
  
  public abstract TokenResponse createPlusProfile(GoogleAccountSetupRequest paramGoogleAccountSetupRequest)
    throws RemoteException;
  
  public abstract GoogleAccountData getAccountData(String paramString)
    throws RemoteException;
  
  public abstract Bundle getAccountExportData(String paramString)
    throws RemoteException;
  
  public abstract AccountRecoveryData getAccountRecoveryCountryInfo()
    throws RemoteException;
  
  public abstract AccountRecoveryData getAccountRecoveryData(AccountRecoveryDataRequest paramAccountRecoveryDataRequest)
    throws RemoteException;
  
  public abstract AccountRecoveryGuidance getAccountRecoveryGuidance(AccountRecoveryGuidanceRequest paramAccountRecoveryGuidanceRequest)
    throws RemoteException;
  
  public abstract GplusInfoResponse getGplusInfo(GplusInfoRequest paramGplusInfoRequest)
    throws RemoteException;
  
  public abstract TokenResponse getToken(TokenRequest paramTokenRequest)
    throws RemoteException;
  
  public abstract WebSetupConfig getWebSetupConfig(WebSetupConfigRequest paramWebSetupConfigRequest)
    throws RemoteException;
  
  public abstract boolean installAccountFromExportData(String paramString, Bundle paramBundle)
    throws RemoteException;
  
  public abstract AccountRemovalResponse removeAccount(AccountRemovalRequest paramAccountRemovalRequest)
    throws RemoteException;
  
  public abstract TokenResponse signIn(AccountSignInRequest paramAccountSignInRequest)
    throws RemoteException;
  
  public abstract AccountRecoveryUpdateResult updateAccountRecoveryData(AccountRecoveryUpdateRequest paramAccountRecoveryUpdateRequest)
    throws RemoteException;
  
  public abstract TokenResponse updateCredentials(UpdateCredentialsRequest paramUpdateCredentialsRequest)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements u
  {
    public static u i(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
      if ((localIInterface != null) && ((localIInterface instanceof u))) {
        return (u)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        return true;
      case 1: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        GoogleAccountData localGoogleAccountData = getAccountData(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localGoogleAccountData != null)
        {
          paramParcel2.writeInt(1);
          localGoogleAccountData.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 2: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i13 = paramParcel1.readInt();
        AccountNameCheckRequest localAccountNameCheckRequest = null;
        if (i13 != 0) {
          localAccountNameCheckRequest = AccountNameCheckRequest.CREATOR.g(paramParcel1);
        }
        AccountNameCheckResponse localAccountNameCheckResponse = checkAccountName(localAccountNameCheckRequest);
        paramParcel2.writeNoException();
        if (localAccountNameCheckResponse != null)
        {
          paramParcel2.writeInt(1);
          localAccountNameCheckResponse.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 3: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i12 = paramParcel1.readInt();
        PasswordCheckRequest localPasswordCheckRequest = null;
        if (i12 != 0) {
          localPasswordCheckRequest = PasswordCheckRequest.CREATOR.A(paramParcel1);
        }
        PasswordCheckResponse localPasswordCheckResponse = checkPassword(localPasswordCheckRequest);
        paramParcel2.writeNoException();
        if (localPasswordCheckResponse != null)
        {
          paramParcel2.writeInt(1);
          localPasswordCheckResponse.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 4: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i11 = paramParcel1.readInt();
        CheckRealNameRequest localCheckRealNameRequest = null;
        if (i11 != 0) {
          localCheckRealNameRequest = CheckRealNameRequest.CREATOR.r(paramParcel1);
        }
        CheckRealNameResponse localCheckRealNameResponse = checkRealName(localCheckRealNameRequest);
        paramParcel2.writeNoException();
        if (localCheckRealNameResponse != null)
        {
          paramParcel2.writeInt(1);
          localCheckRealNameResponse.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 5: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i10 = paramParcel1.readInt();
        GoogleAccountSetupRequest localGoogleAccountSetupRequest2 = null;
        if (i10 != 0) {
          localGoogleAccountSetupRequest2 = GoogleAccountSetupRequest.CREATOR.x(paramParcel1);
        }
        TokenResponse localTokenResponse6 = createAccount(localGoogleAccountSetupRequest2);
        paramParcel2.writeNoException();
        if (localTokenResponse6 != null)
        {
          paramParcel2.writeInt(1);
          localTokenResponse6.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 6: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i9 = paramParcel1.readInt();
        GplusInfoRequest localGplusInfoRequest = null;
        if (i9 != 0) {
          localGplusInfoRequest = GplusInfoRequest.CREATOR.y(paramParcel1);
        }
        GplusInfoResponse localGplusInfoResponse = getGplusInfo(localGplusInfoRequest);
        paramParcel2.writeNoException();
        if (localGplusInfoResponse != null)
        {
          paramParcel2.writeInt(1);
          localGplusInfoResponse.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 7: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i8 = paramParcel1.readInt();
        GoogleAccountSetupRequest localGoogleAccountSetupRequest1 = null;
        if (i8 != 0) {
          localGoogleAccountSetupRequest1 = GoogleAccountSetupRequest.CREATOR.x(paramParcel1);
        }
        TokenResponse localTokenResponse5 = createPlusProfile(localGoogleAccountSetupRequest1);
        paramParcel2.writeNoException();
        if (localTokenResponse5 != null)
        {
          paramParcel2.writeInt(1);
          localTokenResponse5.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 8: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i7 = paramParcel1.readInt();
        TokenRequest localTokenRequest = null;
        if (i7 != 0) {
          localTokenRequest = TokenRequest.CREATOR.C(paramParcel1);
        }
        TokenResponse localTokenResponse4 = getToken(localTokenRequest);
        paramParcel2.writeNoException();
        if (localTokenResponse4 != null)
        {
          paramParcel2.writeInt(1);
          localTokenResponse4.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 9: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i6 = paramParcel1.readInt();
        AccountSignInRequest localAccountSignInRequest = null;
        if (i6 != 0) {
          localAccountSignInRequest = AccountSignInRequest.CREATOR.q(paramParcel1);
        }
        TokenResponse localTokenResponse3 = signIn(localAccountSignInRequest);
        paramParcel2.writeNoException();
        if (localTokenResponse3 != null)
        {
          paramParcel2.writeInt(1);
          localTokenResponse3.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 10: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i5 = paramParcel1.readInt();
        ConfirmCredentialsRequest localConfirmCredentialsRequest = null;
        if (i5 != 0) {
          localConfirmCredentialsRequest = ConfirmCredentialsRequest.CREATOR.v(paramParcel1);
        }
        TokenResponse localTokenResponse2 = confirmCredentials(localConfirmCredentialsRequest);
        paramParcel2.writeNoException();
        if (localTokenResponse2 != null)
        {
          paramParcel2.writeInt(1);
          localTokenResponse2.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 11: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i4 = paramParcel1.readInt();
        UpdateCredentialsRequest localUpdateCredentialsRequest = null;
        if (i4 != 0) {
          localUpdateCredentialsRequest = UpdateCredentialsRequest.CREATOR.E(paramParcel1);
        }
        TokenResponse localTokenResponse1 = updateCredentials(localUpdateCredentialsRequest);
        paramParcel2.writeNoException();
        if (localTokenResponse1 != null)
        {
          paramParcel2.writeInt(1);
          localTokenResponse1.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 12: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        AccountRecoveryData localAccountRecoveryData2 = getAccountRecoveryCountryInfo();
        paramParcel2.writeNoException();
        if (localAccountRecoveryData2 != null)
        {
          paramParcel2.writeInt(1);
          localAccountRecoveryData2.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 13: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i3 = paramParcel1.readInt();
        AccountRecoveryDataRequest localAccountRecoveryDataRequest = null;
        if (i3 != 0) {
          localAccountRecoveryDataRequest = AccountRecoveryDataRequest.CREATOR.j(paramParcel1);
        }
        AccountRecoveryData localAccountRecoveryData1 = getAccountRecoveryData(localAccountRecoveryDataRequest);
        paramParcel2.writeNoException();
        if (localAccountRecoveryData1 != null)
        {
          paramParcel2.writeInt(1);
          localAccountRecoveryData1.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 14: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i2 = paramParcel1.readInt();
        AccountRecoveryUpdateRequest localAccountRecoveryUpdateRequest = null;
        if (i2 != 0) {
          localAccountRecoveryUpdateRequest = AccountRecoveryUpdateRequest.CREATOR.m(paramParcel1);
        }
        AccountRecoveryUpdateResult localAccountRecoveryUpdateResult = updateAccountRecoveryData(localAccountRecoveryUpdateRequest);
        paramParcel2.writeNoException();
        if (localAccountRecoveryUpdateResult != null)
        {
          paramParcel2.writeInt(1);
          localAccountRecoveryUpdateResult.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 15: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int i1 = paramParcel1.readInt();
        AccountRecoveryGuidanceRequest localAccountRecoveryGuidanceRequest = null;
        if (i1 != 0) {
          localAccountRecoveryGuidanceRequest = AccountRecoveryGuidanceRequest.CREATOR.l(paramParcel1);
        }
        AccountRecoveryGuidance localAccountRecoveryGuidance = getAccountRecoveryGuidance(localAccountRecoveryGuidanceRequest);
        paramParcel2.writeNoException();
        if (localAccountRecoveryGuidance != null)
        {
          paramParcel2.writeInt(1);
          localAccountRecoveryGuidance.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 16: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        Bundle localBundle2 = getAccountExportData(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localBundle2 != null)
        {
          paramParcel2.writeInt(1);
          localBundle2.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 17: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        String str = paramParcel1.readString();
        int m = paramParcel1.readInt();
        Bundle localBundle1 = null;
        if (m != 0) {
          localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
        }
        boolean bool = installAccountFromExportData(str, localBundle1);
        paramParcel2.writeNoException();
        if (bool) {}
        for (int n = 1;; n = 0)
        {
          paramParcel2.writeInt(n);
          return true;
        }
      case 18: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int k = paramParcel1.readInt();
        WebSetupConfigRequest localWebSetupConfigRequest = null;
        if (k != 0) {
          localWebSetupConfigRequest = WebSetupConfigRequest.CREATOR.G(paramParcel1);
        }
        WebSetupConfig localWebSetupConfig = getWebSetupConfig(localWebSetupConfigRequest);
        paramParcel2.writeNoException();
        if (localWebSetupConfig != null)
        {
          paramParcel2.writeInt(1);
          localWebSetupConfig.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 19: 
        paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
        int j = paramParcel1.readInt();
        ClearTokenRequest localClearTokenRequest = null;
        if (j != 0) {
          localClearTokenRequest = ClearTokenRequest.CREATOR.t(paramParcel1);
        }
        ClearTokenResponse localClearTokenResponse = clearToken(localClearTokenRequest);
        paramParcel2.writeNoException();
        if (localClearTokenResponse != null)
        {
          paramParcel2.writeInt(1);
          localClearTokenResponse.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
      int i = paramParcel1.readInt();
      AccountRemovalRequest localAccountRemovalRequest = null;
      if (i != 0) {
        localAccountRemovalRequest = AccountRemovalRequest.CREATOR.o(paramParcel1);
      }
      AccountRemovalResponse localAccountRemovalResponse = removeAccount(localAccountRemovalRequest);
      paramParcel2.writeNoException();
      if (localAccountRemovalResponse != null)
      {
        paramParcel2.writeInt(1);
        localAccountRemovalResponse.writeToParcel(paramParcel2, 1);
        return true;
      }
      paramParcel2.writeInt(0);
      return true;
    }
    
    private static class a
      implements u
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public AccountNameCheckResponse checkAccountName(AccountNameCheckRequest paramAccountNameCheckRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramAccountNameCheckRequest != null)
            {
              localParcel1.writeInt(1);
              paramAccountNameCheckRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(2, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                AccountNameCheckResponse localAccountNameCheckResponse2 = AccountNameCheckResponse.CREATOR.h(localParcel2);
                localAccountNameCheckResponse1 = localAccountNameCheckResponse2;
                return localAccountNameCheckResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            AccountNameCheckResponse localAccountNameCheckResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public PasswordCheckResponse checkPassword(PasswordCheckRequest paramPasswordCheckRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramPasswordCheckRequest != null)
            {
              localParcel1.writeInt(1);
              paramPasswordCheckRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(3, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                PasswordCheckResponse localPasswordCheckResponse2 = PasswordCheckResponse.CREATOR.B(localParcel2);
                localPasswordCheckResponse1 = localPasswordCheckResponse2;
                return localPasswordCheckResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PasswordCheckResponse localPasswordCheckResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public CheckRealNameResponse checkRealName(CheckRealNameRequest paramCheckRealNameRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramCheckRealNameRequest != null)
            {
              localParcel1.writeInt(1);
              paramCheckRealNameRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(4, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                CheckRealNameResponse localCheckRealNameResponse2 = CheckRealNameResponse.CREATOR.s(localParcel2);
                localCheckRealNameResponse1 = localCheckRealNameResponse2;
                return localCheckRealNameResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            CheckRealNameResponse localCheckRealNameResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public ClearTokenResponse clearToken(ClearTokenRequest paramClearTokenRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramClearTokenRequest != null)
            {
              localParcel1.writeInt(1);
              paramClearTokenRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(19, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                ClearTokenResponse localClearTokenResponse2 = ClearTokenResponse.CREATOR.u(localParcel2);
                localClearTokenResponse1 = localClearTokenResponse2;
                return localClearTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ClearTokenResponse localClearTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public TokenResponse confirmCredentials(ConfirmCredentialsRequest paramConfirmCredentialsRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramConfirmCredentialsRequest != null)
            {
              localParcel1.writeInt(1);
              paramConfirmCredentialsRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(10, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                TokenResponse localTokenResponse2 = TokenResponse.CREATOR.D(localParcel2);
                localTokenResponse1 = localTokenResponse2;
                return localTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            TokenResponse localTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public TokenResponse createAccount(GoogleAccountSetupRequest paramGoogleAccountSetupRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramGoogleAccountSetupRequest != null)
            {
              localParcel1.writeInt(1);
              paramGoogleAccountSetupRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(5, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                TokenResponse localTokenResponse2 = TokenResponse.CREATOR.D(localParcel2);
                localTokenResponse1 = localTokenResponse2;
                return localTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            TokenResponse localTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public TokenResponse createPlusProfile(GoogleAccountSetupRequest paramGoogleAccountSetupRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramGoogleAccountSetupRequest != null)
            {
              localParcel1.writeInt(1);
              paramGoogleAccountSetupRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(7, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                TokenResponse localTokenResponse2 = TokenResponse.CREATOR.D(localParcel2);
                localTokenResponse1 = localTokenResponse2;
                return localTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            TokenResponse localTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public GoogleAccountData getAccountData(String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: aload_1
        //   16: invokevirtual 146	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   19: aload_0
        //   20: getfield 15	com/google/android/gms/auth/firstparty/dataservice/u$a$a:jR	Landroid/os/IBinder;
        //   23: iconst_1
        //   24: aload_2
        //   25: aload_3
        //   26: iconst_0
        //   27: invokeinterface 49 5 0
        //   32: pop
        //   33: aload_3
        //   34: invokevirtual 52	android/os/Parcel:readException	()V
        //   37: aload_3
        //   38: invokevirtual 56	android/os/Parcel:readInt	()I
        //   41: ifeq +27 -> 68
        //   44: getstatic 151	com/google/android/gms/auth/firstparty/dataservice/GoogleAccountData:CREATOR	Lcom/google/android/gms/auth/firstparty/dataservice/q;
        //   47: aload_3
        //   48: invokevirtual 157	com/google/android/gms/auth/firstparty/dataservice/q:w	(Landroid/os/Parcel;)Lcom/google/android/gms/auth/firstparty/dataservice/GoogleAccountData;
        //   51: astore 7
        //   53: aload 7
        //   55: astore 6
        //   57: aload_3
        //   58: invokevirtual 71	android/os/Parcel:recycle	()V
        //   61: aload_2
        //   62: invokevirtual 71	android/os/Parcel:recycle	()V
        //   65: aload 6
        //   67: areturn
        //   68: aconst_null
        //   69: astore 6
        //   71: goto -14 -> 57
        //   74: astore 4
        //   76: aload_3
        //   77: invokevirtual 71	android/os/Parcel:recycle	()V
        //   80: aload_2
        //   81: invokevirtual 71	android/os/Parcel:recycle	()V
        //   84: aload 4
        //   86: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	87	0	this	a
        //   0	87	1	paramString	String
        //   3	78	2	localParcel1	Parcel
        //   7	70	3	localParcel2	Parcel
        //   74	11	4	localObject	Object
        //   55	15	6	localGoogleAccountData1	GoogleAccountData
        //   51	3	7	localGoogleAccountData2	GoogleAccountData
        // Exception table:
        //   from	to	target	type
        //   8	53	74	finally
      }
      
      /* Error */
      public Bundle getAccountExportData(String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: aload_1
        //   16: invokevirtual 146	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   19: aload_0
        //   20: getfield 15	com/google/android/gms/auth/firstparty/dataservice/u$a$a:jR	Landroid/os/IBinder;
        //   23: bipush 16
        //   25: aload_2
        //   26: aload_3
        //   27: iconst_0
        //   28: invokeinterface 49 5 0
        //   33: pop
        //   34: aload_3
        //   35: invokevirtual 52	android/os/Parcel:readException	()V
        //   38: aload_3
        //   39: invokevirtual 56	android/os/Parcel:readInt	()I
        //   42: ifeq +28 -> 70
        //   45: getstatic 164	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
        //   48: aload_3
        //   49: invokeinterface 170 2 0
        //   54: checkcast 161	android/os/Bundle
        //   57: astore 6
        //   59: aload_3
        //   60: invokevirtual 71	android/os/Parcel:recycle	()V
        //   63: aload_2
        //   64: invokevirtual 71	android/os/Parcel:recycle	()V
        //   67: aload 6
        //   69: areturn
        //   70: aconst_null
        //   71: astore 6
        //   73: goto -14 -> 59
        //   76: astore 4
        //   78: aload_3
        //   79: invokevirtual 71	android/os/Parcel:recycle	()V
        //   82: aload_2
        //   83: invokevirtual 71	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	a
        //   0	89	1	paramString	String
        //   3	80	2	localParcel1	Parcel
        //   7	72	3	localParcel2	Parcel
        //   76	11	4	localObject	Object
        //   57	15	6	localBundle	Bundle
        // Exception table:
        //   from	to	target	type
        //   8	59	76	finally
      }
      
      /* Error */
      public AccountRecoveryData getAccountRecoveryCountryInfo()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	com/google/android/gms/auth/firstparty/dataservice/u$a$a:jR	Landroid/os/IBinder;
        //   18: bipush 12
        //   20: aload_1
        //   21: aload_2
        //   22: iconst_0
        //   23: invokeinterface 49 5 0
        //   28: pop
        //   29: aload_2
        //   30: invokevirtual 52	android/os/Parcel:readException	()V
        //   33: aload_2
        //   34: invokevirtual 56	android/os/Parcel:readInt	()I
        //   37: ifeq +27 -> 64
        //   40: getstatic 177	com/google/android/gms/auth/firstparty/dataservice/AccountRecoveryData:CREATOR	Lcom/google/android/gms/auth/firstparty/dataservice/c;
        //   43: aload_2
        //   44: invokevirtual 183	com/google/android/gms/auth/firstparty/dataservice/c:i	(Landroid/os/Parcel;)Lcom/google/android/gms/auth/firstparty/dataservice/AccountRecoveryData;
        //   47: astore 6
        //   49: aload 6
        //   51: astore 5
        //   53: aload_2
        //   54: invokevirtual 71	android/os/Parcel:recycle	()V
        //   57: aload_1
        //   58: invokevirtual 71	android/os/Parcel:recycle	()V
        //   61: aload 5
        //   63: areturn
        //   64: aconst_null
        //   65: astore 5
        //   67: goto -14 -> 53
        //   70: astore_3
        //   71: aload_2
        //   72: invokevirtual 71	android/os/Parcel:recycle	()V
        //   75: aload_1
        //   76: invokevirtual 71	android/os/Parcel:recycle	()V
        //   79: aload_3
        //   80: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	81	0	this	a
        //   3	73	1	localParcel1	Parcel
        //   7	65	2	localParcel2	Parcel
        //   70	10	3	localObject	Object
        //   51	15	5	localAccountRecoveryData1	AccountRecoveryData
        //   47	3	6	localAccountRecoveryData2	AccountRecoveryData
        // Exception table:
        //   from	to	target	type
        //   8	49	70	finally
      }
      
      public AccountRecoveryData getAccountRecoveryData(AccountRecoveryDataRequest paramAccountRecoveryDataRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramAccountRecoveryDataRequest != null)
            {
              localParcel1.writeInt(1);
              paramAccountRecoveryDataRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(13, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                AccountRecoveryData localAccountRecoveryData2 = AccountRecoveryData.CREATOR.i(localParcel2);
                localAccountRecoveryData1 = localAccountRecoveryData2;
                return localAccountRecoveryData1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            AccountRecoveryData localAccountRecoveryData1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public AccountRecoveryGuidance getAccountRecoveryGuidance(AccountRecoveryGuidanceRequest paramAccountRecoveryGuidanceRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramAccountRecoveryGuidanceRequest != null)
            {
              localParcel1.writeInt(1);
              paramAccountRecoveryGuidanceRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(15, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                AccountRecoveryGuidance localAccountRecoveryGuidance2 = AccountRecoveryGuidance.CREATOR.k(localParcel2);
                localAccountRecoveryGuidance1 = localAccountRecoveryGuidance2;
                return localAccountRecoveryGuidance1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            AccountRecoveryGuidance localAccountRecoveryGuidance1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public GplusInfoResponse getGplusInfo(GplusInfoRequest paramGplusInfoRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramGplusInfoRequest != null)
            {
              localParcel1.writeInt(1);
              paramGplusInfoRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(6, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                GplusInfoResponse localGplusInfoResponse2 = GplusInfoResponse.CREATOR.z(localParcel2);
                localGplusInfoResponse1 = localGplusInfoResponse2;
                return localGplusInfoResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            GplusInfoResponse localGplusInfoResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public TokenResponse getToken(TokenRequest paramTokenRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramTokenRequest != null)
            {
              localParcel1.writeInt(1);
              paramTokenRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(8, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                TokenResponse localTokenResponse2 = TokenResponse.CREATOR.D(localParcel2);
                localTokenResponse1 = localTokenResponse2;
                return localTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            TokenResponse localTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public WebSetupConfig getWebSetupConfig(WebSetupConfigRequest paramWebSetupConfigRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramWebSetupConfigRequest != null)
            {
              localParcel1.writeInt(1);
              paramWebSetupConfigRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(18, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                WebSetupConfig localWebSetupConfig2 = WebSetupConfig.CREATOR.F(localParcel2);
                localWebSetupConfig1 = localWebSetupConfig2;
                return localWebSetupConfig1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            WebSetupConfig localWebSetupConfig1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean installAccountFromExportData(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            localParcel1.writeString(paramString);
            if (paramBundle != null)
            {
              localParcel1.writeInt(1);
              paramBundle.writeToParcel(localParcel1, 0);
              this.jR.transact(17, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public AccountRemovalResponse removeAccount(AccountRemovalRequest paramAccountRemovalRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramAccountRemovalRequest != null)
            {
              localParcel1.writeInt(1);
              paramAccountRemovalRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(20, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                AccountRemovalResponse localAccountRemovalResponse2 = AccountRemovalResponse.CREATOR.p(localParcel2);
                localAccountRemovalResponse1 = localAccountRemovalResponse2;
                return localAccountRemovalResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            AccountRemovalResponse localAccountRemovalResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public TokenResponse signIn(AccountSignInRequest paramAccountSignInRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramAccountSignInRequest != null)
            {
              localParcel1.writeInt(1);
              paramAccountSignInRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(9, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                TokenResponse localTokenResponse2 = TokenResponse.CREATOR.D(localParcel2);
                localTokenResponse1 = localTokenResponse2;
                return localTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            TokenResponse localTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public AccountRecoveryUpdateResult updateAccountRecoveryData(AccountRecoveryUpdateRequest paramAccountRecoveryUpdateRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramAccountRecoveryUpdateRequest != null)
            {
              localParcel1.writeInt(1);
              paramAccountRecoveryUpdateRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(14, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                AccountRecoveryUpdateResult localAccountRecoveryUpdateResult2 = AccountRecoveryUpdateResult.CREATOR.n(localParcel2);
                localAccountRecoveryUpdateResult1 = localAccountRecoveryUpdateResult2;
                return localAccountRecoveryUpdateResult1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            AccountRecoveryUpdateResult localAccountRecoveryUpdateResult1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public TokenResponse updateCredentials(UpdateCredentialsRequest paramUpdateCredentialsRequest)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.auth.firstparty.dataservice.IGoogleAccountDataService");
            if (paramUpdateCredentialsRequest != null)
            {
              localParcel1.writeInt(1);
              paramUpdateCredentialsRequest.writeToParcel(localParcel1, 0);
              this.jR.transact(11, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                TokenResponse localTokenResponse2 = TokenResponse.CREATOR.D(localParcel2);
                localTokenResponse1 = localTokenResponse2;
                return localTokenResponse1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            TokenResponse localTokenResponse1 = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.u
 * JD-Core Version:    0.7.0.1
 */