package com.google.android.gms.auth.firstparty.delegate;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class SetupAccountWorkflowRequest
  implements SafeParcelable
{
  public static final c CREATOR = new c();
  public final AppDescription callingAppDescription;
  boolean pP;
  boolean pQ;
  List<String> pR;
  Bundle pj;
  final int version;
  
  SetupAccountWorkflowRequest(int paramInt, boolean paramBoolean1, boolean paramBoolean2, List<String> paramList, Bundle paramBundle, AppDescription paramAppDescription)
  {
    this.version = paramInt;
    this.pP = paramBoolean1;
    this.pQ = paramBoolean2;
    this.pR = paramList;
    this.pj = paramBundle;
    this.callingAppDescription = ((AppDescription)at.f(paramAppDescription));
  }
  
  public SetupAccountWorkflowRequest(AppDescription paramAppDescription)
  {
    this.version = 1;
    this.pj = new Bundle();
    this.callingAppDescription = paramAppDescription;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public List<String> getAllowedDomains()
  {
    return Collections.unmodifiableList(this.pR);
  }
  
  public Bundle getOptions()
  {
    return new Bundle(this.pj);
  }
  
  public boolean isBackupAccount()
  {
    return this.pQ;
  }
  
  public boolean isMultiUser()
  {
    return this.pP;
  }
  
  public SetupAccountWorkflowRequest setAllowedDomains(Collection<String> paramCollection)
  {
    if (paramCollection != null)
    {
      this.pR = new ArrayList(paramCollection);
      return this;
    }
    this.pR = null;
    return this;
  }
  
  public SetupAccountWorkflowRequest setBackupAccount(boolean paramBoolean)
  {
    this.pQ = paramBoolean;
    return this;
  }
  
  public SetupAccountWorkflowRequest setMultiUser(boolean paramBoolean)
  {
    this.pP = paramBoolean;
    return this;
  }
  
  public SetupAccountWorkflowRequest setOptions(Bundle paramBundle)
  {
    this.pj.clear();
    this.pj.putAll(paramBundle);
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.delegate.SetupAccountWorkflowRequest
 * JD-Core Version:    0.7.0.1
 */