package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class i
  implements Parcelable.Creator<AccountRemovalRequest>
{
  static void a(AccountRemovalRequest paramAccountRemovalRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountRemovalRequest.version);
    b.a(paramParcel, 2, paramAccountRemovalRequest.accountName, false);
    b.C(paramParcel, i);
  }
  
  public AccountRemovalRequest o(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    String str = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountRemovalRequest(j, str);
  }
  
  public AccountRemovalRequest[] t(int paramInt)
  {
    return new AccountRemovalRequest[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.i
 * JD-Core Version:    0.7.0.1
 */