package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.AccountCredentials;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class r
  implements Parcelable.Creator<GoogleAccountSetupRequest>
{
  static void a(GoogleAccountSetupRequest paramGoogleAccountSetupRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramGoogleAccountSetupRequest.version);
    b.a(paramParcel, 2, paramGoogleAccountSetupRequest.pj, false);
    b.a(paramParcel, 3, paramGoogleAccountSetupRequest.pk);
    b.a(paramParcel, 4, paramGoogleAccountSetupRequest.pl);
    b.a(paramParcel, 5, paramGoogleAccountSetupRequest.pm);
    b.a(paramParcel, 6, paramGoogleAccountSetupRequest.oN, false);
    b.a(paramParcel, 7, paramGoogleAccountSetupRequest.oO, false);
    b.a(paramParcel, 8, paramGoogleAccountSetupRequest.secondaryEmail, false);
    b.a(paramParcel, 9, paramGoogleAccountSetupRequest.pn, false);
    b.a(paramParcel, 10, paramGoogleAccountSetupRequest.oK);
    b.a(paramParcel, 11, paramGoogleAccountSetupRequest.po);
    b.a(paramParcel, 12, paramGoogleAccountSetupRequest.oL);
    b.a(paramParcel, 13, paramGoogleAccountSetupRequest.pp, false);
    b.a(paramParcel, 14, paramGoogleAccountSetupRequest.callingAppDescription, paramInt, false);
    b.a(paramParcel, 15, paramGoogleAccountSetupRequest.oM, paramInt, false);
    b.a(paramParcel, 17, paramGoogleAccountSetupRequest.phoneNumber, false);
    b.a(paramParcel, 16, paramGoogleAccountSetupRequest.os, paramInt, false);
    b.a(paramParcel, 18, paramGoogleAccountSetupRequest.phoneCountryCode, false);
    b.C(paramParcel, i);
  }
  
  public GoogleAccountSetupRequest[] C(int paramInt)
  {
    return new GoogleAccountSetupRequest[paramInt];
  }
  
  public GoogleAccountSetupRequest x(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    Bundle localBundle = new Bundle();
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    String str5 = null;
    AppDescription localAppDescription = null;
    AccountCredentials localAccountCredentials = null;
    CaptchaSolution localCaptchaSolution = null;
    String str6 = null;
    String str7 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localBundle = a.n(paramParcel, k);
        break;
      case 3: 
        bool1 = a.c(paramParcel, k);
        break;
      case 4: 
        bool2 = a.c(paramParcel, k);
        break;
      case 5: 
        bool3 = a.c(paramParcel, k);
        break;
      case 6: 
        str1 = a.l(paramParcel, k);
        break;
      case 7: 
        str2 = a.l(paramParcel, k);
        break;
      case 8: 
        str3 = a.l(paramParcel, k);
        break;
      case 9: 
        str4 = a.l(paramParcel, k);
        break;
      case 10: 
        bool4 = a.c(paramParcel, k);
        break;
      case 11: 
        bool5 = a.c(paramParcel, k);
        break;
      case 12: 
        bool6 = a.c(paramParcel, k);
        break;
      case 13: 
        str5 = a.l(paramParcel, k);
        break;
      case 14: 
        localAppDescription = (AppDescription)a.a(paramParcel, k, AppDescription.CREATOR);
        break;
      case 15: 
        localAccountCredentials = (AccountCredentials)a.a(paramParcel, k, AccountCredentials.CREATOR);
        break;
      case 17: 
        str6 = a.l(paramParcel, k);
        break;
      case 16: 
        localCaptchaSolution = (CaptchaSolution)a.a(paramParcel, k, CaptchaSolution.CREATOR);
        break;
      case 18: 
        str7 = a.l(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new GoogleAccountSetupRequest(j, localBundle, bool1, bool2, bool3, str1, str2, str3, str4, bool4, bool5, bool6, str5, localAppDescription, localAccountCredentials, localCaptchaSolution, str6, str7);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.r
 * JD-Core Version:    0.7.0.1
 */