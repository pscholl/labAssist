package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.firstparty.shared.CaptchaChallenge;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import java.util.ArrayList;

public class b
  implements Parcelable.Creator<AccountNameCheckResponse>
{
  static void a(AccountNameCheckResponse paramAccountNameCheckResponse, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramAccountNameCheckResponse.version);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, paramAccountNameCheckResponse.ot, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramAccountNameCheckResponse.ou, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 4, paramAccountNameCheckResponse.ov, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 5, paramAccountNameCheckResponse.ow, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public AccountNameCheckResponse h(Parcel paramParcel)
  {
    CaptchaChallenge localCaptchaChallenge = null;
    int i = a.Y(paramParcel);
    int j = 0;
    String str1 = null;
    ArrayList localArrayList = null;
    String str2 = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str2 = a.l(paramParcel, k);
        break;
      case 3: 
        localArrayList = a.x(paramParcel, k);
        break;
      case 4: 
        str1 = a.l(paramParcel, k);
        break;
      case 5: 
        localCaptchaChallenge = (CaptchaChallenge)a.a(paramParcel, k, CaptchaChallenge.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountNameCheckResponse(j, str2, localArrayList, str1, localCaptchaChallenge);
  }
  
  public AccountNameCheckResponse[] m(int paramInt)
  {
    return new AccountNameCheckResponse[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.b
 * JD-Core Version:    0.7.0.1
 */