package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AccountCredentials;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ConfirmCredentialsRequest
  implements SafeParcelable
{
  public static final p CREATOR = new p();
  AccountCredentials oM;
  CaptchaSolution os;
  final int version;
  
  public ConfirmCredentialsRequest()
  {
    this.version = 1;
  }
  
  ConfirmCredentialsRequest(int paramInt, AccountCredentials paramAccountCredentials, CaptchaSolution paramCaptchaSolution)
  {
    this.version = paramInt;
    this.oM = paramAccountCredentials;
    this.os = paramCaptchaSolution;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public AccountCredentials getAccountCredentials()
  {
    return this.oM;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public ConfirmCredentialsRequest setAccountCredentials(AccountCredentials paramAccountCredentials)
  {
    this.oM = paramAccountCredentials;
    return this;
  }
  
  public ConfirmCredentialsRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    p.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.ConfirmCredentialsRequest
 * JD-Core Version:    0.7.0.1
 */