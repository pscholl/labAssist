package com.google.android.gms.auth.firstparty.shared;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountCredentials
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  boolean pT;
  String pU;
  String pV;
  String pW;
  String pX;
  String pY;
  final int version;
  
  public AccountCredentials()
  {
    this.version = 1;
  }
  
  AccountCredentials(int paramInt, boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    this.version = paramInt;
    this.pT = paramBoolean;
    this.pU = paramString1;
    this.pV = paramString2;
    this.pW = paramString3;
    this.pX = paramString4;
    this.pY = paramString5;
  }
  
  public AccountCredentials(Parcel paramParcel)
  {
    this.version = i;
    if (paramParcel.readInt() == i) {}
    for (;;)
    {
      this.pT = i;
      this.pV = paramParcel.readString();
      this.pU = paramParcel.readString();
      this.pW = paramParcel.readString();
      this.pX = paramParcel.readString();
      this.pY = paramParcel.readString();
      return;
      i = 0;
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getAccountName()
  {
    return this.pU;
  }
  
  public String getAuthorizationCode()
  {
    return this.pW;
  }
  
  public String getLongLivedLoginToken()
  {
    return this.pV;
  }
  
  public String getPassword()
  {
    return this.pX;
  }
  
  public String getVerifier()
  {
    return this.pY;
  }
  
  public boolean isBrowserAuthenticationRequired()
  {
    return this.pT;
  }
  
  public AccountCredentials setAccountName(String paramString)
  {
    this.pU = paramString;
    return this;
  }
  
  public AccountCredentials setAuthorizationCode(String paramString)
  {
    this.pW = paramString;
    return this;
  }
  
  public AccountCredentials setBrowserAuthenticationRequired(boolean paramBoolean)
  {
    this.pT = paramBoolean;
    return this;
  }
  
  public AccountCredentials setLongLivedLoginToken(String paramString)
  {
    this.pV = paramString;
    return this;
  }
  
  public AccountCredentials setPassword(String paramString)
  {
    this.pX = paramString;
    return this;
  }
  
  public AccountCredentials setVerifier(String paramString)
  {
    this.pY = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.shared.AccountCredentials
 * JD-Core Version:    0.7.0.1
 */