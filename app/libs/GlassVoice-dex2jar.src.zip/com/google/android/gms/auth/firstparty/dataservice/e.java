package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class e
  implements Parcelable.Creator<AccountRecoveryGuidance>
{
  static void a(AccountRecoveryGuidance paramAccountRecoveryGuidance, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramAccountRecoveryGuidance.version);
    b.a(paramParcel, 2, paramAccountRecoveryGuidance.accountName, false);
    b.a(paramParcel, 3, paramAccountRecoveryGuidance.isRecoveryInfoNeeded);
    b.a(paramParcel, 4, paramAccountRecoveryGuidance.isRecoveryInterstitialSuggested);
    b.a(paramParcel, 5, paramAccountRecoveryGuidance.isRecoveryUpdateAllowed);
    b.C(paramParcel, i);
  }
  
  public AccountRecoveryGuidance k(Parcel paramParcel)
  {
    boolean bool1 = false;
    int i = a.Y(paramParcel);
    String str = null;
    boolean bool2 = false;
    boolean bool3 = false;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        str = a.l(paramParcel, k);
        break;
      case 3: 
        bool3 = a.c(paramParcel, k);
        break;
      case 4: 
        bool2 = a.c(paramParcel, k);
        break;
      case 5: 
        bool1 = a.c(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new AccountRecoveryGuidance(j, str, bool3, bool2, bool1);
  }
  
  public AccountRecoveryGuidance[] p(int paramInt)
  {
    return new AccountRecoveryGuidance[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.e
 * JD-Core Version:    0.7.0.1
 */