package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;

public class AccountRecoveryDataRequest
  implements SafeParcelable
{
  public static final d CREATOR = new d();
  private static final String oG = "[" + AccountRecoveryDataRequest.class.getSimpleName() + "]";
  public final String accountName;
  public final AppDescription callingAppDescription;
  public final boolean isClearUpdateSuggested;
  public final String requestDescription;
  final int version;
  
  AccountRecoveryDataRequest(int paramInt, String paramString1, boolean paramBoolean, AppDescription paramAppDescription, String paramString2)
  {
    at.b(paramString1, oG + " accountName cannot be empty or null!");
    at.b(paramString2, oG + " requestDescription cannot be empty or null!");
    this.version = paramInt;
    this.accountName = at.C(paramString1);
    this.isClearUpdateSuggested = paramBoolean;
    this.callingAppDescription = ((AppDescription)at.f(paramAppDescription));
    this.requestDescription = paramString2;
  }
  
  public AccountRecoveryDataRequest(String paramString1, boolean paramBoolean, AppDescription paramAppDescription, String paramString2)
  {
    this(0, paramString1, paramBoolean, paramAppDescription, paramString2);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    d.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountRecoveryDataRequest
 * JD-Core Version:    0.7.0.1
 */