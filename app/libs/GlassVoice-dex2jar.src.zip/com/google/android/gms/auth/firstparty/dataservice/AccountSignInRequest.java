package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.auth.firstparty.shared.AccountCredentials;
import com.google.android.gms.auth.firstparty.shared.AppDescription;
import com.google.android.gms.auth.firstparty.shared.CaptchaSolution;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountSignInRequest
  implements SafeParcelable
{
  public static final k CREATOR = new k();
  AppDescription callingAppDescription;
  boolean oK;
  boolean oL;
  AccountCredentials oM;
  CaptchaSolution os;
  final int version;
  
  public AccountSignInRequest()
  {
    this.version = 1;
  }
  
  AccountSignInRequest(int paramInt, AppDescription paramAppDescription, boolean paramBoolean1, boolean paramBoolean2, CaptchaSolution paramCaptchaSolution, AccountCredentials paramAccountCredentials)
  {
    this.version = paramInt;
    this.callingAppDescription = paramAppDescription;
    this.oK = paramBoolean1;
    this.oL = paramBoolean2;
    this.os = paramCaptchaSolution;
    this.oM = paramAccountCredentials;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public AccountCredentials getAccountCredentials()
  {
    return this.oM;
  }
  
  public AppDescription getCallingAppDescription()
  {
    return this.callingAppDescription;
  }
  
  public CaptchaSolution getCaptchaSolution()
  {
    return this.os;
  }
  
  public boolean isAccountCreationInProgress()
  {
    return this.oK;
  }
  
  public boolean isSetupWizardInProgress()
  {
    return this.oL;
  }
  
  public AccountSignInRequest setAccountCreationInProgress(boolean paramBoolean)
  {
    this.oK = paramBoolean;
    return this;
  }
  
  public AccountSignInRequest setAccountCredentials(AccountCredentials paramAccountCredentials)
  {
    this.oM = paramAccountCredentials;
    return this;
  }
  
  public AccountSignInRequest setBackupAccount(boolean paramBoolean)
  {
    this.oL = paramBoolean;
    return this;
  }
  
  public AccountSignInRequest setCallingAppDescription(AppDescription paramAppDescription)
  {
    this.callingAppDescription = paramAppDescription;
    return this;
  }
  
  public AccountSignInRequest setCaptchaSolution(CaptchaSolution paramCaptchaSolution)
  {
    this.os = paramCaptchaSolution;
    return this;
  }
  
  @Deprecated
  public AccountSignInRequest setSetupWizardInProgress(boolean paramBoolean)
  {
    this.oL = paramBoolean;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    k.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.AccountSignInRequest
 * JD-Core Version:    0.7.0.1
 */