package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ClearTokenRequest
  implements SafeParcelable
{
  public static final n CREATOR = new n();
  String oP;
  final int version;
  
  public ClearTokenRequest()
  {
    this.version = 1;
  }
  
  ClearTokenRequest(int paramInt, String paramString)
  {
    this.version = paramInt;
    this.oP = paramString;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getToken()
  {
    return this.oP;
  }
  
  public ClearTokenRequest setToken(String paramString)
  {
    this.oP = paramString;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    n.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.ClearTokenRequest
 * JD-Core Version:    0.7.0.1
 */