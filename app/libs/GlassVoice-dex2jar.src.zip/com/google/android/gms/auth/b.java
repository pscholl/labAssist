package com.google.android.gms.auth;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;

public class b
  implements Parcelable.Creator<RecoveryDecision>
{
  static void a(RecoveryDecision paramRecoveryDecision, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramRecoveryDecision.oj);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, paramRecoveryDecision.recoveryIntent, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramRecoveryDecision.showRecoveryInterstitial);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 4, paramRecoveryDecision.isRecoveryInfoNeeded);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 5, paramRecoveryDecision.isRecoveryInterstitialAllowed);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 6, paramRecoveryDecision.recoveryIntentWithoutIntro, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public RecoveryDecision c(Parcel paramParcel)
  {
    PendingIntent localPendingIntent1 = null;
    boolean bool1 = false;
    int i = a.Y(paramParcel);
    boolean bool2 = false;
    boolean bool3 = false;
    PendingIntent localPendingIntent2 = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        break;
      case 1: 
        j = a.f(paramParcel, k);
        break;
      case 2: 
        localPendingIntent2 = (PendingIntent)a.a(paramParcel, k, PendingIntent.CREATOR);
        break;
      case 3: 
        bool3 = a.c(paramParcel, k);
        break;
      case 4: 
        bool2 = a.c(paramParcel, k);
        break;
      case 5: 
        bool1 = a.c(paramParcel, k);
        break;
      case 6: 
        localPendingIntent1 = (PendingIntent)a.a(paramParcel, k, PendingIntent.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new RecoveryDecision(j, localPendingIntent2, bool3, bool2, bool1, localPendingIntent1);
  }
  
  public RecoveryDecision[] h(int paramInt)
  {
    return new RecoveryDecision[paramInt];
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.b
 * JD-Core Version:    0.7.0.1
 */