package com.google.android.gms.auth.firstparty.dataservice;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class GplusInfoResponse
  implements SafeParcelable
{
  public static final t CREATOR = new t();
  String oN;
  String oO;
  String pp;
  boolean pq;
  String pr;
  boolean ps;
  boolean pt;
  String pu;
  String pv;
  final int version;
  
  GplusInfoResponse(int paramInt, boolean paramBoolean1, String paramString1, String paramString2, String paramString3, boolean paramBoolean2, boolean paramBoolean3, String paramString4, String paramString5, String paramString6)
  {
    this.version = paramInt;
    this.pq = paramBoolean1;
    this.oN = paramString1;
    this.oO = paramString2;
    this.pr = paramString3;
    this.ps = paramBoolean2;
    this.pt = paramBoolean3;
    this.pu = paramString4;
    this.pp = paramString5;
    this.pv = paramString6;
  }
  
  public GplusInfoResponse(boolean paramBoolean1, String paramString1, String paramString2, String paramString3, boolean paramBoolean2, boolean paramBoolean3, String paramString4, String paramString5, String paramString6)
  {
    this.version = 1;
    this.pq = paramBoolean1;
    this.oN = paramString1;
    this.oO = paramString2;
    this.pr = paramString3;
    this.pu = paramString4;
    this.pp = paramString5;
    this.ps = paramBoolean2;
    this.pt = paramBoolean3;
    this.pv = paramString6;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String getFirstName()
  {
    return this.oN;
  }
  
  public String getLastName()
  {
    return this.oO;
  }
  
  public String getPicasaUser()
  {
    return this.pr;
  }
  
  public String getRopRevision()
  {
    return this.pp;
  }
  
  public String getRopText()
  {
    return this.pu;
  }
  
  public String getWireCode()
  {
    return this.pv;
  }
  
  public boolean hasEsMobile()
  {
    return this.pt;
  }
  
  public boolean hasGooglePlus()
  {
    return this.ps;
  }
  
  public boolean isAllowed()
  {
    return this.pq;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    t.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.firstparty.dataservice.GplusInfoResponse
 * JD-Core Version:    0.7.0.1
 */