package com.google.android.gms.droidguard;

public abstract interface DroidGuardResultsCallback
{
  public abstract void onDroidGuardResults(String paramString);
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.droidguard.DroidGuardResultsCallback
 * JD-Core Version:    0.7.0.1
 */