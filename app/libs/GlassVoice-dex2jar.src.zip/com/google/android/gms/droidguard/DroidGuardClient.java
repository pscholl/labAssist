package com.google.android.gms.droidguard;

import android.content.Context;
import com.google.android.gms.internal.bq;
import java.util.Map;

public class DroidGuardClient
{
  public static String getResults(Context paramContext, String paramString, Map<String, String> paramMap)
  {
    return new bq(paramContext).a(paramString, paramMap);
  }
  
  public static void getResults(Context paramContext, String paramString, Map<String, String> paramMap, DroidGuardResultsCallback paramDroidGuardResultsCallback)
  {
    new bq(paramContext).a(paramString, paramMap, paramDroidGuardResultsCallback);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.droidguard.DroidGuardClient
 * JD-Core Version:    0.7.0.1
 */