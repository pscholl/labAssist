package com.google.android.gms.http;

import android.net.TrafficStats;
import android.os.SystemClock;
import android.util.EventLog;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.entity.HttpEntityWrapper;

class b
  extends HttpEntityWrapper
{
  private final String wn;
  private final int wo;
  private final long wp;
  private final long wq;
  private final long wr;
  private final long ws;
  
  public b(HttpEntity paramHttpEntity, String paramString, int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    super(paramHttpEntity);
    this.wn = paramString;
    this.wo = paramInt;
    this.wp = paramLong1;
    this.wq = paramLong2;
    this.wr = paramLong3;
    this.ws = paramLong4;
  }
  
  public InputStream getContent()
    throws IOException
  {
    return new a(super.getContent());
  }
  
  private class a
    extends FilterInputStream
  {
    public a(InputStream paramInputStream)
    {
      super();
    }
    
    public void close()
      throws IOException
    {
      try
      {
        super.close();
        long l4;
        long l5;
        long l6;
        Object[] arrayOfObject2;
        return;
      }
      finally
      {
        long l1 = SystemClock.elapsedRealtime() - b.a(b.this);
        long l2 = TrafficStats.getUidTxBytes(b.b(b.this));
        long l3 = TrafficStats.getUidRxBytes(b.b(b.this));
        Object[] arrayOfObject1 = new Object[5];
        arrayOfObject1[0] = b.c(b.this);
        arrayOfObject1[1] = Long.valueOf(b.d(b.this));
        arrayOfObject1[2] = Long.valueOf(l1);
        arrayOfObject1[3] = Long.valueOf(l2 - b.e(b.this));
        arrayOfObject1[4] = Long.valueOf(l3 - b.f(b.this));
        EventLog.writeEvent(52001, arrayOfObject1);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.http.b
 * JD-Core Version:    0.7.0.1
 */