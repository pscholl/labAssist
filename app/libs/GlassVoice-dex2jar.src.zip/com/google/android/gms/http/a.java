package com.google.android.gms.http;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface a
  extends IInterface
{
  public abstract Bundle K(String paramString)
    throws RemoteException;
  
  public abstract void f(String paramString, int paramInt)
    throws RemoteException;
  
  public static abstract class a
    extends Binder
    implements a
  {
    public static a y(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.http.IGoogleHttpService");
      if ((localIInterface != null) && ((localIInterface instanceof a))) {
        return (a)localIInterface;
      }
      return new a(paramIBinder);
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("com.google.android.gms.http.IGoogleHttpService");
        return true;
      case 1: 
        paramParcel1.enforceInterface("com.google.android.gms.http.IGoogleHttpService");
        Bundle localBundle = K(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localBundle != null)
        {
          paramParcel2.writeInt(1);
          localBundle.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      }
      paramParcel1.enforceInterface("com.google.android.gms.http.IGoogleHttpService");
      f(paramParcel1.readString(), paramParcel1.readInt());
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class a
      implements a
    {
      private IBinder jR;
      
      a(IBinder paramIBinder)
      {
        this.jR = paramIBinder;
      }
      
      /* Error */
      public Bundle K(String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: aload_1
        //   16: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   19: aload_0
        //   20: getfield 15	com/google/android/gms/http/a$a$a:jR	Landroid/os/IBinder;
        //   23: iconst_1
        //   24: aload_2
        //   25: aload_3
        //   26: iconst_0
        //   27: invokeinterface 40 5 0
        //   32: pop
        //   33: aload_3
        //   34: invokevirtual 43	android/os/Parcel:readException	()V
        //   37: aload_3
        //   38: invokevirtual 47	android/os/Parcel:readInt	()I
        //   41: ifeq +28 -> 69
        //   44: getstatic 53	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
        //   47: aload_3
        //   48: invokeinterface 59 2 0
        //   53: checkcast 49	android/os/Bundle
        //   56: astore 6
        //   58: aload_3
        //   59: invokevirtual 62	android/os/Parcel:recycle	()V
        //   62: aload_2
        //   63: invokevirtual 62	android/os/Parcel:recycle	()V
        //   66: aload 6
        //   68: areturn
        //   69: aconst_null
        //   70: astore 6
        //   72: goto -14 -> 58
        //   75: astore 4
        //   77: aload_3
        //   78: invokevirtual 62	android/os/Parcel:recycle	()V
        //   81: aload_2
        //   82: invokevirtual 62	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	88	0	this	a
        //   0	88	1	paramString	String
        //   3	79	2	localParcel1	Parcel
        //   7	71	3	localParcel2	Parcel
        //   75	11	4	localObject	Object
        //   56	15	6	localBundle	Bundle
        // Exception table:
        //   from	to	target	type
        //   8	58	75	finally
      }
      
      public IBinder asBinder()
      {
        return this.jR;
      }
      
      public void f(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.http.IGoogleHttpService");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.jR.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.http.a
 * JD-Core Version:    0.7.0.1
 */