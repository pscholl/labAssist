package com.google.android.gms.http;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.SSLCertificateSocketFactory;
import android.net.SSLSessionCache;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.RequestLine;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.RequestWrapper;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicStatusLine;
import org.apache.http.params.AbstractHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;

public class GoogleHttpClient
  implements HttpClient
{
  public static final String CONTENT_ENCODING = "content-encoding";
  public static final String CONTENT_LENGTH = "content-length";
  public static final String CONTENT_TYPE = "content-type";
  public static final long DEFAULT_SYNC_MIN_GZIP_BYTES = 256L;
  public static final String RULE_BACKOFF = "backoff";
  public static final String RULE_BLOCK = "block";
  public static final String RULE_NAME = "name";
  public static final String RULE_REWRITE = "rewrite";
  public static final String RULE_STATS = "stats";
  private static final ComponentName wc = new ComponentName("com.google.android.gms", "com.google.android.gms.gcm.http.GoogleHttpService");
  private static final Intent wd = new Intent().setPackage("com.google.android.gms").setComponent(wc);
  private static final String[] wf = { "text/", "application/xml", "application/json" };
  protected int connectTimeout;
  private String kh;
  private Context mContext;
  protected HttpParams mParams = new AbstractHttpParams()
  {
    public HttpParams copy()
    {
      throw new UnsupportedOperationException();
    }
    
    public Object getParameter(String paramAnonymousString)
    {
      return null;
    }
    
    public boolean removeParameter(String paramAnonymousString)
    {
      Log.w("GoogleHttpClient", "Ignoring unsupported remove operation for: " + paramAnonymousString);
      return true;
    }
    
    public HttpParams setParameter(String paramAnonymousString, Object paramAnonymousObject)
    {
      if (paramAnonymousString.equals("http.conn-manager.timeout")) {
        return this;
      }
      if (paramAnonymousString.equals("http.socket.timeout"))
      {
        Integer localInteger2 = (Integer)paramAnonymousObject;
        GoogleHttpClient.this.readTimeout = localInteger2.intValue();
        return this;
      }
      if (paramAnonymousString.equals("http.connection.timeout"))
      {
        Integer localInteger1 = (Integer)paramAnonymousObject;
        GoogleHttpClient.this.connectTimeout = localInteger1.intValue();
        return this;
      }
      Log.w("GoogleHttpClient", "Ignoring unsupported parameter: " + paramAnonymousString);
      return this;
    }
  };
  protected SSLSocketFactory mSocketFactory;
  private String nA;
  protected int readTimeout;
  private c we;
  
  public GoogleHttpClient(Context paramContext, String paramString, boolean paramBoolean)
  {
    String str = paramString + " (" + Build.DEVICE + " " + Build.ID + ")";
    if (paramBoolean) {
      str = str + "; gzip";
    }
    this.mContext = paramContext;
    this.kh = paramString;
    this.nA = str;
    this.readTimeout = 60000;
    this.connectTimeout = 60000;
    SSLSessionCache localSSLSessionCache = null;
    if (paramContext != null)
    {
      int i = Build.VERSION.SDK_INT;
      localSSLSessionCache = null;
      if (i > 18) {
        localSSLSessionCache = new SSLSessionCache(paramContext);
      }
    }
    setSslSocketFactory(SSLCertificateSocketFactory.getDefault(60000, localSSLSessionCache));
  }
  
  private static String a(HttpUriRequest paramHttpUriRequest, boolean paramBoolean)
    throws IOException
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("curl ");
    localStringBuilder.append("-X ");
    localStringBuilder.append(paramHttpUriRequest.getMethod());
    localStringBuilder.append(" ");
    Header[] arrayOfHeader = paramHttpUriRequest.getAllHeaders();
    int i = arrayOfHeader.length;
    int j = 0;
    if (j < i)
    {
      Header localHeader = arrayOfHeader[j];
      if ((!paramBoolean) && ((localHeader.getName().equals("Authorization")) || (localHeader.getName().equals("Cookie")))) {}
      for (;;)
      {
        j++;
        break;
        localStringBuilder.append("--header \"");
        localStringBuilder.append(localHeader.toString().trim());
        localStringBuilder.append("\" ");
      }
    }
    URI localURI1 = paramHttpUriRequest.getURI();
    HttpRequest localHttpRequest;
    if ((paramHttpUriRequest instanceof RequestWrapper))
    {
      localHttpRequest = ((RequestWrapper)paramHttpUriRequest).getOriginal();
      if (!(localHttpRequest instanceof HttpUriRequest)) {}
    }
    for (URI localURI2 = ((HttpUriRequest)localHttpRequest).getURI();; localURI2 = localURI1)
    {
      localStringBuilder.append("\"");
      localStringBuilder.append(localURI2);
      localStringBuilder.append("\"");
      ByteArrayOutputStream localByteArrayOutputStream;
      if ((paramHttpUriRequest instanceof HttpEntityEnclosingRequest))
      {
        HttpEntity localHttpEntity = ((HttpEntityEnclosingRequest)paramHttpUriRequest).getEntity();
        if ((localHttpEntity != null) && (localHttpEntity.isRepeatable()))
        {
          if (localHttpEntity.getContentLength() >= 1024L) {
            break label360;
          }
          localByteArrayOutputStream = new ByteArrayOutputStream();
          localHttpEntity.writeTo(localByteArrayOutputStream);
          if (!a(paramHttpUriRequest)) {
            break label332;
          }
          String str2 = Base64.encodeToString(localByteArrayOutputStream.toByteArray(), 2);
          localStringBuilder.insert(0, "echo '" + str2 + "' | base64 -d > /tmp/$$.bin; ");
          localStringBuilder.append(" --data-binary @/tmp/$$.bin");
        }
      }
      for (;;)
      {
        return localStringBuilder.toString();
        label332:
        String str1 = localByteArrayOutputStream.toString();
        localStringBuilder.append(" --data-ascii \"").append(str1).append("\"");
        continue;
        label360:
        localStringBuilder.append(" [TOO MUCH DATA TO INCLUDE]");
      }
    }
  }
  
  private HttpURLConnection a(URL paramURL)
    throws IOException
  {
    HttpURLConnection localHttpURLConnection = newConnection(paramURL);
    localHttpURLConnection.setConnectTimeout(this.connectTimeout);
    localHttpURLConnection.setReadTimeout(this.readTimeout);
    if (((localHttpURLConnection instanceof HttpsURLConnection)) && (this.mSocketFactory != null)) {
      ((HttpsURLConnection)localHttpURLConnection).setSSLSocketFactory(this.mSocketFactory);
    }
    localHttpURLConnection.setInstanceFollowRedirects(false);
    return localHttpURLConnection;
  }
  
  /* Error */
  private HttpResponse a(HttpUriRequest paramHttpUriRequest, b paramb, HttpContext paramHttpContext)
    throws IOException
  {
    // Byte code:
    //   0: invokestatic 298	android/os/Looper:myLooper	()Landroid/os/Looper;
    //   3: ifnull +23 -> 26
    //   6: invokestatic 298	android/os/Looper:myLooper	()Landroid/os/Looper;
    //   9: invokestatic 301	android/os/Looper:getMainLooper	()Landroid/os/Looper;
    //   12: if_acmpne +14 -> 26
    //   15: new 303	java/lang/RuntimeException
    //   18: dup
    //   19: ldc_w 305
    //   22: invokespecial 308	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   25: athrow
    //   26: aload_0
    //   27: getfield 310	com/google/android/gms/http/GoogleHttpClient:we	Lcom/google/android/gms/http/GoogleHttpClient$c;
    //   30: astore 4
    //   32: aload 4
    //   34: ifnull +28 -> 62
    //   37: aload 4
    //   39: invokestatic 315	com/google/android/gms/http/GoogleHttpClient$c:a	(Lcom/google/android/gms/http/GoogleHttpClient$c;)Z
    //   42: ifeq +20 -> 62
    //   45: aload_1
    //   46: instanceof 169
    //   49: ifeq +13 -> 62
    //   52: aload 4
    //   54: aload_1
    //   55: iconst_0
    //   56: invokestatic 317	com/google/android/gms/http/GoogleHttpClient:a	(Lorg/apache/http/client/methods/HttpUriRequest;Z)Ljava/lang/String;
    //   59: invokestatic 320	com/google/android/gms/http/GoogleHttpClient$c:a	(Lcom/google/android/gms/http/GoogleHttpClient$c;Ljava/lang/String;)V
    //   62: aload_2
    //   63: getfield 326	com/google/android/gms/http/GoogleHttpClient$b:wi	Landroid/os/Bundle;
    //   66: ifnull +201 -> 267
    //   69: aload_2
    //   70: getfield 326	com/google/android/gms/http/GoogleHttpClient$b:wi	Landroid/os/Bundle;
    //   73: ldc 35
    //   75: invokevirtual 332	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   78: ifnull +189 -> 267
    //   81: invokestatic 338	android/os/Process:myUid	()I
    //   84: istore 16
    //   86: iload 16
    //   88: invokestatic 344	android/net/TrafficStats:getUidTxBytes	(I)J
    //   91: lstore 17
    //   93: iload 16
    //   95: invokestatic 347	android/net/TrafficStats:getUidRxBytes	(I)J
    //   98: lstore 19
    //   100: aload_0
    //   101: aload_1
    //   102: aload_2
    //   103: aload_3
    //   104: invokevirtual 350	com/google/android/gms/http/GoogleHttpClient:proxyToUrlConnection	(Lorg/apache/http/client/methods/HttpUriRequest;Lcom/google/android/gms/http/GoogleHttpClient$b;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    //   107: pop
    //   108: aload_2
    //   109: ifnonnull +149 -> 258
    //   112: aconst_null
    //   113: astore 22
    //   115: aload 22
    //   117: ifnull +48 -> 165
    //   120: invokestatic 355	android/os/SystemClock:elapsedRealtime	()J
    //   123: lstore 23
    //   125: aload_2
    //   126: lload 23
    //   128: aload_2
    //   129: getfield 358	com/google/android/gms/http/GoogleHttpClient$b:wj	J
    //   132: lsub
    //   133: putfield 361	com/google/android/gms/http/GoogleHttpClient$b:wk	J
    //   136: aload_2
    //   137: new 363	com/google/android/gms/http/b
    //   140: dup
    //   141: aload 22
    //   143: aload_0
    //   144: getfield 132	com/google/android/gms/http/GoogleHttpClient:kh	Ljava/lang/String;
    //   147: iload 16
    //   149: lload 17
    //   151: lload 19
    //   153: aload_2
    //   154: getfield 361	com/google/android/gms/http/GoogleHttpClient$b:wk	J
    //   157: lload 23
    //   159: invokespecial 366	com/google/android/gms/http/b:<init>	(Lorg/apache/http/HttpEntity;Ljava/lang/String;IJJJJ)V
    //   162: invokevirtual 370	com/google/android/gms/http/GoogleHttpClient$b:setEntity	(Lorg/apache/http/HttpEntity;)V
    //   165: aload_2
    //   166: invokevirtual 374	com/google/android/gms/http/GoogleHttpClient$b:getStatusLine	()Lorg/apache/http/StatusLine;
    //   169: invokeinterface 379 1 0
    //   174: istore 11
    //   176: aload_2
    //   177: invokestatic 355	android/os/SystemClock:elapsedRealtime	()J
    //   180: aload_2
    //   181: getfield 358	com/google/android/gms/http/GoogleHttpClient$b:wj	J
    //   184: lsub
    //   185: putfield 361	com/google/android/gms/http/GoogleHttpClient$b:wk	J
    //   188: iconst_4
    //   189: anewarray 4	java/lang/Object
    //   192: astore 14
    //   194: aload 14
    //   196: iconst_0
    //   197: aload_2
    //   198: getfield 361	com/google/android/gms/http/GoogleHttpClient$b:wk	J
    //   201: invokestatic 385	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   204: aastore
    //   205: aload 14
    //   207: iconst_1
    //   208: iload 11
    //   210: invokestatic 390	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   213: aastore
    //   214: aload 14
    //   216: iconst_2
    //   217: aload_0
    //   218: getfield 132	com/google/android/gms/http/GoogleHttpClient:kh	Ljava/lang/String;
    //   221: aastore
    //   222: aload 14
    //   224: iconst_3
    //   225: iconst_0
    //   226: invokestatic 390	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   229: aastore
    //   230: ldc_w 391
    //   233: aload 14
    //   235: invokestatic 397	android/util/EventLog:writeEvent	(I[Ljava/lang/Object;)I
    //   238: pop
    //   239: aload_0
    //   240: aload_1
    //   241: invokeinterface 401 1 0
    //   246: invokeinterface 406 1 0
    //   251: iload 11
    //   253: invokespecial 410	com/google/android/gms/http/GoogleHttpClient:f	(Ljava/lang/String;I)V
    //   256: aload_2
    //   257: areturn
    //   258: aload_2
    //   259: invokevirtual 411	com/google/android/gms/http/GoogleHttpClient$b:getEntity	()Lorg/apache/http/HttpEntity;
    //   262: astore 22
    //   264: goto -149 -> 115
    //   267: aload_0
    //   268: aload_1
    //   269: aload_2
    //   270: aload_3
    //   271: invokevirtual 350	com/google/android/gms/http/GoogleHttpClient:proxyToUrlConnection	(Lorg/apache/http/client/methods/HttpUriRequest;Lcom/google/android/gms/http/GoogleHttpClient$b;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    //   274: pop
    //   275: goto -110 -> 165
    //   278: astore 5
    //   280: aload_2
    //   281: invokestatic 355	android/os/SystemClock:elapsedRealtime	()J
    //   284: aload_2
    //   285: getfield 358	com/google/android/gms/http/GoogleHttpClient$b:wj	J
    //   288: lsub
    //   289: putfield 361	com/google/android/gms/http/GoogleHttpClient$b:wk	J
    //   292: iconst_4
    //   293: anewarray 4	java/lang/Object
    //   296: astore 8
    //   298: aload 8
    //   300: iconst_0
    //   301: aload_2
    //   302: getfield 361	com/google/android/gms/http/GoogleHttpClient$b:wk	J
    //   305: invokestatic 385	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   308: aastore
    //   309: aload 8
    //   311: iconst_1
    //   312: iconst_m1
    //   313: invokestatic 390	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   316: aastore
    //   317: aload 8
    //   319: iconst_2
    //   320: aload_0
    //   321: getfield 132	com/google/android/gms/http/GoogleHttpClient:kh	Ljava/lang/String;
    //   324: aastore
    //   325: aload 8
    //   327: iconst_3
    //   328: iconst_0
    //   329: invokestatic 390	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   332: aastore
    //   333: ldc_w 391
    //   336: aload 8
    //   338: invokestatic 397	android/util/EventLog:writeEvent	(I[Ljava/lang/Object;)I
    //   341: pop
    //   342: aload_0
    //   343: aload_1
    //   344: invokeinterface 401 1 0
    //   349: invokeinterface 406 1 0
    //   354: iconst_m1
    //   355: invokespecial 410	com/google/android/gms/http/GoogleHttpClient:f	(Ljava/lang/String;I)V
    //   358: aload 5
    //   360: athrow
    //   361: astore 12
    //   363: ldc_w 413
    //   366: ldc_w 415
    //   369: aload 12
    //   371: invokestatic 421	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   374: pop
    //   375: aload_2
    //   376: areturn
    //   377: astore 6
    //   379: ldc_w 413
    //   382: ldc_w 415
    //   385: aload 6
    //   387: invokestatic 421	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   390: pop
    //   391: goto -33 -> 358
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	394	0	this	GoogleHttpClient
    //   0	394	1	paramHttpUriRequest	HttpUriRequest
    //   0	394	2	paramb	b
    //   0	394	3	paramHttpContext	HttpContext
    //   30	23	4	localc	c
    //   278	81	5	localObject	Object
    //   377	9	6	localException1	java.lang.Exception
    //   296	41	8	arrayOfObject1	Object[]
    //   174	78	11	i	int
    //   361	9	12	localException2	java.lang.Exception
    //   192	42	14	arrayOfObject2	Object[]
    //   84	64	16	j	int
    //   91	59	17	l1	long
    //   98	54	19	l2	long
    //   113	150	22	localHttpEntity	HttpEntity
    //   123	35	23	l3	long
    // Exception table:
    //   from	to	target	type
    //   62	108	278	finally
    //   120	165	278	finally
    //   165	176	278	finally
    //   258	264	278	finally
    //   267	275	278	finally
    //   176	256	361	java/lang/Exception
    //   280	358	377	java/lang/Exception
  }
  
  private static boolean a(HttpUriRequest paramHttpUriRequest)
  {
    Header[] arrayOfHeader1 = paramHttpUriRequest.getHeaders("content-encoding");
    int i1;
    if (arrayOfHeader1 != null)
    {
      int n = arrayOfHeader1.length;
      i1 = 0;
      if (i1 < n) {
        if (!"gzip".equalsIgnoreCase(arrayOfHeader1[i1].getValue())) {}
      }
    }
    for (;;)
    {
      return true;
      i1++;
      break;
      Header[] arrayOfHeader2 = paramHttpUriRequest.getHeaders("content-type");
      if (arrayOfHeader2 != null)
      {
        int i = arrayOfHeader2.length;
        for (int j = 0; j < i; j++)
        {
          Header localHeader = arrayOfHeader2[j];
          for (String str : wf) {
            if (localHeader.getValue().startsWith(str)) {
              return false;
            }
          }
        }
      }
    }
  }
  
  /* Error */
  private static RequestWrapper b(HttpUriRequest paramHttpUriRequest)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: instanceof 214
    //   4: ifeq +21 -> 25
    //   7: new 443	org/apache/http/impl/client/EntityEnclosingRequestWrapper
    //   10: dup
    //   11: aload_0
    //   12: checkcast 214	org/apache/http/HttpEntityEnclosingRequest
    //   15: invokespecial 446	org/apache/http/impl/client/EntityEnclosingRequestWrapper:<init>	(Lorg/apache/http/HttpEntityEnclosingRequest;)V
    //   18: astore_2
    //   19: aload_2
    //   20: invokevirtual 449	org/apache/http/impl/client/RequestWrapper:resetHeaders	()V
    //   23: aload_2
    //   24: areturn
    //   25: new 203	org/apache/http/impl/client/RequestWrapper
    //   28: dup
    //   29: aload_0
    //   30: invokespecial 452	org/apache/http/impl/client/RequestWrapper:<init>	(Lorg/apache/http/HttpRequest;)V
    //   33: astore_2
    //   34: goto -15 -> 19
    //   37: astore_1
    //   38: new 454	org/apache/http/client/ClientProtocolException
    //   41: dup
    //   42: aload_1
    //   43: invokespecial 457	org/apache/http/client/ClientProtocolException:<init>	(Ljava/lang/Throwable;)V
    //   46: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	47	0	paramHttpUriRequest	HttpUriRequest
    //   37	6	1	localProtocolException	org.apache.http.ProtocolException
    //   18	16	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   0	19	37	org/apache/http/ProtocolException
    //   19	23	37	org/apache/http/ProtocolException
    //   25	34	37	org/apache/http/ProtocolException
  }
  
  private void f(String paramString, int paramInt)
  {
    com.google.android.gms.common.a locala = new com.google.android.gms.common.a();
    if (this.mContext.bindService(wd, locala, 1)) {
      try
      {
        a locala1 = a.a.y(locala.bj());
        if (locala1 != null) {
          locala1.f(paramString, paramInt);
        }
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        Log.w("GoogleHttpClient", "Interrupted during blocking call: ", localInterruptedException);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w("GoogleHttpClient", "Exception in Google Http Service: ", localRemoteException);
        return;
      }
      finally
      {
        this.mContext.unbindService(locala);
      }
    }
    Log.w("GoogleHttpClient", "Failed to bind Google HTTP Service");
  }
  
  public static AbstractHttpEntity getCompressedEntity(byte[] paramArrayOfByte, ContentResolver paramContentResolver)
    throws IOException
  {
    if (paramArrayOfByte.length < getMinGzipSize(paramContentResolver)) {
      return new ByteArrayEntity(paramArrayOfByte);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
    localGZIPOutputStream.write(paramArrayOfByte);
    localGZIPOutputStream.close();
    ByteArrayEntity localByteArrayEntity = new ByteArrayEntity(localByteArrayOutputStream.toByteArray());
    localByteArrayEntity.setContentEncoding("gzip");
    return localByteArrayEntity;
  }
  
  public static long getMinGzipSize(ContentResolver paramContentResolver)
  {
    return 256L;
  }
  
  public static InputStream getUngzippedContent(HttpEntity paramHttpEntity)
    throws IOException
  {
    InputStream localInputStream = paramHttpEntity.getContent();
    if (localInputStream == null) {}
    String str;
    do
    {
      Header localHeader;
      do
      {
        return localInputStream;
        localHeader = paramHttpEntity.getContentEncoding();
      } while (localHeader == null);
      str = localHeader.getValue();
    } while (str == null);
    if (str.contains("gzip")) {}
    for (Object localObject = new GZIPInputStream(localInputStream);; localObject = localInputStream) {
      return localObject;
    }
  }
  
  public static void modifyRequestToAcceptGzipResponse(HttpRequest paramHttpRequest)
  {
    paramHttpRequest.addHeader("Accept-Encoding", "gzip");
  }
  
  public static GoogleHttpClient newInstance(String paramString, Context paramContext)
  {
    return new GoogleHttpClient(paramContext, paramString, false);
  }
  
  protected void beforeSend(HttpURLConnection paramHttpURLConnection) {}
  
  protected Bundle checkRules(String paramString)
  {
    com.google.android.gms.common.a locala = new com.google.android.gms.common.a();
    if (this.mContext.bindService(wd, locala, 1)) {}
    for (;;)
    {
      try
      {
        a locala1 = a.a.y(locala.bj());
        if (locala1 != null)
        {
          Bundle localBundle = locala1.K(paramString);
          return localBundle;
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        Log.w("GoogleHttpClient", "Interrupted during blocking call: ", localInterruptedException);
        this.mContext.unbindService(locala);
        continue;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w("GoogleHttpClient", "Exception in Google Http Service: ", localRemoteException);
        this.mContext.unbindService(locala);
        continue;
      }
      finally
      {
        this.mContext.unbindService(locala);
      }
      return null;
      Log.w("GoogleHttpClient", "Failed to bind Google HTTP Service");
    }
  }
  
  public void close() {}
  
  public void disableCurlLogging()
  {
    this.we = null;
  }
  
  public void enableCurlLogging(String paramString, int paramInt)
  {
    if (paramString == null) {
      throw new NullPointerException("name");
    }
    if ((paramInt < 2) || (paramInt > 7)) {
      throw new IllegalArgumentException("Level is out of range [27]");
    }
    this.we = new c(paramString, paramInt, null);
  }
  
  public <T> T execute(HttpHost paramHttpHost, HttpRequest paramHttpRequest, ResponseHandler<? extends T> paramResponseHandler)
    throws IOException
  {
    throw new UnsupportedOperationException();
  }
  
  public <T> T execute(HttpHost paramHttpHost, HttpRequest paramHttpRequest, ResponseHandler<? extends T> paramResponseHandler, HttpContext paramHttpContext)
    throws IOException
  {
    throw new UnsupportedOperationException();
  }
  
  public <T> T execute(HttpUriRequest paramHttpUriRequest, ResponseHandler<? extends T> paramResponseHandler)
    throws IOException
  {
    return execute(paramHttpUriRequest, paramResponseHandler, null);
  }
  
  public <T> T execute(HttpUriRequest paramHttpUriRequest, ResponseHandler<? extends T> paramResponseHandler, HttpContext paramHttpContext)
    throws IOException
  {
    throw new UnsupportedOperationException();
  }
  
  public HttpResponse execute(HttpHost paramHttpHost, HttpRequest paramHttpRequest)
    throws IOException
  {
    throw new UnsupportedOperationException();
  }
  
  public HttpResponse execute(HttpHost paramHttpHost, HttpRequest paramHttpRequest, HttpContext paramHttpContext)
    throws IOException
  {
    throw new UnsupportedOperationException();
  }
  
  public HttpResponse execute(HttpUriRequest paramHttpUriRequest)
    throws IOException
  {
    return execute(paramHttpUriRequest, (HttpContext)null);
  }
  
  public HttpResponse execute(HttpUriRequest paramHttpUriRequest, HttpContext paramHttpContext)
    throws IOException
  {
    return executeInternal(paramHttpUriRequest, paramHttpContext);
  }
  
  public HttpResponse executeInternal(HttpUriRequest paramHttpUriRequest, HttpContext paramHttpContext)
    throws IOException
  {
    b localb = new b();
    localb.wj = SystemClock.elapsedRealtime();
    String str1 = paramHttpUriRequest.getURI().toString();
    localb.wi = checkRules(str1);
    if ((localb.wi != null) && (localb.wi.getString("block") != null))
    {
      Log.w("GoogleHttpClient", "Blocked by " + localb.wi.getString("name") + ": " + str1);
      throw new a(localb.wi);
    }
    if ((localb.wi != null) && (localb.wi.getString("rewrite") != null))
    {
      String str2 = localb.wi.getString("rewrite");
      try
      {
        URI localURI = new URI(str2);
        RequestWrapper localRequestWrapper = b(paramHttpUriRequest);
        localRequestWrapper.setURI(localURI);
        return a(localRequestWrapper, localb, paramHttpContext);
      }
      catch (URISyntaxException localURISyntaxException)
      {
        Log.w("Ignoring bad URL from rule: " + str2, localURISyntaxException);
        return a(paramHttpUriRequest, localb, paramHttpContext);
      }
    }
    return a(paramHttpUriRequest, localb, paramHttpContext);
  }
  
  public ClientConnectionManager getConnectionManager()
  {
    throw new UnsupportedOperationException();
  }
  
  public HttpParams getParams()
  {
    return this.mParams;
  }
  
  public SSLSocketFactory getSocketFactory()
  {
    return this.mSocketFactory;
  }
  
  protected void makeRequest(HttpURLConnection paramHttpURLConnection, HttpUriRequest paramHttpUriRequest, HttpContext paramHttpContext)
    throws IOException
  {
    paramHttpURLConnection.setRequestMethod(paramHttpUriRequest.getMethod());
    for (Header localHeader3 : paramHttpUriRequest.getAllHeaders()) {
      paramHttpURLConnection.addRequestProperty(localHeader3.getName(), localHeader3.getValue());
    }
    paramHttpURLConnection.setRequestProperty("User-Agent", this.nA);
    beforeSend(paramHttpURLConnection);
    if ((paramHttpUriRequest instanceof HttpEntityEnclosingRequest))
    {
      HttpEntity localHttpEntity = ((HttpEntityEnclosingRequest)paramHttpUriRequest).getEntity();
      if (localHttpEntity == null) {
        throw new IllegalArgumentException("The Entity of HttpEntityEnclosingRequest is null");
      }
      paramHttpURLConnection.setDoOutput(true);
      if (localHttpEntity.isChunked()) {}
      for (long l = -1L;; l = localHttpEntity.getContentLength())
      {
        Header localHeader1 = localHttpEntity.getContentType();
        Header localHeader2 = localHttpEntity.getContentEncoding();
        if (l > 0L) {
          paramHttpURLConnection.setRequestProperty("content-length", Long.toString(l));
        }
        if (localHeader1 != null) {
          paramHttpURLConnection.setRequestProperty("content-type", localHeader1.getValue());
        }
        if (localHeader2 != null) {
          paramHttpURLConnection.setRequestProperty("content-encoding", localHeader2.getValue());
        }
        localHttpEntity.writeTo(paramHttpURLConnection.getOutputStream());
        return;
      }
    }
    paramHttpURLConnection.connect();
  }
  
  protected HttpURLConnection newConnection(URL paramURL)
    throws IOException
  {
    return (HttpURLConnection)paramURL.openConnection();
  }
  
  protected HttpResponse proxyToUrlConnection(HttpUriRequest paramHttpUriRequest, b paramb, HttpContext paramHttpContext)
    throws IOException
  {
    HttpURLConnection localHttpURLConnection = a(new URL(paramHttpUriRequest.getRequestLine().getUri()));
    paramb.wl = localHttpURLConnection;
    for (;;)
    {
      int j;
      Object localObject1;
      Object localObject2;
      String str1;
      try
      {
        makeRequest(localHttpURLConnection, paramHttpUriRequest, paramHttpContext);
        int i = localHttpURLConnection.getResponseCode();
        paramb.setStatusLine(HttpVersion.HTTP_1_1, i, localHttpURLConnection.getResponseMessage());
        j = 0;
        localObject1 = null;
        localObject2 = null;
        str1 = localHttpURLConnection.getHeaderFieldKey(j);
        if (str1 == null)
        {
          if (i < 400) {
            break label223;
          }
          localInputStream = localHttpURLConnection.getErrorStream();
          if (localInputStream == null) {
            localInputStream = localHttpURLConnection.getInputStream();
          }
          if (localInputStream != null)
          {
            InputStreamEntity localInputStreamEntity = new InputStreamEntity(localInputStream, -1L);
            if (localObject1 != null) {
              localInputStreamEntity.setContentType((String)localObject1);
            }
            if (localObject2 != null) {
              localInputStreamEntity.setContentType((String)localObject2);
            }
            paramb.setEntity(localInputStreamEntity);
          }
          return paramb;
        }
      }
      catch (IOException localIOException)
      {
        throw localIOException;
      }
      String str2 = localHttpURLConnection.getHeaderField(j);
      if (str1.equalsIgnoreCase("content-type")) {
        localObject1 = str2;
      }
      if (str1.equalsIgnoreCase("content-encoding")) {
        localObject2 = str2;
      }
      paramb.addHeader(new BasicHeader(str1, str2));
      j++;
      continue;
      label223:
      InputStream localInputStream = null;
    }
  }
  
  public void setSslSocketFactory(SSLSocketFactory paramSSLSocketFactory)
  {
    this.mSocketFactory = paramSSLSocketFactory;
  }
  
  public static class a
    extends IOException
  {
    private final Bundle wh;
    
    a(Bundle paramBundle)
    {
      super();
      this.wh = paramBundle;
    }
  }
  
  static class b
    extends BasicHttpResponse
  {
    private static final StatusLine wm = new BasicStatusLine(HttpVersion.HTTP_1_1, 500, "Unknown error");
    Bundle wi;
    long wj;
    long wk;
    HttpURLConnection wl;
    
    b()
    {
      super(null, null);
    }
  }
  
  private static class c
  {
    private final int level;
    private final String tag;
    
    private c(String paramString, int paramInt)
    {
      this.tag = paramString;
      this.level = paramInt;
    }
    
    private boolean ct()
    {
      return Log.isLoggable(this.tag, this.level);
    }
    
    private void println(String paramString)
    {
      Log.println(this.level, this.tag, paramString);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.http.GoogleHttpClient
 * JD-Core Version:    0.7.0.1
 */