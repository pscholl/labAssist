package com.google.android.gms.photos.autobackup;

import android.app.PendingIntent;
import android.content.Context;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;

public abstract interface AutoBackupApi
{
  public abstract PendingResult<PendingIntentResult> getAutoBackupPromoActivity(GoogleApiClient paramGoogleApiClient);
  
  public abstract PendingResult<AutoBackupSettingsResult> getAutoBackupSettings(GoogleApiClient paramGoogleApiClient);
  
  public abstract PendingResult<PendingIntentResult> getAutoBackupSettingsActivity(GoogleApiClient paramGoogleApiClient);
  
  public static abstract interface AutoBackupSettingsResult
    extends Result
  {
    public abstract String getAccountName();
    
    public abstract boolean isEnabled();
  }
  
  public static abstract interface PendingIntentResult
    extends Result
  {
    public abstract PendingIntent getPendingIntent();
    
    public abstract void launchPendingIntent(Context paramContext);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.photos.autobackup.AutoBackupApi
 * JD-Core Version:    0.7.0.1
 */