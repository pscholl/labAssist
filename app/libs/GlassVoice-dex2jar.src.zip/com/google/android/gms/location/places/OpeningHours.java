package com.google.android.gms.location.places;

import java.util.Date;
import java.util.List;

public abstract class OpeningHours
{
  public abstract List getPeriods();
  
  public abstract boolean isOpenAt(Date paramDate);
  
  public abstract boolean isOpenNow();
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.OpeningHours
 * JD-Core Version:    0.7.0.1
 */