package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;

public class b
  implements Parcelable.Creator<LocationStatus>
{
  static void a(LocationStatus paramLocationStatus, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramLocationStatus.wO);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1000, paramLocationStatus.getVersionCode());
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 2, paramLocationStatus.wP);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramLocationStatus.wQ);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public LocationStatus[] aH(int paramInt)
  {
    return new LocationStatus[paramInt];
  }
  
  public LocationStatus al(Parcel paramParcel)
  {
    int i = 1;
    int j = a.Y(paramParcel);
    int k = 0;
    long l = 0L;
    int m = i;
    while (paramParcel.dataPosition() < j)
    {
      int n = a.X(paramParcel);
      switch (a.al(n))
      {
      default: 
        a.b(paramParcel, n);
        break;
      case 1: 
        m = a.f(paramParcel, n);
        break;
      case 1000: 
        k = a.f(paramParcel, n);
        break;
      case 2: 
        i = a.f(paramParcel, n);
        break;
      case 3: 
        l = a.g(paramParcel, n);
      }
    }
    if (paramParcel.dataPosition() != j) {
      throw new a.a("Overread allowed size end=" + j, paramParcel);
    }
    return new LocationStatus(k, m, i, l);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.b
 * JD-Core Version:    0.7.0.1
 */