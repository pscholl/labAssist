package com.google.android.gms.location.reporting;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class a
  implements Parcelable.Creator<GmmSettings>
{
  static void a(GmmSettings paramGmmSettings, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.c(paramParcel, 1, paramGmmSettings.getVersionCode());
    b.a(paramParcel, 2, paramGmmSettings.getReadMillis());
    b.a(paramParcel, 3, paramGmmSettings.getAccount(), paramInt, false);
    b.a(paramParcel, 4, paramGmmSettings.isReportingSelected());
    b.C(paramParcel, i);
  }
  
  public GmmSettings[] aW(int paramInt)
  {
    return new GmmSettings[paramInt];
  }
  
  public GmmSettings ax(Parcel paramParcel)
  {
    boolean bool = false;
    int i = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    long l = 0L;
    Account localAccount = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.al(k))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, k);
        break;
      case 1: 
        j = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, k);
        break;
      case 2: 
        l = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, k);
        break;
      case 3: 
        localAccount = (Account)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, k, Account.CREATOR);
        break;
      case 4: 
        bool = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new GmmSettings(j, l, localAccount, bool);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.a
 * JD-Core Version:    0.7.0.1
 */