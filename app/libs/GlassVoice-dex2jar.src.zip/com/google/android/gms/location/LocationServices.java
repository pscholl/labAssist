package com.google.android.gms.location;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.internal.ai;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.bu;
import com.google.android.gms.internal.bv;
import com.google.android.gms.internal.bz;

public class LocationServices
{
  public static final Api API = new Api(CLIENT_BUILDER, new Scope[0]);
  private static final Api.b<bz> CLIENT_BUILDER = new Api.b()
  {
    public bz b(Context paramAnonymousContext, Looper paramAnonymousLooper, ai paramAnonymousai, GoogleApiClient.ApiOptions paramAnonymousApiOptions, GoogleApiClient.ConnectionCallbacks paramAnonymousConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramAnonymousOnConnectionFailedListener)
    {
      return new bz(paramAnonymousContext, paramAnonymousLooper, paramAnonymousConnectionCallbacks, paramAnonymousOnConnectionFailedListener, "locationServices");
    }
    
    public int getPriority()
    {
      return 2147483647;
    }
  };
  public static FusedLocationProvider FusedLocationApi = new bu();
  public static Geofencing GeofencingApi = new bv();
  
  public static bz getConnectedClientImpl(GoogleApiClient paramGoogleApiClient)
  {
    boolean bool1 = true;
    boolean bool2;
    bz localbz;
    if (paramGoogleApiClient != null)
    {
      bool2 = bool1;
      at.b(bool2, "GoogleApiClient parameter is required.");
      localbz = (bz)paramGoogleApiClient.a(CLIENT_BUILDER);
      if (localbz == null) {
        break label44;
      }
    }
    for (;;)
    {
      at.a(bool1, "GoogleApiClient is not configured to use the LocationServices.API Api. Pass thisinto GoogleApiClient.Builder#addApi() to use this feature.");
      return localbz;
      bool2 = false;
      break;
      label44:
      bool1 = false;
    }
  }
  
  public static abstract class a<R extends Result>
    extends a.a<R, bz>
  {
    public a()
    {
      super();
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.LocationServices
 * JD-Core Version:    0.7.0.1
 */