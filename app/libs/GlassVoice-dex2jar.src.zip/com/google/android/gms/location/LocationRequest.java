package com.google.android.gms.location;

import android.os.Parcel;
import android.os.SystemClock;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;

public final class LocationRequest
  implements SafeParcelable
{
  public static final LocationRequestCreator CREATOR = new LocationRequestCreator();
  public static final int PRIORITY_BALANCED_POWER_ACCURACY = 102;
  public static final int PRIORITY_HIGH_ACCURACY = 100;
  public static final int PRIORITY_LOW_POWER = 104;
  public static final int PRIORITY_NO_POWER = 105;
  int mPriority;
  private final int oj;
  long wC;
  long wJ;
  long wK;
  boolean wL;
  int wM;
  float wN;
  
  public LocationRequest()
  {
    this.oj = 1;
    this.mPriority = 102;
    this.wJ = 3600000L;
    this.wK = 600000L;
    this.wL = false;
    this.wC = 9223372036854775807L;
    this.wM = 2147483647;
    this.wN = 0.0F;
  }
  
  LocationRequest(int paramInt1, int paramInt2, long paramLong1, long paramLong2, boolean paramBoolean, long paramLong3, int paramInt3, float paramFloat)
  {
    this.oj = paramInt1;
    this.mPriority = paramInt2;
    this.wJ = paramLong1;
    this.wK = paramLong2;
    this.wL = paramBoolean;
    this.wC = paramLong3;
    this.wM = paramInt3;
    this.wN = paramFloat;
  }
  
  private static void a(float paramFloat)
  {
    if (paramFloat < 0.0F) {
      throw new IllegalArgumentException("invalid displacement: " + paramFloat);
    }
  }
  
  private static void aC(int paramInt)
  {
    switch (paramInt)
    {
    case 101: 
    case 103: 
    default: 
      throw new IllegalArgumentException("invalid quality: " + paramInt);
    }
  }
  
  public static String aD(int paramInt)
  {
    switch (paramInt)
    {
    case 101: 
    case 103: 
    default: 
      return "???";
    case 100: 
      return "PRIORITY_HIGH_ACCURACY";
    case 102: 
      return "PRIORITY_BALANCED_POWER_ACCURACY";
    case 104: 
      return "PRIORITY_LOW_POWER";
    }
    return "PRIORITY_NO_POWER";
  }
  
  private static void b(long paramLong)
  {
    if (paramLong < 0L) {
      throw new IllegalArgumentException("invalid interval: " + paramLong);
    }
  }
  
  public static LocationRequest create()
  {
    return new LocationRequest();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    LocationRequest localLocationRequest;
    do
    {
      return true;
      if (!(paramObject instanceof LocationRequest)) {
        return false;
      }
      localLocationRequest = (LocationRequest)paramObject;
    } while ((this.mPriority == localLocationRequest.mPriority) && (this.wJ == localLocationRequest.wJ) && (this.wK == localLocationRequest.wK) && (this.wL == localLocationRequest.wL) && (this.wC == localLocationRequest.wC) && (this.wM == localLocationRequest.wM) && (this.wN == localLocationRequest.wN));
    return false;
  }
  
  public long getExpirationTime()
  {
    return this.wC;
  }
  
  public long getFastestInterval()
  {
    return this.wK;
  }
  
  public long getInterval()
  {
    return this.wJ;
  }
  
  public int getNumUpdates()
  {
    return this.wM;
  }
  
  public int getPriority()
  {
    return this.mPriority;
  }
  
  public float getSmallestDisplacement()
  {
    return this.wN;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[7];
    arrayOfObject[0] = Integer.valueOf(this.mPriority);
    arrayOfObject[1] = Long.valueOf(this.wJ);
    arrayOfObject[2] = Long.valueOf(this.wK);
    arrayOfObject[3] = Boolean.valueOf(this.wL);
    arrayOfObject[4] = Long.valueOf(this.wC);
    arrayOfObject[5] = Integer.valueOf(this.wM);
    arrayOfObject[6] = Float.valueOf(this.wN);
    return ar.hashCode(arrayOfObject);
  }
  
  public LocationRequest setExpirationDuration(long paramLong)
  {
    long l = SystemClock.elapsedRealtime();
    if (paramLong > 9223372036854775807L - l) {}
    for (this.wC = 9223372036854775807L;; this.wC = (l + paramLong))
    {
      if (this.wC < 0L) {
        this.wC = 0L;
      }
      return this;
    }
  }
  
  public LocationRequest setExpirationTime(long paramLong)
  {
    this.wC = paramLong;
    if (this.wC < 0L) {
      this.wC = 0L;
    }
    return this;
  }
  
  public LocationRequest setFastestInterval(long paramLong)
  {
    b(paramLong);
    this.wL = true;
    this.wK = paramLong;
    return this;
  }
  
  public LocationRequest setInterval(long paramLong)
  {
    b(paramLong);
    this.wJ = paramLong;
    if (!this.wL) {
      this.wK = ((this.wJ / 6.0D));
    }
    return this;
  }
  
  public LocationRequest setNumUpdates(int paramInt)
  {
    if (paramInt <= 0) {
      throw new IllegalArgumentException("invalid numUpdates: " + paramInt);
    }
    this.wM = paramInt;
    return this;
  }
  
  public LocationRequest setPriority(int paramInt)
  {
    aC(paramInt);
    this.mPriority = paramInt;
    return this;
  }
  
  public LocationRequest setSmallestDisplacement(float paramFloat)
  {
    a(paramFloat);
    this.wN = paramFloat;
    return this;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Request[").append(aD(this.mPriority));
    if (this.mPriority != 105)
    {
      localStringBuilder.append(" requested=");
      localStringBuilder.append(this.wJ + "ms");
    }
    localStringBuilder.append(" fastest=");
    localStringBuilder.append(this.wK + "ms");
    if (this.wC != 9223372036854775807L)
    {
      long l = this.wC - SystemClock.elapsedRealtime();
      localStringBuilder.append(" expireIn=");
      localStringBuilder.append(l + "ms");
    }
    if (this.wM != 2147483647) {
      localStringBuilder.append(" num=").append(this.wM);
    }
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    LocationRequestCreator.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.LocationRequest
 * JD-Core Version:    0.7.0.1
 */