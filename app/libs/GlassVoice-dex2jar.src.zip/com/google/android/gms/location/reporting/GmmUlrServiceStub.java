package com.google.android.gms.location.reporting;

import android.os.RemoteException;
import java.util.List;

public abstract class GmmUlrServiceStub
  extends b.a
{
  public abstract List<GmmSettings> getAllGmmSettings()
    throws RemoteException;
  
  public List<GmmSettings> getAllGmmSettingsInternal()
    throws RemoteException
  {
    return getAllGmmSettings();
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.GmmUlrServiceStub
 * JD-Core Version:    0.7.0.1
 */