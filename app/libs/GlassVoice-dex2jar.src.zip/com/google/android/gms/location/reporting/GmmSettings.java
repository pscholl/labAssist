package com.google.android.gms.location.reporting;

import android.accounts.Account;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.cq;

public class GmmSettings
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  private final int oj;
  private final long yJ;
  private final Account yK;
  private final boolean yL;
  
  public GmmSettings(int paramInt, long paramLong, Account paramAccount, boolean paramBoolean)
  {
    this.oj = paramInt;
    this.yJ = paramLong;
    this.yK = paramAccount;
    this.yL = paramBoolean;
  }
  
  public GmmSettings(long paramLong, Account paramAccount, boolean paramBoolean)
  {
    this(0, paramLong, paramAccount, paramBoolean);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof GmmSettings)) {}
    GmmSettings localGmmSettings;
    do
    {
      return false;
      localGmmSettings = (GmmSettings)paramObject;
      if ((this.yJ != localGmmSettings.yJ) || (this.yL != localGmmSettings.yL) || (this.oj != localGmmSettings.oj) || (this.yK != null)) {
        break;
      }
    } while (localGmmSettings.yK != null);
    return true;
    return this.yK.equals(localGmmSettings.yK);
  }
  
  public Account getAccount()
  {
    return this.yK;
  }
  
  public long getReadMillis()
  {
    return this.yJ;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    int i = 31 * (31 * this.oj + (int)(this.yJ ^ this.yJ >>> 32));
    if (this.yK != null) {}
    for (int j = this.yK.hashCode();; j = 0)
    {
      int k = 31 * (j + i);
      boolean bool = this.yL;
      int m = 0;
      if (bool) {
        m = 1;
      }
      return k + m;
    }
  }
  
  public boolean isReportingSelected()
  {
    return this.yL;
  }
  
  public String toString()
  {
    return "GmmSettings{mVersionCode=" + this.oj + ", mValueReadMillis=" + this.yJ + ", mAccount=" + cq.a(this.yK) + ", mReportingSelected=" + this.yL + '}';
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.GmmSettings
 * JD-Core Version:    0.7.0.1
 */