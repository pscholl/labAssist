package com.google.android.gms.location.reporting;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Iterator;

public class InactiveReason
  implements SafeParcelable
{
  public static final c CREATOR = new c();
  public static final int VERSION_CODE;
  private final String mName;
  private final int oj;
  private final int yM;
  
  public InactiveReason(int paramInt1, int paramInt2, String paramString)
  {
    this.oj = paramInt1;
    this.yM = paramInt2;
    this.mName = paramString;
  }
  
  public InactiveReason(int paramInt, String paramString)
  {
    this(0, paramInt, paramString);
  }
  
  public static boolean reasonsContain(Iterable<InactiveReason> paramIterable, int paramInt)
  {
    Iterator localIterator = paramIterable.iterator();
    while (localIterator.hasNext()) {
      if (((InactiveReason)localIterator.next()).getIdentifier() == paramInt) {
        return true;
      }
    }
    return false;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    return ((paramObject instanceof InactiveReason)) && (this.yM == ((InactiveReason)paramObject).yM);
  }
  
  public int getIdentifier()
  {
    return this.yM;
  }
  
  public String getName()
  {
    return this.mName;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    return this.yM;
  }
  
  public String toString()
  {
    return "InactiveReason{mVersionCode=" + this.oj + ", mIdentifier=" + this.yM + ", mName='" + this.mName + '\'' + '}';
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    c.a(this, paramParcel, paramInt);
  }
  
  public static abstract interface Identifier
  {
    public static final int ACCOUNT_RESTRICTION = 7;
    public static final int AUTH_ERROR = 10;
    public static final int DEFERRING_TO_GMM = 2;
    public static final int INVALID_ACCOUNT = 5;
    public static final int LOCATION_DISABLED = 12;
    public static final int LOCATION_DISABLED_FOR_GOOGLE_APPS = 4;
    public static final int REPORTING_NOT_ENABLED = 6;
    public static final int RESTRICTED_PROFILE = 11;
    public static final int UNKNOWN = 0;
    public static final int UNSUPPORTED_GEO = 3;
    public static final int UNSUPPORTED_OS = 1;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.InactiveReason
 * JD-Core Version:    0.7.0.1
 */