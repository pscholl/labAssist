package com.google.android.gms.location.places;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class PlaceTypes
{
  public static final Set<PlaceType> ADDRESS_COMPONENTS;
  public static final Set<PlaceType> ALL;
  public static final Set<PlaceType> COARSE;
  private static final HashMap<String, PlaceType> xL;
  
  static
  {
    PlaceType[] arrayOfPlaceType1 = new PlaceType[21];
    arrayOfPlaceType1[0] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_1;
    arrayOfPlaceType1[1] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_2;
    arrayOfPlaceType1[2] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_3;
    arrayOfPlaceType1[3] = PlaceType.COUNTRY;
    arrayOfPlaceType1[4] = PlaceType.FLOOR;
    arrayOfPlaceType1[5] = PlaceType.LOCALITY;
    arrayOfPlaceType1[6] = PlaceType.POST_BOX;
    arrayOfPlaceType1[7] = PlaceType.POSTAL_CODE;
    arrayOfPlaceType1[8] = PlaceType.POSTAL_CODE_PREFIX;
    arrayOfPlaceType1[9] = PlaceType.POSTAL_TOWN;
    arrayOfPlaceType1[10] = PlaceType.PREMISE;
    arrayOfPlaceType1[11] = PlaceType.ROOM;
    arrayOfPlaceType1[12] = PlaceType.ROUTE;
    arrayOfPlaceType1[13] = PlaceType.STREET_ADDRESS;
    arrayOfPlaceType1[14] = PlaceType.SUBLOCALITY;
    arrayOfPlaceType1[15] = PlaceType.SUBLOCALITY_LEVEL_1;
    arrayOfPlaceType1[16] = PlaceType.SUBLOCALITY_LEVEL_2;
    arrayOfPlaceType1[17] = PlaceType.SUBLOCALITY_LEVEL_3;
    arrayOfPlaceType1[18] = PlaceType.SUBLOCALITY_LEVEL_4;
    arrayOfPlaceType1[19] = PlaceType.SUBLOCALITY_LEVEL_5;
    arrayOfPlaceType1[20] = PlaceType.SUBPREMISE;
    ADDRESS_COMPONENTS = Collections.unmodifiableSet(new HashSet(Arrays.asList(arrayOfPlaceType1)));
    PlaceType[] arrayOfPlaceType2 = new PlaceType[8];
    arrayOfPlaceType2[0] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_1;
    arrayOfPlaceType2[1] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_2;
    arrayOfPlaceType2[2] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_3;
    arrayOfPlaceType2[3] = PlaceType.COUNTRY;
    arrayOfPlaceType2[4] = PlaceType.LOCALITY;
    arrayOfPlaceType2[5] = PlaceType.POSTAL_CODE;
    arrayOfPlaceType2[6] = PlaceType.POSTAL_CODE_PREFIX;
    arrayOfPlaceType2[7] = PlaceType.POSTAL_TOWN;
    COARSE = Collections.unmodifiableSet(new HashSet(Arrays.asList(arrayOfPlaceType2)));
    PlaceType[] arrayOfPlaceType3 = new PlaceType[125];
    arrayOfPlaceType3[0] = PlaceType.ACCOUNTING;
    arrayOfPlaceType3[1] = PlaceType.AIRPORT;
    arrayOfPlaceType3[2] = PlaceType.AMUSEMENT_PARK;
    arrayOfPlaceType3[3] = PlaceType.AQUARIUM;
    arrayOfPlaceType3[4] = PlaceType.ART_GALLERY;
    arrayOfPlaceType3[5] = PlaceType.ATM;
    arrayOfPlaceType3[6] = PlaceType.BAKERY;
    arrayOfPlaceType3[7] = PlaceType.BANK;
    arrayOfPlaceType3[8] = PlaceType.BAR;
    arrayOfPlaceType3[9] = PlaceType.BEAUTY_SALON;
    arrayOfPlaceType3[10] = PlaceType.BICYCLE_STORE;
    arrayOfPlaceType3[11] = PlaceType.BOOK_STORE;
    arrayOfPlaceType3[12] = PlaceType.BOWLING_ALLEY;
    arrayOfPlaceType3[13] = PlaceType.BUS_STATION;
    arrayOfPlaceType3[14] = PlaceType.CAFE;
    arrayOfPlaceType3[15] = PlaceType.CAMPGROUND;
    arrayOfPlaceType3[16] = PlaceType.CAR_DEALER;
    arrayOfPlaceType3[17] = PlaceType.CAR_RENTAL;
    arrayOfPlaceType3[18] = PlaceType.CAR_REPAIR;
    arrayOfPlaceType3[19] = PlaceType.CAR_WASH;
    arrayOfPlaceType3[20] = PlaceType.CASINO;
    arrayOfPlaceType3[21] = PlaceType.CEMETARY;
    arrayOfPlaceType3[22] = PlaceType.CHURCH;
    arrayOfPlaceType3[23] = PlaceType.CITY_HALL;
    arrayOfPlaceType3[24] = PlaceType.CLOTHING_STORE;
    arrayOfPlaceType3[25] = PlaceType.CONVENIENCE_STORE;
    arrayOfPlaceType3[26] = PlaceType.COURTHOUSE;
    arrayOfPlaceType3[27] = PlaceType.DENTIST;
    arrayOfPlaceType3[28] = PlaceType.DEPARTMENT_STORE;
    arrayOfPlaceType3[29] = PlaceType.DOCTOR;
    arrayOfPlaceType3[30] = PlaceType.ELECTRICIAN;
    arrayOfPlaceType3[31] = PlaceType.ELECTRONICS_STORE;
    arrayOfPlaceType3[32] = PlaceType.EMBASSY;
    arrayOfPlaceType3[33] = PlaceType.ESTABLISHMENT;
    arrayOfPlaceType3[34] = PlaceType.FINANCE;
    arrayOfPlaceType3[35] = PlaceType.FIRE_STATION;
    arrayOfPlaceType3[36] = PlaceType.FLORIST;
    arrayOfPlaceType3[37] = PlaceType.FOOD;
    arrayOfPlaceType3[38] = PlaceType.FUNERAL_HOME;
    arrayOfPlaceType3[39] = PlaceType.FURNITURE_STORE;
    arrayOfPlaceType3[40] = PlaceType.GAS_STATION;
    arrayOfPlaceType3[41] = PlaceType.GENERAL_CONTRACTOR;
    arrayOfPlaceType3[42] = PlaceType.GROCERY_OR_SUPERMARKET;
    arrayOfPlaceType3[43] = PlaceType.GYM;
    arrayOfPlaceType3[44] = PlaceType.HAIR_CARE;
    arrayOfPlaceType3[45] = PlaceType.HARDWARE_STORE;
    arrayOfPlaceType3[46] = PlaceType.HEALTH;
    arrayOfPlaceType3[47] = PlaceType.HINDU_TEMPLE;
    arrayOfPlaceType3[48] = PlaceType.HOME_GOODS_STORE;
    arrayOfPlaceType3[49] = PlaceType.HOSPITAL;
    arrayOfPlaceType3[50] = PlaceType.INSURANCE_AGENCY;
    arrayOfPlaceType3[51] = PlaceType.JEWELRY_STORE;
    arrayOfPlaceType3[52] = PlaceType.LAUNDRY;
    arrayOfPlaceType3[53] = PlaceType.LAWYER;
    arrayOfPlaceType3[54] = PlaceType.LIBRARY;
    arrayOfPlaceType3[55] = PlaceType.LIQUOR_STORE;
    arrayOfPlaceType3[56] = PlaceType.LOCAL_GOVERNMENT_OFFICE;
    arrayOfPlaceType3[57] = PlaceType.LOCKSMITH;
    arrayOfPlaceType3[58] = PlaceType.LODGING;
    arrayOfPlaceType3[59] = PlaceType.MEAL_DELIVERY;
    arrayOfPlaceType3[60] = PlaceType.MEAL_TAKEAWAY;
    arrayOfPlaceType3[61] = PlaceType.MOSQUE;
    arrayOfPlaceType3[62] = PlaceType.MOVIE_RENTAL;
    arrayOfPlaceType3[63] = PlaceType.MOVIE_THEATER;
    arrayOfPlaceType3[64] = PlaceType.MOVING_COMPANY;
    arrayOfPlaceType3[65] = PlaceType.MUSEUM;
    arrayOfPlaceType3[66] = PlaceType.NIGHT_CLUB;
    arrayOfPlaceType3[67] = PlaceType.PAINTER;
    arrayOfPlaceType3[68] = PlaceType.PARK;
    arrayOfPlaceType3[69] = PlaceType.PARKING;
    arrayOfPlaceType3[70] = PlaceType.PET_STORE;
    arrayOfPlaceType3[71] = PlaceType.PHARMACY;
    arrayOfPlaceType3[72] = PlaceType.PHYSIOTHERAPIST;
    arrayOfPlaceType3[73] = PlaceType.PLACE_OF_WORSHIP;
    arrayOfPlaceType3[74] = PlaceType.PLUMBER;
    arrayOfPlaceType3[75] = PlaceType.POLICE;
    arrayOfPlaceType3[76] = PlaceType.POST_OFFICE;
    arrayOfPlaceType3[77] = PlaceType.REAL_ESTATE_AGENCY;
    arrayOfPlaceType3[78] = PlaceType.RESTAURANT;
    arrayOfPlaceType3[79] = PlaceType.ROOFING_CONTRACTOR;
    arrayOfPlaceType3[80] = PlaceType.RV_PARK;
    arrayOfPlaceType3[81] = PlaceType.SCHOOL;
    arrayOfPlaceType3[82] = PlaceType.SHOE_STORE;
    arrayOfPlaceType3[83] = PlaceType.SHOPPING_MALL;
    arrayOfPlaceType3[84] = PlaceType.SPA;
    arrayOfPlaceType3[85] = PlaceType.STADIUM;
    arrayOfPlaceType3[86] = PlaceType.STORAGE;
    arrayOfPlaceType3[87] = PlaceType.STORE;
    arrayOfPlaceType3[88] = PlaceType.SUBWAY_STATION;
    arrayOfPlaceType3[89] = PlaceType.SYNAGOGUE;
    arrayOfPlaceType3[90] = PlaceType.TAXI_STAND;
    arrayOfPlaceType3[91] = PlaceType.TRAIN_STATION;
    arrayOfPlaceType3[92] = PlaceType.TRAVEL_AGENCY;
    arrayOfPlaceType3[93] = PlaceType.UNIVERSITY;
    arrayOfPlaceType3[94] = PlaceType.VETERINARY_CARE;
    arrayOfPlaceType3[95] = PlaceType.ZOO;
    arrayOfPlaceType3[96] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_1;
    arrayOfPlaceType3[97] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_2;
    arrayOfPlaceType3[98] = PlaceType.ADMINISTRATIVE_AREA_LEVEL_3;
    arrayOfPlaceType3[99] = PlaceType.COLLOQUIAL_AREA;
    arrayOfPlaceType3[100] = PlaceType.COUNTRY;
    arrayOfPlaceType3[101] = PlaceType.FLOOR;
    arrayOfPlaceType3[102] = PlaceType.GEOCODE;
    arrayOfPlaceType3[103] = PlaceType.INTERSECTION;
    arrayOfPlaceType3[104] = PlaceType.LOCALITY;
    arrayOfPlaceType3[105] = PlaceType.NATURAL_FEATURE;
    arrayOfPlaceType3[106] = PlaceType.NEIGHBORHOOD;
    arrayOfPlaceType3[107] = PlaceType.POLITICAL;
    arrayOfPlaceType3[108] = PlaceType.POINT_OF_INTEREST;
    arrayOfPlaceType3[109] = PlaceType.POST_BOX;
    arrayOfPlaceType3[110] = PlaceType.POSTAL_CODE;
    arrayOfPlaceType3[111] = PlaceType.POSTAL_CODE_PREFIX;
    arrayOfPlaceType3[112] = PlaceType.POSTAL_TOWN;
    arrayOfPlaceType3[113] = PlaceType.PREMISE;
    arrayOfPlaceType3[114] = PlaceType.ROOM;
    arrayOfPlaceType3[115] = PlaceType.ROUTE;
    arrayOfPlaceType3[116] = PlaceType.STREET_ADDRESS;
    arrayOfPlaceType3[117] = PlaceType.SUBLOCALITY;
    arrayOfPlaceType3[118] = PlaceType.SUBLOCALITY_LEVEL_1;
    arrayOfPlaceType3[119] = PlaceType.SUBLOCALITY_LEVEL_2;
    arrayOfPlaceType3[120] = PlaceType.SUBLOCALITY_LEVEL_3;
    arrayOfPlaceType3[121] = PlaceType.SUBLOCALITY_LEVEL_4;
    arrayOfPlaceType3[122] = PlaceType.SUBLOCALITY_LEVEL_5;
    arrayOfPlaceType3[123] = PlaceType.SUBPREMISE;
    arrayOfPlaceType3[124] = PlaceType.TRANSIT_STATION;
    ALL = Collections.unmodifiableSet(new HashSet(Arrays.asList(arrayOfPlaceType3)));
    xL = new HashMap(ALL.size());
    Iterator localIterator = ALL.iterator();
    while (localIterator.hasNext())
    {
      PlaceType localPlaceType = (PlaceType)localIterator.next();
      xL.put(localPlaceType.getTypeName(), localPlaceType);
    }
  }
  
  public static final PlaceType get(String paramString)
  {
    return (PlaceType)xL.get(paramString);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceTypes
 * JD-Core Version:    0.7.0.1
 */