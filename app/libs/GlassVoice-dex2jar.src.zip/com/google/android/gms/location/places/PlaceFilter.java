package com.google.android.gms.location.places;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.ar.a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class PlaceFilter
  implements SafeParcelable
{
  public static final a CREATOR = new a();
  final int oj;
  final List<PlaceType> xA;
  private final String xB;
  private final boolean xC;
  private final Set<PlaceType> xD;
  
  PlaceFilter(int paramInt, List<PlaceType> paramList, String paramString, boolean paramBoolean)
  {
    this.oj = paramInt;
    if (paramList == null) {}
    for (List localList = Collections.emptyList();; localList = Collections.unmodifiableList(paramList))
    {
      this.xA = localList;
      if (paramString == null) {
        paramString = "";
      }
      this.xB = paramString;
      this.xC = paramBoolean;
      if (!this.xA.isEmpty()) {
        break;
      }
      this.xD = Collections.emptySet();
      return;
    }
    this.xD = Collections.unmodifiableSet(new HashSet(this.xA));
  }
  
  private PlaceFilter(List<PlaceType> paramList, String paramString, boolean paramBoolean)
  {
    this(0, paramList, paramString, paramBoolean);
  }
  
  public static PlaceFilter getDefaultFilter()
  {
    return new Builder(null).build();
  }
  
  public static Builder newBuilder()
  {
    return new Builder(null);
  }
  
  public static Builder newBuilder(PlaceFilter paramPlaceFilter)
  {
    return new Builder(paramPlaceFilter, null);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    PlaceFilter localPlaceFilter;
    do
    {
      return true;
      if (!(paramObject instanceof PlaceFilter)) {
        return false;
      }
      localPlaceFilter = (PlaceFilter)paramObject;
    } while ((this.xD.equals(localPlaceFilter.xD)) && (this.xB == localPlaceFilter.xB) && (this.xC == localPlaceFilter.xC));
    return false;
  }
  
  public Set<PlaceType> getPlaceTypes()
  {
    return this.xD;
  }
  
  public String getTextQuery()
  {
    return this.xB;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = this.xD;
    arrayOfObject[1] = this.xB;
    arrayOfObject[2] = Boolean.valueOf(this.xC);
    return ar.hashCode(arrayOfObject);
  }
  
  public boolean isOpenNowRequired()
  {
    return this.xC;
  }
  
  public String toString()
  {
    return ar.e(this).a("types", this.xD).a("textQuery", this.xB).a("isOpenNowRequired", Boolean.valueOf(this.xC)).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    a.a(this, paramParcel, paramInt);
  }
  
  public static final class Builder
  {
    private String xB = null;
    private boolean xC = false;
    private Collection<PlaceType> xE = null;
    
    private Builder() {}
    
    private Builder(PlaceFilter paramPlaceFilter)
    {
      this.xE = paramPlaceFilter.getPlaceTypes();
      this.xB = paramPlaceFilter.getTextQuery();
      this.xC = paramPlaceFilter.isOpenNowRequired();
    }
    
    public PlaceFilter build()
    {
      if (this.xE != null) {}
      for (ArrayList localArrayList = new ArrayList(this.xE);; localArrayList = null) {
        return new PlaceFilter(localArrayList, this.xB, this.xC, null);
      }
    }
    
    public Builder restrictToPlaceTypes(Collection<PlaceType> paramCollection)
    {
      this.xE = paramCollection;
      return this;
    }
    
    public Builder restrictToPlaceTypes(PlaceType... paramVarArgs)
    {
      return restrictToPlaceTypes(Arrays.asList(paramVarArgs));
    }
    
    public Builder restrictToPlacesOpenNow()
    {
      this.xC = true;
      return this;
    }
    
    public Builder textQuery(String paramString)
    {
      this.xB = paramString;
      return this;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceFilter
 * JD-Core Version:    0.7.0.1
 */