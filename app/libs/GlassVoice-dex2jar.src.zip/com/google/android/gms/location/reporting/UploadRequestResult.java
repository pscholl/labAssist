package com.google.android.gms.location.reporting;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;

public final class UploadRequestResult
  implements SafeParcelable
{
  public static final int CALLER_NOT_AUTHORIZED = 4;
  public static final f CREATOR = new f();
  public static final int DURATION_TOO_LONG = 2;
  @Deprecated
  public static final int EXPIRATION_TOO_LATE = 2;
  public static final long FAILURE_REQUEST_ID = -1L;
  public static final int ID_NOT_FOUND = 100;
  public static final int REPORTING_NOT_ACTIVE = 3;
  public static final int SUCCESS;
  private final int oj;
  private final int zb;
  private final long zc;
  
  UploadRequestResult(int paramInt1, int paramInt2, long paramLong)
  {
    this.oj = paramInt1;
    this.zb = paramInt2;
    this.zc = paramLong;
  }
  
  public UploadRequestResult(int paramInt, long paramLong)
  {
    this(1, paramInt, paramLong);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof UploadRequestResult)) {}
    UploadRequestResult localUploadRequestResult;
    do
    {
      return false;
      localUploadRequestResult = (UploadRequestResult)paramObject;
    } while ((this.zc != localUploadRequestResult.zc) || (this.zb != localUploadRequestResult.zb));
    return true;
  }
  
  public long getRequestId()
  {
    return this.zc;
  }
  
  public int getResultCode()
  {
    return this.zb;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = Integer.valueOf(this.zb);
    arrayOfObject[1] = Long.valueOf(this.zc);
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    return "Result{mVersionCode=" + this.oj + ", mResultCode=" + this.zb + ", mRequestId=" + this.zc + '}';
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    f.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.UploadRequestResult
 * JD-Core Version:    0.7.0.1
 */