package com.google.android.gms.location.places;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.internal.ai;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.bz;
import java.util.Locale;

public class Places
{
  public static final Api API = new Api(CLIENT_BUILDER, new Scope[0]);
  private static final Api.b<bz> CLIENT_BUILDER = new Api.b()
  {
    public bz b(Context paramAnonymousContext, Looper paramAnonymousLooper, ai paramAnonymousai, GoogleApiClient.ApiOptions paramAnonymousApiOptions, GoogleApiClient.ConnectionCallbacks paramAnonymousConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramAnonymousOnConnectionFailedListener)
    {
      if (paramAnonymousApiOptions == null) {}
      for (Object localObject = new Places.a.a().cD();; localObject = paramAnonymousApiOptions)
      {
        at.h(localObject instanceof Places.a);
        return new bz(paramAnonymousContext, paramAnonymousLooper, paramAnonymousConnectionCallbacks, paramAnonymousOnConnectionFailedListener, "places", null, Places.a.a((Places.a)localObject));
      }
    }
    
    public int getPriority()
    {
      return 2147483647;
    }
  };
  public static final PlacesApi PlacesApi = new f(CLIENT_BUILDER);
  
  public static final class a
    implements GoogleApiClient.ApiOptions
  {
    private final Locale locale;
    
    private a(a parama)
    {
      this.locale = a.a(parama);
    }
    
    public static class a
    {
      private Locale locale = Locale.getDefault();
      
      public Places.a cD()
      {
        return new Places.a(this, null);
      }
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.Places
 * JD-Core Version:    0.7.0.1
 */