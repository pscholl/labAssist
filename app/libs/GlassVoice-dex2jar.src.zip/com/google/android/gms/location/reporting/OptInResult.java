package com.google.android.gms.location.reporting;

public class OptInResult
{
  public static final int ACCOUNT_MISSING = 2;
  public static final int ACCOUNT_NOT_VALID = 3;
  public static final int CAN_NOT_BE_ACTIVATED = 7;
  public static final int COMMUNICATION_FAILURE = 8;
  public static final int REMOTE_EXCEPTION = 9;
  @Deprecated
  public static final int REPORTING_NOT_ALLOWED = 1;
  public static final int SENDER_MISSING = 4;
  public static final int SENDER_NON_GOOGLE = 6;
  public static final int SENDER_NOT_AUTHORIZED = 5;
  public static final int SUCCESS = 0;
  public static final int UNKNOWN = 1;
  
  public static int sanitize(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      paramInt = 1;
    }
    return paramInt;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.OptInResult
 * JD-Core Version:    0.7.0.1
 */