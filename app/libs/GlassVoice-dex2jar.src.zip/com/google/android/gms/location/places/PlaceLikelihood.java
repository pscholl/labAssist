package com.google.android.gms.location.places;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.ch;

public class PlaceLikelihood
  implements SafeParcelable
{
  public static final Parcelable.Creator<PlaceLikelihood> CREATOR = new b();
  final int oj;
  final ch xF;
  final float xG;
  
  PlaceLikelihood(int paramInt, ch paramch, float paramFloat)
  {
    this.oj = paramInt;
    this.xF = paramch;
    this.xG = paramFloat;
  }
  
  public static PlaceLikelihood create(ch paramch, float paramFloat)
  {
    return new PlaceLikelihood(0, (ch)at.f(paramch), paramFloat);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public float getLikelihood()
  {
    return this.xG;
  }
  
  public Place getPlace()
  {
    return this.xF;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceLikelihood
 * JD-Core Version:    0.7.0.1
 */