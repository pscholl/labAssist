package com.google.android.gms.location.places;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.internal.ch;

public class b
  implements Parcelable.Creator<PlaceLikelihood>
{
  static void a(PlaceLikelihood paramPlaceLikelihood, Parcel paramParcel, int paramInt)
  {
    int i = com.google.android.gms.common.internal.safeparcel.b.Z(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 1, paramPlaceLikelihood.xF, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1000, paramPlaceLikelihood.oj);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, paramPlaceLikelihood.xG);
    com.google.android.gms.common.internal.safeparcel.b.C(paramParcel, i);
  }
  
  public PlaceLikelihood[] aM(int paramInt)
  {
    return new PlaceLikelihood[paramInt];
  }
  
  public PlaceLikelihood ao(Parcel paramParcel)
  {
    int i = a.Y(paramParcel);
    int j = 0;
    Object localObject1 = null;
    float f1 = 0.0F;
    if (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      float f2;
      Object localObject2;
      int m;
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        f2 = f1;
        localObject2 = localObject1;
        m = j;
      }
      for (;;)
      {
        j = m;
        localObject1 = localObject2;
        f1 = f2;
        break;
        ch localch = (ch)a.a(paramParcel, k, ch.CREATOR);
        m = j;
        f2 = f1;
        localObject2 = localch;
        continue;
        int n = a.f(paramParcel, k);
        float f3 = f1;
        localObject2 = localObject1;
        m = n;
        f2 = f3;
        continue;
        f2 = a.i(paramParcel, k);
        localObject2 = localObject1;
        m = j;
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new PlaceLikelihood(j, localObject1, f1);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.b
 * JD-Core Version:    0.7.0.1
 */