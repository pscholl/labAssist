package com.google.android.gms.location.places;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLngBounds;

public abstract interface PlacesApi
{
  public abstract String getAttributions(GoogleApiClient paramGoogleApiClient);
  
  public abstract PendingResult<PlaceEstimateBuffer> getCurrentPlace(GoogleApiClient paramGoogleApiClient, PlaceFilter paramPlaceFilter);
  
  public abstract PendingResult<PlaceEstimateBuffer> getPlaceById(GoogleApiClient paramGoogleApiClient, String paramString);
  
  public abstract PendingResult<Status> reportPlace(GoogleApiClient paramGoogleApiClient, PlaceReport paramPlaceReport);
  
  public abstract PendingResult<PlaceEstimateBuffer> search(GoogleApiClient paramGoogleApiClient, LatLngBounds paramLatLngBounds, PlaceFilter paramPlaceFilter, int paramInt)
    throws PlacesApi.a;
  
  public static class PlaceResult
    implements Result
  {
    private final Status xM;
    private final Place xN;
    
    public PlaceResult(Status paramStatus, Place paramPlace)
    {
      this.xM = paramStatus;
      this.xN = paramPlace;
    }
    
    public Place getPlace()
    {
      return this.xN;
    }
    
    public Status getStatus()
    {
      return this.xM;
    }
  }
  
  public static class a
    extends RuntimeException
  {}
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlacesApi
 * JD-Core Version:    0.7.0.1
 */