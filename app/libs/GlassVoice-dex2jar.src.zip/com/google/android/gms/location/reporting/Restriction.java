package com.google.android.gms.location.reporting;

import android.util.Log;

public class Restriction
{
  public static final int ACCOUNT_DELETED = 5;
  public static final int ACCOUNT_PURGED = 6;
  public static final int AGE_UNDER_13 = 1;
  public static final int AGE_UNKNOWN = 2;
  public static final int DASHER_POLICY = 3;
  public static final int LEGAL_COUNTRY = 4;
  public static final int NONE = 0;
  public static final int UNKNOWN = -1;
  
  public static int decode(String paramString)
  {
    int i = 3;
    if (paramString == null) {
      i = 0;
    }
    do
    {
      return i;
      if ("ageUnder13".equals(paramString)) {
        return 1;
      }
      if ("ageUnknown".equals(paramString)) {
        return 2;
      }
    } while ("dasherPolicy".equals(paramString));
    if ("legalCountry".equals(paramString)) {
      return 4;
    }
    if ("accountDeleted".equals(paramString)) {
      return 5;
    }
    if ("accountPurged".equals(paramString)) {
      return 6;
    }
    if (Log.isLoggable("GCoreUlr", i)) {
      Log.d("GCoreUlr", "Unknown user restriction from server: " + paramString);
    }
    return -1;
  }
  
  public static InactiveReason getInactiveReason(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return new InactiveReason(7, "UnknownRestriction");
    case 0: 
      return null;
    case 1: 
      return new InactiveReason(7, "AgeUnder13");
    case 2: 
      return new InactiveReason(7, "AgeUnknown");
    case 3: 
      return new InactiveReason(7, "DasherPolicy");
    case 4: 
      return new InactiveReason(7, "LegalCountry");
    case 5: 
      return new InactiveReason(7, "AccountDeleted");
    }
    return new InactiveReason(7, "AccountPurged");
  }
  
  public static boolean isRestricted(int paramInt)
  {
    return paramInt != 0;
  }
  
  public static int sanitize(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      paramInt = -1;
    }
    return paramInt;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.Restriction
 * JD-Core Version:    0.7.0.1
 */