package com.google.android.gms.location.reporting;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;

public class ReportingState
  implements SafeParcelable
{
  public static final d CREATOR = new d();
  private final int oj;
  private final int yO;
  private final int yP;
  private final boolean yQ;
  private final boolean yR;
  private final boolean yS;
  private final int yT;
  
  public ReportingState(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt4)
  {
    this.oj = paramInt1;
    this.yO = paramInt2;
    this.yP = paramInt3;
    this.yQ = paramBoolean1;
    this.yR = paramBoolean2;
    this.yS = paramBoolean3;
    this.yT = paramInt4;
  }
  
  public ReportingState(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3)
  {
    this(1, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof ReportingState)) {}
    ReportingState localReportingState;
    do
    {
      return false;
      localReportingState = (ReportingState)paramObject;
    } while ((this.yO != localReportingState.yO) || (this.yP != localReportingState.yP) || (this.yQ != localReportingState.yQ) || (this.yR != localReportingState.yR) || (this.yS != localReportingState.yS) || (this.yT != localReportingState.yT));
    return true;
  }
  
  public int getExpectedOptInResult()
  {
    return OptInResult.sanitize(this.yT);
  }
  
  public int getHistoryEnabled()
  {
    return Setting.sanitize(this.yP);
  }
  
  public int getReportingEnabled()
  {
    return Setting.sanitize(this.yO);
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[6];
    arrayOfObject[0] = Integer.valueOf(this.yO);
    arrayOfObject[1] = Integer.valueOf(this.yP);
    arrayOfObject[2] = Boolean.valueOf(this.yQ);
    arrayOfObject[3] = Boolean.valueOf(this.yR);
    arrayOfObject[4] = Boolean.valueOf(this.yS);
    arrayOfObject[5] = Integer.valueOf(this.yT);
    return ar.hashCode(arrayOfObject);
  }
  
  public boolean isActive()
  {
    return this.yR;
  }
  
  public boolean isAllowed()
  {
    return this.yQ;
  }
  
  public boolean isAmbiguous()
  {
    return (this.yO == -2) || (this.yP == -2);
  }
  
  public boolean isDeferringToMaps()
  {
    return this.yS;
  }
  
  public boolean isOptedIn()
  {
    return (Setting.isOn(this.yO)) && (Setting.isOn(this.yP));
  }
  
  @Deprecated
  public boolean shouldOptIn()
  {
    return shouldOptInInsistent();
  }
  
  public boolean shouldOptInInsistent()
  {
    return (!isOptedIn()) && (getExpectedOptInResult() == 0);
  }
  
  public boolean shouldOptInLenient()
  {
    return ((Setting.isOff(this.yO)) || (Setting.isOff(this.yP))) && (getExpectedOptInResult() == 0);
  }
  
  public String toString()
  {
    return "ReportingState{mReportingEnabled=" + this.yO + ", mHistoryEnabled=" + this.yP + ", mAllowed=" + this.yQ + ", mActive=" + this.yR + ", mDefer=" + this.yS + ", mExpectedOptInResult=" + this.yT + ", mVersionCode=" + this.oj + '}';
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    d.a(this, paramParcel, paramInt);
  }
  
  public static final class Setting
  {
    public static final int AMBIGUOUS = -2;
    public static final int OFF = -1;
    public static final int ON = 1;
    public static final int UNDEFINED = 0;
    public static final int UNKNOWN_OFF = -3;
    public static final int UNKNOWN_ON = 99;
    
    public static boolean isOff(int paramInt)
    {
      return paramInt < 0;
    }
    
    public static boolean isOn(int paramInt)
    {
      return paramInt > 0;
    }
    
    public static int sanitize(int paramInt)
    {
      switch (paramInt)
      {
      default: 
        if (!isOn(paramInt)) {
          break;
        }
      }
      for (int i = 99;; i = -3)
      {
        paramInt = i;
        return paramInt;
      }
    }
    
    public static String toString(int paramInt)
    {
      switch (paramInt)
      {
      default: 
        return "Unknown";
      case 0: 
        return "Undefined";
      case -2: 
        return "Ambiguous";
      case -1: 
        return "Off";
      }
      return "On";
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.ReportingState
 * JD-Core Version:    0.7.0.1
 */