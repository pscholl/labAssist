package com.google.android.gms.location.reporting;

import android.accounts.Account;
import android.content.Context;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.internal.cr;
import com.google.android.gms.location.places.PlaceReport;
import java.io.IOException;

public class ReportingClient
  implements GooglePlayServicesClient
{
  public static final String SETTINGS_CHANGED = "com.google.android.gms.location.reporting.SETTINGS_CHANGED";
  private final cr yN;
  
  public ReportingClient(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.yN = new cr(paramContext, paramConnectionCallbacks, paramOnConnectionFailedListener, new String[0]);
  }
  
  public int cancelUpload(long paramLong)
    throws IOException
  {
    return this.yN.cancelUpload(paramLong);
  }
  
  public void connect()
  {
    this.yN.connect();
  }
  
  public void disconnect()
  {
    this.yN.disconnect();
  }
  
  public ReportingState getReportingState(Account paramAccount)
    throws IOException
  {
    return this.yN.getReportingState(paramAccount);
  }
  
  public boolean isConnected()
  {
    return this.yN.isConnected();
  }
  
  public boolean isConnecting()
  {
    return this.yN.isConnected();
  }
  
  public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    return this.yN.isConnectionCallbacksRegistered(paramConnectionCallbacks);
  }
  
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    return this.yN.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.yN.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.yN.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public int reportPlace(Account paramAccount, PlaceReport paramPlaceReport)
    throws IOException
  {
    return this.yN.reportPlace(paramAccount, paramPlaceReport);
  }
  
  public UploadRequestResult requestUpload(UploadRequest paramUploadRequest)
    throws IOException
  {
    return this.yN.requestUpload(paramUploadRequest);
  }
  
  public int tryOptIn(Account paramAccount)
  {
    return this.yN.tryOptIn(paramAccount);
  }
  
  public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.yN.unregisterConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.yN.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.ReportingClient
 * JD-Core Version:    0.7.0.1
 */