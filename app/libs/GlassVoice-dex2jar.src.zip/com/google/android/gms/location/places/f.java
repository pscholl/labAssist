package com.google.android.gms.location.places;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.common.data.d;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.bz;
import com.google.android.gms.internal.cd.a;
import com.google.android.gms.internal.cl;
import com.google.android.gms.maps.model.LatLngBounds;

public class f
  implements PlacesApi
{
  private final Api.b<bz> qP;
  
  public f(Api.b<bz> paramb)
  {
    this.qP = paramb;
  }
  
  public String getAttributions(GoogleApiClient paramGoogleApiClient)
  {
    return ((bz)paramGoogleApiClient.a(this.qP)).cx().cN();
  }
  
  public PendingResult<PlaceEstimateBuffer> getCurrentPlace(GoogleApiClient paramGoogleApiClient, final PlaceFilter paramPlaceFilter)
  {
    paramGoogleApiClient.a(new a(this.qP)
    {
      protected void a(bz paramAnonymousbz)
        throws RemoteException
      {
        paramAnonymousbz.cx().a(new f.b(f.this, this, null), paramPlaceFilter);
      }
      
      protected PlaceEstimateBuffer d(Status paramAnonymousStatus)
      {
        return PlaceEstimateBuffer.empty(paramAnonymousStatus);
      }
    });
  }
  
  public PendingResult<PlaceEstimateBuffer> getPlaceById(GoogleApiClient paramGoogleApiClient, final String paramString)
  {
    at.C(paramString);
    paramGoogleApiClient.a(new a(this.qP)
    {
      protected void a(bz paramAnonymousbz)
        throws RemoteException
      {
        paramAnonymousbz.cx().a(new f.b(f.this, this, null), paramString);
      }
      
      protected PlaceEstimateBuffer d(Status paramAnonymousStatus)
      {
        return PlaceEstimateBuffer.empty(paramAnonymousStatus);
      }
    });
  }
  
  public PendingResult<Status> reportPlace(GoogleApiClient paramGoogleApiClient, final PlaceReport paramPlaceReport)
  {
    paramGoogleApiClient.a(new a(this.qP)
    {
      protected void a(bz paramAnonymousbz)
        throws RemoteException
      {
        paramAnonymousbz.cx().a(this, paramPlaceReport);
      }
      
      protected Status c(Status paramAnonymousStatus)
      {
        return paramAnonymousStatus;
      }
    });
  }
  
  public PendingResult<PlaceEstimateBuffer> search(GoogleApiClient paramGoogleApiClient, final LatLngBounds paramLatLngBounds, final PlaceFilter paramPlaceFilter, final int paramInt)
  {
    paramGoogleApiClient.a(new a(this.qP)
    {
      protected void a(bz paramAnonymousbz)
        throws RemoteException
      {
        paramAnonymousbz.cx().a(new f.b(f.this, this, null), paramLatLngBounds, paramInt, paramPlaceFilter);
      }
      
      protected PlaceEstimateBuffer d(Status paramAnonymousStatus)
      {
        return PlaceEstimateBuffer.empty(paramAnonymousStatus);
      }
    });
  }
  
  public static abstract class a<R extends Result>
    extends a.a<R, bz>
  {
    public a(Api.b<bz> paramb)
    {
      super();
    }
  }
  
  public class b
    extends cd.a
  {
    private final f.a<PlaceEstimateBuffer> xU;
    
    private b()
    {
      Object localObject;
      this.xU = localObject;
    }
    
    public void a(d paramd)
      throws RemoteException
    {
      PlaceEstimateBuffer localPlaceEstimateBuffer = new PlaceEstimateBuffer(paramd);
      this.xU.a(localPlaceEstimateBuffer);
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.f
 * JD-Core Version:    0.7.0.1
 */