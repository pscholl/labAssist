package com.google.android.gms.location.places;

@Deprecated
public abstract class PlaceEstimate
{
  public abstract Place getPlace(int paramInt);
  
  public abstract int getPlaceCount();
  
  public abstract float getProbability(int paramInt);
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceEstimate
 * JD-Core Version:    0.7.0.1
 */