package com.google.android.gms.location.places;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.location.LocationRequest;

public class d
  implements Parcelable.Creator<PlaceRequest>
{
  static void a(PlaceRequest paramPlaceRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.a(paramParcel, 1, paramPlaceRequest.getLocationRequest(), paramInt, false);
    b.c(paramParcel, 1000, paramPlaceRequest.oj);
    b.a(paramParcel, 2, paramPlaceRequest.getFilter(), paramInt, false);
    b.C(paramParcel, i);
  }
  
  public PlaceRequest[] aO(int paramInt)
  {
    return new PlaceRequest[paramInt];
  }
  
  public PlaceRequest aq(Parcel paramParcel)
  {
    Object localObject1 = null;
    int i = a.Y(paramParcel);
    int j = 0;
    Object localObject2 = null;
    if (paramParcel.dataPosition() < i)
    {
      int k = a.X(paramParcel);
      Object localObject3;
      Object localObject4;
      int m;
      switch (a.al(k))
      {
      default: 
        a.b(paramParcel, k);
        localObject3 = localObject1;
        localObject4 = localObject2;
        m = j;
      }
      for (;;)
      {
        j = m;
        localObject2 = localObject4;
        localObject1 = localObject3;
        break;
        LocationRequest localLocationRequest = (LocationRequest)a.a(paramParcel, k, LocationRequest.CREATOR);
        m = j;
        localObject3 = localObject1;
        localObject4 = localLocationRequest;
        continue;
        int n = a.f(paramParcel, k);
        Object localObject5 = localObject1;
        localObject4 = localObject2;
        m = n;
        localObject3 = localObject5;
        continue;
        localObject3 = (PlaceFilter)a.a(paramParcel, k, PlaceFilter.CREATOR);
        localObject4 = localObject2;
        m = j;
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new PlaceRequest(j, localObject2, localObject1);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.d
 * JD-Core Version:    0.7.0.1
 */