package com.google.android.gms.location;

import android.app.PendingIntent;
import android.location.Location;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient;

public abstract interface FusedLocationProvider
{
  public static final String EXTRA_KEY_LOCATION_TYPE = "locationType";
  public static final String EXTRA_VALUE_LOCATION_TYPE_CELL = "cell";
  public static final String EXTRA_VALUE_LOCATION_TYPE_GPS = "gps";
  public static final String EXTRA_VALUE_LOCATION_TYPE_WIFI = "wifi";
  public static final int INJECTION_TYPE_GPS_EXTERNAL = 1;
  public static final String KEY_LOCATION_CHANGED = "com.google.android.location.LOCATION";
  public static final String KEY_MOCK_LOCATION = "mockLocation";
  
  public abstract Location getLastLocation(GoogleApiClient paramGoogleApiClient);
  
  public abstract LocationStatus getLastLocationStatus(GoogleApiClient paramGoogleApiClient);
  
  public abstract void injectLocation(GoogleApiClient paramGoogleApiClient, Location paramLocation, int paramInt);
  
  public abstract void removeLocationUpdates(GoogleApiClient paramGoogleApiClient, PendingIntent paramPendingIntent);
  
  public abstract void removeLocationUpdates(GoogleApiClient paramGoogleApiClient, LocationListener paramLocationListener);
  
  public abstract void requestLocationUpdates(GoogleApiClient paramGoogleApiClient, LocationRequest paramLocationRequest, PendingIntent paramPendingIntent);
  
  public abstract void requestLocationUpdates(GoogleApiClient paramGoogleApiClient, LocationRequest paramLocationRequest, LocationListener paramLocationListener);
  
  public abstract void requestLocationUpdates(GoogleApiClient paramGoogleApiClient, LocationRequest paramLocationRequest, LocationListener paramLocationListener, Looper paramLooper);
  
  public abstract void setMockLocation(GoogleApiClient paramGoogleApiClient, Location paramLocation);
  
  public abstract void setMockMode(GoogleApiClient paramGoogleApiClient, boolean paramBoolean);
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.FusedLocationProvider
 * JD-Core Version:    0.7.0.1
 */