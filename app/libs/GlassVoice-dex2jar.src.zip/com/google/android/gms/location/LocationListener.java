package com.google.android.gms.location;

import android.location.Location;

public abstract interface LocationListener
{
  public abstract void onLocationChanged(Location paramLocation);
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.LocationListener
 * JD-Core Version:    0.7.0.1
 */