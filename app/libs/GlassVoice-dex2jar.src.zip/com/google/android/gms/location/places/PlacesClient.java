package com.google.android.gms.location.places;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.internal.bz;
import com.google.android.gms.internal.cl;
import java.io.IOException;
import java.util.List;

@Deprecated
public class PlacesClient
  implements GooglePlayServicesClient
{
  private final bz wu;
  private final cl xV;
  
  public PlacesClient(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.wu = new bz(paramContext, new a(paramConnectionCallbacks), paramOnConnectionFailedListener, "places");
    this.xV = this.wu.cx();
  }
  
  public static PlaceEstimate getPlaceEstimate(Intent paramIntent)
  {
    return cl.e(paramIntent);
  }
  
  public boolean arePlaceIdsEquivalent(String paramString1, String paramString2)
  {
    return this.xV.arePlaceIdsEquivalent(paramString1, paramString2);
  }
  
  public void connect()
  {
    this.wu.connect();
  }
  
  public void disconnect()
  {
    this.xV.cO();
    this.wu.disconnect();
  }
  
  public boolean isConnected()
  {
    return this.wu.isConnected();
  }
  
  public boolean isConnecting()
  {
    return this.wu.isConnecting();
  }
  
  public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    return this.wu.isConnectionCallbacksRegistered(paramConnectionCallbacks);
  }
  
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    return this.wu.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.wu.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.wu.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void removePlaceUpdates(PendingIntent paramPendingIntent)
  {
    this.xV.removePlaceUpdates(paramPendingIntent);
  }
  
  public void requestPlaceUpdates(PlaceRequest paramPlaceRequest, PendingIntent paramPendingIntent)
  {
    this.xV.requestPlaceUpdates(paramPlaceRequest, paramPendingIntent);
  }
  
  public List<Place> searchByPhoneNumber(String paramString)
    throws IOException
  {
    return this.xV.searchByPhoneNumber(paramString);
  }
  
  public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
  {
    this.wu.unregisterConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener)
  {
    this.wu.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  private class a
    implements GooglePlayServicesClient.ConnectionCallbacks
  {
    private final GooglePlayServicesClient.ConnectionCallbacks xW;
    
    public a(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks)
    {
      this.xW = paramConnectionCallbacks;
    }
    
    public void onConnected(Bundle paramBundle)
    {
      PlacesClient.a(PlacesClient.this).onConnected();
      this.xW.onConnected(paramBundle);
    }
    
    public void onDisconnected()
    {
      this.xW.onDisconnected();
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlacesClient
 * JD-Core Version:    0.7.0.1
 */