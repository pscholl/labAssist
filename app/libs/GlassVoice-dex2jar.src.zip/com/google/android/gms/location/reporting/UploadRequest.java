package com.google.android.gms.location.reporting;

import android.accounts.Account;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.at;
import com.google.android.gms.internal.cq;

public class UploadRequest
  implements SafeParcelable
{
  public static final e CREATOR = new e();
  private final int oj;
  private final Account yK;
  private final String yU;
  private final long yV;
  private final long yW;
  private final long yX;
  private final String yY;
  
  UploadRequest(int paramInt, Account paramAccount, String paramString1, long paramLong1, long paramLong2, long paramLong3, String paramString2)
  {
    this.oj = paramInt;
    this.yK = paramAccount;
    this.yU = paramString1;
    this.yV = paramLong1;
    this.yW = paramLong2;
    this.yX = paramLong3;
    this.yY = paramString2;
  }
  
  private UploadRequest(Builder paramBuilder)
  {
    this.oj = 1;
    this.yK = Builder.a(paramBuilder);
    this.yU = Builder.b(paramBuilder);
    this.yV = Builder.c(paramBuilder);
    this.yW = Builder.d(paramBuilder);
    this.yX = Builder.e(paramBuilder);
    this.yY = Builder.f(paramBuilder);
  }
  
  public static Builder builder(Account paramAccount, String paramString, long paramLong)
  {
    return new Builder(paramAccount, paramString, paramLong, null);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    UploadRequest localUploadRequest;
    do
    {
      return true;
      if (!(paramObject instanceof UploadRequest)) {
        return false;
      }
      localUploadRequest = (UploadRequest)paramObject;
    } while ((this.yK.equals(localUploadRequest.yK)) && (this.yU.equals(localUploadRequest.yU)) && (ar.equal(Long.valueOf(this.yV), Long.valueOf(localUploadRequest.yV))) && (this.yW == localUploadRequest.yW) && (this.yX == localUploadRequest.yX) && (ar.equal(this.yY, localUploadRequest.yY)));
    return false;
  }
  
  public Account getAccount()
  {
    return this.yK;
  }
  
  public String getAppSpecificKey()
  {
    return this.yY;
  }
  
  public long getDurationMillis()
  {
    return this.yV;
  }
  
  public long getMovingLatencyMillis()
  {
    return this.yW;
  }
  
  public String getReason()
  {
    return this.yU;
  }
  
  public long getStationaryLatencyMillis()
  {
    return this.yX;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[6];
    arrayOfObject[0] = this.yK;
    arrayOfObject[1] = this.yU;
    arrayOfObject[2] = Long.valueOf(this.yV);
    arrayOfObject[3] = Long.valueOf(this.yW);
    arrayOfObject[4] = Long.valueOf(this.yX);
    arrayOfObject[5] = this.yY;
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    return "UploadRequest{mVersionCode=" + this.oj + ", mAccount=" + cq.a(this.yK) + ", mReason='" + this.yU + '\'' + ", mDurationMillis=" + this.yV + ", mMovingLatencyMillis=" + this.yW + ", mStationaryLatencyMillis=" + this.yX + ", mAppSpecificKey='" + this.yY + '\'' + '}';
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    e.a(this, paramParcel, paramInt);
  }
  
  public static class Builder
  {
    private final Account yK;
    private final String yU;
    private final long yV;
    private String yY;
    private long yZ = 9223372036854775807L;
    private long za = 9223372036854775807L;
    
    private Builder(Account paramAccount, String paramString, long paramLong)
    {
      this.yK = ((Account)at.a(paramAccount, "account"));
      this.yU = ((String)at.a(paramString, "reason"));
      this.yV = paramLong;
    }
    
    public Builder appSpecificKey(String paramString)
    {
      this.yY = paramString;
      return this;
    }
    
    public UploadRequest build()
    {
      return new UploadRequest(this, null);
    }
    
    public Builder latencyMillis(long paramLong)
    {
      return movingLatencyMillis(paramLong).stationaryLatencyMillis(paramLong);
    }
    
    public Builder movingLatencyMillis(long paramLong)
    {
      this.yZ = paramLong;
      return this;
    }
    
    public Builder stationaryLatencyMillis(long paramLong)
    {
      this.za = paramLong;
      return this;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.UploadRequest
 * JD-Core Version:    0.7.0.1
 */