package com.google.android.gms.location.places;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.ar.a;
import com.google.android.gms.internal.at;

public class PlaceReport
  implements SafeParcelable
{
  public static final c CREATOR = new c();
  private final String mTag;
  final int oj;
  private final String xH;
  
  PlaceReport(int paramInt, String paramString1, String paramString2)
  {
    this.oj = paramInt;
    this.xH = paramString1;
    this.mTag = paramString2;
  }
  
  public static PlaceReport create(String paramString1, String paramString2)
  {
    at.C(paramString1);
    at.C(paramString2);
    return new PlaceReport(1, paramString1, paramString2);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof PlaceReport)) {}
    PlaceReport localPlaceReport;
    do
    {
      return false;
      localPlaceReport = (PlaceReport)paramObject;
    } while ((!ar.equal(this.xH, localPlaceReport.xH)) || (!ar.equal(this.mTag, localPlaceReport.mTag)));
    return true;
  }
  
  public String getPlaceId()
  {
    return this.xH;
  }
  
  public String getTag()
  {
    return this.mTag;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = this.xH;
    arrayOfObject[1] = this.mTag;
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    return ar.e(this).a("mPlaceId", this.xH).a("mTag", this.mTag).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceReport
 * JD-Core Version:    0.7.0.1
 */