package com.google.android.gms.location.places;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class a
  implements Parcelable.Creator<PlaceFilter>
{
  static void a(PlaceFilter paramPlaceFilter, Parcel paramParcel, int paramInt)
  {
    int i = b.Z(paramParcel);
    b.b(paramParcel, 1, paramPlaceFilter.xA, false);
    b.c(paramParcel, 1000, paramPlaceFilter.oj);
    b.a(paramParcel, 2, paramPlaceFilter.getTextQuery(), false);
    b.a(paramParcel, 3, paramPlaceFilter.isOpenNowRequired());
    b.C(paramParcel, i);
  }
  
  public PlaceFilter[] aL(int paramInt)
  {
    return new PlaceFilter[paramInt];
  }
  
  public PlaceFilter an(Parcel paramParcel)
  {
    String str = null;
    boolean bool = false;
    int i = com.google.android.gms.common.internal.safeparcel.a.Y(paramParcel);
    ArrayList localArrayList = null;
    int j = 0;
    while (paramParcel.dataPosition() < i)
    {
      int k = com.google.android.gms.common.internal.safeparcel.a.X(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.al(k))
      {
      default: 
        com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, k);
        break;
      case 1: 
        localArrayList = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, k, PlaceType.CREATOR);
        break;
      case 1000: 
        j = com.google.android.gms.common.internal.safeparcel.a.f(paramParcel, k);
        break;
      case 2: 
        str = com.google.android.gms.common.internal.safeparcel.a.l(paramParcel, k);
        break;
      case 3: 
        bool = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i) {
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    }
    return new PlaceFilter(j, localArrayList, str, bool);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.a
 * JD-Core Version:    0.7.0.1
 */