package com.google.android.gms.location;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;

public class LocationStatus
  implements SafeParcelable
{
  public static final b CREATOR = new b();
  public static final int STATUS_INVALID_SCAN = 4;
  public static final int STATUS_IN_PROGRESS = 8;
  public static final int STATUS_LOCATION_DISABLED_IN_SETTINGS = 7;
  public static final int STATUS_NO_INFO_IN_DATABASE = 3;
  public static final int STATUS_SCANS_DISABLED_IN_SETTINGS = 6;
  public static final int STATUS_SUCCESSFUL = 0;
  public static final int STATUS_TIMED_OUT_ON_SCAN = 2;
  public static final int STATUS_UNABLE_TO_QUERY_DATABASE = 5;
  public static final int STATUS_UNKNOWN = 1;
  private final int oj;
  int wO;
  int wP;
  long wQ;
  
  LocationStatus(int paramInt1, int paramInt2, int paramInt3, long paramLong)
  {
    this.oj = paramInt1;
    this.wO = paramInt2;
    this.wP = paramInt3;
    this.wQ = paramLong;
  }
  
  private String aE(int paramInt)
  {
    switch (paramInt)
    {
    case 1: 
    default: 
      return "STATUS_UNKNOWN";
    case 0: 
      return "STATUS_SUCCESSFUL";
    case 2: 
      return "STATUS_TIMED_OUT_ON_SCAN";
    case 3: 
      return "STATUS_NO_INFO_IN_DATABASE";
    case 4: 
      return "STATUS_INVALID_SCAN";
    case 5: 
      return "STATUS_UNABLE_TO_QUERY_DATABASE";
    case 6: 
      return "STATUS_SCANS_DISABLED_IN_SETTINGS";
    case 7: 
      return "STATUS_LOCATION_DISABLED_IN_SETTINGS";
    }
    return "STATUS_IN_PROGRESS";
  }
  
  public static LocationStatus create(int paramInt1, int paramInt2, long paramLong)
  {
    return new LocationStatus(1, paramInt1, paramInt2, paramLong);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof LocationStatus)) {}
    LocationStatus localLocationStatus;
    do
    {
      return false;
      localLocationStatus = (LocationStatus)paramObject;
    } while ((this.wO != localLocationStatus.wO) || (this.wP != localLocationStatus.wP) || (this.wQ != localLocationStatus.wQ));
    return true;
  }
  
  public int getCellStatus()
  {
    return this.wO;
  }
  
  public long getElapsedRealtimeNs()
  {
    return this.wQ;
  }
  
  int getVersionCode()
  {
    return this.oj;
  }
  
  public int getWifiStatus()
  {
    return this.wP;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = Integer.valueOf(this.wO);
    arrayOfObject[1] = Integer.valueOf(this.wP);
    arrayOfObject[2] = Long.valueOf(this.wQ);
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("LocationStatus[cell status: ").append(aE(this.wO));
    localStringBuilder.append(", wifi status: ").append(aE(this.wP));
    localStringBuilder.append(", elapsed realtime ns: ").append(this.wQ);
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.LocationStatus
 * JD-Core Version:    0.7.0.1
 */