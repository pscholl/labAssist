package com.google.android.gms.location.reporting;

public class PlaceReportResult
{
  public static final int FAILED_TO_WRITE_TO_STORE = 2;
  public static final int REPORTING_NOT_ACTIVE = 1;
  public static final int SUCCESS;
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.reporting.PlaceReportResult
 * JD-Core Version:    0.7.0.1
 */