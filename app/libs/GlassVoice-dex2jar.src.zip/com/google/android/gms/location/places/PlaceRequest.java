package com.google.android.gms.location.places;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ar;
import com.google.android.gms.internal.ar.a;
import com.google.android.gms.location.LocationRequest;

public final class PlaceRequest
  implements SafeParcelable
{
  public static final d CREATOR = new d();
  final int oj;
  private final LocationRequest xI;
  private final PlaceFilter xJ;
  
  public PlaceRequest(int paramInt, LocationRequest paramLocationRequest, PlaceFilter paramPlaceFilter)
  {
    this.oj = paramInt;
    this.xI = paramLocationRequest;
    this.xJ = paramPlaceFilter;
  }
  
  private PlaceRequest(LocationRequest paramLocationRequest, PlaceFilter paramPlaceFilter)
  {
    this(0, paramLocationRequest, paramPlaceFilter);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    PlaceRequest localPlaceRequest;
    do
    {
      return true;
      if (!(paramObject instanceof PlaceRequest)) {
        return false;
      }
      localPlaceRequest = (PlaceRequest)paramObject;
    } while ((this.xI.equals(localPlaceRequest.xI)) && (this.xJ.equals(localPlaceRequest.xJ)));
    return false;
  }
  
  public PlaceFilter getFilter()
  {
    return this.xJ;
  }
  
  public LocationRequest getLocationRequest()
  {
    return this.xI;
  }
  
  public int hashCode()
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = this.xI;
    arrayOfObject[1] = this.xJ;
    return ar.hashCode(arrayOfObject);
  }
  
  public String toString()
  {
    return ar.e(this).a("locationRequest", this.xI).a("filter", this.xJ).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    d.a(this, paramParcel, paramInt);
  }
  
  public static final class Builder
  {
    private LocationRequest xI = null;
    private PlaceFilter xJ = null;
    
    public PlaceRequest build()
    {
      if (this.xI == null) {
        throw new IllegalArgumentException("LocationRequest not set");
      }
      return new PlaceRequest(this.xI, this.xJ, null);
    }
    
    public Builder filter(PlaceFilter paramPlaceFilter)
    {
      this.xJ = paramPlaceFilter;
      return this;
    }
    
    public Builder locationRequest(LocationRequest paramLocationRequest)
    {
      this.xI = paramLocationRequest;
      return this;
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceRequest
 * JD-Core Version:    0.7.0.1
 */