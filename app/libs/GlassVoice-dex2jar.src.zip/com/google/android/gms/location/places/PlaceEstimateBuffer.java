package com.google.android.gms.location.places;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.c;
import com.google.android.gms.common.data.d;
import com.google.android.gms.common.data.d.a;

public class PlaceEstimateBuffer
  extends c<PlaceLikelihood>
  implements Result
{
  private final Status xz;
  
  public PlaceEstimateBuffer(d paramd)
  {
    super(paramd, PlaceLikelihood.CREATOR);
    this.xz = new Status(paramd.getStatusCode());
  }
  
  public static PlaceEstimateBuffer empty(Status paramStatus)
  {
    return new PlaceEstimateBuffer(emptyDataHolder(paramStatus.getStatusCode()));
  }
  
  public static d emptyDataHolder(int paramInt)
  {
    return c.buildDataHolder().ae(paramInt);
  }
  
  public Status getStatus()
  {
    return this.xz;
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.PlaceEstimateBuffer
 * JD-Core Version:    0.7.0.1
 */