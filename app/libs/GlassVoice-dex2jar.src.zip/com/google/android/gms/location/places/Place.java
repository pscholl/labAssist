package com.google.android.gms.location.places;

import android.net.Uri;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public abstract class Place
{
  public abstract String getAddress();
  
  public abstract Map<PlaceType, String> getAddressComponents();
  
  public abstract String getId();
  
  public abstract LatLng getLatLng();
  
  public abstract float getLevelNumber();
  
  public abstract Locale getLocale();
  
  public abstract String getName();
  
  public abstract OpeningHours getOpeningHours();
  
  public abstract String getPhoneNumber();
  
  public abstract int getPriceLevel();
  
  public abstract float getRating();
  
  public abstract TimeZone getTimeZone();
  
  public abstract List<PlaceType> getTypes();
  
  public abstract LatLngBounds getViewport();
  
  public abstract Uri getWebsiteUri();
  
  public abstract boolean isPermanentlyClosed();
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.places.Place
 * JD-Core Version:    0.7.0.1
 */