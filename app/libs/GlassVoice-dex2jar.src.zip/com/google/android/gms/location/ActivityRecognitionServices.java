package com.google.android.gms.location;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.internal.ai;
import com.google.android.gms.internal.bt;
import com.google.android.gms.internal.bz;

public class ActivityRecognitionServices
{
  public static final Api API = new Api(CLIENT_BUILDER, new Scope[0]);
  public static ActivityRecognition ActivityRecognitionApi = new bt();
  private static final Api.b<bz> CLIENT_BUILDER = new Api.b()
  {
    public bz b(Context paramAnonymousContext, Looper paramAnonymousLooper, ai paramAnonymousai, GoogleApiClient.ApiOptions paramAnonymousApiOptions, GoogleApiClient.ConnectionCallbacks paramAnonymousConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramAnonymousOnConnectionFailedListener)
    {
      return new bz(paramAnonymousContext, paramAnonymousLooper, paramAnonymousConnectionCallbacks, paramAnonymousOnConnectionFailedListener, "activity_recognition");
    }
    
    public int getPriority()
    {
      return 2147483647;
    }
  };
  public static final String CLIENT_NAME = "activity_recognition";
  
  public static abstract class a<R extends Result>
    extends a.a<R, bz>
  {
    public a()
    {
      super();
    }
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.gms.location.ActivityRecognitionServices
 * JD-Core Version:    0.7.0.1
 */