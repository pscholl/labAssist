package com.google.android.gms.ads.adshield;

import android.content.Context;
import android.net.Uri;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.internal.v;
import com.google.android.gms.internal.w;

public final class AdShieldClient
{
  private final w jS;
  
  public AdShieldClient(String paramString, Context paramContext)
  {
    this.jS = v.b(paramString, paramContext);
  }
  
  public Uri addSignalsToAdRequest(Uri paramUri, Context paramContext)
    throws UrlParseException, RemoteException
  {
    b localb1 = c.g(paramUri);
    b localb2 = c.g(paramContext);
    b localb3 = this.jS.a(localb1, localb2);
    if (localb3 == null) {
      throw new UrlParseException();
    }
    return (Uri)c.d(localb3);
  }
  
  public String getAdRequestSignals(Context paramContext)
    throws RemoteException
  {
    return this.jS.c(c.g(paramContext));
  }
  
  public String getSignalsUrlKey()
    throws RemoteException
  {
    return this.jS.getSignalsUrlKey();
  }
  
  public boolean isAdRequestAdSense(Uri paramUri)
    throws RemoteException
  {
    b localb = c.g(paramUri);
    return this.jS.a(localb);
  }
  
  public boolean isGoogleAdUrl(Uri paramUri)
    throws RemoteException
  {
    b localb = c.g(paramUri);
    return this.jS.b(localb);
  }
  
  public void setAdSenseDomainAndPath(String paramString1, String paramString2)
    throws RemoteException
  {
    this.jS.setAdSenseDomainAndPath(paramString1, paramString2);
  }
  
  public void setGoogleAdUrlSuffixes(String paramString)
    throws RemoteException
  {
    this.jS.setGoogleAdUrlSuffixes(paramString);
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.adshield.AdShieldClient
 * JD-Core Version:    0.7.0.1
 */