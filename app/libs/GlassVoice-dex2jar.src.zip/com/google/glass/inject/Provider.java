package com.google.glass.inject;

import com.google.common.base.Preconditions;
import com.google.common.base.Supplier;
import com.google.glass.predicates.Assert;
import java.util.concurrent.atomic.AtomicReference;

public class Provider<V>
{
  private final AtomicReference<V> testInstanceRef = new AtomicReference();
  
  public void clearTestInstance()
  {
    Assert.assertIsTest();
    this.testInstanceRef.set(null);
  }
  
  protected V get(Supplier<V> paramSupplier)
  {
    Object localObject = this.testInstanceRef.get();
    if (localObject != null) {
      return localObject;
    }
    return paramSupplier.get();
  }
  
  public void setTestInstance(V paramV)
  {
    Assert.assertIsTest();
    Preconditions.checkNotNull(paramV, "null testInstance");
    this.testInstanceRef.set(paramV);
  }
}


/* Location:           C:\Users\Ramon\git\labAssist\app\libs\GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.glass.inject.Provider
 * JD-Core Version:    0.7.0.1
 */