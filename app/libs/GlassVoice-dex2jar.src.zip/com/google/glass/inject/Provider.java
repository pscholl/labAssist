package com.google.glass.inject;

import com.google.glass.predicates.Assert;

public class Provider<V>
{
  private V testInstance;
  private boolean testInstanceSet;
  
  public void clearTestInstance()
  {
    try
    {
      Assert.assertIsTest();
      this.testInstanceSet = false;
      this.testInstance = null;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  /* Error */
  protected V get(com.google.common.base.Supplier<V> paramSupplier)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 22	com/google/glass/inject/Provider:testInstanceSet	Z
    //   6: ifeq +14 -> 20
    //   9: aload_0
    //   10: getfield 24	com/google/glass/inject/Provider:testInstance	Ljava/lang/Object;
    //   13: astore 4
    //   15: aload_0
    //   16: monitorexit
    //   17: aload 4
    //   19: areturn
    //   20: aload_1
    //   21: invokeinterface 31 1 0
    //   26: astore_3
    //   27: aload_3
    //   28: astore 4
    //   30: goto -15 -> 15
    //   33: astore_2
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_2
    //   37: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	38	0	this	Provider
    //   0	38	1	paramSupplier	com.google.common.base.Supplier<V>
    //   33	4	2	localObject1	Object
    //   26	2	3	localObject2	Object
    //   13	16	4	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   2	15	33	finally
    //   20	27	33	finally
  }
  
  protected boolean isTestInstanceSet()
  {
    try
    {
      boolean bool = this.testInstanceSet;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
  
  public void setTestInstance(V paramV)
  {
    try
    {
      Assert.assertIsTest();
      this.testInstanceSet = true;
      this.testInstance = paramV;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}


/* Location:           C:\Users\Ramon\git\ess\labAssist\app\libs\glassvoice_dex2jar.jar
 * Qualified Name:     com.google.glass.inject.Provider
 * JD-Core Version:    0.7.0.1
 */