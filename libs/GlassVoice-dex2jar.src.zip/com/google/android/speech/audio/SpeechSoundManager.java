package com.google.android.speech.audio;

public abstract interface SpeechSoundManager
{
  public abstract int playSpeakNowSound();
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.audio.SpeechSoundManager
 * JD-Core Version:    0.6.2
 */