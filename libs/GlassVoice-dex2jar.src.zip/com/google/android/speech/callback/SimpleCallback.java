package com.google.android.speech.callback;

public abstract interface SimpleCallback<T>
{
  public abstract void onResult(T paramT);
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.callback.SimpleCallback
 * JD-Core Version:    0.6.2
 */