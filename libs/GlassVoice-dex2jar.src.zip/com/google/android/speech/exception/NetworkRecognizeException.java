package com.google.android.speech.exception;

public class NetworkRecognizeException extends RecognizeException
{
  private static final long serialVersionUID = 8244751826901640304L;

  public NetworkRecognizeException(String paramString)
  {
    super(paramString);
  }

  public NetworkRecognizeException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.exception.NetworkRecognizeException
 * JD-Core Version:    0.6.2
 */