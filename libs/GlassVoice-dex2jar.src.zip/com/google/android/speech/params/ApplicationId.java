package com.google.android.speech.params;

public abstract interface ApplicationId
{
  public static final String HANDS_FREE_NAME = "hands-free";
  public static final String INTENT_API = "intent-api";
  public static final String SERVICE_API = "service-api";
  public static final String VOICE_IME = "voice-ime";
  public static final String VOICE_SEARCH = "voice-search";
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.speech.params.ApplicationId
 * JD-Core Version:    0.6.2
 */