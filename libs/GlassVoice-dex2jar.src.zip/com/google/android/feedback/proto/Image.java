package com.google.android.feedback.proto;

public abstract interface Image
{
  public static final int CONTENT = 2;
  public static final int IMAGE_DIMENSION = 3;
  public static final int MIME_TYPE = 1;
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.Image
 * JD-Core Version:    0.6.2
 */