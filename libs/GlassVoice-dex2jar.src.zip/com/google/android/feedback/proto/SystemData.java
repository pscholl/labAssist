package com.google.android.feedback.proto;

public abstract interface SystemData
{
  public static final int EVENT_LOG = 3;
  public static final int INSTALLED_PACKAGES = 4;
  public static final int RUNNING_APPLICATIONS = 5;
  public static final int SYSTEM_LOG = 2;
  public static final int TELEPHONY_DATA = 6;
  public static final int TIMESTAMP = 1;
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.SystemData
 * JD-Core Version:    0.6.2
 */