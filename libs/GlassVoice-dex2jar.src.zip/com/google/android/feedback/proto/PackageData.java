package com.google.android.feedback.proto;

public abstract interface PackageData
{
  public static final int INSTALLER_PACKAGE_NAME = 2;
  public static final int PACKAGE_NAME = 1;
  public static final int PACKAGE_VERSION = 4;
  public static final int PACKAGE_VERSION_NAME = 5;
  public static final int PROCESS_NAME = 3;
  public static final int SYSTEM_APP = 6;
}

/* Location:           /home/phil/workspace/labAssist/libs/GlassVoice-dex2jar.jar
 * Qualified Name:     com.google.android.feedback.proto.PackageData
 * JD-Core Version:    0.6.2
 */